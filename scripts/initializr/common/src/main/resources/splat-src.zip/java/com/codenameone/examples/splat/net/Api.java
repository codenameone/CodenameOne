package com.codenameone.examples.splat.net;

import com.codename1.io.rest.RestClients;
import com.codenameone.examples.splat.api.AccountApi;
import com.codenameone.examples.splat.api.AdminApi;
import com.codenameone.examples.splat.api.GameApi;
import com.codenameone.examples.splat.api.MissionApi;
import com.codenameone.examples.splat.api.ProgressApi;
import com.codenameone.examples.splat.api.ShopApi;
import com.codenameone.examples.splat.api.SocialApi;

/// The generated REST clients, one per contract in the shared module, all
/// pointed at the server [Session] is using.
public final class Api {
    private static AccountApi account;
    private static GameApi game;
    private static ShopApi shop;
    private static AdminApi admin;
    private static ProgressApi progress;
    private static SocialApi social;
    private static MissionApi mission;

    private Api() {
    }

    static void connect(String baseUrl) {
        account = RestClients.create(AccountApi.class, baseUrl);
        game = RestClients.create(GameApi.class, baseUrl);
        shop = RestClients.create(ShopApi.class, baseUrl);
        admin = RestClients.create(AdminApi.class, baseUrl);
        progress = RestClients.create(ProgressApi.class, baseUrl);
        social = RestClients.create(SocialApi.class, baseUrl);
        mission = RestClients.create(MissionApi.class, baseUrl);
    }

    public static AccountApi account() {
        return account;
    }

    public static MissionApi mission() {
        return mission;
    }

    public static GameApi game() {
        return game;
    }

    public static ShopApi shop() {
        return shop;
    }

    public static AdminApi admin() {
        return admin;
    }

    public static ProgressApi progress() {
        return progress;
    }


    public static SocialApi social() {
        return social;
    }
}
