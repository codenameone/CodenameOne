package com.codenameone.examples.splat.play;

import com.codenameone.examples.splat.rules.Catalog;
import com.codenameone.examples.splat.rules.Mode;

/// The playlist: every field with every mode, as the `arena:MODE` references
/// the server takes. The fields ship with the app, so nothing is downloaded.
public final class Arenas {
    public static final String DEFAULT = "lot7:TEAM_PAINT";

    private Arenas() {
    }

    public static String[] all() {
        Mode[] modes = Mode.values();
        String[] out = new String[Catalog.ARENAS.length * modes.length];
        int k = 0;
        for (int a = 0; a < Catalog.ARENAS.length; a++) {
            for (int m = 0; m < modes.length; m++) {
                out[k++] = Catalog.ARENAS[a].id + ":" + modes[m].name();
            }
        }
        return out;
    }

    public static String arenaName(String ref) {
        return Catalog.arena(ref.substring(0, ref.indexOf(':'))).name;
    }

    public static Mode mode(String ref) {
        return Mode.byName(ref.substring(ref.indexOf(':') + 1));
    }
}
