package com.codenameone.examples.splat.ui;

import com.codename1.components.MultiButton;
import com.codename1.ui.Form;
import com.codenameone.examples.splat.api.RaceSummaryDto;
import com.codenameone.examples.splat.net.Api;
import com.codename1.appkit.Net;

/// The player's recent races, each one a replay away.
public final class HistoryForm {
    private HistoryForm() {
    }

    public static void show() {
        final Form f = Ui.form("Replays", "history");
        Ui.desktopColumn(f);
        Ui.back(f, Nav::home);
        Api.game().history(Net.to(list -> Ui.later(() -> {
            if (list.isEmpty()) {
                f.add(Ui.text("No races yet. Your live races appear here, ready to replay.", "Empty"));
            }
            for (final RaceSummaryDto r : list) {
                MultiButton b = new MultiButton(place(r.place()) + " of " + r.runners() + "   " + r.score() + " pts");
                b.setUIID("HistoryRow");
                b.setUIIDLine1(r.place() == 0 ? "HistoryWin" : r.place() * 2 < r.runners() ? "HistoryDraw"
                        : "HistoryLoss");
                b.setTextLine2(r.level() + "   " + (r.trophyChange() > 0 ? "+" : "") + r.trophyChange()
                        + " trophies");
                b.setName("race-" + r.id());
                b.addActionListener(e -> ReplayForm.load(r.id()));
                f.add(b);
            }
            f.revalidate();
        }), Ui::failed));
        f.show();
    }

    /// `place` counted from 0, as a word: 1st, 2nd, 3rd...
    public static String place(int place) {
        int n = place + 1;
        int tens = n % 100;
        if (tens >= 11 && tens <= 13) {
            return n + "th";
        }
        switch (n % 10) {
            case 1:
                return n + "st";
            case 2:
                return n + "nd";
            case 3:
                return n + "rd";
            default:
                return n + "th";
        }
    }
}
