package com.codenameone.examples.splat.engage;

import com.codename1.analytics.invite.Invite;
import com.codename1.analytics.invite.InviteAttribution;
import com.codename1.analytics.invite.InviteListener;
import com.codename1.analytics.invite.InviteRequest;
import com.codename1.analytics.invite.Invites;
import com.codename1.io.Log;
import com.codename1.io.Preferences;
import com.codenameone.examples.splat.api.InviteClaimDto;
import com.codenameone.examples.splat.api.InviteDto;
import com.codenameone.examples.splat.net.Api;
import com.codenameone.examples.splat.net.Net;
import com.codenameone.examples.splat.net.Session;
import com.codenameone.examples.splat.ui.Rewards;
import com.codenameone.examples.splat.ui.Ui;

/// Invite a friend, through Codename One's `com.codename1.analytics.invite`.
///
/// The inviter's side mints a link with [Invites#create] -- the campaign, the
/// channel, and the player's own code from the server in the payload -- and
/// hands it to the native share sheet. The friend's side calls
/// [Invites#checkForInvite] on every start: a link that opened the installed
/// app, or one that went through the store first (the Play install referrer,
/// an iOS App Clip), comes back as an [InviteAttribution]. From then on every
/// analytics event the friend's app sends carries the campaign and the
/// referrer, so the invite funnel, retention and revenue per campaign are in
/// the Codename One console without the game counting anything itself.
///
/// The server's part is the reward: the code is kept until the friend is
/// signed in, then claimed, and the inviter is paid once the friend has
/// played. [Invites#conversion] marks those steps in analytics too.
public final class Friends {
    public static final String CAMPAIGN = "friends";
    private static final String PENDING = "myappname.invite.";

    private Friends() {
    }

    /// From the app's start(): pick up an invite this launch carries.
    public static void start() {
        Invites.setInviteListener(new InviteListener() {
            @Override
            public void inviteReceived(InviteAttribution a) {
                if (a.getPayload() == null || a.getPayload().length() == 0) {
                    // A campaign link from the console: attributed in
                    // analytics, nobody to reward.
                    return;
                }
                Preferences.set(PENDING + "code", a.getPayload());
                Preferences.set(PENDING + "campaign", a.getCampaign() == null ? "" : a.getCampaign());
                Preferences.set(PENDING + "channel", a.getChannel() == null ? "" : a.getChannel());
                Preferences.set(PENDING + "match", a.getMatchType() == null ? "" : a.getMatchType());
                if (Session.user() != null) {
                    Ui.later(Friends::claimPending);
                }
            }

            @Override
            public void attributionUnavailable(String reason) {
                // The ordinary case: most installs were not invited.
            }
        });
        Invites.checkForInvite();
    }

    /// Signed in: credit a waiting invite to this account, once.
    public static void claimPending() {
        final String code = Preferences.get(PENDING + "code", "");
        if (code.length() == 0 || Session.user() == null) {
            return;
        }
        InviteClaimDto claim = new InviteClaimDto(code, Preferences.get(PENDING + "campaign", ""),
                Preferences.get(PENDING + "channel", ""), Preferences.get(PENDING + "match", ""));
        Api.social().claim(claim, Net.to(reward -> {
            clear();
            Telemetry.inviteAccepted();
            Ui.later(() -> Rewards.show(reward, () -> { }));
        }, (status, message) -> {
            // Refused for good (an old account, a second claim, our own code)
            // or the code is unknown: forget it. Anything else is retried on
            // the next sign-in.
            if (status >= 400 && status < 500) {
                clear();
            }
            Log.p("Invite not credited: " + status + " " + message);
        }));
    }

    private static void clear() {
        Preferences.delete(PENDING + "code");
        Preferences.delete(PENDING + "campaign");
        Preferences.delete(PENDING + "channel");
        Preferences.delete(PENDING + "match");
    }

    /// Opens the share sheet with the player's invite link.
    public static void share(InviteDto mine) {
        Invite invite = Invites.create(InviteRequest.create()
                .campaign(CAMPAIGN)
                .channel("share_sheet")
                .payload(mine.code())
                .title("Join me in Splat")
                .description("An endless runner. Race me, same track, live.")
                .build());
        Invites.share(invite, "Race me in Splat! You get " + mine.friendCoins()
                + " coins to start with: " + invite.getUrl());
        Telemetry.inviteSent(CAMPAIGN);
    }

    /// A link for a marketing campaign, made from the admin console: no
    /// player's code in it, so it rewards nobody, and everything the players
    /// it brings in do is reported under `campaign` in analytics.
    public static Invite campaignLink(String campaign) {
        return Invites.create(InviteRequest.create()
                .campaign(campaign)
                .channel("console")
                .title("Splat")
                .description("An endless runner you can race your friends in")
                .build());
    }

    /// Marks a step of an invited player's way in, for the invite funnel:
    /// the first race and the first win, once each. A no-op on an install
    /// no invite brought in.
    public static void raceFinished(boolean won) {
        once("first_race");
        if (won) {
            once("first_win");
        }
    }

    private static void once(String action) {
        String key = PENDING + "conv." + action;
        if (!Preferences.get(key, false)) {
            Preferences.set(key, true);
            Invites.conversion(action);
        }
    }
}
