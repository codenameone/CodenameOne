package com.codenameone.examples.splat.admin;

import com.codename1.components.MultiButton;
import com.codename1.ui.CN;
import com.codename1.ui.Button;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.Tabs;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.util.UITimer;
import com.codenameone.examples.splat.api.AdminActionDto;
import com.codenameone.examples.splat.api.ConditionDto;
import com.codenameone.examples.splat.api.AuditDto;
import com.codenameone.examples.splat.api.FlagDto;
import com.codenameone.examples.splat.api.LiveRaceDto;
import com.codenameone.examples.splat.api.RaceSummaryDto;
import com.codenameone.examples.splat.api.PlayerDetailDto;
import com.codenameone.examples.splat.api.PlayerDto;
import com.codenameone.examples.splat.engage.Telemetry;
import com.codenameone.examples.splat.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.splat.ui.HistoryForm;
import com.codenameone.examples.splat.ui.MatchLobby;
import com.codenameone.examples.splat.ui.Nav;
import com.codenameone.examples.splat.ui.ReplayForm;
import com.codenameone.examples.splat.ui.Ui;
import java.util.List;

/// "God mode": the game as its operator sees it. Every number and list comes
/// from `/api/admin`, which only an account with the admin role may call --
/// the server enforces that, not this screen.
///
/// - **Overview**: what is happening now, and charts of players, races,
///   sales, the funnel, retention and the trophy ladder ([ReportsTab]).
/// - **Flags**: reports from players and the server's own suspicions (a
///   desynced client, impossible play rates), newest first. New ones raise a
///   notification here and, on a phone, a push.
/// - **Players**: search, a player's history, flags and purchases, and the
///   actions -- warn, mute, suspend, ban, reset trophies, revoke items. Each
///   one is written to the audit log with the reason given.
/// - **Live**: every race being run, each one watchable as it happens.
/// - **Audit**: who did what to whom.
/// - **Query**: which players meet a set of conditions ([QueryTab]).
/// - **Pipelines**: when a player meets conditions, push or reward them,
///   every hour, with a cool-down ([PipelinesTab]).
/// - **Promote**: push broadcasts, the home spotlight and campaign links.
///
/// The console is a tool, not part of the game, so it has a look of its own
/// ([Desk]): a desktop application's, in the same app.
public final class AdminConsole {
    private static final int POLL_MILLIS = 15000;
    private static int knownFlags = -1;

    private static final String[] TABS = {"Overview", "Flags", "Players", "Live", "Audit", "Query",
        "Pipelines", "Promote"};
    // Not MATERIAL_DASHBOARD: the Initializr renames every "Splat" in this
    // template to the new app's name, and the constant would be renamed too.
    private static final char[] ICONS = {FontImage.MATERIAL_ANALYTICS, FontImage.MATERIAL_FLAG,
        FontImage.MATERIAL_PEOPLE, FontImage.MATERIAL_SPORTS_ESPORTS, FontImage.MATERIAL_HISTORY,
        FontImage.MATERIAL_SEARCH, FontImage.MATERIAL_ALT_ROUTE,
        FontImage.MATERIAL_CAMPAIGN};

    private final Form form = new Form("Splat console", new BorderLayout());
    private final ReportsTab overview = new ReportsTab();
    private final Container flags = Desk.page();
    private final Container players = Desk.page();
    private final Container live = Desk.page();
    private final Container audit = Desk.page();
    private final QueryTab query = new QueryTab(this);
    private final PipelinesTab pipelines = new PipelinesTab();
    private final PromoteTab promote = new PromoteTab();
    private Tabs tabs;
    /// The desktop side bar's width.
    private static final float SIDE_MM = 42f;

    private AdminConsole() {
    }

    public static void show() {
        new AdminConsole().build();
    }

    private void build() {
        form.setName("admin");
        form.setUIID("DeskForm");
        form.getToolbar().setUIID("DeskToolbar");
        form.getToolbar().getTitleComponent().setUIID("DeskTitle");
        form.setScrollableY(false);
        Telemetry.screen("admin");
        form.getToolbar().addMaterialCommandToRightBar("", FontImage.MATERIAL_SPORTS_ESPORTS,
                e -> Nav.home());
        tabs = new Tabs();
        tabs.setUIID("DeskTabs");
        tabs.setTabUIID("DeskTab");
        tabs.getTabsContainer().setUIID("DeskSide");
        tabs.setName("adminTabs");
        Component[] pages = {overview.page(), flags, playersTab(), live, audit, query.page(),
            pipelines.page(), promote.column()};
        for (int i = 0; i < TABS.length; i++) {
            tabs.addTab(TABS[i], FontImage.createMaterial(ICONS[i], "DeskTab", 3.2f), pages[i]);
            tabs.setTabSelectedIcon(i, FontImage.createMaterial(ICONS[i],
                    UIManager.getInstance().getComponentSelectedStyle("DeskTab"), 3.2f));
        }
        // On a desktop or a tablet the console is a side bar and a page, the
        // way an operator's tools usually are; on a phone, tabs along the top.
        if (wide()) {
            tabs.setTabPlacement(Component.LEFT);
            tabs.setTabTextPosition(Component.RIGHT);
            // Tabs lays a side bar out as a grid, which spreads nine tabs over
            // the full height of a desktop window, and sizes it to its widest
            // label. A side bar is a list from the top, wide enough to read.
            Container side = tabs.getTabsContainer();
            side.setLayout(BoxLayout.y());
            side.setPreferredW(Math.max(side.getPreferredW(), CN.convertToPixels(SIDE_MM)));
        } else {
            // Nine tabs do not fit across a phone: they scroll sideways.
            tabs.getTabsContainer().setScrollableX(true);
            tabs.setTabTextPosition(Component.BOTTOM);
        }
        tabs.addSelectionListener((was, now) -> refresh(now));
        form.add(BorderLayout.CENTER, tabs);
        refresh(0);
        // The queue is watched while the console is open; a phone also gets a
        // push for each new flag, sent by the server's GamePushes.
        UITimer.timer(POLL_MILLIS, true, form, this::pollFlags);
        form.show();
    }

    private void refresh(int tab) {
        if (tab == 0) {
            overview.refresh();
        } else if (tab == 1) {
            Api.admin().flags(true, Net.to(list -> Ui.later(() -> showFlags(list)), Ui::failed));
        } else if (tab == 2) {
            search("");
        } else if (tab == 3) {
            Api.admin().liveRaces(Net.to(list -> Ui.later(() -> showLive(list)), Ui::failed));
        } else if (tab == 4) {
            Api.admin().audit(Net.to(list -> Ui.later(() -> showAudit(list)), Ui::failed));
        } else if (tab == 5) {
            query.refresh();
        } else if (tab == 6) {
            pipelines.refresh();
        } else {
            promote.refresh();
        }
    }

    /// From the query tool: a pipeline that starts with its conditions.
    void newPipeline(List<ConditionDto> conditions) {
        pipelines.editNext(PipelinesTab.blank(conditions));
        if (tabs.getSelectedIndex() == 7) {
            refresh(7);
        } else {
            tabs.setSelectedIndex(7);
        }
    }

    void openPlayer(String username) {
        player(username, null);
    }
    private void pollFlags() {
        Api.admin().stats(Net.to(s -> Ui.later(() -> {
            if (knownFlags >= 0 && s.openFlags() > knownFlags) {
                Ui.toast((s.openFlags() - knownFlags) + " new flag(s) to review");
            }
            knownFlags = s.openFlags();
        }), (st, m) -> { }));
    }

    private void showFlags(List<FlagDto> list) {
        flags.removeAll();
        if (list.isEmpty()) {
            flags.add(Desk.empty("Nothing to review."));
        }
        for (final FlagDto fl : list) {
            MultiButton b = Desk.row(fl.displayName() + " (" + fl.kind() + ")", fl.reason(),
                    fl.reporter() == null || fl.reporter().length() == 0 ? "raised by the server"
                    : "reported by " + fl.reporter());
            b.setUIID(Flag.AUTO.equals(fl.kind()) ? "DeskRowAlert" : "DeskRowWarn");
            b.setName("flag-" + fl.id());
            b.addActionListener(e -> player(fl.username(), fl.id()));
            flags.add(b);
        }
        form.revalidate();
    }

    private Container playersTab() {
        final TextField q = new TextField("", "Search name or email", 20, TextField.ANY);
        q.setUIID("DeskInput");
        q.setName("playerSearch");
        q.addActionListener(e -> search(q.getText().trim()));
        Container c = new Container(new BorderLayout());
        c.setUIID("DeskPage");
        c.add(BorderLayout.NORTH, Desk.field("Search", q)).add(BorderLayout.CENTER, players);
        return c;
    }

    private void search(String query) {
        Api.admin().players(query, Net.to(list -> Ui.later(() -> {
            players.removeAll();
            for (final PlayerDto p : list) {
                MultiButton b = Desk.row(p.displayName(), p.username() + "   " + p.trophies() + " trophies",
                        status(p));
                if (p.flagged()) {
                    b.setUIID("DeskRowWarn");
                }
                b.setName("player-" + p.username());
                b.addActionListener(e -> player(p.username(), null));
                players.add(b);
            }
            form.revalidate();
        }), Ui::failed));
    }

    private static String joined(List<String> names) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < names.size(); i++) {
            sb.append(i == 0 ? "" : ", ").append(names.get(i));
        }
        return sb.toString();
    }

    private void showLive(List<LiveRaceDto> list) {
        live.removeAll();
        if (list.isEmpty()) {
            live.add(Desk.empty("No races being run."));
        }
        for (final LiveRaceDto m : list) {
            MultiButton b = Desk.row(m.level() + ": " + joined(m.names()), "leading: " + m.leader()
                    + "   " + (m.tick() / 60) + "s" + (m.bots() > 0 ? "   (" + m.bots() + " bots)" : ""), null);
            b.setName("live-" + m.id());
            b.addActionListener(e -> MatchLobby.spectate(m.id()));
            live.add(b);
        }
        form.revalidate();
    }

    private void showAudit(List<AuditDto> list) {
        audit.removeAll();
        for (AuditDto a : list) {
            MultiButton b = Desk.row(a.action() + "  " + a.username(), a.reason(), "by " + a.admin());
            audit.add(b);
        }
        form.revalidate();
    }

    /// One player, everything known about them, and what can be done.
    private void player(final String username, final String flagId) {
        Api.admin().player(username, Net.to(d -> Ui.later(() -> showPlayer(d, flagId)), Ui::failed));
    }

    private void showPlayer(final PlayerDetailDto d, final String flagId) {
        final PlayerDto p = d.player();
        Form f = new Form(p.displayName(), new BorderLayout());
        f.setName("adminPlayer");
        f.setUIID("DeskForm");
        f.getToolbar().setUIID("DeskToolbar");
        f.getToolbar().getTitleComponent().setUIID("DeskTitle");
        Ui.back(f, AdminConsole::show);
        Container page = Desk.page();
        f.add(BorderLayout.CENTER, page);
        Container facts = Desk.panel();
        facts.add(Desk.field("Account", new Label(p.username(), "DeskValue")));
        facts.add(Desk.field("Record", new Label(p.trophies() + " trophies, " + p.wins() + " won, " + p.losses()
                + " lost", "DeskValue")));
        facts.add(Desk.field("Wallet", new Label(p.coins() + " coins, " + p.gems() + " gems", "DeskValue")));
        facts.add(Desk.field("Standing", new Label(status(p), p.suspended() ? "DeskValueAlert" : "DeskValue")));
        page.add(facts);
        if (flagId != null) {
            page.add(Desk.actions(Desk.primary("Resolve this flag", "resolveFlag", e -> Api.admin().resolve(flagId,
                    Net.to(done -> Ui.later(() -> {
                        Ui.toast("Resolved");
                        AdminConsole.show();
                    }), Ui::failed)))));
        }
        page.add(Desk.section("Actions"));
        page.add(Desk.actions(
                act(p, Moderation.WARN, "Warn", 0),
                act(p, p.muted() ? Moderation.UNMUTE : Moderation.MUTE, p.muted() ? "Unmute" : "Mute", 0),
                act(p, Moderation.SUSPEND, "Suspend 3 days", 3),
                act(p, Moderation.RESET_TROPHIES, "Reset trophies", 0),
                act(p, Moderation.REVOKE_ITEMS, "Revoke items", 0),
                act(p, p.suspended() ? Moderation.UNBAN : Moderation.BAN, p.suspended() ? "Lift ban" : "Ban", 0)));
        section(page, "Flags", d.flags().size());
        for (FlagDto fl : d.flags()) {
            page.add(new Label(fl.kind() + ": " + fl.reason(), fl.open() ? "DeskValueAlert" : "DeskValue"));
        }
        section(page, "Races", d.races().size());
        for (final RaceSummaryDto m : d.races()) {
            MultiButton b = Desk.row(HistoryForm.place(m.place()) + " of " + m.runners() + " on " + m.level(),
                    m.score() + " points, " + (m.trophyChange() >= 0 ? "+" : "") + m.trophyChange() + " trophies",
                    null);
            b.addActionListener(e -> ReplayForm.load(m.id()));
            page.add(b);
        }
        section(page, "Purchases", d.purchases().size());
        for (String purchase : d.purchases()) {
            page.add(new Label(purchase, "DeskValue"));
        }
        section(page, "Moderation history", d.actions().size());
        for (AuditDto a : d.actions()) {
            page.add(new Label(a.action() + ": " + a.reason(), "DeskValue"));
        }
        f.show();
    }

    private Button act(final PlayerDto p, final String action, final String text, final int days) {
        ActionListener<ActionEvent> go = e -> {
            TextField reason = new TextField("", "Reason (kept in the audit log)", 30, TextField.ANY);
            reason.setName("reason");
            if (Dialog.show(text + " " + p.displayName() + "?", reason, new Command("Cancel"),
                    new Command("Confirm")).getCommandName().equals("Confirm")) {
                Api.admin().act(p.username(), new AdminActionDto(action, reason.getText().trim(), days),
                        Net.to(updated -> Ui.later(() -> {
                            Ui.toast(text + ": done");
                            player(p.username(), null);
                        }), Ui::failed));
            }
        };
        Button b = Moderation.BAN.equals(action) ? Desk.danger(text, "act-" + action, go)
                : Desk.button(text, "act-" + action, go);
        return b;
    }

    private static String status(PlayerDto p) {
        StringBuilder sb = new StringBuilder();
        if (p.suspended()) {
            sb.append("suspended ");
        }
        if (p.muted()) {
            sb.append("muted ");
        }
        if (p.flagged()) {
            sb.append("flagged ");
        }
        if (p.admin()) {
            sb.append("admin ");
        }
        return sb.length() == 0 ? "in good standing" : sb.toString().trim();
    }

    private static void section(Container page, String title, int count) {
        page.add(Desk.section(title + " (" + count + ")"));
    }

    /// Wider than a phone held sideways: a desktop window or a tablet.
    static boolean wide() {
        return CN.isDesktop() || CN.isTablet()
                || CN.getDisplayWidth() > CN.convertToPixels(160);
    }

    /// The action and flag names, as the server spells them.
    static final class Moderation {
        static final String WARN = "WARN";
        static final String MUTE = "MUTE";
        static final String UNMUTE = "UNMUTE";
        static final String SUSPEND = "SUSPEND";
        static final String BAN = "BAN";
        static final String UNBAN = "UNBAN";
        static final String RESET_TROPHIES = "RESET_TROPHIES";
        static final String REVOKE_ITEMS = "REVOKE_ITEMS";

        private Moderation() {
        }
    }

    static final class Flag {
        static final String AUTO = "AUTO";

        private Flag() {
        }
    }
}
