package com.codenameone.examples.splat.ui;

import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codenameone.examples.splat.api.RegisterDto;
import com.codenameone.examples.splat.engage.Telemetry;
import com.codenameone.examples.splat.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.splat.net.Session;

/// Creating an account. The player name is the one piece of text a player
/// types that everyone else sees, so its field is styled as a banner -- the
/// `NameField` UIID in `theme.css` -- and previews the name as it will appear
/// over the arena.
public final class RegisterForm {
    private RegisterForm() {
    }

    public static void show() {
        Form f = Ui.form("New player", "register");
        Ui.desktopColumn(f);
        Ui.back(f, SignInForm::show);
        final TextField name = new TextField("", "Your runner name", 16, TextField.ANY);
        name.setUIID("NameField");
        name.setName("displayName");
        name.setMaxSize(16);
        final TextField email = SignInForm.field("Email", TextField.EMAILADDR, "email");
        final TextField password = SignInForm.field("Password (8+ characters)", TextField.PASSWORD,
                "password");
        Container col = Ui.column();
        col.add(Ui.label("CHOOSE YOUR CALLSIGN", "SectionTitle"));
        col.add(Ui.panel(name));
        col.add(Ui.panel(email, password, Ui.primary("Start running", "createButton", e -> {
            final String mail = email.getText().trim();
            final String pass = password.getText();
            Api.account().register(new RegisterDto(mail, pass, name.getText().trim()),
                    Net.to(player -> {
                        Telemetry.registered();
                        Session.signIn(mail, pass, () -> Ui.later(Nav::signedIn), Ui::failed);
                    }, Ui::failed));
        })));
        f.add(Ui.centeredColumn(col));
        f.show();
    }
}
