package com.codenameone.examples.splat;

import com.codename1.appreview.AppReview;
import com.codename1.payment.PurchaseCallback;
import com.codename1.system.Lifecycle;
import com.codenameone.examples.splat.play.Sfx;
import com.codenameone.examples.splat.engage.Ads;
import com.codenameone.examples.splat.engage.Friends;
import com.codenameone.examples.splat.engage.Notifications;
import com.codenameone.examples.splat.engage.Store;
import com.codenameone.examples.splat.engage.Telemetry;
import com.codenameone.examples.splat.net.Session;
import com.codenameone.examples.splat.ui.Nav;
import com.codenameone.examples.splat.ui.SettingsForm;
import com.codenameone.examples.splat.ui.Ui;

/// The game. It opens on whatever the stored session allows -- home, the
/// admin console, or a challenge link it was opened with -- and on the sign-in
/// screen otherwise.
///
/// Where things are:
///
/// - `rules` (its own module) -- the simulation. The server runs the same
///   classes, so the client never decides a score on its own.
/// - `run` -- the track, drawn with `com.codename1.gaming` in 3D and, where
///   a level says so, as a side-scroller, and the drivers that feed it: solo,
///   live race, replay.
/// - `ui` -- every other screen, built from ordinary widgets that
///   `src/main/css/theme.css` dresses as a game.
/// - `admin` -- the operator's console.
/// - `engage` -- analytics, push, ads and in-app purchases.
/// - `net` -- the session, the REST clients and the game socket.
///
/// The class is the `PurchaseCallback` because that is how Codename One
/// reports a finished store purchase: to the main class.
public class Splat extends Lifecycle implements PurchaseCallback {
    @Override
    public void runApp() {
        SettingsForm.apply();
        Sfx.load();
        Telemetry.start();
        Ads.start();
        // The store's own rating prompt, asked only of a player who has come
        // back: five launches over three days, and never twice in a month.
        // ResultForm asks after a win, the moment a player is happiest.
        AppReview.getInstance().setMinimumLaunches(5).setMinimumDaysInstalled(3)
                .setDaysBetweenPrompts(30).registerSession();
        Session.start(AppConfig.serverUrl());
        Nav.launch();
    }

    @Override
    public void start() {
        super.start();
        Notifications.start();
        Friends.start();
    }

    @Override
    public void stop() {
        super.stop();
        Telemetry.flush();
    }

    @Override
    public void itemPurchased(String sku) {
        Store.purchased(sku);
    }

    @Override
    public void itemPurchaseError(String sku, String errorMessage) {
        Ui.toast("The purchase did not go through: " + errorMessage);
    }

    @Override
    public void itemRefunded(String sku) {
        // The server hears about refunds from the store itself.
    }

    @Override
    public void subscriptionStarted(String sku) {
        Store.purchased(sku);
    }

    @Override
    public void subscriptionCanceled(String sku) {
    }

    @Override
    public void paymentFailed(String paymentCode, String failureReason) {
    }

    @Override
    public void paymentSucceeded(String paymentCode, double amount, String currency) {
    }
}
