package com.codenameone.examples.splat.ui;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codenameone.examples.splat.api.AchievementDto;
import com.codenameone.examples.splat.api.ProgressDto;

/// Every achievement, unlocked or still to go, with how far along each is.
public final class AchievementsForm {
    private AchievementsForm() {
    }

    public static void show() {
        final Form f = Ui.form("Trophy room", "achievements");
        Ui.back(f, Nav::home);
        final Container col = Ui.column();
        f.add(Ui.centeredColumn(col));
        Rewards.refresh(() -> {
            ProgressDto p = Rewards.progress();
            if (p == null) {
                col.add(Ui.label("Could not load your progress.", "Empty"));
            } else {
                int done = 0;
                for (AchievementDto a : p.achievements()) {
                    done += a.unlocked() ? 1 : 0;
                }
                col.add(Ui.label(done + " of " + p.achievements().size() + " unlocked", "LeagueName"));
                for (AchievementDto a : p.achievements()) {
                    col.add(row(a));
                }
            }
            f.revalidate();
        });
        f.show();
    }

    private static Container row(AchievementDto a) {
        Container c = new Container(new BorderLayout());
        c.setUIID(a.unlocked() ? "AchievementRow" : "AchievementLocked");
        c.setName("achievement-" + a.id());
        Label icon = new Label("", "Container");
        icon.setIcon(FontImage.createMaterial(a.unlocked() ? FontImage.MATERIAL_MILITARY_TECH : FontImage.MATERIAL_LOCK,
                a.unlocked() ? "RewardAchievement" : "XpText", 7));
        c.add(BorderLayout.WEST, icon);
        Container text = new Container(BoxLayout.y());
        text.add(new Label(a.title(), "QuestTitle"));
        text.add(new Label(a.detail(), "XpText"));
        Container bar = new Container(new BorderLayout());
        bar.add(BorderLayout.CENTER, Ui.bar(a.progress(), a.goal(), a.unlocked() ? 0xffd34d : 0x7a849e));
        bar.add(BorderLayout.EAST, new Label(" " + a.progress() + "/" + a.goal(), "XpText"));
        text.add(bar);
        c.add(BorderLayout.CENTER, text);
        return c;
    }
}
