package com.codenameone.examples.pulse.trainer;

import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.pulse.api.ShiftDto;
import com.codenameone.examples.pulse.net.Api;
import com.codenameone.examples.pulse.net.Net;
import com.codenameone.examples.pulse.net.Session;
import com.codenameone.examples.pulse.ui.Lang;
import com.codenameone.examples.pulse.ui.Ui;
import java.util.List;

/// The trainer's shifts still to come, and those colleagues offered up. A
/// shift of one's own can be offered for a swap (and the offer withdrawn);
/// someone else's offered shift can be taken.
public final class ShiftsForm {
    /// The shift states the server uses.
    public static final String ASSIGNED = "ASSIGNED";
    public static final String SWAP_REQUESTED = "SWAP_REQUESTED";

    private ShiftsForm() {
    }

    public static void show(final Form previous) {
        final Form form = Ui.form("Shifts", "Shifts");
        Ui.back(form, previous);
        final Container list = Ui.list("shifts");
        final Runnable[] load = new Runnable[1];
        load[0] = () -> Api.trainer().shifts(Net.to(shifts -> fill(form, list, shifts, load[0]),
                Ui.failed(list, load[0])));
        Ui.pull(list, load[0]);
        form.add(BorderLayout.CENTER, list);
        form.show();
        load[0].run();
    }

    private static void fill(Form form, Container list, List<ShiftDto> shifts,
            final Runnable load) {
        list.removeAll();
        String me = Session.user() == null ? "" : Session.user().username();
        Ui.section(list, "Mine");
        int mine = 0;
        for (int iter = 0; shifts != null && iter < shifts.size(); iter++) {
            final ShiftDto shift = shifts.get(iter);
            if (!me.equals(shift.staff())) {
                continue;
            }
            boolean offered = SWAP_REQUESTED.equals(shift.state());
            // The action sits on the row it is about rather than under it.
            Button offer = action(offered ? "Withdraw" : "Offer swap", "offer-" + iter,
                    offered, e -> Api.trainer().offer(shift.id(), Net.to(changed -> {
                        Ui.say(SWAP_REQUESTED.equals(changed.state())
                                ? Lang.tr("Offered to the team") : Lang.tr("Offer withdrawn"));
                        load.run();
                    }, Ui::fail)));
            list.add(Ui.row(FontImage.MATERIAL_SCHEDULE, shift.duty(), span(shift)
                    + (offered ? Ui.DOT + Lang.tr("Offered") : ""), offer));
            mine++;
        }
        if (mine == 0) {
            list.add(Ui.text("No shifts to come.", "SvMuted"));
        }
        Ui.section(list, "Offered by others");
        int open = 0;
        for (int iter = 0; shifts != null && iter < shifts.size(); iter++) {
            final ShiftDto shift = shifts.get(iter);
            if (me.equals(shift.staff()) || !SWAP_REQUESTED.equals(shift.state())) {
                continue;
            }
            list.add(row(shift, action("Take", "take-" + iter, false,
                    e -> Api.trainer().take(shift.id(), Net.to(taken -> {
                        Ui.say(Lang.tr("The shift is yours"));
                        load.run();
                    }, Ui::fail)))));
            open++;
        }
        if (open == 0) {
            list.add(Ui.text("Nothing offered right now.", "SvMuted"));
        }
        Ui.refresh(form);
    }

    /// A shift as a row of a list, with who works it and `value` at its end.
    public static Container row(ShiftDto shift, com.codename1.ui.Component value) {
        return Ui.row(FontImage.MATERIAL_SCHEDULE, shift.duty(), span(shift) + Ui.DOT
                + shift.staffName(), value);
    }

    /// "06:00 - 12:00", for a list already headed by the day.
    public static String hours(ShiftDto shift) {
        String span = span(shift);
        return span.substring(span.indexOf(", ") + 2);
    }

    /// "Nov 2, 06:00 - 12:00", naming the end's day only when it is another.
    static String span(ShiftDto shift) {
        String start = Ui.when(shift.startsAt());
        String end = Ui.when(shift.endsAt());
        String day = start.substring(0, start.lastIndexOf(' '));
        return end.startsWith(day + " ") ? start + " - " + end.substring(day.length() + 1)
                : start + " - " + end;
    }

    private static Button action(String text, String name, boolean quiet,
            ActionListener<ActionEvent> onClick) {
        Button button = new Button(text, quiet ? "SvRowActionQuiet" : "SvRowAction");
        button.setName(name);
        button.addActionListener(onClick);
        return button;
    }
}
