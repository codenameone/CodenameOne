package com.codenameone.examples.pulse.trainer;

import com.codename1.components.Switch;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.pulse.api.AttendanceDto;
import com.codenameone.examples.pulse.api.RosterEntryDto;
import com.codenameone.examples.pulse.api.SessionDto;
import com.codenameone.examples.pulse.member.Classes;
import com.codenameone.examples.pulse.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.pulse.owner.MembersForm;
import com.codenameone.examples.pulse.ui.Lang;
import com.codenameone.examples.pulse.ui.Ui;
import java.util.List;

/// Who is booked into a class, with what the trainer should know before it
/// starts: a first visit, a medical note. A switch per person marks them
/// present, for someone the door did not see.
public final class RosterForm {
    private RosterForm() {
    }

    public static void show(final Form previous, final SessionDto session) {
        final Form form = Ui.form(session.name(), "Roster");
        Ui.back(form, previous);
        final Container list = Ui.list("roster");
        final Runnable[] load = new Runnable[1];
        load[0] = () -> Api.trainer().roster(session.id(), Net.to(
                roster -> fill(form, list, session, roster),
                Ui.failed(list, load[0])));
        Ui.pull(list, load[0]);
        form.add(BorderLayout.CENTER, list);
        form.add(BorderLayout.SOUTH, Ui.dock(Ui.primary("Live view", "live",
                e -> LiveClassForm.show(form, session))));
        form.show();
        load[0].run();
    }

    private static void fill(Form form, Container list, SessionDto session,
            List<RosterEntryDto> roster) {
        list.removeAll();
        list.add(Ui.text(Ui.when(session.startsAt()) + Ui.DOT + session.roomName(), "SvMuted"));
        Ui.section(list, "Booked");
        int queued = 0;
        for (int iter = 0; roster != null && iter < roster.size(); iter++) {
            final RosterEntryDto entry = roster.get(iter);
            if (Classes.WAITLISTED.equals(entry.state())) {
                queued++;
                continue;
            }
            if (Classes.CANCELLED.equals(entry.state())) {
                continue;
            }
            StringBuilder detail = new StringBuilder();
            if (entry.firstVisit()) {
                // A newcomer is who a coach greets first, so it leads the line.
                detail.append(Lang.tr("First visit")).append(Ui.DOT);
            }
            detail.append(Lang.tr("Age {0}", Integer.valueOf(entry.age())));
            if (entry.heartRate() > 0) {
                detail.append(Ui.DOT).append(entry.heartRate()).append(" bpm");
            }
            if (entry.medicalNote() != null && entry.medicalNote().length() > 0) {
                detail.append('\n').append(Lang.tr("Medical: {0}", entry.medicalNote()));
            }
            final Switch present = Ui.toggle("present-" + entry.bookingId(),
                    Classes.CHECKED_IN.equals(entry.state()), on -> mark(session, entry, on));
            Container row = MembersForm.person(entry.name(), detail.toString(), present);
            row.setName("roster-" + iter);
            list.add(row);
        }
        if (queued > 0) {
            list.add(Ui.text(Lang.tr("{0} waiting for a place", Integer.valueOf(queued)),
                    "SvMuted"));
        }
        if (roster == null || roster.isEmpty()) {
            list.add(Ui.text("Nobody booked yet.", "SvMuted"));
        }
        Ui.refresh(form);
    }

    private static void mark(SessionDto session, RosterEntryDto entry,
            final boolean present) {
        Api.trainer().attendance(session.id(), new AttendanceDto(entry.bookingId(), present),
                Net.to(saved -> Ui.say(present ? Lang.tr("Marked present")
                        : Lang.tr("Marked absent")), Ui::fail));
    }
}
