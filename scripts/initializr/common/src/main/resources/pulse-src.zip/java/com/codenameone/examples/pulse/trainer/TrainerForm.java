package com.codenameone.examples.pulse.trainer;

import com.codename1.ui.Button;
import com.codename1.ui.CN;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codenameone.examples.pulse.api.NameCountDto;
import com.codenameone.examples.pulse.api.SessionDto;
import com.codenameone.examples.pulse.api.TrainerStatsDto;
import com.codenameone.examples.pulse.live.LiveChannel;
import com.codenameone.examples.pulse.member.Classes;
import com.codenameone.examples.pulse.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.pulse.owner.OwnerForm;
import com.codenameone.examples.pulse.owner.MembersForm;
import com.codenameone.examples.pulse.ui.Badges;
import com.codenameone.examples.pulse.ui.Beat;
import com.codename1.appkit.Chart;
import com.codenameone.examples.pulse.ui.StatRow;
import com.codenameone.examples.pulse.ui.Lang;
import com.codenameone.examples.pulse.ui.Level;
import com.codenameone.examples.pulse.ui.Menu;
import com.codenameone.examples.pulse.ui.Nav;
import com.codenameone.examples.pulse.ui.Ui;
import com.codenameone.examples.pulse.watch.WatchBridge;
import java.util.List;

/// The trainer's home: the classes they teach this week, each leading to its
/// roster, and from there to the live view of the class.
public class TrainerForm extends LiveChannel.Adapter implements Nav.Home {
    private final Form form = Ui.home("Trainer");
    private final Menu menu = new Menu(form, Nav.TRAINER);
    private final Container list = Ui.list("trainer");
    private List<SessionDto> classes;
    private TrainerStatsDto stats;

    @Override
    public Form form() {
        return form;
    }

    @Override
    public void start() {
        menu.item(FontImage.MATERIAL_EVENT, "My classes", "classes", () -> form.showBack());
        menu.item(FontImage.MATERIAL_FAVORITE, "Live class", "live", this::live);
        menu.item(FontImage.MATERIAL_SCHEDULE, "Shifts", "shifts", () -> ShiftsForm.show(form));
        Container bar = new Container(new BorderLayout());
        bar.setUIID("SvHomeBar");
        bar.add(BorderLayout.WEST, menu.flatButton());
        bar.add(BorderLayout.CENTER, Ui.label("Coaching", "SvTitle"));
        Ui.pull(list, this::load);
        Container shell = new Container(new BorderLayout());
        shell.add(BorderLayout.NORTH, bar);
        shell.add(BorderLayout.CENTER, list);
        form.add(shell);
        menu.install();
        form.addShowListener(e -> {
            LiveChannel.listen(this);
            load();
        });
    }

    private void load() {
        Api.trainer().classes(Net.to(found -> {
            classes = found;
            fill();
        }, Ui.failed(list, this::load)));
        // The month is extra: when it does not come, the classes still do.
        Api.trainer().stats(Net.to(found -> {
            stats = found;
            if (classes != null) {
                fill();
            }
        }, (status, message) -> { }));
    }

    private void fill() {
        list.removeAll();
        long at = System.currentTimeMillis();
        SessionDto featured = current(classes, at);
        if (featured != null) {
            list.add(featured(featured, featured.startsAt() <= at));
        }
        WatchBridge.coach(featured, stats);
        // Above the week rather than under it: below twenty class cards nobody found it.
        if (stats != null) {
            game(stats);
            month(stats);
        }
        // The rest of the week as the members see it, a day at a time, with
        // the room's fill instead of a booking button.
        String day = null;
        for (int iter = 0; classes != null && iter < classes.size(); iter++) {
            final SessionDto session = classes.get(iter);
            if (session == featured || session.endsAt() < at) {
                continue;
            }
            String heading = dayName(session.startsAt(), at);
            if (!heading.equals(day)) {
                day = heading;
                Ui.section(list, heading);
            }
            boolean cancelled = Classes.CANCELLED.equals(session.state());
            Label fill = Ui.badge(cancelled ? Lang.tr("Cancelled")
                    : session.booked() + "/" + session.capacity(),
                    cancelled ? "SvBadgeBad" : "SvBadge");
            list.add(Ui.tap(Classes.card(session, fill, null), "class-" + session.id(),
                    e -> RosterForm.show(form, session)));
        }
        if (classes == null || classes.isEmpty()) {
            list.add(Ui.empty(FontImage.MATERIAL_SPORTS, Lang.tr("No classes this week"),
                    Lang.tr("Classes the studio gives you appear here.")));
        }
        Ui.refresh(form);
    }

    /// The coach's game: their level and streak, their badges, and where they
    /// stand among the studio's coaches. Members play for visits; a coach plays
    /// for full rooms and people who keep coming back.
    private void game(TrainerStatsDto game) {
        Ui.section(list, "Your game");
        int span = Math.max(1, game.nextLevel() - game.levelFloor());
        Level ring = new Level(game.level(), Math.min(1.0,
                (game.points() - game.levelFloor()) / (double) span));
        ring.setName("coachLevel");
        Container about = new Container(BoxLayout.y(), "SvLevelBox");
        about.add(Ui.label(Lang.tr("{0} points", Integer.valueOf(game.points())), "SvHeading"));
        about.add(Ui.label(Lang.tr("{0} more to level {1}",
                Integer.valueOf(game.nextLevel() - game.points()),
                Integer.valueOf(game.level() + 1)), "SvMuted"));
        Container chips = new Container(new FlowLayout());
        if (game.weekStreak() > 0) {
            Label streak = Ui.badge(Lang.tr("{0} week streak",
                    Integer.valueOf(game.weekStreak())), "SvBadgeGood");
            Ui.icon(streak, FontImage.MATERIAL_LOCAL_FIRE_DEPARTMENT, 2.6f);
            streak.getAllStyles().setMarginLeft(0);
            chips.add(streak);
        }
        if (game.rank() > 0) {
            Label rank = Ui.badge(Lang.tr("Rank {0} of {1}", Integer.valueOf(game.rank()),
                    Integer.valueOf(game.leaderboard().size())),
                    game.rank() == 1 ? "SvBadgeWarn" : "SvBadge");
            Ui.icon(rank, FontImage.MATERIAL_EMOJI_EVENTS, 2.6f);
            chips.add(rank);
        }
        about.add(chips);
        Container row = new Container(new BorderLayout());
        row.add(BorderLayout.WEST, ring).add(BorderLayout.CENTER, about);
        list.add(row);
        list.add(Ui.text(Lang.tr("10 points a check-in, 5 a kudos and 25 a full class."),
                "SvMuted"));

        list.add(Ui.label(Lang.tr("Badges  {0}/{1}",
                Integer.valueOf(Badges.coachCount(game.badges())),
                Integer.valueOf(Badges.coachTotal())), "SvChartTitle"));
        list.add(Badges.coachShelf(game.badges()));

        List<NameCountDto> board = game.leaderboard();
        if (board != null && board.size() > 1) {
            list.add(Ui.label("Leaderboard", "SvChartTitle"));
            Container ranks = new Container(BoxLayout.y());
            ranks.setName("leaderboard");
            for (int iter = 0; iter < board.size(); iter++) {
                NameCountDto coach = board.get(iter);
                boolean me = iter + 1 == game.rank();
                Container line = MembersForm.line(coach.name(), Lang.tr("{0} check-ins",
                        Integer.valueOf(coach.count())), me ? Ui.badge(Lang.tr("You"),
                        "SvBadgeGood") : null);
                line.add(BorderLayout.WEST, BorderLayout.centerAbsolute(
                        Ui.label(String.valueOf(iter + 1), iter == 0 ? "SvRankFirst"
                        : "SvRankPlace")).add(BorderLayout.EAST,
                        FlowLayout.encloseCenterMiddle(Ui.avatar(coach.name()))));
                ranks.add(line);
            }
            list.add(ranks);
        }
    }

    /// The trainer's last four weeks: how many they taught and coached, how
    /// full and how faithfully attended their classes were, and what for.
    private void month(TrainerStatsDto month) {
        Ui.section(list, "Your month");
        StatRow tiles = Ui.stats(3);
        tiles.stat(String.valueOf(month.classes()), "Classes", "monthClasses")
                .stat(String.valueOf(month.attendees()), "Check-ins", "monthAttendees")
                .stat(month.fillPercent() + "%", "Places filled", "monthFill")
                .stat(month.showPercent() + "%", "Showed up", "monthShow")
                .stat(String.valueOf(month.regulars()), "Regulars", "monthRegulars")
                .stat(String.valueOf(month.kudos()), "Kudos", "monthKudos");
        list.add(tiles);
        List<Integer> weeks = month.attendeesByWeek();
        double[] values = new double[weeks == null ? 0 : weeks.size()];
        for (int iter = 0; iter < values.length; iter++) {
            Integer value = weeks.get(iter);
            values[iter] = value == null ? 0 : value.intValue();
        }
        list.add(Ui.label("Check-ins a week", "SvChartTitle"));
        list.add(Chart.of("Sv", "trainerAttendance", values, Lang.tr("7 weeks ago"),
                Lang.tr("This week")));
        if (month.topClasses() != null && !month.topClasses().isEmpty()) {
            list.add(Ui.label("Top classes", "SvChartTitle"));
            list.add(OwnerForm.popular(month.topClasses()));
        }
    }

    // The class on now, or the next one: the one thing a coach opens the app
    // for, so it leads on the dark card the member's home uses for theirs.
    private Container featured(final SessionDto session, boolean running) {
        Container card = new Container(BoxLayout.y(), "SvInk");
        card.setName("featured");
        Container head = new Container(new BorderLayout(), "SvInkRow");
        head.add(BorderLayout.CENTER, Ui.label(running ? "ON NOW" : "UP NEXT", "SvInkEyebrow"));
        Beat beat = new Beat("SvBeat", running);
        beat.setPreferredW(CN.convertToPixels(14));
        beat.setPreferredH(CN.convertToPixels(5));
        head.add(BorderLayout.EAST, beat);
        card.add(head);
        card.add(Ui.text(session.name(), "SvInkTitle"));
        card.add(Ui.text(Ui.when(session.startsAt()) + Ui.DOT + session.roomName() + Ui.DOT
                + Lang.tr("{0} of {1} booked", Integer.valueOf(session.booked()),
                        Integer.valueOf(session.capacity())), "SvInkText"));
        Button live = new Button(Lang.tr("Open live view"), "SvInkButton");
        live.setName("openLive");
        live.addActionListener(e -> LiveClassForm.show(form, session));
        Button roster = new Button(Lang.tr("Roster"), "SvInkText");
        roster.getAllStyles().setBgTransparency(0);
        // Named as a class in the list below is, since both open its roster:
        // the class leaves the list while it is the one featured here.
        roster.setName("class-" + session.id());
        roster.addActionListener(e -> RosterForm.show(form, session));
        Container actions = new Container(new BorderLayout(), "SvInkRow");
        actions.add(BorderLayout.WEST, live).add(BorderLayout.EAST, roster);
        card.add(actions);
        return card;
    }

    private static String dayName(long millis, long now) {
        java.util.Calendar a = java.util.Calendar.getInstance();
        a.setTime(new java.util.Date(millis));
        java.util.Calendar b = java.util.Calendar.getInstance();
        b.setTime(new java.util.Date(now));
        int days = (int) ((start(a) - start(b)) / 86400000L);
        if (days == 0) {
            return Lang.tr("Today");
        }
        if (days == 1) {
            return Lang.tr("Tomorrow");
        }
        return new com.codename1.l10n.SimpleDateFormat("EEEE, MMM d").format(
                new java.util.Date(millis));
    }

    private static long start(java.util.Calendar day) {
        day.set(java.util.Calendar.HOUR_OF_DAY, 12);
        day.set(java.util.Calendar.MINUTE, 0);
        day.set(java.util.Calendar.SECOND, 0);
        day.set(java.util.Calendar.MILLISECOND, 0);
        return day.getTime().getTime();
    }

    /// Opens the class that is on now, or the next one.
    private void live() {
        SessionDto now = current(classes, System.currentTimeMillis());
        if (now == null) {
            Ui.say(Lang.tr("No class today"));
            return;
        }
        LiveClassForm.show(form, now);
    }

    /// The class running at `at`, else the next to start; cancelled ones never.
    static SessionDto current(List<SessionDto> classes, long at) {
        SessionDto next = null;
        for (int iter = 0; classes != null && iter < classes.size(); iter++) {
            SessionDto session = classes.get(iter);
            if (Classes.CANCELLED.equals(session.state()) || session.endsAt() < at) {
                continue;
            }
            if (session.startsAt() <= at) {
                return session;
            }
            if (next == null || session.startsAt() < next.startsAt()) {
                next = session;
            }
        }
        return next;
    }

    @Override
    public void sessionChanged(String id, int booked, int waitlisted, String state) {
        load();
    }
}
