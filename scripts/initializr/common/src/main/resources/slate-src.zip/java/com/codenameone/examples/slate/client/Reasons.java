package com.codenameone.examples.slate.client;

import com.codenameone.examples.slate.ui.Lang;

/// Why a day has nothing free, from the slot engine's reason code. The
/// server sends the code rather than the words so that the words can be
/// the app's, in the user's language.
public final class Reasons {
    private Reasons() {
    }

    public static String say(String code) {
        if ("TOO_SOON".equals(code)) {
            return Lang.tr("Bookings need more notice than that.");
        }
        if ("TOO_FAR".equals(code)) {
            return Lang.tr("Bookings are not open that far ahead yet.");
        }
        if ("OUTSIDE_HOURS".equals(code)) {
            return Lang.tr("Nobody is working that day.");
        }
        if ("BOOKED".equals(code) || "TIME_OFF".equals(code) || "CALENDAR".equals(code)) {
            return Lang.tr("Everyone is booked that day.");
        }
        if ("DAY_FULL".equals(code)) {
            return Lang.tr("That day is fully booked.");
        }
        if ("CLIENT_BUSY".equals(code) || "CLIENT_GAP".equals(code)) {
            return Lang.tr("You already have an appointment close to every free time.");
        }
        if ("CLIENT_DAY_FULL".equals(code)) {
            return Lang.tr("You have booked as many appointments that day as the business allows.");
        }
        if ("NO_RESOURCE".equals(code)) {
            return Lang.tr("Every room is in use that day.");
        }
        if ("NOT_ENOUGH_PROVIDERS".equals(code)) {
            return Lang.tr("Not enough people are free together that day.");
        }
        if ("GROUP_FULL".equals(code)) {
            return Lang.tr("Every group that day is full.");
        }
        return Lang.tr("Try another day.");
    }
}
