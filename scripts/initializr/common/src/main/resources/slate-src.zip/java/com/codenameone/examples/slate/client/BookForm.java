package com.codenameone.examples.slate.client;

import com.codename1.io.Preferences;
import com.codename1.l10n.SimpleDateFormat;
import com.codename1.ui.Button;
import com.codename1.ui.CN;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.spinner.Picker;
import com.codenameone.examples.slate.Telemetry;
import com.codenameone.examples.slate.api.AppointmentDto;
import com.codenameone.examples.slate.api.DaySlotsDto;
import com.codenameone.examples.slate.api.FindTimeDto;
import com.codenameone.examples.slate.api.FindTimeRequestDto;
import com.codenameone.examples.slate.api.HoldRequestDto;
import com.codenameone.examples.slate.api.LocationDto;
import com.codenameone.examples.slate.api.ProviderDto;
import com.codenameone.examples.slate.api.RescheduleDto;
import com.codenameone.examples.slate.api.ServiceDto;
import com.codenameone.examples.slate.api.SlotDto;
import com.codenameone.examples.slate.calendar.DeviceCalendar;
import com.codenameone.examples.slate.live.LiveChannel;
import com.codenameone.examples.slate.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.slate.ui.Lang;
import com.codenameone.examples.slate.ui.Layouts;
import com.codenameone.examples.slate.ui.Ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/// Choosing when: a service, who with, and a free start, by the day or the
/// week.
///
/// The day is chosen two ways. A strip of pills has the days around the one
/// shown, a tap each. Beside it a date `Picker` opens the Material calendar
/// for any other day -- the theme asks for it with `pickerStyle: material`,
/// so the same field is the platform's own picker under another theme. The
/// calendar starts today and has no last day: how far ahead a booking may be
/// is the business's rule, the server holds it, and a day past it comes back
/// with no starts and the reason.
///
/// The free starts are the server's answer and nobody else's: the slot
/// engine has every provider's hours, bookings, buffers and connected
/// calendars, and the rules the business set. The phone adds one thing the
/// server cannot know -- the client's own calendar on this phone. With
/// "Check my calendar" on, a start that clashes with something there is
/// marked, though it can still be booked: the client knows whether that
/// dentist appointment can move.
///
/// The same screen moves an existing appointment: given one, a start is a
/// reschedule rather than a new hold.
public final class BookForm extends LiveChannel.Adapter {
    private static final String CHECK_CALENDAR = "myappname.checkCalendar";
    private static final int DAYS_SHOWN = 21;
    private static final String DAY = "day";
    private static final String WEEK = "week";
    /// The width of the summary beside the times on a wide window, in millimetres.
    private static final float SUMMARY_MM = 100f;

    private final Form form;
    private final AppointmentDto moving;
    private final Container choices = new Container(BoxLayout.y());
    private final Container days = new Container(new BorderLayout());
    private Picker dayField;
    private final Container slots = new Container(BoxLayout.y());
    // Below the times, not above them: the times are what the screen is for,
    // and the switch is set once and left alone.
    private final Container myCalendar = new Container(BoxLayout.y());
    private final List<ServiceDto> services = new ArrayList<ServiceDto>();
    private final List<ProviderDto> providers = new ArrayList<ProviderDto>();
    private ServiceDto service;
    private String location = "";
    private String provider = "";
    private String view = DAY;
    private long day = Times.dayStart(System.currentTimeMillis());
    /// The client's own busy time on this phone over the days shown, once read.
    private List<long[]> mine = new ArrayList<long[]>();
    /// The first day of the strip `mine` was read for.
    private long mineFrom;
    /// Counts the reads of the busy time, so that an answer can tell whether
    /// a later read has replaced the one it belongs to.
    private int mineRead;
    /// Beside the times on a wide window: the start picked, held, with its
    /// price and the button that books it. Null on a phone.
    private final Container summary;
    private ConfirmForm open;

    private BookForm(Form previous, ServiceDto service, AppointmentDto moving) {
        this.service = service;
        this.moving = moving;
        form = Ui.form(moving == null ? "Book" : "Move appointment", "Book");
        Ui.back(form, () -> {
            if (open != null) {
                open.letGo();
            }
            previous.showBack();
        });
        Container page = Ui.page();
        choices.setName("choices");
        slots.setName("slots");
        page.add(choices).add(slots).add(myCalendar);
        Layouts.broaden(page);
        if (Layouts.wide() && moving == null) {
            summary = new Container(new BorderLayout()) {
                @Override
                protected Dimension calcPreferredSize() {
                    Dimension size = super.calcPreferredSize();
                    size.setWidth(CN.convertToPixels(SUMMARY_MM));
                    return size;
                }
            };
            summary.setUIID("SvMaster");
            summary.setName("summary");
            summary.add(BorderLayout.CENTER, Ui.empty(FontImage.MATERIAL_EVENT, "Pick a time",
                    "What it costs and how it is paid show here."));
            Container both = new Container(new BorderLayout());
            both.add(BorderLayout.CENTER, page);
            both.add(BorderLayout.EAST, summary);
            form.add(BorderLayout.CENTER, both);
        } else {
            summary = null;
            form.add(BorderLayout.CENTER, page);
        }
        form.addShowListener(e -> LiveChannel.listen(this));
    }

    /// Books `service`, or asks which first when it is null.
    public static void show(Form previous, ServiceDto service) {
        new BookForm(previous, service, null).load();
    }

    /// Picks a new time for `a`, with the same service and provider.
    public static void reschedule(Form previous, AppointmentDto a) {
        BookForm book = new BookForm(previous, null, a);
        book.provider = Appointments.providerRef(a);
        book.day = Times.dayStart(a.start());
        book.load();
    }

    private void load() {
        form.show();
        Api.business().services(Net.to(list -> {
            services.clear();
            services.addAll(list);
            String wanted = moving != null ? moving.serviceId() : service == null ? "" : service.id();
            service = null;
            for (int iter = 0; iter < list.size(); iter++) {
                if (list.get(iter).id().equals(wanted)) {
                    service = list.get(iter);
                }
            }
            if (service == null && !list.isEmpty()) {
                service = list.get(0);
            }
            Api.business().providers(Net.to(people -> {
                providers.clear();
                providers.addAll(people);
                Api.business().locations(Net.to(this::located, Ui::fail));
            }, Ui::fail));
        }, Ui::fail));
    }

    private void located(List<LocationDto> places) {
        location = moving != null ? moving.locationId() : places.isEmpty() ? "" : places.get(0).id();
        buildChoices(places);
        readMine();
    }

    private void buildChoices(final List<LocationDto> places) {
        choices.removeAll();
        if (service == null) {
            choices.add(Ui.empty(FontImage.MATERIAL_EVENT_BUSY, "Nothing to book",
                    "This business has no services on offer yet."));
            Ui.relayout(choices);
            return;
        }
        if (moving == null && services.size() > 1) {
            String[] labels = new String[services.size()];
            String[] values = new String[services.size()];
            for (int iter = 0; iter < services.size(); iter++) {
                labels[iter] = services.get(iter).name();
                values[iter] = services.get(iter).id();
            }
            choices.add(Ui.label(ClientForm.business().serviceNoun(), "SvLabel"));
            choices.add(Ui.pills("service", labels, values, service.id(), id -> {
                for (int iter = 0; iter < services.size(); iter++) {
                    if (services.get(iter).id().equals(id)) {
                        service = services.get(iter);
                    }
                }
                provider = "";
                buildChoices(places);
                loadSlots();
            }));
        }
        choices.add(Ui.text(service.description() == null ? "" : service.description(), "SvText"));
        // What it takes and costs, before a time is picked: every booking app
        // answers this first.
        String terms = Times.length(service.minutes()) + Ui.DOT
                + Ui.money(service.priceCents(), service.currency());
        if (service.depositPercent() > 0) {
            terms += Ui.DOT + Lang.tr("Deposit {0}", Ui.money(service.priceCents()
                    * service.depositPercent() / 100, service.currency()));
        }
        choices.add(Ui.text(terms, "SvCaption"));
        if (places.size() > 1 && moving == null && !service.online()) {
            String[] labels = new String[places.size()];
            String[] values = new String[places.size()];
            for (int iter = 0; iter < places.size(); iter++) {
                labels[iter] = places.get(iter).name();
                values[iter] = places.get(iter).id();
            }
            choices.add(Ui.label("Where", "SvLabel"));
            choices.add(Ui.pills("location", labels, values, location, id -> {
                location = id;
                loadSlots();
            }));
        }
        List<ProviderDto> offering = offering();
        String[] labels = new String[offering.size() + 1];
        String[] values = new String[offering.size() + 1];
        labels[0] = Lang.tr("Anyone");
        values[0] = "";
        for (int iter = 0; iter < offering.size(); iter++) {
            labels[iter + 1] = offering.get(iter).displayName();
            values[iter + 1] = offering.get(iter).username();
        }
        choices.add(Ui.label(ClientForm.business().providerNoun(), "SvLabel"));
        choices.add(Ui.pills("provider", labels, values, provider, who -> {
            provider = who;
            loadSlots();
        }));

        Container when = new Container(new BorderLayout());
        when.add(BorderLayout.CENTER, Ui.choice("view", new String[] {Lang.tr("Day"), Lang.tr("Week")},
                new String[] {DAY, WEEK}, view, chosen -> {
                    view = chosen;
                    loadSlots();
                }));
        choices.add(when);
        myCalendar.removeAll();
        if (DeviceCalendar.canReadBusy()) {
            myCalendar.add(Ui.row(FontImage.MATERIAL_EVENT_NOTE, "Check my calendar",
                    "Marks times that clash with this phone's calendar",
                    Ui.toggle("checkCalendar", Preferences.get(CHECK_CALENDAR, false), on -> {
                        Preferences.set(CHECK_CALENDAR, on);
                        readMine();
                    })));
        }
        days.setName("days");
        fillDays();
        choices.add(days);
        Ui.relayout(choices);
    }

    /// The first day of the strip: today, or as many whole strips later as
    /// it takes to have the chosen day on it.
    private long stripStart() {
        long today = Times.dayStart(System.currentTimeMillis());
        // Noon, so a day an hour short or long still counts as one.
        int ahead = (int) ((Times.dayStart(day) - today + 12 * Times.HOUR) / Times.DAY);
        return Times.addDays(today, Math.max(0, ahead) / DAYS_SHOWN * DAYS_SHOWN);
    }

    /// The calendar and the strip, for the day that is chosen.
    private void fillDays() {
        days.removeAll();
        dayField = dayPicker();
        days.add(BorderLayout.WEST, dayField);
        final Container strip = dayStrip();
        days.add(BorderLayout.CENTER, strip);
        // The chosen day may be the last pill of a strip that scrolls.
        final String chosen = "day-" + Times.iso(day);
        CN.callSerially(() -> {
            for (int iter = 0; iter < strip.getComponentCount(); iter++) {
                Component pill = strip.getComponentAt(iter);
                if (chosen.equals(pill.getName())) {
                    strip.scrollComponentToVisible(pill);
                }
            }
        });
    }

    /// The Material calendar, for a day the strip does not have.
    private Picker dayPicker() {
        final Picker picker = new Picker();
        picker.setType(Display.PICKER_TYPE_DATE);
        // Yesterday cannot be booked whatever the business allows. The other
        // end is the server's to decide, and it says why when it refuses.
        picker.setStartDate(new Date(Times.dayStart(System.currentTimeMillis())));
        picker.setFormatter(new SimpleDateFormat("MMM d"));
        picker.setDate(new Date(day));
        picker.setName("day-picker");
        picker.setUIID("SvDayPicker");
        picker.setMaterialIcon(FontImage.MATERIAL_EVENT, 2.8f);
        // Told when the field is tapped as well as when a date is confirmed:
        // a tap, like a Cancel, leaves the date what it was.
        picker.addActionListener(e -> pick(picker.getDate().getTime(), false));
        return picker;
    }

    /// Shows `millis`'s day. The picker keeps the time of day it was given,
    /// and a day is its midnight in the phone's zone everywhere in this app.
    private void pick(long millis, boolean onStrip) {
        long chosen = Math.max(Times.dayStart(millis), Times.dayStart(System.currentTimeMillis()));
        if (chosen == day) {
            return;
        }
        long shown = stripStart();
        day = chosen;
        if (onStrip && stripStart() == shown) {
            // The pill is already down and the strip is where the finger
            // left it: only the field has to say the new day.
            dayField.setDate(new Date(day));
        } else {
            fillDays();
        }
        Ui.relayout(choices);
        if (stripStart() != mineFrom) {
            readMine();
        } else {
            loadSlots();
        }
    }

    private Container dayStrip() {
        final long first = stripStart();
        long today = Times.dayStart(System.currentTimeMillis());
        String[] labels = new String[DAYS_SHOWN];
        String[] values = new String[DAYS_SHOWN];
        for (int iter = 0; iter < DAYS_SHOWN; iter++) {
            long d = Times.addDays(first, iter);
            labels[iter] = d == today ? Lang.tr("Today")
                    : d == Times.addDays(today, 1) ? Lang.tr("Tomorrow") : Times.shortDay(d);
            values[iter] = Times.iso(d);
        }
        return Ui.pills("day", labels, values, Times.iso(day), iso -> {
            for (int iter = 0; iter < DAYS_SHOWN; iter++) {
                long d = Times.addDays(first, iter);
                if (Times.iso(d).equals(iso)) {
                    pick(d, true);
                }
            }
        });
    }

    private List<ProviderDto> offering() {
        List<ProviderDto> out = new ArrayList<ProviderDto>();
        for (int iter = 0; iter < providers.size(); iter++) {
            ProviderDto p = providers.get(iter);
            if (p.services() != null && p.services().contains(service.id())) {
                out.add(p);
            }
        }
        return out;
    }

    /// The client's own busy time, when they asked for it to be checked.
    private void readMine() {
        final long from = stripStart();
        final int read = ++mineRead;
        mineFrom = from;
        if (!DeviceCalendar.canReadBusy() || !Preferences.get(CHECK_CALENDAR, false)) {
            mine = new ArrayList<long[]>();
            loadSlots();
            return;
        }
        DeviceCalendar.busy(null, from, Times.addDays(from, DAYS_SHOWN + 7), busy -> {
            // An answer that a later read has replaced -- the strip was left,
            // or the check was turned off -- is not the busy time to mark:
            // the later read brings its own.
            if (read != mineRead) {
                return;
            }
            mine = busy;
            loadSlots();
        });
    }

    @Override
    public void slotsChanged(String changedService, String changedDay) {
        if (service == null || changedService.length() > 0 && !changedService.equals(service.id())) {
            return;
        }
        if (changedDay.length() > 0 && DAY.equals(view) && !changedDay.equals(Times.iso(day))) {
            return;
        }
        loadSlots();
    }

    private void loadSlots() {
        if (service == null) {
            return;
        }
        slots.removeAll();
        slots.add(com.codename1.components.Skeleton.rows(3).shimmer(false).uiid("SvSkeleton"));
        Ui.relayout(slots);
        if (WEEK.equals(view)) {
            List<String> who = provider.length() == 0 ? new ArrayList<String>()
                    : Collections.singletonList(provider);
            Api.business().findTime(new FindTimeRequestDto(service.id(), location, Times.iso(day), 7,
                    who), Net.to(this::showWeek, Ui.failed(slots, this::loadSlots)));
        } else {
            Api.business().slots(service.id(), location, Times.iso(day), provider,
                    Net.to(this::showDay, Ui.failed(slots, this::loadSlots)));
        }
    }

    private void showDay(DaySlotsDto answer) {
        slots.removeAll();
        if (answer.slots().isEmpty()) {
            slots.add(Ui.empty(FontImage.MATERIAL_EVENT_BUSY, "Nothing free that day",
                    Reasons.say(answer.emptyReason())));
            if (moving == null) {
                slots.add(Ui.secondary("Tell me if a time frees up", "waitlist-join",
                        e -> WaitlistForm.join(form, service, provider, day)));
            }
            slots.add(Ui.link("Look at the whole week", "to-week", e -> {
                view = WEEK;
                loadSlots();
            }));
        } else {
            slots.add(grid(answer.slots()));
        }
        Ui.relayout(slots);
    }

    private void showWeek(FindTimeDto answer) {
        slots.removeAll();
        if (answer.slots().isEmpty()) {
            slots.add(Ui.empty(FontImage.MATERIAL_EVENT_BUSY, "Nothing free that week",
                    "Try another week, or anyone instead of one person."));
        }
        List<SlotDto> sameDay = new ArrayList<SlotDto>();
        String current = "";
        for (int iter = 0; iter <= answer.slots().size(); iter++) {
            SlotDto s = iter < answer.slots().size() ? answer.slots().get(iter) : null;
            String d = s == null ? "" : Times.iso(s.start());
            if (s == null || !d.equals(current)) {
                if (!sameDay.isEmpty()) {
                    slots.add(Ui.label(Ui.weekday(sameDay.get(0).start()), "SvSection"));
                    slots.add(grid(sameDay));
                    sameDay = new ArrayList<SlotDto>();
                }
                current = d;
            }
            if (s != null) {
                sameDay.add(s);
            }
        }
        Ui.relayout(slots);
    }

    private Container grid(List<SlotDto> list) {
        // As many as fit the room the times really have: beside the summary on
        // a wide window that is less than a column.
        int room = slots.getWidth() > 0 ? Math.min(slots.getWidth(), Layouts.column())
                : Layouts.column();
        int columns = Layouts.columns(room, 18f, 6);
        Container grid = new Container(new GridLayout(Math.max(1, (list.size() + columns - 1) / columns),
                columns));
        grid.setUIID("SvSlotGrid");
        for (int iter = 0; iter < list.size(); iter++) {
            grid.add(slot(list.get(iter)));
        }
        return grid;
    }

    private Button slot(final SlotDto s) {
        boolean clash = DeviceCalendar.clashes(mine, s.start(), s.end());
        Button b = new Button(Times.clock(s.start()), clash ? "SvSlotClash" : "SvSlot");
        b.setName("slot-" + Times.clock(s.start()).replace(':', '-'));
        StringBuilder spoken = new StringBuilder(Times.clock(s.start()));
        if (s.providerNames() != null && !s.providerNames().isEmpty() && provider.length() == 0) {
            spoken.append(", ").append(s.providerNames().get(0));
        }
        if (clash) {
            spoken.append(", ").append(Lang.tr("clashes with your calendar"));
            b.setMaterialIcon(FontImage.MATERIAL_WARNING, 2.6f);
        }
        if (s.seatsLeft() > 1) {
            spoken.append(", ").append(Lang.tr("{0} places left", String.valueOf(s.seatsLeft())));
        }
        b.setAccessibilityText(spoken.toString());
        b.addActionListener(e -> take(s));
        return b;
    }

    private void take(final SlotDto s) {
        List<String> who = provider.length() > 0 ? Collections.singletonList(provider)
                : s.providers();
        if (moving != null) {
            Api.appointments().reschedule(moving.id(), new RescheduleDto(s.start(), who),
                    Net.to(moved -> {
                        Telemetry.rescheduled();
                        Reminders.changed(moved);
                        AppointmentForm.show(form, moved);
                    }, this::refused));
            return;
        }
        Api.appointments().hold(new HoldRequestDto(service.id(), location, s.start(), who),
                Net.to(held -> {
                    if (summary == null) {
                        ConfirmForm.show(form, held, service);
                        return;
                    }
                    if (open != null) {
                        open.letGo();
                    }
                    open = ConfirmForm.beside(form, summary, held, service);
                }, this::refused));
    }

    /// The start went to someone else between the list and the tap, or a
    /// rule turned it down: said, and the list read again.
    private void refused(int status, String message) {
        Ui.fail(status, message);
        loadSlots();
    }
}
