package com.codenameone.examples.slate.owner;

import com.codename1.appkit.Net;
import com.codename1.scheduling.GanttTask;
import com.codename1.scheduling.ProjectModel;
import com.codename1.scheduling.ScheduleResource;
import com.codename1.scheduling.WorkCalendar;
import com.codename1.ui.CN;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.scheduler.Gantt;
import com.codename1.ui.scheduler.GanttAdapter;
import com.codenameone.examples.slate.api.AppointmentDto;
import com.codenameone.examples.slate.api.BusyDto;
import com.codenameone.examples.slate.api.ScheduleDto;
import com.codenameone.examples.slate.api.ShiftDto;
import com.codenameone.examples.slate.client.Times;
import com.codenameone.examples.slate.live.LiveChannel;
import com.codenameone.examples.slate.net.Api;
import com.codenameone.examples.slate.ui.Lang;
import com.codenameone.examples.slate.ui.Ui;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/// The week's staffing plan as a Gantt chart: a row per provider, a bar for
/// each shift they work, and how much of that shift is booked.
///
/// A shift is a task with fixed dates (`setManuallyScheduled`), so the plan
/// is drawn exactly as the hours were set and nothing reschedules it. Its
/// progress is the share of the shift that's booked, and it's assigned to
/// its provider in those units, so the load under the chart reads as each
/// provider's utilisation, hour by hour, against a capacity of one. A shift
/// lost to time off stays in the plan, struck through in the busy style, so
/// the gap it leaves is plain to see.
///
/// The plan is for reading: hours change in the provider's settings, so every
/// drag is refused, and opening a shift opens that day's board.
public final class StaffingForm extends LiveChannel.Adapter {
    private static final long MINUTE = 60000L;

    private final Form form = Ui.form("Staffing", "Staffing");
    private final Container body = new Container(new BorderLayout());
    private final Label title = Ui.label("", "SvHeading");
    private long week = Times.weekStart(System.currentTimeMillis());

    private StaffingForm(Form previous) {
        Ui.back(form, previous);
        Container heading = new Container(new BorderLayout());
        heading.add(BorderLayout.WEST, Ui.flat(FontImage.MATERIAL_CHEVRON_LEFT, "Earlier",
                "earlier", e -> move(-7)));
        heading.add(BorderLayout.CENTER, title);
        heading.add(BorderLayout.EAST, Ui.flat(FontImage.MATERIAL_CHEVRON_RIGHT, "Later",
                "later", e -> move(7)));
        body.setName("staffing");
        form.add(BorderLayout.NORTH, heading);
        form.add(BorderLayout.CENTER, body);
        form.addShowListener(e -> {
            LiveChannel.listen(this);
            load();
        });
    }

    public static void show(Form previous) {
        new StaffingForm(previous).form.show();
    }

    @Override
    public void scheduleChanged(String username) {
        load();
    }

    private void move(int days) {
        week = Times.addDays(week, days);
        load();
    }

    private void load() {
        title.setText(Lang.tr("Week of") + " " + Times.monthDay(week));
        Api.owner().staffing(Times.iso(week), 7, Net.to(this::show, Ui::fail));
    }

    private void show(List<ScheduleDto> staff) {
        body.removeAll();
        if (staff.isEmpty()) {
            body.add(Ui.empty(FontImage.MATERIAL_PEOPLE, "No providers",
                    "Add providers and their hours to plan the week."));
            Ui.relayout(body);
            return;
        }
        Gantt gantt = new Gantt(plan(staff));
        gantt.setName("staffing-gantt");
        gantt.setToolbarVisible(false);
        gantt.setDragEdits(false);
        gantt.setShowLinks(false);
        gantt.setLoadVisible(true);
        gantt.setColumns(Gantt.Column.START, Gantt.Column.PROGRESS);
        gantt.setCurrentTime(System.currentTimeMillis());
        gantt.addGanttListener(new GanttAdapter() {
            @Override
            public boolean taskChanging(Gantt g, GanttTask task, long start, long end) {
                return false;
            }

            @Override
            public void taskOpened(Gantt g, GanttTask task) {
                if (!task.isSummary()) {
                    BoardForm.show(form, Times.dayStart(task.getStart()));
                }
            }
        });
        body.add(BorderLayout.CENTER, gantt);
        Ui.relayout(body);
        // Fitting needs the chart's width, which it has once laid out.
        CN.callSerially(gantt::zoomToFit);
    }

    /// The plan for a week of schedules: what the chart and the load draw.
    static ProjectModel plan(List<ScheduleDto> staff) {
        // No working hours of its own: each shift's dates are the provider's
        // hours as they were set, nights and weekends included.
        WorkCalendar calendar = WorkCalendar.continuous(ZoneId.systemDefault());
        ProjectModel project = new ProjectModel(calendar, staff.get(0).from());
        for (ScheduleDto s : staff) {
            project.addResource(new ScheduleResource(s.username(), s.displayName())
                    .setCapacity(1f));
            GanttTask person = new GanttTask("p-" + s.username(), s.displayName());
            project.addTask(person);
            int n = 0;
            for (ShiftDto shift : s.shifts()) {
                if (shift.end() <= shift.start()) {
                    continue;
                }
                long off = covered(timeOff(shift, s.busy()));
                long open = shift.end() - shift.start() - off;
                GanttTask task = new GanttTask("s-" + s.username() + "-" + n++,
                        Times.shortDay(shift.start()) + " " + Times.clock(shift.start()));
                task.setManuallyScheduled(true);
                task.setDates(shift.start(), shift.end());
                if (open <= 0) {
                    task.setName(Times.shortDay(shift.start()) + " " + Lang.tr("Time off"));
                    task.setUIID("SvTimelineBusy");
                } else {
                    float used = Math.min(1f, booked(shift, s.appointments(), s.busy()) / (float) open);
                    task.setPercentComplete(Math.round(used * 100));
                    if (used > 0) {
                        // An assignment is in units greater than zero; an
                        // empty shift puts no load on anyone.
                        task.assign(s.username(), used);
                    }
                }
                project.addTask(person, task);
            }
        }
        project.update();
        return project;
    }

    // The booked time inside a shift that isn't time off. A booking's buffers
    // count, since the provider can't take anyone else then either; time
    // covered twice (overlapping blocks, a booking inside time off) counts once.
    private static long booked(ShiftDto shift, List<AppointmentDto> appointments,
            List<BusyDto> busy) {
        List<long[]> taken = timeOff(shift, busy);
        long off = covered(taken);
        for (AppointmentDto a : appointments) {
            if (!"CANCELLED".equals(a.state()) && !"EXPIRED".equals(a.state())) {
                clip(taken, shift, a.blockStart() > 0 ? a.blockStart() : a.start(),
                        a.blockEnd() > 0 ? a.blockEnd() : a.end());
            }
        }
        return (covered(taken) - off) / MINUTE * MINUTE;
    }

    private static List<long[]> timeOff(ShiftDto shift, List<BusyDto> busy) {
        List<long[]> out = new ArrayList<>();
        for (BusyDto b : busy) {
            if ("TIME_OFF".equals(b.kind())) {
                clip(out, shift, b.start(), b.end());
            }
        }
        return out;
    }

    private static void clip(List<long[]> out, ShiftDto shift, long from, long to) {
        long f = Math.max(shift.start(), from);
        long t = Math.min(shift.end(), to);
        if (t > f) {
            out.add(new long[] {f, t});
        }
    }

    // The length of the union of the intervals.
    private static long covered(List<long[]> spans) {
        List<long[]> sorted = new ArrayList<>(spans);
        Collections.sort(sorted, (x, y) -> Long.compare(x[0], y[0]));
        long total = 0;
        long end = Long.MIN_VALUE;
        for (long[] s : sorted) {
            if (s[1] > end) {
                total += s[1] - Math.max(s[0], end);
                end = s[1];
            }
        }
        return total;
    }
}
