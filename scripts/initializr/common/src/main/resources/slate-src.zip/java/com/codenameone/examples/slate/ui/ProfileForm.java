package com.codenameone.examples.slate.ui;

import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.slate.api.ProfileDto;
import com.codenameone.examples.slate.api.UserDto;
import com.codenameone.examples.slate.net.Account;
import com.codenameone.examples.slate.net.Session;

/// Who the user is to the business: the name providers and the owner see.
public final class ProfileForm {
    private ProfileForm() {
    }

    /// @param saved where to go once the profile is saved: a screen that shows
    ///     the name is built again there
    public static void show(final Form previous, final Runnable saved) {
        final Form form = Ui.form("Profile", "Profile");
        Ui.back(form, previous);
        UserDto user = Session.user();
        ProfileDto profile = Account.profile();
        Container page = Ui.page();

        Ui.section(page, "About you");
        final TextField name = Ui.field(page, "Name", "name",
                "What your coaches will call you");
        name.setText(profile == null ? user.displayName() : profile.name());

        final SpanLabel error = Ui.text("", "SvError");
        error.setName("error");
        final Button save = Ui.primary("Save", "submit", null);
        save.addActionListener(e -> {
            save.setEnabled(false);
            error.setText("");
            Account.saveProfile(name.getText().trim(), saved, (status, message) -> {
                save.setEnabled(true);
                error.setText(message);
                Ui.refresh(form);
            });
        });
        page.add(error).add(save);

        form.add(BorderLayout.CENTER, page);
        form.show();
    }
}
