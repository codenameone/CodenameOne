package com.codenameone.examples.slate.owner;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.slate.api.AppointmentDto;
import com.codenameone.examples.slate.api.BusyDto;
import com.codenameone.examples.slate.api.ScheduleDto;
import com.codenameone.examples.slate.api.ShiftDto;
import com.codenameone.examples.slate.client.Appointments;
import com.codenameone.examples.slate.client.Times;
import com.codenameone.examples.slate.live.LiveChannel;
import com.codenameone.examples.slate.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.slate.ui.Lang;
import com.codenameone.examples.slate.ui.Timeline;
import com.codenameone.examples.slate.ui.Ui;

import java.util.ArrayList;
import java.util.List;

/// Every provider's day side by side: one column each, wide enough on a
/// tablet or desktop to see who is free at a glance, scrolling sideways on a
/// phone.
public final class BoardForm extends LiveChannel.Adapter {
    private final Form form = Ui.form("Day board", "Board");
    private final Container columns = new Container(new BorderLayout());
    private final Label title = Ui.label("", "SvHeading");
    private long day = Times.dayStart(System.currentTimeMillis());

    private BoardForm(Form previous) {
        Ui.back(form, previous);
        Container heading = new Container(new BorderLayout());
        heading.add(BorderLayout.WEST, Ui.flat(FontImage.MATERIAL_CHEVRON_LEFT, "Earlier",
                "earlier", e -> move(-1)));
        heading.add(BorderLayout.CENTER, title);
        heading.add(BorderLayout.EAST, Ui.flat(FontImage.MATERIAL_CHEVRON_RIGHT, "Later",
                "later", e -> move(1)));
        // A lane per provider at a readable width. The board scrolls inside
        // itself -- more providers than fit sideways, a long day down -- with
        // the names and the hours staying in view, so nothing around it does.
        columns.setName("board");
        form.add(BorderLayout.NORTH, heading);
        form.add(BorderLayout.CENTER, columns);
        form.addShowListener(e -> {
            LiveChannel.listen(this);
            load();
        });
    }

    public static void show(Form previous) {
        new BoardForm(previous).form.show();
    }

    /// The board for `day`, the start of a day, as the staffing plan opens it.
    public static void show(Form previous, long day) {
        BoardForm board = new BoardForm(previous);
        board.day = Times.dayStart(day);
        board.form.show();
    }

    @Override
    public void scheduleChanged(String username) {
        load();
    }

    private void move(int days) {
        day = Times.addDays(day, days);
        load();
    }

    private void load() {
        title.setText(Ui.weekday(day));
        Api.owner().schedule(Times.iso(day), Net.to(this::show, Ui::fail));
    }

    private void show(List<ScheduleDto> board) {
        columns.removeAll();
        if (board.isEmpty()) {
            columns.add(Ui.empty(FontImage.MATERIAL_PEOPLE, "No providers",
                    "Add providers and their hours to fill the board."));
            Ui.relayout(columns);
            return;
        }
        List<Timeline.Lane> lanes = new ArrayList<Timeline.Lane>();
        for (int iter = 0; iter < board.size(); iter++) {
            ScheduleDto s = board.get(iter);
            Timeline.Lane lane = new Timeline.Lane(s.displayName(), day);
            for (int i = 0; i < s.shifts().size(); i++) {
                ShiftDto shift = s.shifts().get(i);
                lane.add(new Timeline.Block(Timeline.SHIFT, shift.start(), shift.end(), "", "", null));
            }
            for (int i = 0; i < s.busy().size(); i++) {
                BusyDto b = s.busy().get(i);
                lane.add(new Timeline.Block(Timeline.BUSY, b.start(), b.end(),
                        Lang.tr("Busy"), "", null));
            }
            for (int i = 0; i < s.appointments().size(); i++) {
                final AppointmentDto a = s.appointments().get(i);
                lane.add(new Timeline.Block(Timeline.kindOf(a.state()), a.start(),
                        a.end(), a.serviceName(), a.clientName() + Ui.DOT + Appointments.state(a),
                        null));
            }
            lanes.add(lane);
        }
        Timeline grid = new Timeline(lanes, true);
        grid.setName("board-grid");
        columns.add(BorderLayout.CENTER, grid);
        columns.add(BorderLayout.NORTH, Timeline.legend());
        Ui.relayout(columns);
    }
}
