package com.codenameone.examples.skirmish.engage;

import com.codename1.analytics.Analytics;
import com.codename1.analytics.AnalyticsConsent;
import com.codename1.analytics.AnalyticsEvent;
import com.codename1.analytics.AnalyticsProvider;
import com.codename1.analytics.CodenameOneAnalyticsProvider;
import com.codename1.analytics.LoggingAnalyticsProvider;
import com.codename1.ui.CN;

/// What the game reports about how it is played, through
/// `com.codename1.analytics`.
///
/// The events are a funnel a game designer reads top to bottom: installed,
/// signed up, first battle, first win, deck edited, first purchase. Battles
/// also report how long they took and which cards were played, which is what
/// balancing a card needs. Nothing is sent until the player says yes on the
/// consent screen, and nothing that names them is sent at all.
///
/// The simulator logs every event to the console instead of sending it; swap
/// in your own provider (Firebase, Amplitude, your own server) with [#use].
public final class Telemetry {
    private static final String ACCOUNT = "account";
    private static final String BATTLE = "battle";
    private static final String ECONOMY = "economy";
    private static boolean started;
    private static String screen;

    private Telemetry() {
    }

    public static void start() {
        if (started) {
            return;
        }
        started = true;
        Analytics.addProvider(CN.isSimulator() ? new LoggingAnalyticsProvider()
                : new CodenameOneAnalyticsProvider());
    }

    /// Replaces the providers; the tests use it to read what was sent.
    public static void use(AnalyticsProvider... providers) {
        started = true;
        Analytics.clearProviders();
        for (AnalyticsProvider p : providers) {
            Analytics.addProvider(p);
        }
        screen = null;
    }

    public static boolean asked() {
        return Analytics.getConsent() != null;
    }

    public static boolean allowed() {
        AnalyticsConsent c = Analytics.getConsent();
        return c != null && c.isAnalytics();
    }

    public static void allow(boolean yes) {
        Analytics.setConsent(AnalyticsConsent.builder()
                .analytics(yes)
                .crashReporting(yes)
                .personalization(false)
                .adStorage(false)
                .build());
    }

    public static void flush() {
        Analytics.flush();
    }

    public static void screen(String name) {
        if (name.equals(screen) || !allowed()) {
            return;
        }
        Analytics.screen(name, screen);
        screen = name;
    }

    public static void registered() {
        send(ACCOUNT, "sign_up", "method", "password");
    }

    public static void signedIn() {
        send(ACCOUNT, "login", "method", "password");
    }

    public static void battleStarted(String mode) {
        send(BATTLE, "battle_start", "mode", mode);
    }

    /// `result` is 1 for a win, 0 for a draw and -1 for a loss.
    public static void battleEnded(String mode, int result, int seconds, int cardsPlayed) {
        send(BATTLE, "battle_end", "mode", mode,
                "result", result > 0 ? "win" : result < 0 ? "loss" : "draw",
                "seconds", Integer.valueOf(seconds), "cards", Integer.valueOf(cardsPlayed));
    }

    public static void cardPlayed(String card) {
        send(BATTLE, "card_played", "card", card);
    }

    public static void deckSaved() {
        send(ECONOMY, "deck_saved");
    }

    public static void itemBought(String item, String currency) {
        send(ECONOMY, "spend_virtual_currency", "item", item, "currency", currency);
    }

    public static void purchase(String sku) {
        send(ECONOMY, "purchase", "sku", sku);
    }

    public static void adWatched(String placement) {
        send(ECONOMY, "ad_reward", "placement", placement);
    }

    public static void challengeShared() {
        send(ACCOUNT, "share", "content", "challenge");
    }

    private static void send(String category, String name, Object... pairs) {
        if (!allowed()) {
            return;
        }
        AnalyticsEvent.Builder event = AnalyticsEvent.create(name).category(category);
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            event.param(String.valueOf(pairs[i]), pairs[i + 1]);
        }
        Analytics.event(event.build());
    }
}
