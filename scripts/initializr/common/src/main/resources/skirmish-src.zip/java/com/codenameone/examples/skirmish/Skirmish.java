package com.codenameone.examples.skirmish;

import com.codename1.payment.PurchaseCallback;
import com.codename1.system.Lifecycle;
import com.codenameone.examples.skirmish.battle.Sfx;
import com.codenameone.examples.skirmish.engage.Ads;
import com.codenameone.examples.skirmish.engage.Notifications;
import com.codenameone.examples.skirmish.engage.Store;
import com.codenameone.examples.skirmish.engage.Telemetry;
import com.codenameone.examples.skirmish.net.Session;
import com.codenameone.examples.skirmish.ui.Nav;
import com.codenameone.examples.skirmish.ui.SettingsForm;
import com.codenameone.examples.skirmish.ui.Ui;

/// The game. It opens on whatever the stored session allows -- home, the
/// admin console, or a challenge link it was opened with -- and on the sign-in
/// screen otherwise.
///
/// Where things are:
///
/// - `rules` (its own module) -- the simulation. The server runs the same
///   classes, so the client never decides a battle on its own.
/// - `battle` -- the arena, drawn with `com.codename1.gaming`, and the
///   drivers that feed it: practice, online, replay.
/// - `ui` -- every other screen, built from ordinary widgets that
///   `src/main/css/theme.css` dresses as a game.
/// - `admin` -- the operator's console.
/// - `engage` -- analytics, push, ads and in-app purchases.
/// - `net` -- the session, the REST clients and the game socket.
///
/// The class is the `PurchaseCallback` because that is how Codename One
/// reports a finished store purchase: to the main class.
public class Skirmish extends Lifecycle implements PurchaseCallback {
    @Override
    public void runApp() {
        SettingsForm.apply();
        Sfx.load();
        Telemetry.start();
        Ads.start();
        boolean tour = AppConfig.tourRequested();
        Session.start(AppConfig.serverUrl());
        Nav.launch();
        if (tour) {
            com.codenameone.examples.skirmish.ui.Tour.start();
        }
    }

    @Override
    public void start() {
        super.start();
        Notifications.start();
    }

    @Override
    public void stop() {
        super.stop();
        Telemetry.flush();
    }

    @Override
    public void itemPurchased(String sku) {
        Store.purchased(sku);
    }

    @Override
    public void itemPurchaseError(String sku, String errorMessage) {
        Ui.toast("The purchase did not go through: " + errorMessage);
    }

    @Override
    public void itemRefunded(String sku) {
        // The server hears about refunds from the store itself.
    }

    @Override
    public void subscriptionStarted(String sku) {
        Store.purchased(sku);
    }

    @Override
    public void subscriptionCanceled(String sku) {
    }

    @Override
    public void paymentFailed(String paymentCode, String failureReason) {
    }

    @Override
    public void paymentSucceeded(String paymentCode, double amount, String currency) {
    }
}
