package com.codenameone.examples.skirmish.ui;

import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codenameone.examples.skirmish.api.RegisterDto;
import com.codenameone.examples.skirmish.engage.Telemetry;
import com.codenameone.examples.skirmish.net.Api;
import com.codenameone.examples.skirmish.net.Net;
import com.codenameone.examples.skirmish.net.Session;

/// Creating an account. The player name is the one piece of text a player
/// types that everyone else sees, so its field is styled as a banner -- the
/// `NameField` UIID in `theme.css` -- and previews the name as it will appear
/// over the arena.
public final class RegisterForm {
    private RegisterForm() {
    }

    public static void show() {
        Form f = Ui.form("New player", "register");
        Ui.back(f, SignInForm::show);
        final TextField name = new TextField("", "Your battle name", 16, TextField.ANY);
        name.setUIID("NameField");
        name.setName("displayName");
        name.setMaxSize(16);
        final Label preview = new Label("???", "NamePreview");
        name.addDataChangedListener((type, index) -> {
            String n = name.getText().trim();
            preview.setText(n.length() == 0 ? "???" : n);
            preview.getParent().revalidate();
        });
        final TextField email = SignInForm.field("Email", TextField.EMAILADDR, "email");
        final TextField password = SignInForm.field("Password (8+ characters)", TextField.PASSWORD,
                "password");
        Container col = Ui.column();
        col.add(SignInForm.heroes());
        col.add(Ui.label("Choose your battle name", "SectionTitle"));
        col.add(Ui.panel(name, Ui.centered(preview)));
        col.add(Ui.panel(email, password, Ui.wood("Enter the arena", "createButton", e -> {
            final String mail = email.getText().trim();
            final String pass = password.getText();
            Api.account().register(new RegisterDto(mail, pass, name.getText().trim()),
                    Net.to(player -> {
                        Telemetry.registered();
                        Session.signIn(mail, pass, () -> Ui.later(Nav::signedIn), Ui::failed);
                    }, Ui::failed));
        })));
        f.add(Ui.centeredColumn(col));
        f.show();
    }
}
