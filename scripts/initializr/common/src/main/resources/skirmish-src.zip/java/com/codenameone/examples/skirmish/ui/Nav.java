package com.codenameone.examples.skirmish.ui;

import com.codename1.ui.CN;
import com.codenameone.examples.skirmish.AppConfig;
import com.codenameone.examples.skirmish.admin.AdminConsole;
import com.codenameone.examples.skirmish.engage.Friends;
import com.codenameone.examples.skirmish.engage.Notifications;
import com.codenameone.examples.skirmish.engage.Store;
import com.codenameone.examples.skirmish.engage.Telemetry;
import com.codenameone.examples.skirmish.forge.ForgeHome;
import com.codenameone.examples.skirmish.forge.PackScreen;
import com.codenameone.examples.skirmish.net.Session;

/// Where the app goes. Every screen change that is not a plain "back" comes
/// through here, so a push notification, a challenge link and a button all
/// land on the same screen the same way.
public final class Nav {
    private static String pendingChallenge;
    private static String pendingPack;

    private Nav() {
    }

    /// The first screen: the stored session decides between home and sign-in.
    public static void launch() {
        pendingChallenge = AppConfig.challengeCode();
        pendingPack = AppConfig.packId();
        Session.onSignedOut(() -> CN.callSerially(SignInForm::show));
        Session.restore(() -> CN.callSerially(Nav::enter),
                () -> CN.callSerially(SignInForm::show),
                () -> CN.callSerially(() -> {
                    SignInForm.show();
                    Ui.toast("The server did not answer. Is it running?");
                }));
    }

    /// Signed in: a challenge or pack link opened the app wins, then the admin
    /// console for an administrator who was last there, then home.
    public static void enter() {
        Notifications.signedIn();
        Store.resend();
        if (pendingChallenge != null) {
            String code = pendingChallenge;
            pendingChallenge = null;
            challenge(code);
            return;
        }
        if (pendingPack != null) {
            String id = pendingPack;
            pendingPack = null;
            PackScreen.show(id);
            return;
        }
        if (Session.user() != null && Session.user().admin()
                && "admin".equals(AppConfig.mode(Session.user().username()))) {
            adminConsole();
            return;
        }
        home();
    }

    public static void signedIn() {
        Telemetry.signedIn();
        Friends.claimPending();
        enter();
    }

    public static void home() {
        AppConfig.setMode("player", Session.user() == null ? "" : Session.user().username());
        HomeForm.show();
    }

    public static void challenge(String code) {
        MatchmakingForm.join(code);
    }

    public static void adminConsole() {
        AppConfig.setMode("admin", Session.user().username());
        AdminConsole.show();
    }

    /// A screen named by a push or the admin's broadcast composer; the names
    /// are the server's `Promotion.SCREENS`.
    public static void screen(String name) {
        if ("shop".equals(name)) {
            shop();
        } else if ("friends".equals(name)) {
            FriendsForm.show();
        } else if ("forge".equals(name)) {
            ForgeHome.show();
        } else if ("deck".equals(name)) {
            DeckForm.show();
        } else if ("battle".equals(name)) {
            MatchmakingForm.queue();
        } else {
            home();
        }
    }

    public static void shop() {
        ShopForm.show();
    }

    public static void signOut() {
        Notifications.signingOut(() -> Session.signOut(() -> CN.callSerially(SignInForm::show)));
    }
}
