package com.codenameone.examples.skirmish.net;

import com.codename1.io.rest.RestClients;
import com.codenameone.examples.skirmish.api.AccountApi;
import com.codenameone.examples.skirmish.api.AdminApi;
import com.codenameone.examples.skirmish.api.GameApi;
import com.codenameone.examples.skirmish.api.ProgressApi;
import com.codenameone.examples.skirmish.api.ShopApi;

/// The generated REST clients, one per contract in the shared module, all
/// pointed at the server [Session] is using.
public final class Api {
    private static AccountApi account;
    private static GameApi game;
    private static ShopApi shop;
    private static AdminApi admin;
    private static ProgressApi progress;

    private Api() {
    }

    static void connect(String baseUrl) {
        account = RestClients.create(AccountApi.class, baseUrl);
        game = RestClients.create(GameApi.class, baseUrl);
        shop = RestClients.create(ShopApi.class, baseUrl);
        admin = RestClients.create(AdminApi.class, baseUrl);
        progress = RestClients.create(ProgressApi.class, baseUrl);
    }

    public static AccountApi account() {
        return account;
    }

    public static GameApi game() {
        return game;
    }

    public static ShopApi shop() {
        return shop;
    }

    public static AdminApi admin() {
        return admin;
    }

    public static ProgressApi progress() {
        return progress;
    }
}
