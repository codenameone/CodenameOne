package com.codenameone.examples.skirmish.forge;

import com.codename1.components.MultiButton;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.GridLayout;
import com.codenameone.examples.skirmish.api.PackSummaryDto;
import com.codenameone.examples.skirmish.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.skirmish.ui.Nav;
import com.codenameone.examples.skirmish.ui.Ui;

/// The Forge's front door: the game's own campaigns, what other players
/// made, and the player's own packs, with a button to start a new one.
public final class ForgeHome {
    private static final String[] SCOPES = {"official", "popular", "new", "mine"};
    private static final String[] TITLES = {"Official", "Popular", "New", "Yours"};

    private ForgeHome() {
    }

    public static void show() {
        show("official");
    }

    static void show(final String scope) {
        final Form f = Ui.form("Forge", "forge");
        Ui.back(f, Nav::home);
        Container tabs = new Container(new GridLayout(1, SCOPES.length));
        for (int i = 0; i < SCOPES.length; i++) {
            final String s = SCOPES[i];
            Button b = Ui.button(TITLES[i], s.equals(scope) ? "ForgeTabOn" : "ForgeTab", "forge-" + s,
                    e -> show(s));
            tabs.add(b);
        }
        f.add(tabs);
        f.add(Ui.wood("Create a pack", "forgeCreate", e -> PackEditor.create()));
        Api.forge().packs(scope, Net.to(list -> Ui.later(() -> {
            if (list.isEmpty()) {
                f.add(Ui.text("mine".equals(scope)
                        ? "Nothing yet. A pack holds your own cards, arenas and missions; create one and "
                        + "share it with friends."
                        : "No packs here yet.", "Empty"));
            }
            for (final PackSummaryDto p : list) {
                f.add(row(p, "mine".equals(scope)));
            }
            f.revalidate();
        }), Ui::failed));
        f.show();
    }

    private static MultiButton row(final PackSummaryDto p, boolean mine) {
        MultiButton b = new MultiButton(p.name().length() == 0 ? p.id() : p.name());
        b.setUIID("HistoryRow");
        b.setUIIDLine1(p.official() ? "ForgeOfficial" : "HistoryDraw");
        StringBuilder line = new StringBuilder("by ").append(p.author()).append("  ")
                .append(p.missions()).append(p.missions() == 1 ? " mission" : " missions");
        if (p.ratings() > 0) {
            line.append("  ").append(p.rating() / 10).append('.').append(p.rating() % 10).append(" stars");
        }
        b.setTextLine2(line.toString());
        if (mine) {
            b.setTextLine3(p.version() == 0 ? "Draft, not published" : "Version " + p.version() + ", "
                    + p.status() + (p.pendingAssets() ? ", files waiting for review" : ""));
        }
        b.setName("pack-" + p.id());
        b.addActionListener(e -> {
            if (mine && p.version() == 0) {
                PackEditor.open(p.id());
            } else {
                PackScreen.show(p.id());
            }
        });
        return b;
    }
}
