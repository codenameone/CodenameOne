package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.SavedAddress;

import java.util.List;

/// The places customers keep to be delivered to.
@Repository(entity = SavedAddress.class, key = String.class)
public interface SavedAddressRepository extends CrudRepository<SavedAddress, String> {
    List<SavedAddress> findByUsernameOrderByCreatedAtAsc(String username);

    long countByUsername(String username);

    int deleteByUsername(String username);
}
