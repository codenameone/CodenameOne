package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.MenuSection;

import java.util.List;

/// The headings of every menu.
@Repository(entity = MenuSection.class, key = String.class)
public interface MenuSectionRepository extends CrudRepository<MenuSection, String> {
    List<MenuSection> findByRestaurantIdOrderByPositionAsc(String restaurantId);

    long countByRestaurantId(String restaurantId);
}
