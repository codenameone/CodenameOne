package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.DishOption;

import java.util.List;

/// The extras of every dish.
@Repository(entity = DishOption.class, key = String.class)
public interface DishOptionRepository extends CrudRepository<DishOption, String> {
    List<DishOption> findByDishIdOrderByPositionAsc(String dishId);

    List<DishOption> findByDishIdIn(List<String> dishIds);

    int deleteByDishId(String dishId);
}
