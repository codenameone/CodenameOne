package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codename1.orm.session.Identifier;
import com.codenameone.examples.savor.domain.CourierHours;

/// The time each courier spent on line, a row for each day, keyed by
/// `Identifier.of(username, dayNumber)`.
@Repository(entity = CourierHours.class, key = Identifier.class)
public interface CourierHoursRepository extends CrudRepository<CourierHours, Identifier> {
    /// Adds time on line to a day that already has a row. The addition is the
    /// database's, so reports that overlap are both counted.
    ///
    /// @return 1, or 0 when the day has no row yet
    @Modifying
    @Query("update CourierHours h set h.millis = h.millis + :millis "
            + "where h.username = :username and h.dayNumber = :day")
    int addMillis(@Param("username") String username, @Param("day") long dayNumber,
            @Param("millis") long millis);

    int deleteByUsername(String username);
}
