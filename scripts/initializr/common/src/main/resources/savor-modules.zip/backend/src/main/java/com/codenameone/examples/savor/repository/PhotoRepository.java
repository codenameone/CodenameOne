package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Photo;

/// The pictures of restaurants and dishes.
@Repository(entity = Photo.class, key = String.class)
public interface PhotoRepository extends CrudRepository<Photo, String> {
    long countByRestaurantId(String restaurantId);
}
