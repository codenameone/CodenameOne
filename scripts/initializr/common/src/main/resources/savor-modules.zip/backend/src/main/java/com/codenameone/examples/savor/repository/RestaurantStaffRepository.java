package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codename1.orm.session.Identifier;
import com.codenameone.examples.savor.domain.RestaurantStaff;

import java.util.List;

/// Who works for which restaurant, keyed by `Identifier.of(restaurantId, username)`.
@Repository(entity = RestaurantStaff.class, key = Identifier.class)
public interface RestaurantStaffRepository extends CrudRepository<RestaurantStaff, Identifier> {
    List<RestaurantStaff> findByUsername(String username);

    List<RestaurantStaff> findByRestaurantId(String restaurantId);

    int deleteByUsername(String username);
}
