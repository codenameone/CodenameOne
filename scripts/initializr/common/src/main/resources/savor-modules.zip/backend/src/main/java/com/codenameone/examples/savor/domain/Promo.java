package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A code a customer types at checkout: a percentage or an amount off the food,
/// for an order of at least `minimumCents`, once per account.
@Entity
public class Promo {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String code = "";

    @Column(nullable = false)
    private int percentOff;

    @Column(nullable = false)
    private long amountOffCents;

    @Column(nullable = false)
    private long minimumCents;

    @Column(nullable = false)
    private boolean active;

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public Promo() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getPercentOff() {
        return percentOff;
    }

    public void setPercentOff(int percentOff) {
        this.percentOff = percentOff;
    }

    public long getAmountOffCents() {
        return amountOffCents;
    }

    public void setAmountOffCents(long amountOffCents) {
        this.amountOffCents = amountOffCents;
    }

    public long getMinimumCents() {
        return minimumCents;
    }

    public void setMinimumCents(long minimumCents) {
        this.minimumCents = minimumCents;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
