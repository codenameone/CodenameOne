package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codename1.orm.session.Identifier;
import com.codenameone.examples.savor.domain.DeliveryPassed;

import java.util.List;

/// The couriers who passed on a delivery or let its offer lapse, keyed by
/// `Identifier.of(deliveryId, courier)`.
@Repository(entity = DeliveryPassed.class, key = Identifier.class)
public interface DeliveryPassedRepository extends CrudRepository<DeliveryPassed, Identifier> {
    List<DeliveryPassed> findByDeliveryId(String deliveryId);

    long countByCourier(String courier);

    /// How many offers each courier has passed on or let lapse, as `{courier,
    /// count}`.
    @Query("select p.courier, count(p.deliveryId) from DeliveryPassed p group by p.courier")
    List<Object[]> countByCourier();
}
