package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.OrderEvent;

import java.util.List;

/// What happened to each order: one row for every state it came into.
@Repository(entity = OrderEvent.class, key = String.class)
public interface OrderEventRepository extends CrudRepository<OrderEvent, String> {
    List<OrderEvent> findByOrderIdOrderByCreatedAtAsc(String orderId);
}
