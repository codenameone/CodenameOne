package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Payout;

import java.util.List;

/// The payouts made to couriers.
@Repository(entity = Payout.class, key = String.class)
public interface PayoutRepository extends CrudRepository<Payout, String> {
    /// The last hundred payouts made to a courier, newest first.
    List<Payout> findTop100ByCourierOrderByCreatedAtDescIdAsc(String courier);

    /// Everything ever paid out to a courier. A sum over no rows is nothing at
    /// all to a database, hence the zero to fall back on.
    @Query("select coalesce(sum(p.amountCents), 0) from Payout p where p.courier = :courier")
    Long paidOut(@Param("courier") String courier);
}
