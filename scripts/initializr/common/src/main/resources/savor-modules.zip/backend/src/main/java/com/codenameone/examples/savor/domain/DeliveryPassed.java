package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A courier who passed on a delivery, or let its offer lapse, and is not asked again.
@Entity
public class DeliveryPassed {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String deliveryId = "";

    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String courier = "";

    public DeliveryPassed() {
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getCourier() {
        return courier;
    }

    public void setCourier(String courier) {
        this.courier = courier;
    }
}
