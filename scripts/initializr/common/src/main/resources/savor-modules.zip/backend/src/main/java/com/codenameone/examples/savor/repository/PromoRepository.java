package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Promo;

import java.util.List;

/// The promotion codes, by code.
@Repository(entity = Promo.class, key = String.class)
public interface PromoRepository extends CrudRepository<Promo, String> {
    @Query("select p from Promo p order by p.createdAt desc")
    List<Promo> newest(PageRequest page);
}
