package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.PayoutAccount;

/// Where each courier is paid, keyed by the courier.
@Repository(entity = PayoutAccount.class, key = String.class)
public interface PayoutAccountRepository extends CrudRepository<PayoutAccount, String> {
    /// Makes the rest of the transaction wait its turn behind any other that
    /// holds the same courier's payout account.
    ///
    /// @return 1, or 0 for a courier who has not said where to be paid
    @Modifying
    @Query("update PayoutAccount a set a.last4 = a.last4 where a.username = :courier")
    int hold(@Param("courier") String courier);

    int deleteByUsername(String username);
}
