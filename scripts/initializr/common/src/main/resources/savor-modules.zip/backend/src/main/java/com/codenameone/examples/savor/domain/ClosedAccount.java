package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// What is left of an account that was closed: the hash of its e-mail, kept so
/// that the address cannot be registered again.
@Entity
public class ClosedAccount {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String usernameHash = "";

    @Column(nullable = false)
    private long closedAt;

    public ClosedAccount() {
    }

    public String getUsernameHash() {
        return usernameHash;
    }

    public void setUsernameHash(String usernameHash) {
        this.usernameHash = usernameHash;
    }

    public long getClosedAt() {
        return closedAt;
    }

    public void setClosedAt(long closedAt) {
        this.closedAt = closedAt;
    }
}
