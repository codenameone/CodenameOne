package com.codenameone.examples.savor;

import com.codenameone.examples.savor.api.DeliveryState;
import com.codenameone.examples.savor.api.OrderState;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/// Reading the rows a repository answers for a select of several values,
/// `select r.courier, count(r) ...`, which come back as `Object[]`.
///
/// What a column holds is checked and never cast blindly: a count is a `Long`
/// on one database and an `Integer` on another, and a state is the enum or
/// its name depending on how the column was read.
public final class Rows {
    private Rows() {
    }

    /// A column as a whole number; 0 for null or anything that is not a
    /// number.
    public static long number(Object value) {
        return value instanceof Number ? ((Number) value).longValue() : 0L;
    }

    /// A column holding a point in time as milliseconds since the epoch: the
    /// `Instant` an entity's time field is read as, or 0 for null or anything
    /// else.
    public static long millis(Object value) {
        return value instanceof Instant ? ((Instant) value).toEpochMilli() : 0L;
    }

    /// A column as text; empty for null.
    public static String text(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    /// A column holding a delivery's state, or null for one that names none.
    /// An order's state as a query answers it: the enum, or its name.
    public static OrderState orderState(Object value) {
        if (value instanceof OrderState) {
            return (OrderState) value;
        }
        String name = text(value);
        OrderState[] all = OrderState.values();
        for (int iter = 0; iter < all.length; iter++) {
            if (all[iter].name().equals(name)) {
                return all[iter];
            }
        }
        return null;
    }

    public static DeliveryState state(Object value) {
        if (value instanceof DeliveryState) {
            return (DeliveryState) value;
        }
        String name = text(value);
        DeliveryState[] all = DeliveryState.values();
        for (int iter = 0; iter < all.length; iter++) {
            if (all[iter].name().equals(name)) {
                return all[iter];
            }
        }
        return null;
    }

    /// Rows of `{name, count}` as a map from the name to the count.
    public static Map<String, Long> counts(List<Object[]> rows) {
        Map<String, Long> out = new HashMap<String, Long>();
        for (int iter = 0; iter < rows.size(); iter++) {
            Object[] row = rows.get(iter);
            out.put(text(row[0]), Long.valueOf(number(row[1])));
        }
        return out;
    }

    /// A single number a repository answers, which is null for a sum or a
    /// maximum of no rows.
    public static long number(Long value) {
        return value == null ? 0L : value.longValue();
    }
}
