package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Payment;

import java.time.Instant;
import java.util.List;

/// What each delivery was charged, keyed by the delivery.
@Repository(entity = Payment.class, key = String.class)
public interface PaymentRepository extends CrudRepository<Payment, String> {
    /// The payments of several deliveries, in no order.
    List<Payment> findByDeliveryIdIn(List<String> deliveryIds);

    /// Payments whose refund the processor took and has not finished, the
    /// oldest first.
    List<Payment> findByStatusOrderByCreatedAtAsc(String status, PageRequest page);

    /// Records how a pending refund ended.
    ///
    /// @return 1 for the one caller that recorded it
    @Modifying
    @Query("update Payment p set p.status = :status, p.refundedAt = :at "
            + "where p.deliveryId = :id and p.status = 'REFUND_PENDING'")
    int endRefund(@Param("id") String deliveryId, @Param("status") String status,
            @Param("at") Instant at);
}
