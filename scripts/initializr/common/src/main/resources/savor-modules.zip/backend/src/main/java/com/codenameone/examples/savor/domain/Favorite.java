package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A restaurant a customer keeps, keyed by `Identifier.of(username, restaurantId)`.
@Entity
public class Favorite {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String restaurantId = "";

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public Favorite() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(String restaurantId) {
        this.restaurantId = restaurantId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
