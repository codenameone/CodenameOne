package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codename1.orm.session.Identifier;
import com.codenameone.examples.savor.domain.PromoUse;

/// The codes each account has used, keyed by `Identifier.of(code, username)`.
@Repository(entity = PromoUse.class, key = Identifier.class)
public interface PromoUseRepository extends CrudRepository<PromoUse, Identifier> {
    int deleteByUsername(String username);

    int deleteByOrderId(String orderId);
}
