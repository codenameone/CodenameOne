package com.codenameone.examples.savor.delivery;

import com.codename1.backend.DataSource;
import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codename1.backend.test.MockMvc;
import com.codenameone.examples.savor.People;
import com.codenameone.examples.savor.Trips;
import com.codenameone.examples.savor.account.Accounts;
import com.codenameone.examples.savor.account.DemoAccounts;
import com.codenameone.examples.savor.api.CourierStatusDto;
import com.codenameone.examples.savor.api.DeliveryDto;
import com.codenameone.examples.savor.api.DeliveryState;
import com.codenameone.examples.savor.courier.Couriers;
import com.codenameone.examples.savor.order.Orders;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/// An offer made to a courier who stopped being fit for the delivery after the
/// search chose them.
///
/// Choosing and offering are two transactions, and a courier can go off line,
/// ride away, lose their approval or be blocked in between. Each of those is
/// set up here and the offer made to them anyway, which is the second
/// transaction running after the first read them as they were. It sits in
/// this package because the offer is not part of the service's public face.
@BackendTest
class OfferRecheckTest {
    // Bologna.
    private static final double LAT = 44.4949;
    private static final double LNG = 11.3426;

    @Autowired
    private MockMvc mvc;
    @Autowired
    private Accounts accounts;
    @Autowired
    private Orders orders;
    @Autowired
    private Deliveries deliveries;
    @Autowired
    private Couriers couriers;
    @Autowired
    private DataSource db;

    private void at(String courier, boolean online, double lat, double lng) throws Exception {
        couriers.report(courier, new CourierStatusDto(online, lat, lng, 90d));
    }

    private void notOffered(String id, String courier, String why) throws Exception {
        assertNull(deliveries.offer(id, courier), why);
        assertEquals(DeliveryState.REQUESTED, deliveries.forOrder(id, "", false).state(), why);
    }

    @Test
    void aCourierNoLongerFitForTheDeliveryIsNotOfferedIt() throws Exception {
        String customer = People.customer(accounts, "blq-customer");
        String courier = People.courier(accounts, "blq-courier");
        // Cooked with nobody on line, so it waits. The courier is kept unfit
        // from here until the end, so the scheduled search, which runs
        // alongside, has nobody to offer it to either.
        String id = Trips.ask(mvc, customer, Trips.trip(LAT, LNG, LAT + 0.02, LNG + 0.02));
        assertEquals(DeliveryState.REQUESTED, deliveries.forOrder(id, "", false).state());

        // On line, a hundred kilometres away.
        at(courier, true, LAT + 1d, LNG);
        notOffered(id, courier, "a courier out of reach");

        // In reach, and blocked.
        accounts.suspend(DemoAccounts.ADMIN, courier, true, "a test");
        at(courier, true, LAT, LNG);
        notOffered(id, courier, "a blocked courier");

        // No longer approved.
        db.execute("UPDATE courier_application SET status = 'rejected' WHERE username = ?",
                new Object[] {courier});
        accounts.suspend(DemoAccounts.ADMIN, courier, false, "a test");
        notOffered(id, courier, "a courier whose approval was withdrawn");

        // Not heard from in a long while, whatever their status says.
        db.execute("UPDATE courier_state SET last_seen = 1 WHERE username = ?",
                new Object[] {courier});
        db.execute("UPDATE courier_application SET status = 'approved' WHERE username = ?",
                new Object[] {courier});
        notOffered(id, courier, "a courier not heard from");

        // Off line.
        at(courier, false, 0d, 0d);
        notOffered(id, courier, "a courier off line");

        // And once fit again, the delivery is theirs: offered here, or by the
        // scheduled search if it got there first.
        at(courier, true, LAT, LNG);
        deliveries.offer(id, courier);
        DeliveryDto now = deliveries.forOrder(id, courier, true);
        assertEquals(DeliveryState.OFFERED, now.state());
        assertEquals(courier, now.courierUsername());
        orders.cancelByAdmin(DemoAccounts.ADMIN, id, "the test is over");
        at(courier, false, 0d, 0d);
    }
}
