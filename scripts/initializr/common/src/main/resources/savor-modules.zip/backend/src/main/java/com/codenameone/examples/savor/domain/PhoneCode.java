package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// The verification code an account was last sent, as its hash.
@Entity
public class PhoneCode {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String codeHash = "";

    @Column(nullable = false)
    private Instant expiresAt = Instant.EPOCH;

    @Column(nullable = false)
    private int attempts;

    @Column(nullable = false)
    private Instant sentAt = Instant.EPOCH;

    /// The code sent before this one, while it is still good, or empty.
    @Column(nullable = false, type = "VARCHAR(64)")
    private String previousHash = "";

    @Column(nullable = false)
    private Instant previousExpiresAt = Instant.EPOCH;

    /// The guesses already taken at the code before, which keeps the budget
    /// it had rather than starting a new one when another code is sent.
    @Column(nullable = false)
    private int previousAttempts;

    public PhoneCode() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCodeHash() {
        return codeHash;
    }

    public void setCodeHash(String codeHash) {
        this.codeHash = codeHash;
    }

    public Instant getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Instant expiresAt) {
        this.expiresAt = expiresAt;
    }

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    public Instant getPreviousExpiresAt() {
        return previousExpiresAt;
    }

    public void setPreviousExpiresAt(Instant previousExpiresAt) {
        this.previousExpiresAt = previousExpiresAt;
    }

    public int getPreviousAttempts() {
        return previousAttempts;
    }

    public void setPreviousAttempts(int previousAttempts) {
        this.previousAttempts = previousAttempts;
    }
}
