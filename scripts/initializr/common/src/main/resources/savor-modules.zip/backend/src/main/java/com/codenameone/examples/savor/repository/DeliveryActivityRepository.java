package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.DeliveryActivity;

import java.util.List;

/// The Live Activities customers follow their deliveries in, by delivery.
@Repository(entity = DeliveryActivity.class, key = String.class)
public interface DeliveryActivityRepository extends CrudRepository<DeliveryActivity, String> {
    int deleteByDeliveryId(String deliveryId);

    int deleteByUsername(String username);

    /// Records that a state went out, unless one went out after `before`:
    /// 1 for the caller who gets to send, 0 for anyone else at the same moment.
    @Modifying
    @Query("update DeliveryActivity a set a.sentAt = :now "
            + "where a.deliveryId = :deliveryId and a.sentAt < :before")
    int claim(@Param("deliveryId") String deliveryId, @Param("now") long now,
            @Param("before") long before);

    /// Records that the delivery ended at `now`, unless that is already recorded.
    @Modifying
    @Query("update DeliveryActivity a set a.endedAt = :now "
            + "where a.deliveryId = :deliveryId and a.endedAt = 0")
    int markEnded(@Param("deliveryId") String deliveryId, @Param("now") long now);

    /// The activities whose delivery ended before `before` and that are still
    /// here, because the phone was not told: oldest first.
    @Query("select a from DeliveryActivity a where a.endedAt > 0 and a.endedAt < :before "
            + "order by a.endedAt")
    List<DeliveryActivity> leftBehind(@Param("before") long before, PageRequest page);

    /// Forgets the activities whose delivery ended before `before`.
    @Modifying
    @Query("delete from DeliveryActivity a where a.endedAt > 0 and a.endedAt < :before")
    int dropEndedBefore(@Param("before") long before);
}
