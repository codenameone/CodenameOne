package com.codenameone.examples.savor.live;

import com.codename1.backend.WebSocket;
import com.codename1.backend.WebSocketSession;
import com.codename1.backend.annotations.WebSocketMapping;
import com.codenameone.examples.savor.account.Accounts;
import com.codenameone.examples.savor.api.UserDto;

/// The live channel: one WebSocket per signed-in app, down which the server
/// says what changed ([LiveHub]).
///
/// No filter chain covers this path, deliberately: the handshake cannot carry
/// the bearer token on every platform. The connection is let in by the ticket
/// in its address instead ([LiveTickets]), and one that presents none, or one
/// already used, is closed before it is told anything.
@WebSocketMapping("/ws/live")
public class LiveEndpoint implements WebSocket {
    private final LiveTickets tickets;
    private final Accounts accounts;
    private final LiveHub hub;

    public LiveEndpoint(LiveTickets tickets, Accounts accounts, LiveHub hub) {
        this.tickets = tickets;
        this.accounts = accounts;
        this.hub = hub;
    }

    @Override
    public void onOpen(WebSocketSession session) throws Exception {
        String username = tickets.redeem(ticket(session.getQuery()));
        UserDto user = username == null ? null : accounts.describe(username);
        if (user == null || user.suspended()) {
            session.close(4401, "ticket");
            return;
        }
        // Who this connection is, kept on the connection: the one piece of
        // state a WebSocket has that a request does not.
        session.setAttachment(username);
        hub.add(username, user.admin(), session);
        // Read again now that the connection is in the hub. A block or a
        // withdrawn admin role commits and then drops the account's
        // connections; one that committed after the read above and dropped
        // before the add found nothing to drop, and this connection would
        // carry what was read before -- for an admin, every courier's position.
        // Either the change is seen here, or its drop comes after the add and
        // closes this connection.
        UserDto now = accounts.describe(username);
        if (now == null || now.suspended() || now.admin() != user.admin()) {
            hub.remove(username, session);
            session.close(4403, "changed");
            return;
        }
        session.sendText("{\"type\":\"ready\"}");
    }

    @Override
    public void onText(WebSocketSession session, String message) throws Exception {
        // The app says one thing, to learn the connection is still alive on a
        // network that drops idle ones without telling either end.
        if (session.getAttachment() != null && message != null
                && message.indexOf("\"ping\"") >= 0) {
            session.sendText("{\"type\":\"pong\"}");
        }
    }

    @Override
    public void onBinary(WebSocketSession session, byte[] message, int offset, int length)
            throws Exception {
        session.close(1003, "text only");
    }

    @Override
    public void onClose(WebSocketSession session, int code, String reason) {
        Object username = session.getAttachment();
        // Only an admitted connection; a refused one has no user and its end is
        // expected. 1000 and 1001 are the app leaving. Anything else -- 1006
        // above all, a connection lost with no Close -- is what to read first
        // when pushes stop arriving, so it costs a line per dropped app.
        if (username != null && code != 1000 && code != 1001) {
            System.err.println("[live] websocket " + session.getId() + " of " + username
                    + " closed " + code + (reason == null || reason.isEmpty() ? "" : " " + reason));
        }
        if (username instanceof String) {
            hub.remove((String) username, session);
        }
    }

    @Override
    public void onError(WebSocketSession session, Exception error) {
        // A read failure, a protocol error or a callback that threw: the backend
        // reports it here and then closes, and without this line the only trace
        // of why a channel ended would be the 1006 that onClose prints.
        System.err.println("[live] websocket " + session.getId() + " of "
                + session.getAttachment() + " failed: " + error);
    }

    /// The `ticket` parameter of a query string, or null. A ticket is hex, so
    /// there is nothing in it to decode.
    static String ticket(String query) {
        if (query == null) {
            return null;
        }
        int at = 0;
        while (at < query.length()) {
            int end = query.indexOf('&', at);
            if (end < 0) {
                end = query.length();
            }
            if (query.startsWith("ticket=", at)) {
                return query.substring(at + 7, end);
            }
            at = end + 1;
        }
        return null;
    }
}
