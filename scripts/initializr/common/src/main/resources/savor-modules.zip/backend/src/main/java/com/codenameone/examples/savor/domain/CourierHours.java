package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// How long a courier was on line on one day, counted in UTC days.
@Entity
public class CourierHours {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String username = "";

    @Id(autoIncrement = false)
    @Column(nullable = false)
    private long dayNumber;

    @Column(nullable = false)
    private long millis;

    public CourierHours() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public long getDayNumber() {
        return dayNumber;
    }

    public void setDayNumber(long dayNumber) {
        this.dayNumber = dayNumber;
    }

    public long getMillis() {
        return millis;
    }

    public void setMillis(long millis) {
        this.millis = millis;
    }
}
