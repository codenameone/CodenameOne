package com.codenameone.examples.savor.order;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.savor.Ids;
import com.codenameone.examples.savor.api.OrderState;
import com.codenameone.examples.savor.domain.OrderEvent;
import com.codenameone.examples.savor.repository.OrderEventRepository;
import java.io.IOException;

/// The history of an order: one row per move, with who made it. Written in
/// the transaction that made the move.
@Component
public class OrderEvents {
    private final OrderEventRepository events;

    public OrderEvents(OrderEventRepository events) {
        this.events = events;
    }

    public void record(String orderId, OrderState state, String actor) throws IOException {
        OrderEvent event = new OrderEvent();
        event.setId(Ids.next());
        event.setOrderId(orderId);
        event.setState(state);
        event.setActor(actor == null ? "" : actor);
        event.setCreatedAt(System.currentTimeMillis());
        events.insert(event);
    }
}
