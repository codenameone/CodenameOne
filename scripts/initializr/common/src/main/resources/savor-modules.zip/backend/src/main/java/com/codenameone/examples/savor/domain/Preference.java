package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// How one person wants the app and their deliveries, when they have said.
@Entity
public class Preference {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String username = "";

    @Column(nullable = false)
    private String theme = "";

    @Column(nullable = false)
    private String units = "";

    @Column(nullable = false)
    private boolean notifyDeliveries;

    @Column(nullable = false)
    private boolean notifyReceipts;

    @Column(nullable = false)
    private boolean notifyPromotions;

    @Column(nullable = false)
    private int defaultTip;

    public Preference() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public boolean isNotifyDeliveries() {
        return notifyDeliveries;
    }

    public void setNotifyDeliveries(boolean notifyDeliveries) {
        this.notifyDeliveries = notifyDeliveries;
    }

    public boolean isNotifyReceipts() {
        return notifyReceipts;
    }

    public void setNotifyReceipts(boolean notifyReceipts) {
        this.notifyReceipts = notifyReceipts;
    }

    public boolean isNotifyPromotions() {
        return notifyPromotions;
    }

    public void setNotifyPromotions(boolean notifyPromotions) {
        this.notifyPromotions = notifyPromotions;
    }

    public int getDefaultTip() {
        return defaultTip;
    }

    public void setDefaultTip(int defaultTip) {
        this.defaultTip = defaultTip;
    }

}
