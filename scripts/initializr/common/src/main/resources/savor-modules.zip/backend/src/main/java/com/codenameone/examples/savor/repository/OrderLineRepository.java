package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.OrderLine;

import java.util.List;

/// The lines of every order.
@Repository(entity = OrderLine.class, key = String.class)
public interface OrderLineRepository extends CrudRepository<OrderLine, String> {
    List<OrderLine> findByOrderIdOrderByPositionAsc(String orderId);

    List<OrderLine> findByOrderIdIn(List<String> orderIds);
}
