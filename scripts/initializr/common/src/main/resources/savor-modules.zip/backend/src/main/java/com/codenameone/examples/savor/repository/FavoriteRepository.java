package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codename1.orm.session.Identifier;
import com.codenameone.examples.savor.domain.Favorite;

import java.util.List;

/// The restaurants customers keep, keyed by `Identifier.of(username, restaurantId)`.
@Repository(entity = Favorite.class, key = Identifier.class)
public interface FavoriteRepository extends CrudRepository<Favorite, Identifier> {
    List<Favorite> findByUsernameOrderByCreatedAtDesc(String username);

    long countByUsername(String username);

    int deleteByUsername(String username);
}
