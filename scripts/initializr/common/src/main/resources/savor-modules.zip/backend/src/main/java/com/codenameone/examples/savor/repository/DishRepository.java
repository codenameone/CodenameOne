package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Dish;

import java.util.List;

/// Every menu's dishes.
@Repository(entity = Dish.class, key = String.class)
public interface DishRepository extends CrudRepository<Dish, String> {
    List<Dish> findByRestaurantIdOrderByPositionAsc(String restaurantId);

    long countBySectionId(String sectionId);

    long countByRestaurantId(String restaurantId);

    List<Dish> findByRestaurantIdIn(List<String> restaurantIds);
}
