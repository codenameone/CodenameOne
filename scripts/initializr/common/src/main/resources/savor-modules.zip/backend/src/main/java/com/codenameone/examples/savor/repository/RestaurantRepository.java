package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Restaurant;

import java.util.List;

/// The restaurants, approved or not.
@Repository(entity = Restaurant.class, key = String.class)
public interface RestaurantRepository extends CrudRepository<Restaurant, String> {
    /// The approved restaurants inside a box, for the caller to measure and sort.
    @Query("select r from Restaurant r where r.status = :status "
            + "and r.lat between :south and :north and r.lng between :west and :east")
    List<Restaurant> inBox(@Param("status") String status, @Param("south") double south,
            @Param("north") double north, @Param("west") double west, @Param("east") double east);

    List<Restaurant> findByStatusOrderByCreatedAtDesc(String status);

    @Query("select r from Restaurant r order by r.createdAt desc")
    List<Restaurant> newest(PageRequest page);

    Restaurant findFirstByApplicantOrderByCreatedAtDesc(String applicant);

    long countByStatus(String status);

    /// Makes the rest of the transaction wait behind any other that is
    /// changing the restaurant -- pausing it, suspending it, its hours -- as
    /// [ProfileRepository#hold] does for an account. Read the restaurant after
    /// it, not before.
    ///
    /// @return 1, or 0 when there is no such restaurant
    @Modifying
    @Query("update Restaurant r set r.updatedAt = r.updatedAt where r.id = :id")
    int hold(@Param("id") String id);

    /// Adds a rating to a restaurant's running total, in the database.
    @Modifying
    @Query("update Restaurant r set r.ratingTotal = r.ratingTotal + :stars, "
            + "r.ratingCount = r.ratingCount + 1 where r.id = :id")
    int addRating(@Param("id") String id, @Param("stars") long stars);
}
