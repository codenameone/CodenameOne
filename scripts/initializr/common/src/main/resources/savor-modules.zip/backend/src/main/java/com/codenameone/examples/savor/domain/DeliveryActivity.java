package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The Live Activity a customer's phone shows a delivery in, while the delivery lasts.
@Entity
public class DeliveryActivity {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String deliveryId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    /// The id the phone's platform gave the activity.
    @Column(nullable = false, type = "VARCHAR(190)")
    private String activityId = "";

    /// When the server last sent it a state, for spacing out the updates.
    @Column(nullable = false)
    private long sentAt;

    /// When its delivery ended, 0 while the delivery lasts. An ended activity is kept
    /// until the phone has been told to end it.
    @Column(nullable = false)
    private long endedAt;

    public DeliveryActivity() {
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public long getSentAt() {
        return sentAt;
    }

    public void setSentAt(long sentAt) {
        this.sentAt = sentAt;
    }

    public long getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(long endedAt) {
        this.endedAt = endedAt;
    }
}
