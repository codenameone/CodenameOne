package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// The Live Activity a customer's phone shows a delivery in, while the delivery lasts.
@Entity
public class DeliveryActivity {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String deliveryId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    /// The id the phone's platform gave the activity.
    @Column(nullable = false, type = "VARCHAR(190)")
    private String activityId = "";

    /// When the server last sent it a state, for spacing out the updates.
    @Column(nullable = false)
    private Instant sentAt = Instant.EPOCH;

    /// When its delivery ended, 0 while the delivery lasts. An ended activity is kept
    /// until the phone has been told to end it.
    @Column(nullable = false)
    private Instant endedAt = Instant.EPOCH;

    public DeliveryActivity() {
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }

    public Instant getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(Instant endedAt) {
        this.endedAt = endedAt;
    }
}
