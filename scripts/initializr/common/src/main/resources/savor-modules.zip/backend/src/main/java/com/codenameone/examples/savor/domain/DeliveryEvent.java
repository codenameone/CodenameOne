package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import com.codenameone.examples.savor.api.DeliveryState;
import java.time.Instant;

/// One change of a delivery's state: what it became, who made it so, and when.
@Entity
public class DeliveryEvent {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String deliveryId = "";

    @Column(nullable = false, type = "VARCHAR(24)")
    private DeliveryState state;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String actor = "";

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public DeliveryEvent() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public DeliveryState getState() {
        return state;
    }

    public void setState(DeliveryState state) {
        this.state = state;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
