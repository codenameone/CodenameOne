package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.api.DeliveryState;
import com.codenameone.examples.savor.domain.DeliveryEvent;

import java.util.List;

/// What happened to each delivery: one row for every state it came into.
@Repository(entity = DeliveryEvent.class, key = String.class)
public interface DeliveryEventRepository extends CrudRepository<DeliveryEvent, String> {
    long countByActorAndState(String actor, DeliveryState state);

    /// How many offers each courier has accepted, as `{courier, count}`.
    @Query("select e.actor, count(e) from DeliveryEvent e where e.state = :accepted "
            + "group by e.actor")
    List<Object[]> countByActor(@Param("accepted") DeliveryState accepted);

    /// When each delivery asked for since `since` came into `state`: `{deliveryId,
    /// createdAt}`. The entities have no relationship to join along, so the
    /// deliveries are named by a nested query.
    @Query("select e.deliveryId, e.createdAt from DeliveryEvent e where e.state = :state "
            + "and e.deliveryId in (select r.id from Delivery r where r.requestedAt >= :since)")
    List<Object[]> reached(@Param("since") long since, @Param("state") DeliveryState state);
}
