package com.codenameone.examples.savor.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.savor.domain.Pricing;

/// The admin's prices: one row, whose key is [#ONLY]. A migration creates it,
/// with an `updatedAt` of 0 while the prices are still the settings'.
@Repository(entity = Pricing.class, key = Integer.class)
public interface PricingRepository extends CrudRepository<Pricing, Integer> {
    /// The key of the one row there is.
    Integer ONLY = Integer.valueOf(1);

    /// Writes new prices over the one row, in one statement that reads
    /// nothing first: two admins saving together each write theirs, and the
    /// later one is what stays.
    ///
    /// @return 1, or 0 when the row is missing
    @Modifying
    @Query("update Pricing p set p.baseCents = :base, p.perKmCents = :perKm, "
            + "p.surge = :surge, p.smallOrderCents = :smallOrder, "
            + "p.smallOrderFeeCents = :smallOrderFee, p.feePercent = :fee, "
            + "p.taxPercent = :tax, p.commissionPercent = :commission, "
            + "p.updatedAt = :at, p.updatedBy = :by where p.id = :id")
    int change(@Param("id") int id, @Param("base") long base, @Param("perKm") long perKm,
            @Param("surge") double surge, @Param("smallOrder") long smallOrder,
            @Param("smallOrderFee") long smallOrderFee, @Param("fee") double fee,
            @Param("tax") double tax, @Param("commission") double commission,
            @Param("at") long at, @Param("by") String by);
}
