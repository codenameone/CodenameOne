package com.codenameone.examples.savor.onboarding;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.savor.api.DocumentContentDto;
import com.codenameone.examples.savor.api.DocumentUploadDto;
import com.codenameone.examples.savor.api.CourierApplicationDto;
import com.codenameone.examples.savor.api.OnboardingApiServer;

/// The server's half of `OnboardingApi`.
///
/// Open to anyone signed in, which is why its paths are not under
/// `/api/courier`: applying is what someone does before they hold the COURIER
/// role. What keeps one applicant out of another's application -- and out of
/// the identity documents in it -- is that no method here takes a name. Each
/// acts on the application of whoever is signed in, and there is no parameter
/// to change.
@Component
public class OnboardingEndpoint implements OnboardingApiServer {
    private final Applications applications;

    public OnboardingEndpoint(Applications applications) {
        this.applications = applications;
    }

    @Override
    public CourierApplicationDto application() throws Exception {
        return applications.get(Caller.name());
    }

    @Override
    public CourierApplicationDto save(CourierApplicationDto application) throws Exception {
        return applications.save(Caller.name(), application);
    }

    @Override
    public CourierApplicationDto upload(DocumentUploadDto document) throws Exception {
        return applications.upload(Caller.name(), document);
    }

    @Override
    public DocumentContentDto document(String kind) throws Exception {
        return applications.document(Caller.name(), kind);
    }

    @Override
    public CourierApplicationDto submit() throws Exception {
        return applications.submit(Caller.name());
    }
}
