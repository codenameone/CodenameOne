package com.codenameone.examples.savor.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// What a completed delivery was charged, and what was given back.
@Entity
public class Payment {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String deliveryId = "";

    @Column(nullable = false)
    private long amountCents;

    @Column(nullable = false, type = "VARCHAR(3)")
    private String currency = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String status = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String providerRef = "";

    @Column(nullable = false)
    private long createdAt;

    @Column(nullable = false, type = "VARCHAR(64)")
    private String tipRef = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String refundRef = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String tipRefundRef = "";

    @Column(nullable = false, type = "VARCHAR(255)")
    private String refundReason = "";

    @Column(nullable = false)
    private long refundedAt;

    public Payment() {
    }

    public String getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(String deliveryId) {
        this.deliveryId = deliveryId;
    }

    public long getAmountCents() {
        return amountCents;
    }

    public void setAmountCents(long amountCents) {
        this.amountCents = amountCents;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProviderRef() {
        return providerRef;
    }

    public void setProviderRef(String providerRef) {
        this.providerRef = providerRef;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public String getTipRef() {
        return tipRef;
    }

    public void setTipRef(String tipRef) {
        this.tipRef = tipRef;
    }

    public String getRefundRef() {
        return refundRef;
    }

    public void setRefundRef(String refundRef) {
        this.refundRef = refundRef;
    }

    public String getTipRefundRef() {
        return tipRefundRef;
    }

    public void setTipRefundRef(String tipRefundRef) {
        this.tipRefundRef = tipRefundRef;
    }

    public String getRefundReason() {
        return refundReason;
    }

    public void setRefundReason(String refundReason) {
        this.refundReason = refundReason;
    }

    public long getRefundedAt() {
        return refundedAt;
    }

    public void setRefundedAt(long refundedAt) {
        this.refundedAt = refundedAt;
    }
}
