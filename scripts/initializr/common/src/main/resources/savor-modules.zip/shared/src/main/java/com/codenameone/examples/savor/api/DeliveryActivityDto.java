package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// The Live Activity a customer's phone started for a delivery, by the id the
/// platform gave it. The server addresses its updates to that id.
@Mapped
public record DeliveryActivityDto(String activityId) {
}
