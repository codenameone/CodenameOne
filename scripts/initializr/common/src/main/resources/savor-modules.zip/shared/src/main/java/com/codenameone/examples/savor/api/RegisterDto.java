package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// What opening an account takes. The password travels once, in the body of a
/// request over TLS, and the server keeps only its hash.
///
/// @param wantsToDeliver Opens a courier application with the account. The account is a
///     customer until an admin approves the application.
@Mapped
public record RegisterDto(
        String email,
        String password,
        String displayName,
        String phone,
        String vehicle,
        String plate,
        boolean wantsToDeliver) {
}
