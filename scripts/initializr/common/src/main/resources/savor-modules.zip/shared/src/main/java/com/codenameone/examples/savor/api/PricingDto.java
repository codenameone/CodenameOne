package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// What an order costs on top of its food, and what the service keeps of it.
///
/// @param baseCents The delivery fee's base.
/// @param perKmCents Added to it for each kilometre from the restaurant to the door.
/// @param surge The delivery fee is multiplied by it.
/// @param smallOrderCents Food worth less than this pays the difference ...
/// @param smallOrderFeeCents ... up to this much.
/// @param commissionPercent Kept of the food; the restaurant is paid the rest.
@Mapped
public record PricingDto(
        String currency,
        long baseCents,
        long perKmCents,
        double surge,
        long smallOrderCents,
        long smallOrderFeeCents,
        double serviceFeePercent,
        double taxPercent,
        double commissionPercent) {
}
