package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// Why an admin did something: rejected an application, cancelled a delivery,
/// refunded one.
@Mapped
public record ReasonDto(String reason) {
}
