package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// One day of the service.
///
/// @param date `yyyy-MM-dd`, in UTC.
/// @param revenue Cents: the fares of the day's completed, paid deliveries.
@Mapped
public record DayStatsDto(
        String date,
        int orders,
        int delivered,
        int cancelled,
        long revenue,
        int newUsers) {
}
