package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A restaurant's details as its applicant or its staff send them.
@Mapped
public record RestaurantEditDto(
        String name,
        String cuisine,
        String description,
        String address,
        double lat,
        double lng,
        int opensAt,
        int closesAt,
        int prepMinutes,
        long minimumCents,
        int priceLevel,
        String photoId) {
}
