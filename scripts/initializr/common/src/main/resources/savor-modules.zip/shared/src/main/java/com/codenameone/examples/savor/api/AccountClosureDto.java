package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// The request to close an account: the password of whoever is asking.
@Mapped
public record AccountClosureDto(String password) {
}
