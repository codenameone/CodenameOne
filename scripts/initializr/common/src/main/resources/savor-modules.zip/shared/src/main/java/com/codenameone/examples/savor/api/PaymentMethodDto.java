package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A way to pay. Cash is always one of them, under the id `cash`.
///
/// @param kind `card` or `cash`.
/// @param label The method as a person would name it: "Visa 4242", "Cash".
@Mapped
public record PaymentMethodDto(
        String id,
        String kind,
        String brand,
        String last4,
        int expMonth,
        int expYear,
        boolean isDefault,
        String label) {
}
