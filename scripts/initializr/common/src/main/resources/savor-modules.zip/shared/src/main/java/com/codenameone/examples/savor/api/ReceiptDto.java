package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// What an order cost and how it was paid. Every amount is in cents.
///
/// @param subtotal The food, extras included, before the discount.
/// @param smallOrderFee Charged when the subtotal is under the small-order threshold.
/// @param total Everything the card was charged: the subtotal less the discount, the fees,
///     the tax and the tip.
/// @param status `pending`, `paid`, `failed`, `refunded` or `cash`; while a refund the processor
///     took has not finished, `refund_pending`, and `refund_failed` when it then did not return the
///     money.
/// @param paidAt Milliseconds since the epoch, or 0 while unpaid.
/// @param customerUsername Who paid. Filled for an admin; a customer's own receipts leave it empty.
@Mapped
public record ReceiptDto(
        String orderId,
        String currency,
        String restaurantName,
        long subtotal,
        long deliveryFee,
        long serviceFee,
        long smallOrderFee,
        long tax,
        long discount,
        long tip,
        long total,
        String methodLabel,
        String status,
        long paidAt,
        String dropoffName,
        String courierName,
        String vehicle,
        String customerUsername) {
}
