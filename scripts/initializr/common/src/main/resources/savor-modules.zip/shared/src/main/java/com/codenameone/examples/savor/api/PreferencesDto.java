package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// How one person wants the app and their deliveries. Kept on the server, so it
/// follows the account to another phone.
///
/// @param language `en`, `es`, `fr`, `de` or `he`.
/// @param theme `system`, `light` or `dark`.
/// @param units `km` or `mi`.
/// @param defaultPaymentMethodId A saved method's id, or `cash`.
/// @param defaultTipPercent 0, 10, 15 or 20.
@Mapped
public record PreferencesDto(
        String language,
        String theme,
        String units,
        boolean notifyDeliveryUpdates,
        boolean notifyReceipts,
        boolean notifyPromotions,
        String defaultPaymentMethodId,
        int defaultTipPercent) {
}
