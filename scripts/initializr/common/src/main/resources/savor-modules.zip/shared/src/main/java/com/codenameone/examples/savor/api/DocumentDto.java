package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// One of the documents of a onboarding application. The picture itself is read
/// separately, and only by the applicant and the admins.
///
/// @param kind `photo_id`, `licence`, `selfie`, `vehicle_registration` or `insurance`.
/// @param status `missing`, `uploaded`, `accepted` or `rejected`.
/// @param uploadedAt Milliseconds since the epoch, or 0 when missing.
@Mapped
public record DocumentDto(String kind, String status, long uploadedAt) {
}
