package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// The parts of an account its owner edits.
///
@Mapped
public record ProfileDto(
        String name) {
}
