package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Something on a menu.
///
/// @param available False while sold out: listed, and not orderable.
@Mapped
public record DishDto(
        String id,
        String sectionId,
        String name,
        String description,
        long priceCents,
        String photoId,
        boolean available,
        boolean popular,
        List<DishOptionDto> options) {
}
