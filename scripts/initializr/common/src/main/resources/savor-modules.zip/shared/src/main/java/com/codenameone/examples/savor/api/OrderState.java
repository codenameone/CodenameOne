package com.codenameone.examples.savor.api;

/// The states of an order, as [OrderDto#state] carries them and the server stores
/// them: by name, on the wire and in the database column.
///
/// The courier's part runs beside it, as the order's [DeliveryDto]: it is
/// looked for from the moment the restaurant accepts, so that someone is at the
/// counter about when the food is.
public enum OrderState {
    /// No order. Never stored; it answers "is there one?".
    NONE,
    /// Paid for and sent; the restaurant has not answered.
    PLACED,
    /// The restaurant took it and is making it.
    ACCEPTED,
    /// Made, and waiting at the counter for the courier.
    READY,
    /// With the courier, on the way.
    PICKED_UP,
    DELIVERED,
    /// The restaurant turned it down.
    REJECTED,
    CANCELLED_BY_CUSTOMER,
    /// Stopped by an admin, at any point before it was delivered.
    CANCELLED_BY_ADMIN,
    /// Made or not, nobody could be found to bring it.
    NO_COURIERS;

    /// Whether the order is still going on.
    public boolean isActive() {
        return this == PLACED || this == ACCEPTED || this == READY || this == PICKED_UP;
    }

    /// Whether the order ended without reaching the customer.
    public boolean isCancelled() {
        return this == REJECTED || this == CANCELLED_BY_CUSTOMER || this == CANCELLED_BY_ADMIN
                || this == NO_COURIERS;
    }
}
