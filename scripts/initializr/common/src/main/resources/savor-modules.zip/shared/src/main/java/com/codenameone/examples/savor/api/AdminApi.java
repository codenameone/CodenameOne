package com.codenameone.examples.savor.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.PUT;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Admin mode: the numbers, the fleet, who may deliver, and who may do what.
@RestClient
public interface AdminApi {
    @GET("/api/admin/stats")
    void stats(OnComplete<Response<AdminStatsDto>> callback);

    /// The charts, over the last `days` days; 1 to 90.
    @GET("/api/admin/stats/series")
    void statsSeries(@Query("days") int days, OnComplete<Response<StatsSeriesDto>> callback);

    @GET("/api/admin/deliveries")
    void deliveries(OnComplete<Response<List<DeliveryDto>>> callback);

    @GET("/api/admin/users")
    void users(OnComplete<Response<List<UserDto>>> callback);

    @GET("/api/admin/users/{username}")
    void user(@Path("username") String username, OnComplete<Response<UserDetailDto>> callback);

    @GET("/api/admin/couriers")
    void couriers(OnComplete<Response<List<CourierDto>>> callback);

    @POST("/api/admin/users/{username}/roles")
    void setRoles(@Path("username") String username, @Body RoleChangeDto roles,
            OnComplete<Response<UserDto>> callback);

    /// Blocks an account, or lifts the block.
    @POST("/api/admin/users/{username}/suspend")
    void suspend(@Path("username") String username, @Body SuspendDto suspend,
            OnComplete<Response<UserDto>> callback);

    @POST("/api/admin/users/{username}/flag")
    void flag(@Path("username") String username, @Body FlagDto flag,
            OnComplete<Response<UserDto>> callback);

    /// Onboarding applications, newest first. `status` narrows them to one status;
    /// empty lists them all.
    @GET("/api/admin/applications")
    void applications(@Query("status") String status,
            OnComplete<Response<List<CourierApplicationDto>>> callback);

    @GET("/api/admin/applications/{username}")
    void application(@Path("username") String username,
            OnComplete<Response<CourierApplicationDto>> callback);

    @GET("/api/admin/applications/{username}/documents/{kind}")
    void document(@Path("username") String username, @Path("kind") String kind,
            OnComplete<Response<DocumentContentDto>> callback);

    /// Approves an application, which makes its account a courier.
    @POST("/api/admin/applications/{username}/approve")
    void approve(@Path("username") String username,
            OnComplete<Response<CourierApplicationDto>> callback);

    @POST("/api/admin/applications/{username}/reject")
    void reject(@Path("username") String username, @Body ReasonDto reason,
            OnComplete<Response<CourierApplicationDto>> callback);

    /// The most recent orders, newest first.
    @GET("/api/admin/orders")
    void orders(OnComplete<Response<List<OrderDto>>> callback);

    /// Ends an order that has not arrived, lets the card hold go and takes its
    /// delivery off the road.
    @POST("/api/admin/orders/{id}/cancel")
    void cancelOrder(@Path("id") String id, @Body ReasonDto reason,
            OnComplete<Response<OrderDto>> callback);

    /// Returns what a delivered order cost to the card that paid for it.
    @POST("/api/admin/orders/{id}/refund")
    void refundOrder(@Path("id") String id, @Body ReasonDto reason,
            OnComplete<Response<ReceiptDto>> callback);

    /// Restaurants in one status: `PENDING` (applications), `APPROVED`,
    /// `REJECTED` or `SUSPENDED`.
    @GET("/api/admin/restaurants")
    void restaurants(@Query("status") String status,
            OnComplete<Response<List<RestaurantDto>>> callback);

    @POST("/api/admin/restaurants/{id}/approve")
    void approveRestaurant(@Path("id") String id, OnComplete<Response<RestaurantDto>> callback);

    @POST("/api/admin/restaurants/{id}/reject")
    void rejectRestaurant(@Path("id") String id, @Body ReasonDto reason,
            OnComplete<Response<RestaurantDto>> callback);

    /// Takes a listed restaurant off the app, or puts it back.
    @POST("/api/admin/restaurants/{id}/suspend")
    void suspendRestaurant(@Path("id") String id, @Body SuspendDto suspend,
            OnComplete<Response<RestaurantDto>> callback);

    @GET("/api/admin/promos")
    void promos(OnComplete<Response<List<PromoDto>>> callback);

    /// Creates a promotion code or changes one, by its code.
    @PUT("/api/admin/promos")
    void savePromo(@Body PromoDto promo, OnComplete<Response<PromoDto>> callback);

    @GET("/api/admin/payments")
    void payments(OnComplete<Response<List<ReceiptDto>>> callback);

    @GET("/api/admin/pricing")
    void pricing(OnComplete<Response<PricingDto>> callback);

    @PUT("/api/admin/pricing")
    void savePricing(@Body PricingDto pricing, OnComplete<Response<PricingDto>> callback);
}
