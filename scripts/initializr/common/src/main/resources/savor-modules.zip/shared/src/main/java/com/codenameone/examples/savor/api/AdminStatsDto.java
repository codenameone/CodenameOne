package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// The numbers on the admin dashboard.
@Mapped
public record AdminStatsDto(
        int users,
        int couriers,
        int couriersOnline,
        int ordersToday,
        int ordersActive,
        int ordersDelivered,
        long revenueCents,
        String currency) {
}
