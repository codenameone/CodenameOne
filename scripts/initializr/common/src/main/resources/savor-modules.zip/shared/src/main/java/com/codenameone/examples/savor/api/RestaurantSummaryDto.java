package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A restaurant as a list shows it: enough to choose one.
///
/// @param photoId Empty for none; fetched with `CatalogApi.photo`.
/// @param rating Average stars, 0 when nobody has rated it.
/// @param priceLevel One to four.
/// @param etaMinutes From ordering to the door, as the server estimates it now.
/// @param open Taking orders now: within its hours and not paused.
@Mapped
public record RestaurantSummaryDto(
        String id,
        String name,
        String cuisine,
        String photoId,
        double rating,
        long ratingCount,
        int priceLevel,
        int etaMinutes,
        long deliveryFeeCents,
        double distanceMeters,
        boolean open,
        boolean favorite) {
}
