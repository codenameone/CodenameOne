package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A tip for the courier of a completed delivery, in cents.
@Mapped
public record TipDto(long amount) {
}
