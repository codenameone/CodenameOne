package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// An order, for its customer, its restaurant, its courier or an admin.
///
/// @param etaMinutes Until it is at the door, as the server estimates it now; 0 once it has ended.
/// @param reason Why it was rejected or cancelled.
/// @param delivery Its courier's leg, or one whose state is NONE before the restaurant accepts.
@Mapped
public record OrderDto(
        String id,
        OrderState state,
        String restaurantId,
        String restaurantName,
        String restaurantAddress,
        double restaurantLat,
        double restaurantLng,
        String customer,
        String customerName,
        List<OrderLineDto> lines,
        long subtotalCents,
        long deliveryFeeCents,
        long serviceFeeCents,
        long smallOrderCents,
        long taxCents,
        long discountCents,
        long tipCents,
        long totalCents,
        String currency,
        double dropoffLat,
        double dropoffLng,
        String dropoffAddress,
        String note,
        String methodLabel,
        String paymentStatus,
        int prepMinutes,
        long placedAt,
        long acceptedAt,
        long readyAt,
        long deliveredAt,
        int etaMinutes,
        String reason,
        int stars,
        DeliveryDto delivery) {
}
