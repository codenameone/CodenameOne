package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A picture of a document, sent as base64. JPEG or PNG, and small: the app
/// shrinks a photograph before sending it.
///
/// @param contentType `image/jpeg` or `image/png`.
@Mapped
public record DocumentUploadDto(String kind, String contentType, String dataBase64) {
}
