package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// One day of a courier's earnings.
///
/// @param date `yyyy-MM-dd`, in UTC.
@Mapped
public record DayAmountDto(String date, long amount, int trips) {
}
