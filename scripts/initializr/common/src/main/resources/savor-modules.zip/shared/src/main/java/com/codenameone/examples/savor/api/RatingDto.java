package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A customer's rating of a completed delivery.
@Mapped
public record RatingDto(int stars) {
}
