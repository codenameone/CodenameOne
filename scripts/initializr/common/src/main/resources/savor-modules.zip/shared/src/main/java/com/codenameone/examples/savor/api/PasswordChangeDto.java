package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A change of password: the one in use, and the one to use from now on.
@Mapped
public record PasswordChangeDto(String current, String replacement) {
}
