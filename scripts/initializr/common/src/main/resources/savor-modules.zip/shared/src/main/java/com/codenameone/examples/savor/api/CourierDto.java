package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A courier, for the admin's fleet view and for the courier's own status.
///
/// @param approved Whether the courier application was approved. Only an approved courier can go on
///     line.
/// @param acceptanceRate The share of the offers this courier was sent that they took, 0 to 1; 1
///     before any was sent.
@Mapped
public record CourierDto(
        String username,
        String displayName,
        String vehicle,
        String plate,
        boolean online,
        double lat,
        double lng,
        double heading,
        double rating,
        long lastSeen,
        int deliveries,
        boolean approved,
        double acceptanceRate,
        boolean flagged) {
}
