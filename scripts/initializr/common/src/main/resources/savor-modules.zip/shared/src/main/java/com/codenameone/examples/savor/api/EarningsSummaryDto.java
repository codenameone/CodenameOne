package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A courier's money: what came in, what is owed, and how the last two weeks
/// went. Amounts are cents, and are the courier's share -- the fare less the
/// service's commission, plus tips.
///
/// @param balance Earned and not yet paid out.
/// @param onlineMinutes Time on line today.
/// @param acceptanceRate 0 to 1.
/// @param daily The last 14 days, oldest first, every day present.
@Mapped
public record EarningsSummaryDto(
        String currency,
        long today,
        long week,
        long month,
        long balance,
        int trips,
        long tips,
        int onlineMinutes,
        double rating,
        double acceptanceRate,
        List<DayAmountDto> daily) {
}
