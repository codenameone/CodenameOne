package com.codenameone.examples.savor.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Ways to pay, and what was paid. Everything here is the signed-in user's own.
@RestClient
public interface PaymentApi {
    @GET("/api/payments/config")
    void config(OnComplete<Response<PaymentConfigDto>> callback);

    /// The saved cards, and cash, which is always there.
    @GET("/api/payments/methods")
    void methods(OnComplete<Response<List<PaymentMethodDto>>> callback);

    /// Begins adding a card; see [PaymentSetupDto] for the two ways it goes on.
    @POST("/api/payments/methods/setup")
    void startSetup(OnComplete<Response<PaymentSetupDto>> callback);

    /// Finishes adding a card. `card` is read by the simulated processor and
    /// ignored when the setup was hosted.
    @POST("/api/payments/methods/setup/{id}/complete")
    void completeSetup(@Path("id") String id, @Body CardDto card,
            OnComplete<Response<PaymentMethodDto>> callback);

    @POST("/api/payments/methods/{id}/default")
    void makeDefault(@Path("id") String id, OnComplete<Response<PaymentMethodDto>> callback);

    @POST("/api/payments/methods/{id}/remove")
    void remove(@Path("id") String id, OnComplete<Response<PaymentMethodDto>> callback);

    /// The caller's receipts as a customer, newest first.
    @GET("/api/payments/receipts")
    void receipts(OnComplete<Response<List<ReceiptDto>>> callback);

    @GET("/api/payments/receipts/{orderId}")
    void receipt(@Path("orderId") String orderId, OnComplete<Response<ReceiptDto>> callback);

    /// Tips the courier of a delivered order, once.
    @POST("/api/orders/{id}/tip")
    void tip(@Path("id") String id, @Body TipDto tip, OnComplete<Response<ReceiptDto>> callback);
}
