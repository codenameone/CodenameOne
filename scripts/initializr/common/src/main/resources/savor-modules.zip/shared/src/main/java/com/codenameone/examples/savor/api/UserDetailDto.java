package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One account in full, for the admin deciding what to do about it.
///
/// @param deliveries Deliveries taken part in, as customer or courier.
/// @param cancellations How many of those deliveries were cancelled.
/// @param rating As a courier; 0 for an account that has not driven.
/// @param spent Cents paid as a customer.
/// @param earned Cents earned as a courier.
/// @param events Newest first.
@Mapped
public record UserDetailDto(
        UserDto user,
        int orders,
        int deliveries,
        int cancellations,
        double rating,
        long spent,
        long earned,
        List<ModerationEventDto> events) {
}
