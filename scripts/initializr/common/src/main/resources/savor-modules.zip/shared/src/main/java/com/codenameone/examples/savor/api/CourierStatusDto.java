package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// A courier going on or off line, or reporting where the car is.
@Mapped
public record CourierStatusDto(boolean online, double lat, double lng, double heading) {
}
