package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// What a courier has earned. `deliveries` counts every paid delivery the courier ever
/// completed, and `todayDeliveries` those of them that `todayCents` is made of.
@Mapped
public record EarningsDto(
        long todayCents,
        long weekCents,
        long totalCents,
        int deliveries,
        int todayDeliveries,
        String currency) {
}
