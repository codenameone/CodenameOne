package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A restaurant with its menu, as its page shows it.
///
/// @param opensAt Minutes after local midnight.
/// @param status `pending`, `approved`, `rejected` or `suspended`.
/// @param reason Why an admin rejected or suspended it.
@Mapped
public record RestaurantDto(
        String id,
        String name,
        String cuisine,
        String description,
        String address,
        double lat,
        double lng,
        String photoId,
        double rating,
        long ratingCount,
        int priceLevel,
        int etaMinutes,
        long deliveryFeeCents,
        long minimumCents,
        boolean open,
        boolean paused,
        int opensAt,
        int closesAt,
        int prepMinutes,
        boolean favorite,
        String status,
        String reason,
        List<MenuSectionDto> menu) {
}
