package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The admin's charts: how the service did, day by day.
///
/// @param days Oldest first, every day present.
/// @param byHour Deliveries asked for in each hour of the day (UTC), 24 numbers.
/// @param byRestaurant Orders placed in the period at each restaurant, the busiest first.
/// @param topCouriers The couriers who completed the most deliveries in the period; `deliveries` is that count.
/// @param averageFare Cents.
/// @param averageWaitSeconds From a delivery being asked for to a courier taking it.
/// @param completionRate Completed deliveries over deliveries asked for, 0 to 1.
@Mapped
public record StatsSeriesDto(
        List<DayStatsDto> days,
        List<Integer> byHour,
        List<NameCountDto> byState,
        List<NameCountDto> byRestaurant,
        List<CourierDto> topCouriers,
        long averageOrder,
        double averageDeliveryMinutes,
        double completionRate,
        int pendingApplications,
        int flaggedUsers,
        String currency) {
}
