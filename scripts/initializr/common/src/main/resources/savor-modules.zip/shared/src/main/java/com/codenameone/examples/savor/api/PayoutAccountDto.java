package com.codenameone.examples.savor.api;

import com.codename1.annotations.Mapped;

/// Where a courier's payouts go. Only the last four digits of the account are
/// kept.
@Mapped
public record PayoutAccountDto(String holder, String bankName, String accountLast4) {
}
