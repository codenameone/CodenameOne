package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// One span of clocked time: SHIFT, TRAVEL or JOB.
@Mapped
public record TimeEntryDto(
        String kind,
        long start,
        long end,
        String jobId) {
}
