package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A customer site.
@Mapped
public record SiteDto(
        String id,
        String name,
        String address,
        double lat,
        double lng,
        String customer,
        String assetType,
        String assetModel) {
}
