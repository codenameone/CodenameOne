package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A job report the assistant drafted from the checklist, notes and photos.
@Mapped
public record ReportDto(
        String jobId,
        String summary,
        List<String> findings,
        List<String> followUps,
        String source) {
}
