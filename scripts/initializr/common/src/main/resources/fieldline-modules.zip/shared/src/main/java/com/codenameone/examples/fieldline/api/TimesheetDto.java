package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// Everyone's clocked time for the week from `weekStart`.
@Mapped
public record TimesheetDto(
        long weekStart,
        List<TimesheetRowDto> rows,
        long totalCostCents) {
}
