package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// The checklist and notes a technician filled in.
@Mapped
public record ChecklistDto(
        List<CheckDto> checklist,
        String notes) {
}
