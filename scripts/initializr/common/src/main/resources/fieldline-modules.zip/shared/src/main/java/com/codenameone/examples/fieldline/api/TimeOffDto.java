package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// Requested or approved absence. Times are epoch milliseconds.
@Mapped
public record TimeOffDto(
        String id,
        String techId,
        String techName,
        long start,
        long end,
        String reason,
        String status) {
}
