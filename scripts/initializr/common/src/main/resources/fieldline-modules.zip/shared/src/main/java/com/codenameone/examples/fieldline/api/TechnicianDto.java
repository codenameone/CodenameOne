package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A technician or inspector, with the live figures the dispatch board shows.
@Mapped
public record TechnicianDto(
        String id,
        String name,
        String initials,
        String color,
        List<String> skills,
        double homeLat,
        double homeLng,
        String homeLabel,
        double lat,
        double lng,
        String status,
        int jobsToday,
        int utilizationPct,
        String username) {
}
