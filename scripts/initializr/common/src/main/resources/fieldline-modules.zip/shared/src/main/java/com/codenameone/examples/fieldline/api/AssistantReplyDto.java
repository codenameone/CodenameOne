package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// The assistant's answer and what it did. `run` is set when it changed the schedule.
@Mapped
public record AssistantReplyDto(
        String reply,
        List<String> actions,
        ScheduleRunDto run,
        String source) {
}
