package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A photo taken on site and the diagnosis made from it. `data` is only filled when the photo itself is asked for.
@Mapped
public record PhotoDto(
        String id,
        String jobId,
        long takenAt,
        String note,
        String data,
        DiagnosisDto diagnosis) {
}
