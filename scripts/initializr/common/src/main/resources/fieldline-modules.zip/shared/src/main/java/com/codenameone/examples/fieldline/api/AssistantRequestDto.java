package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A question for the assistant. `jobId` puts the conversation in the context of a job.
@Mapped
public record AssistantRequestDto(
        String message,
        List<ChatTurnDto> history,
        String jobId) {
}
