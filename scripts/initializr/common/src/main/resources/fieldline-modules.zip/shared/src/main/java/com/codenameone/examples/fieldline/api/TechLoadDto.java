package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// One technician's planned load over the report's span.
@Mapped
public record TechLoadDto(
        String id,
        String name,
        String color,
        int availableMinutes,
        int workMinutes,
        int driveMinutes,
        int overtimeMinutes,
        int jobs) {
}
