package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// The company's planning rules as the Rules page edits them. Weights are
/// relative: what matters is how one compares with another. Rush hours are
/// minutes of the day: a drive that sets off inside one takes `rushExtraPct`
/// percent longer. Clocked time rounds to `timeRoundingMinutes`, and a shift
/// nobody clocked out of closes itself after `autoClockOutHours`.
@Mapped
public record PolicyDto(
        int breakMinutes,
        int breakAfterMinutes,
        int breakBeforeMinutes,
        boolean strictTerritories,
        int travelWeight,
        int overtimeWeight,
        int latenessWeight,
        int continuityWeight,
        int balanceWeight,
        int territoryWeight,
        int urgentSlaHours,
        int routineSlaHours,
        int rushAmFrom,
        int rushAmTo,
        int rushPmFrom,
        int rushPmTo,
        int rushExtraPct,
        int timeRoundingMinutes,
        int autoClockOutHours) {
}
