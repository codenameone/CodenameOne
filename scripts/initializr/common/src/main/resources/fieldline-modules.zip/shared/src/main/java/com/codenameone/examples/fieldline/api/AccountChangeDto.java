package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// What an admin sets on an account: its roles and whether it may sign in.
@Mapped
public record AccountChangeDto(
        String username,
        boolean technician,
        boolean dispatcher,
        boolean admin,
        boolean suspended) {
}
