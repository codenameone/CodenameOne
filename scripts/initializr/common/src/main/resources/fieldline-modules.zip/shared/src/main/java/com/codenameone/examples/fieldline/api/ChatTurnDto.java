package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// One turn of a conversation with the assistant: `role` is user or assistant.
@Mapped
public record ChatTurnDto(
        String role,
        String text) {
}
