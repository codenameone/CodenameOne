/// The Fieldline scheduling engine: technicians, jobs, shifts and an Adaptive
/// Large Neighbourhood Search that places jobs on routes.
///
/// It depends on nothing outside `java.lang` and `java.util` and uses integer
/// arithmetic throughout, so the same seed and problem give the same plan on
/// the server, in the app and in the tests. Start at `Problem`, `Solver` and
/// `Reoptimizer`.
package com.codenameone.examples.fieldline.scheduler;
