package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// How many open jobs the planner could not place for one reason.
@Mapped
public record ReasonCountDto(
        String code,
        String text,
        int jobs) {
}
