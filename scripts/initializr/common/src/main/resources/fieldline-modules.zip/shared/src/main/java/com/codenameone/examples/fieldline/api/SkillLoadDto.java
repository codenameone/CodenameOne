package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// Demand for a skill against the hours of the technicians who have it. A
/// technician with several skills counts toward each, so this is the most the
/// crew could give a skill, not a split of its time.
@Mapped
public record SkillLoadDto(
        String skill,
        int technicians,
        int capacityMinutes,
        int demandMinutes) {
}
