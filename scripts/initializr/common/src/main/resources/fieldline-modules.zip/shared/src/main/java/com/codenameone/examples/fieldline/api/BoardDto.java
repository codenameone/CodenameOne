package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// The dispatch board: everyone's routes over a number of days from `dayStart`.
@Mapped
public record BoardDto(
        long dayStart,
        int days,
        List<TechnicianDto> technicians,
        List<JobDto> jobs,
        KpiDto kpis,
        ScheduleRunDto lastRun,
        List<TimeOffDto> timeOff,
        List<BreakDto> breaks) {
}
