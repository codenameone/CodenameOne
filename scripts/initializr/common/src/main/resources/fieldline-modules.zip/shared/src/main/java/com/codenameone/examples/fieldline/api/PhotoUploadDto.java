package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A photo to attach, base64 JPEG or PNG.
@Mapped
public record PhotoUploadDto(
        String data,
        String mime,
        String note) {
}
