package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// Opening an account. New accounts are technicians; the dispatcher role is granted.
@Mapped
public record RegisterDto(
        String email,
        String password,
        String displayName,
        String phone) {
}
