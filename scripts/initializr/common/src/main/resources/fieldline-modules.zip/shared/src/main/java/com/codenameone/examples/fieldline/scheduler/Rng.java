package com.codenameone.examples.fieldline.scheduler;

/// A seeded xorshift64* generator. `java.util.Random` is avoided so that a seed
/// produces the same schedule on the JVM, under ParparVM and in JavaScript.
public final class Rng {
    private long state;

    public Rng(long seed) {
        state = seed == 0 ? 0x9E3779B97F4A7C15L : seed;
    }

    public long nextLong() {
        long x = state;
        x ^= x >>> 12;
        x ^= x << 25;
        x ^= x >>> 27;
        state = x;
        return x * 0x2545F4914F6CDD1DL;
    }

    /// Uniform in `[0, bound)`; `bound` must be positive.
    public int nextInt(int bound) {
        long r = (nextLong() >>> 33) % bound;
        return (int) r;
    }
}
