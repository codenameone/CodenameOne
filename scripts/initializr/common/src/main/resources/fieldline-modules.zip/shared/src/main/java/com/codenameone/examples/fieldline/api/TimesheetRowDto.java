package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// One technician's week: the paid minutes their roster holds
/// (`plannedMinutes`), what they clocked on shift, driving, on
/// site and on a break, the overtime past their regular week, and what it
/// cost at their rate.
@Mapped
public record TimesheetRowDto(
        String techId,
        String name,
        String rateName,
        int plannedMinutes,
        int shiftMinutes,
        int travelMinutes,
        int jobMinutes,
        int breakMinutes,
        int overtimeMinutes,
        int weekendMinutes,
        int callouts,
        long costCents,
        List<TimeEntryDto> entries) {
}
