package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// What an account says about itself.
@Mapped
public record ProfileDto(
        String name,
        String phone) {
}
