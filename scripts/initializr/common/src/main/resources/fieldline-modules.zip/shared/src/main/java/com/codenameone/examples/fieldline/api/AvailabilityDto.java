package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A technician's standing constraints, which the scheduler treats as hard limits.
@Mapped
public record AvailabilityDto(
        String techId,
        List<WindowDto> week,
        int maxDriveMinutes,
        int maxHoursPerWeek,
        int regularHoursPerWeek) {
}
