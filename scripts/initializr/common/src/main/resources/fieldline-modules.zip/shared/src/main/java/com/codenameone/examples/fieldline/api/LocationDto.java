package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// Where a technician is.
@Mapped
public record LocationDto(
        double lat,
        double lng) {
}
