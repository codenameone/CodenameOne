package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// One day of the staffing report: the minutes the crew is available
/// (rostered, less time off and breaks), the minutes of work due that day,
/// what the plan fills with work and driving, and the work it could not place.
@Mapped
public record DayLoadDto(
        long day,
        int capacityMinutes,
        int demandMinutes,
        int workMinutes,
        int driveMinutes,
        int unassignedMinutes) {
}
