package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// Clocking in (`in` true) or out.
@Mapped
public record ClockDto(
        boolean in) {
}
