package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A technician's day: their route in order and how it is going, and when
/// they clocked in, or 0 while they are off the clock.
@Mapped
public record TodayDto(
        TechnicianDto me,
        List<JobDto> jobs,
        int driveMinutes,
        int done,
        long day,
        long clockedInAt) {
}
