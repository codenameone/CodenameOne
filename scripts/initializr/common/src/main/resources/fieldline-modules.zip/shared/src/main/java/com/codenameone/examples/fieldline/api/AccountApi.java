package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.PUT;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

/// Opening an account, asking who is signed in, and the
/// settings an account keeps.
///
/// The app calls these through the generated client. The server implements the
/// generated `AccountApiServer`, and its build routes each path to that
/// implementation; neither side writes the other's half.
@RestClient
public interface AccountApi {
    /// Opens an account. The one call here that needs no sign-in.
    @POST("/api/account/register")
    void register(@Body RegisterDto request, OnComplete<Response<UserDto>> callback);

    @GET("/api/me")
    void me(OnComplete<Response<UserDto>> callback);

    /// A ticket for the live channel; see [TicketDto].
    @POST("/api/live/ticket")
    void liveTicket(OnComplete<Response<TicketDto>> callback);

    @GET("/api/account/preferences")
    void preferences(OnComplete<Response<PreferencesDto>> callback);

    @PUT("/api/account/preferences")
    void savePreferences(@Body PreferencesDto preferences,
            OnComplete<Response<PreferencesDto>> callback);

    @GET("/api/account/profile")
    void profile(OnComplete<Response<ProfileDto>> callback);

    @PUT("/api/account/profile")
    void saveProfile(@Body ProfileDto profile, OnComplete<Response<UserDto>> callback);

    @POST("/api/account/password")
    void changePassword(@Body PasswordChangeDto change, OnComplete<Response<UserDto>> callback);

    /// Closes the account for good. Refused without the account's password: a token is what a borrowed phone
    /// holds too, and this cannot be taken back.
    @POST("/api/account/delete")
    void deleteAccount(@Body AccountClosureDto closure, OnComplete<Response<UserDto>> callback);

    /// Records a device the signed-in account is to be sent notifications on.
    /// Registering the same token again moves it to this account: a phone
    /// belongs to whoever signed in on it last.
    @POST("/api/account/push")
    void registerPush(@Body PushDeviceDto device, OnComplete<Response<PushDeviceDto>> callback);

    /// Forgets a device, on signing out: the next person to use the phone is
    /// not to be told about this account's jobs.
    @POST("/api/account/push/remove")
    void unregisterPush(@Body PushDeviceDto device, OnComplete<Response<PushDeviceDto>> callback);
}
