package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// One run of the scheduler: what it was asked, what it changed and what that bought.
@Mapped
public record ScheduleRunDto(
        String id,
        long at,
        String kind,
        String summary,
        KpiDto before,
        KpiDto after,
        List<ChangeDto> changes,
        String operators,
        int iterations,
        long millis) {
}
