package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A labour rate: pay per hour, the overtime and weekend multipliers as
/// percentages of it, and the fee an urgent call-out adds. `members` counts
/// the technicians paid at it.
@Mapped
public record RateDto(
        String id,
        String name,
        int hourlyCents,
        int overtimePct,
        int weekendPct,
        int calloutCents,
        int members) {
}
