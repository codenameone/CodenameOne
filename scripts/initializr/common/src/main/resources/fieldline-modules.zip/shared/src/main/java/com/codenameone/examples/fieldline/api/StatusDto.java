package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A technician moving a job along: EN_ROUTE, ON_SITE, COMPLETED. The position is where they were.
@Mapped
public record StatusDto(
        String status,
        double lat,
        double lng) {
}
