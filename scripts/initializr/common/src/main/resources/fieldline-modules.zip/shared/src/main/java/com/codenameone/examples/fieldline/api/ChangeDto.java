package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// One job a re-plan moved, and why.
@Mapped
public record ChangeDto(
        String jobId,
        String jobTitle,
        String fromTech,
        String toTech,
        long fromStart,
        long toStart,
        String reason) {
}
