package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A meal break the plan placed in a technician's day.
@Mapped
public record BreakDto(
        String techId,
        long start,
        long end) {
}
