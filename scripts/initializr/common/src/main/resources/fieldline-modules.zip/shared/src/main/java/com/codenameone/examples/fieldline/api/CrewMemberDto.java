package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A technician record as the admin edits it: the skills the planner matches
/// jobs against, the limits it plans within, and whether it plans them at all.
@Mapped
public record CrewMemberDto(
        String id,
        String name,
        String initials,
        String color,
        String username,
        List<String> skills,
        String homeLabel,
        int maxDriveMinutes,
        int regularMinutesPerWeek,
        int maxMinutesPerWeek,
        boolean active,
        List<String> certifications,
        List<String> territories,
        int maxJobsPerDay,
        int maxMinutesPerDay,
        String rateId) {
}
