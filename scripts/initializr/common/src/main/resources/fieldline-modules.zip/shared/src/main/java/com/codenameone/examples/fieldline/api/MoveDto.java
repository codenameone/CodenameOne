package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A dispatcher dragging a job: to this technician at this start. `apply` false only validates.
@Mapped
public record MoveDto(
        String jobId,
        String techId,
        long start,
        boolean apply) {
}
