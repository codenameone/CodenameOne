package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// The figures a dispatcher compares between two plans.
@Mapped
public record KpiDto(
        int scheduled,
        int unassigned,
        int driveMinutes,
        int overtimeMinutes,
        int utilizationPct,
        int highPriorityOpen,
        int lateJobs) {
}
