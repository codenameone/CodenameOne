package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// Whether a move is allowed, and if not, which constraint refuses it.
@Mapped
public record ValidationDto(
        boolean ok,
        String message,
        List<String> warnings,
        JobDto job) {
}
