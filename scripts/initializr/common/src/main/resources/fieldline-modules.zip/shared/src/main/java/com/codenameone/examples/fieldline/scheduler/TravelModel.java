package com.codenameone.examples.fieldline.scheduler;

/// Driving minutes between two points given in microdegrees. Plug a routing
/// service in here; the solver only ever reads the precomputed matrix.
public interface TravelModel {
    int minutes(int lat1, int lon1, int lat2, int lon2);
}
