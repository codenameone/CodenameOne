package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A dispatcher moving a job between the intake states: UNASSIGNED,
/// AWAITING_PARTS or BLOCKED.
@Mapped
public record IntakeDto(String status) {
}
