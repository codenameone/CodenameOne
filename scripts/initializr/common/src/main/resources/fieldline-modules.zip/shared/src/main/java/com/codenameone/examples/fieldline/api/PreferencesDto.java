package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// Settings that follow the account between devices.
@Mapped
public record PreferencesDto(
        String language,
        String theme,
        boolean notifyAssignments,
        boolean notifyScheduleChanges,
        boolean calendarSync,
        boolean aiAssist) {
}
