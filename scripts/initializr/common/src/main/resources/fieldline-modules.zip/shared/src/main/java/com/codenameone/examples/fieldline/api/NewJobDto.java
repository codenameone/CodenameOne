package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A job a dispatcher creates. `siteId` names a known site.
@Mapped
public record NewJobDto(
        String title,
        String kind,
        int priority,
        String siteId,
        String description,
        int durationMinutes,
        List<String> skills,
        long windowStart,
        long windowEnd,
        long dueAt,
        List<String> certifications,
        String afterJobId,
        List<String> excludedTechs) {
}
