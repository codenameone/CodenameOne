package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// What the assistant saw in a photo. `severity` is LOW, MEDIUM, HIGH or CRITICAL; `source` is the model that answered, or `demo`.
@Mapped
public record DiagnosisDto(
        String issue,
        String severity,
        String likelyCause,
        String recommendedAction,
        List<String> parts,
        int confidence,
        String safetyNote,
        String source) {
}
