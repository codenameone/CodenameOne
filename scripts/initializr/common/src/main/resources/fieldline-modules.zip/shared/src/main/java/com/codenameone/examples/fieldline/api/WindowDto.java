package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A weekly working window: `day` 0 (Monday) to 6, minutes from midnight.
@Mapped
public record WindowDto(
        int day,
        int start,
        int end) {
}
