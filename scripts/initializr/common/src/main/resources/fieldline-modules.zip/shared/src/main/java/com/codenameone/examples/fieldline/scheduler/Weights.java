package com.codenameone.examples.fieldline.scheduler;

/// The soft-constraint weights. Every cost is an integer so two runtimes always
/// agree on which of two schedules is better.
public final class Weights {
    /// Per minute of driving.
    public int travel = 10;
    /// Per minute past a technician's regular hours.
    public int overtime = 15;
    /// Times priority squared, per job left unplaced.
    public int unassigned = 20000;
    /// Per job not given to its preferred technician.
    public int continuity = 300;
    /// Per job moved off the technician that held it before a re-plan.
    public int disruption = 800;
    /// Per minute of idle waiting before a window opens.
    public int waiting = 1;
    /// Times the squared deviation (in hours) from the mean workload.
    public int balance = 40;
    /// Per minute a job finishes past its SLA deadline, times its priority.
    public int lateness = 30;
    /// Per job done outside the technician's territories, when territories
    /// are a preference rather than a rule.
    public int outOfTerritory = 400;
    /// When true a technician is never sent outside their territories.
    public boolean strictTerritories;
}
