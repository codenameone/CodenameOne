package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A customer's sign-off. `reportHash` is a SHA-256 over the job report, the signature, the time and the place; `verified` says the stored report still hashes to it.
@Mapped
public record SignatureDto(
        String jobId,
        String signerName,
        String png,
        long signedAt,
        double lat,
        double lng,
        String reportHash,
        boolean verified) {
}
