package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A visit, as both the board and the technician see it. Times are epoch milliseconds, 0 when unset.
@Mapped
public record JobDto(
        String id,
        String title,
        String kind,
        String status,
        int priority,
        String siteId,
        String siteName,
        String address,
        double lat,
        double lng,
        String customer,
        String contactPhone,
        String assetType,
        String assetModel,
        String description,
        int durationMinutes,
        List<String> skills,
        long windowStart,
        long windowEnd,
        String techId,
        String techName,
        long plannedStart,
        long plannedEnd,
        int travelBefore,
        int sequence,
        long actualStart,
        long actualEnd,
        List<CheckDto> checklist,
        int photos,
        boolean signed,
        String notes,
        long dueAt,
        List<String> certifications,
        String afterJobId,
        List<String> excludedTechs,
        String territory,
        String unassignedReason) {
}
