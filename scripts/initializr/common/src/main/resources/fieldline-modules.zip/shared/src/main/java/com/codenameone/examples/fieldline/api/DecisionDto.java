package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A dispatcher answering a time-off request.
@Mapped
public record DecisionDto(
        boolean approve) {
}
