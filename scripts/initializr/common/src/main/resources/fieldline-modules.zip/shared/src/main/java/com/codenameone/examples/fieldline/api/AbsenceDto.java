package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// A sick call or other sudden absence: re-plan around it now.
@Mapped
public record AbsenceDto(
        String techId,
        long start,
        long end,
        String reason) {
}
