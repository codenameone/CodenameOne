package com.codenameone.examples.fieldline.scheduler;

/// One continuous stretch of a technician's availability, after time off has
/// been cut out of it. Each shift is one route: it leaves home at `start` and
/// must be home again by `end`.
public final class Shift {
    final int tech;
    final int start;
    final int end;

    Shift(int tech, int start, int end) {
        this.tech = tech;
        this.start = start;
        this.end = end;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }
}
