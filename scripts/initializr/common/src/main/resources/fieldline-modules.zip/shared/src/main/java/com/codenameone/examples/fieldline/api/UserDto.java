package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// An account as the app sees it. A technician account carries the id of its technician record.
@Mapped
public record UserDto(
        String username,
        String displayName,
        String phone,
        boolean technician,
        boolean dispatcher,
        boolean admin,
        boolean suspended,
        String techId,
        String language) {
}
