package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// The staffing report: capacity against demand by day and by skill, every
/// technician's load, how many jobs meet their SLA, and why the rest of the
/// work is unplaced. `lowPct` and `highPct` bound a healthy load: a day under
/// the first is overstaffed, a day over the second understaffed.
/// `plannedCostCents` is what the planned hours cost at each technician's rate.
@Mapped
public record StaffingDto(
        long from,
        int lowPct,
        int highPct,
        List<DayLoadDto> days,
        List<SkillLoadDto> skills,
        List<TechLoadDto> technicians,
        int jobsDue,
        int onTime,
        int late,
        int unassigned,
        List<ReasonCountDto> reasons,
        long plannedCostCents) {
}
