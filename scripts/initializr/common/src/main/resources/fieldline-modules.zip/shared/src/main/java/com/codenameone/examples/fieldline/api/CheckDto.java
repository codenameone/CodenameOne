package com.codenameone.examples.fieldline.api;

import com.codename1.annotations.Mapped;

/// One line of a checklist: `result` is PASS, FAIL, NA or empty.
@Mapped
public record CheckDto(
        int index,
        String label,
        String result,
        String note) {
}
