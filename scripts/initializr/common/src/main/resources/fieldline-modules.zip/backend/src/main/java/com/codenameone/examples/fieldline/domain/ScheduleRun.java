package com.codenameone.examples.fieldline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One run of the optimizer and what it changed. The key figures before and
/// after are kept as `scheduled,unassigned,drive,overtime,utilization,urgentOpen`.
@Entity
public class ScheduleRun {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(40)")
    private String id = "";

    @Column(nullable = false)
    private long ranAt;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String kind = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String summary = "";

    @Column(nullable = false, type = "VARCHAR(120)")
    private String beforeKpis = "";

    @Column(nullable = false, type = "VARCHAR(120)")
    private String afterKpis = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String operators = "";

    @Column(nullable = false)
    private int iterations;

    @Column(nullable = false)
    private long millis;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String actor = "";

    public ScheduleRun() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getRanAt() {
        return ranAt;
    }

    public void setRanAt(long ranAt) {
        this.ranAt = ranAt;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getBeforeKpis() {
        return beforeKpis;
    }

    public void setBeforeKpis(String beforeKpis) {
        this.beforeKpis = beforeKpis;
    }

    public String getAfterKpis() {
        return afterKpis;
    }

    public void setAfterKpis(String afterKpis) {
        this.afterKpis = afterKpis;
    }

    public String getOperators() {
        return operators;
    }

    public void setOperators(String operators) {
        this.operators = operators;
    }

    public int getIterations() {
        return iterations;
    }

    public void setIterations(int iterations) {
        this.iterations = iterations;
    }

    public long getMillis() {
        return millis;
    }

    public void setMillis(long millis) {
        this.millis = millis;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }
}
