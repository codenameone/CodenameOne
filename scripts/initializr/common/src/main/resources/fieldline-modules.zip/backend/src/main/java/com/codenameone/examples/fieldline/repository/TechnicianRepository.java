package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.Technician;

import java.util.List;

/// Technicians. `active` ones are the ones the scheduler plans for.
@Repository(entity = Technician.class, key = String.class)
public interface TechnicianRepository extends CrudRepository<Technician, String> {
    Technician findByUsername(String username);

    @Query("select t from Technician t where t.active = true order by t.name asc, t.id asc")
    List<Technician> active();
}
