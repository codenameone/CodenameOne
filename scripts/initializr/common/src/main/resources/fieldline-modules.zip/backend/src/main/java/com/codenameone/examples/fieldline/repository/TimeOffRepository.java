package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.TimeOff;

import java.util.List;

/// Time-off requests and approved absences.
@Repository(entity = TimeOff.class, key = String.class)
public interface TimeOffRepository extends CrudRepository<TimeOff, String> {
    @Query("select t from TimeOff t where t.techId = :tech order by t.startAt desc")
    List<TimeOff> ofTechnician(@Param("tech") String techId);

    /// Every request overlapping the span from `from` to `to`, any status,
    /// earliest first.
    @Query("select t from TimeOff t where t.endAt > :from and t.startAt < :to order by t.startAt asc")
    List<TimeOff> overlapping(@Param("from") long from, @Param("to") long to);

    @Query("select t from TimeOff t where t.status = :status order by t.startAt asc")
    List<TimeOff> withStatus(@Param("status") String status);
}
