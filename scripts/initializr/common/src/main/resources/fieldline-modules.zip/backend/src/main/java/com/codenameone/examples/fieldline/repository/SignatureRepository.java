package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.Signature;

/// Sign-offs, keyed by the job they sign.
@Repository(entity = Signature.class, key = String.class)
public interface SignatureRepository extends CrudRepository<Signature, String> {
}
