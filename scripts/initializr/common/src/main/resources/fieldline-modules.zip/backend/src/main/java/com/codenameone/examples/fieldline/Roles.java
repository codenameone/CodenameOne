package com.codenameone.examples.fieldline;

/// The roles an account can hold. A technician works the jobs assigned to
/// them; a dispatcher plans everybody's work; an admin manages accounts. The
/// app opens on the mode of the strongest role the account holds and offers
/// the others from its menu.
public final class Roles {
    public static final String TECHNICIAN = "TECHNICIAN";
    public static final String DISPATCHER = "DISPATCHER";
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
