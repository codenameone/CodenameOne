package com.codenameone.examples.fieldline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A pay rate technicians are costed at: an hourly rate, the uplift for
/// overtime and weekend hours, and the fee an urgent call-out adds.
@Entity
public class LabourRate {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(40)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(80)")
    private String name = "";

    @Column(nullable = false)
    private int hourlyCents;

    @Column(nullable = false)
    private int overtimePct = 150;

    @Column(nullable = false)
    private int weekendPct = 200;

    @Column(nullable = false)
    private int calloutCents;

    public LabourRate() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHourlyCents() {
        return hourlyCents;
    }

    public void setHourlyCents(int hourlyCents) {
        this.hourlyCents = hourlyCents;
    }

    public int getOvertimePct() {
        return overtimePct;
    }

    public void setOvertimePct(int overtimePct) {
        this.overtimePct = overtimePct;
    }

    public int getWeekendPct() {
        return weekendPct;
    }

    public void setWeekendPct(int weekendPct) {
        this.weekendPct = weekendPct;
    }

    public int getCalloutCents() {
        return calloutCents;
    }

    public void setCalloutCents(int calloutCents) {
        this.calloutCents = calloutCents;
    }
}
