package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.TimeEntry;

import java.util.List;

/// Clocked time.
@Repository(entity = TimeEntry.class, key = String.class)
public interface TimeEntryRepository extends CrudRepository<TimeEntry, String> {
    /// A technician's spans that start inside the span from `from` to `to`,
    /// earliest first.
    @Query("select t from TimeEntry t where t.techId = :tech and t.startAt >= :from and t.startAt < :to order by t.startAt asc")
    List<TimeEntry> ofTechnician(@Param("tech") String techId, @Param("from") long from, @Param("to") long to);

    /// A technician's spans still open, of any kind.
    @Query("select t from TimeEntry t where t.techId = :tech and t.endAt = 0 order by t.startAt asc")
    List<TimeEntry> open(@Param("tech") String techId);
}
