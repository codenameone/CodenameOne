package com.codenameone.examples.fieldline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A passage of an equipment manual, the unit the assistant retrieves.
/// `terms` holds the passage's words folded for matching.
@Entity
public class ManualChunk {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(40)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String assetType = "";

    @Column(nullable = false, type = "VARCHAR(160)")
    private String title = "";

    @Column(nullable = false, type = "VARCHAR(2000)")
    private String body = "";

    @Column(nullable = false, type = "VARCHAR(2000)")
    private String terms = "";

    public ManualChunk() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }
}
