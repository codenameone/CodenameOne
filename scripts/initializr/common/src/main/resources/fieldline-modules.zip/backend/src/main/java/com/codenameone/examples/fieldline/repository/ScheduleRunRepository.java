package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.ScheduleRun;

import java.util.List;

/// Runs of the scheduler.
@Repository(entity = ScheduleRun.class, key = String.class)
public interface ScheduleRunRepository extends CrudRepository<ScheduleRun, String> {
    @Query("select r from ScheduleRun r order by r.ranAt desc")
    List<ScheduleRun> newestFirst();
}
