package com.codenameone.examples.fieldline;

import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codename1.backend.test.MockMvc;
import com.codename1.backend.test.MockRequestBuilder;
import com.codenameone.examples.fieldline.account.Accounts;
import com.codenameone.examples.fieldline.account.DemoAccounts;
import com.codenameone.examples.fieldline.live.LiveTickets;
import org.junit.jupiter.api.Test;

import static com.codename1.backend.test.MockMvcRequestBuilders.get;
import static com.codename1.backend.test.MockMvcRequestBuilders.post;
import static com.codename1.backend.test.MockMvcResultMatchers.jsonPath;
import static com.codename1.backend.test.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/// Who may call what, with tokens earned by signing in: these go through the
/// decoder and the role lookup the app's own requests go through.
@BackendTest
class AccessTest {
    @Autowired
    private MockMvc mvc;
    @Autowired
    private Accounts accounts;
    @Autowired
    private LiveTickets tickets;

    private MockRequestBuilder as(MockRequestBuilder request, String token) {
        return request.header("Host", SignIn.HOST).header("Authorization", "Bearer " + token);
    }

    @Test
    void eachRoleReachesItsOwnPartOfTheApi() throws Exception {
        String tech = SignIn.token(mvc, DemoAccounts.TECHNICIAN, DemoAccounts.PASSWORD);
        String dispatcher = SignIn.token(mvc, DemoAccounts.DISPATCHER, DemoAccounts.PASSWORD);

        mvc.perform(as(get("/api/me"), tech)).andExpect(status().isOk())
                .andExpect(jsonPath("$.technician").value(true))
                .andExpect(jsonPath("$.dispatcher").value(false));
        mvc.perform(as(get("/api/my/day"), tech)).andExpect(status().isOk())
                .andExpect(jsonPath("$.me.name").value("Dana Okafor"));
        mvc.perform(as(get("/api/dispatch/board?day=0&days=5"), tech))
                .andExpect(status().isForbidden());

        mvc.perform(as(get("/api/dispatch/board?day=0&days=5"), dispatcher))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.technicians.length()").value(12));
        // A dispatcher is not on the crew, so has no day of their own.
        mvc.perform(as(get("/api/my/day"), dispatcher)).andExpect(status().isForbidden());
    }

    @Test
    void aNewAccountIsATechnicianOnTheCrew() throws Exception {
        String username = People.technician(accounts, "newcomer");
        String token = SignIn.token(mvc, username, People.PASSWORD);
        mvc.perform(as(get("/api/my/availability"), token)).andExpect(status().isOk())
                .andExpect(jsonPath("$.week.length()").value(5));
        mvc.perform(as(get("/api/dispatch/runs"), token)).andExpect(status().isForbidden());
    }

    @Test
    void aLiveTicketIsGoodOnce() throws Exception {
        String tech = SignIn.token(mvc, DemoAccounts.TECHNICIAN, DemoAccounts.PASSWORD);
        mvc.perform(post("/api/live/ticket")).andExpect(status().isUnauthorized());
        String body = mvc.perform(as(post("/api/live/ticket"), tech))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.expiresInSeconds").value(30))
                .andReturn().getResponse().getContentAsString();
        String ticket = (String) com.codename1.backend.Json.parseObject(body).get("ticket");
        assertEquals(DemoAccounts.TECHNICIAN, tickets.redeem(ticket));
        assertNull(tickets.redeem(ticket));
        assertNull(tickets.redeem("not-a-ticket"));
    }

    @Test
    void placesAreFoundThroughTheServer() throws Exception {
        String tech = SignIn.token(mvc, DemoAccounts.TECHNICIAN, DemoAccounts.PASSWORD);
        mvc.perform(get("/api/geo/search?q=pioneer&lat=45.52&lng=-122.68"))
                .andExpect(status().isUnauthorized());
        mvc.perform(as(get("/api/geo/search?q=PIONEER&lat=45.52&lng=-122.68"), tech))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Pioneer Courthouse Square"));
        // Too little to search for.
        mvc.perform(as(get("/api/geo/search?q=pi&lat=45.52&lng=-122.68"), tech))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
        mvc.perform(as(get("/api/geo/reverse?lat=45.5290&lng=-122.6766"), tech))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Union Station"))
                .andExpect(jsonPath("$.lat").value(45.5290));
    }
}
