package com.codenameone.examples.fieldline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One line of a job's checklist. `result` is PASS, FAIL or NA, empty while
/// unanswered.
@Entity
public class JobCheck {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(48)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String jobId = "";

    @Column(nullable = false)
    private int ordinal;

    @Column(nullable = false, type = "VARCHAR(255)")
    private String label = "";

    @Column(nullable = false, type = "VARCHAR(8)")
    private String result = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String note = "";

    public JobCheck() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public int getOrdinal() {
        return ordinal;
    }

    public void setOrdinal(int ordinal) {
        this.ordinal = ordinal;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
