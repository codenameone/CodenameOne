package com.codenameone.examples.fieldline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// What an account chose in Settings. A missing row reads as the defaults.
@Entity
public class Preference {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false, type = "VARCHAR(8)")
    private String theme = "";

    @Column(nullable = false)
    private boolean notifyAssignments;

    @Column(nullable = false)
    private boolean notifyScheduleChanges;

    @Column(nullable = false)
    private boolean calendarSync;

    @Column(nullable = false)
    private boolean aiAssist;

    public Preference() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public boolean isNotifyAssignments() {
        return notifyAssignments;
    }

    public void setNotifyAssignments(boolean notifyAssignments) {
        this.notifyAssignments = notifyAssignments;
    }

    public boolean isNotifyScheduleChanges() {
        return notifyScheduleChanges;
    }

    public void setNotifyScheduleChanges(boolean notifyScheduleChanges) {
        this.notifyScheduleChanges = notifyScheduleChanges;
    }

    public boolean isCalendarSync() {
        return calendarSync;
    }

    public void setCalendarSync(boolean calendarSync) {
        this.calendarSync = calendarSync;
    }

    public boolean isAiAssist() {
        return aiAssist;
    }

    public void setAiAssist(boolean aiAssist) {
        this.aiAssist = aiAssist;
    }
}
