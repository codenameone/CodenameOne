package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.LabourRate;

/// The labour rate table.
@Repository(entity = LabourRate.class, key = String.class)
public interface LabourRateRepository extends CrudRepository<LabourRate, String> {
}
