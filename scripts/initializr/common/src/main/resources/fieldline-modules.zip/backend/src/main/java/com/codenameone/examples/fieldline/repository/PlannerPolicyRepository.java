package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.PlannerPolicy;

/// The planner policy. One row, keyed by [PlannerPolicy#ID]; a missing row
/// reads as the defaults.
@Repository(entity = PlannerPolicy.class, key = String.class)
public interface PlannerPolicyRepository extends CrudRepository<PlannerPolicy, String> {
}
