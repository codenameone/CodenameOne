package com.codenameone.examples.fieldline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One job a schedule run moved, and why.
@Entity
public class ScheduleChange {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(48)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String runId = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String jobId = "";

    @Column(nullable = false, type = "VARCHAR(160)")
    private String jobTitle = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String fromTech = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String toTech = "";

    @Column(nullable = false)
    private long fromStart;

    @Column(nullable = false)
    private long toStart;

    @Column(nullable = false, type = "VARCHAR(255)")
    private String reason = "";

    public ScheduleChange() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getFromTech() {
        return fromTech;
    }

    public void setFromTech(String fromTech) {
        this.fromTech = fromTech;
    }

    public String getToTech() {
        return toTech;
    }

    public void setToTech(String toTech) {
        this.toTech = toTech;
    }

    public long getFromStart() {
        return fromStart;
    }

    public void setFromStart(long fromStart) {
        this.fromStart = fromStart;
    }

    public long getToStart() {
        return toStart;
    }

    public void setToStart(long toStart) {
        this.toStart = toStart;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
