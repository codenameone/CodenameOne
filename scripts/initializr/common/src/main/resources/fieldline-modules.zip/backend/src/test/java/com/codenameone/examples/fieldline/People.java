package com.codenameone.examples.fieldline;

import com.codename1.backend.test.MockRequestBuilder;
import com.codenameone.examples.fieldline.account.Accounts;
import com.codenameone.examples.fieldline.api.RegisterDto;

import static com.codename1.backend.test.SecurityMockMvcRequestPostProcessors.jwt;

/// The people a test needs, made fresh for it.
///
/// Every test class shares one running server and one database, so a test that
/// borrowed a demo account would meet whatever the test before it left behind.
/// Each test that changes an account makes its own.
final class People {
    static final String PASSWORD = "a-long-password";

    private People() {
    }

    /// Opens a technician's account, as the app's registration does, and
    /// returns its name.
    static String technician(Accounts accounts, String name) throws Exception {
        RegisterDto request = new RegisterDto(name + "@test.example", PASSWORD, name, "+15550111");
        return accounts.register(request).username();
    }

    /// The request, made as a technician. The authorities are stated here and
    /// not read from the account: `AccessTest` is the one that signs in for real.
    static MockRequestBuilder asTechnician(MockRequestBuilder request, String username) {
        return request.with(jwt().subject(username).authorities("ROLE_TECHNICIAN"));
    }

    static MockRequestBuilder asDispatcher(MockRequestBuilder request, String username) {
        return request.with(jwt().subject(username).authorities("ROLE_DISPATCHER"));
    }
}
