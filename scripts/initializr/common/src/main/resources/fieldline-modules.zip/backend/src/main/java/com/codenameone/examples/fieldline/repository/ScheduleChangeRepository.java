package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.ScheduleChange;

import java.util.List;

/// What each run changed.
@Repository(entity = ScheduleChange.class, key = String.class)
public interface ScheduleChangeRepository extends CrudRepository<ScheduleChange, String> {
    List<ScheduleChange> findByRunId(String runId);
}
