package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.ManualChunk;

import java.util.List;

/// Manual passages, the assistant's reference library.
@Repository(entity = ManualChunk.class, key = String.class)
public interface ManualChunkRepository extends CrudRepository<ManualChunk, String> {
    List<ManualChunk> findByAssetType(String assetType);
}
