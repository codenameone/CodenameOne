package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.JobCheck;

import java.util.List;

/// The lines of each job's checklist.
@Repository(entity = JobCheck.class, key = String.class)
public interface JobCheckRepository extends CrudRepository<JobCheck, String> {
    @Query("select c from JobCheck c where c.jobId = :job order by c.ordinal asc")
    List<JobCheck> ofJob(@Param("job") String jobId);
}
