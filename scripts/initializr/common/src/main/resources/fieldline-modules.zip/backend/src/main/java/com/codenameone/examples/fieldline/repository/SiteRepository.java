package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.Site;

import java.util.List;

/// Sites, the places jobs are done at.
@Repository(entity = Site.class, key = String.class)
public interface SiteRepository extends CrudRepository<Site, String> {
    @Query("select s from Site s order by s.name asc")
    List<Site> byName();
}
