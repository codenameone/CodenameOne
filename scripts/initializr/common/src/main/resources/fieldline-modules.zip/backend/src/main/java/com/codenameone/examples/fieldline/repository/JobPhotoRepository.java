package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.JobPhoto;

import java.util.List;

/// The photos of each job.
@Repository(entity = JobPhoto.class, key = String.class)
public interface JobPhotoRepository extends CrudRepository<JobPhoto, String> {
    @Query("select p from JobPhoto p where p.jobId = :job order by p.takenAt asc")
    List<JobPhoto> ofJob(@Param("job") String jobId);

    long countByJobId(String jobId);
}
