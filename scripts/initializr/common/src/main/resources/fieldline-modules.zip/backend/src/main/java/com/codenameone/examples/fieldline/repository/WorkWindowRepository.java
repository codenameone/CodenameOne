package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.WorkWindow;

import java.util.List;

/// The windows of each technician's regular week.
@Repository(entity = WorkWindow.class, key = String.class)
public interface WorkWindowRepository extends CrudRepository<WorkWindow, String> {
    @Query("select w from WorkWindow w where w.techId = :tech order by w.weekday asc, w.startMinute asc")
    List<WorkWindow> ofTechnician(@Param("tech") String techId);

    @Query("select w from WorkWindow w order by w.techId asc, w.weekday asc, w.startMinute asc")
    List<WorkWindow> everyone();

    int deleteByTechId(String techId);
}
