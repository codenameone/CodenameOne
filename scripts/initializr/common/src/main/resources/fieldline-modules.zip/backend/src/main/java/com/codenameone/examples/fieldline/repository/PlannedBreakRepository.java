package com.codenameone.examples.fieldline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.fieldline.domain.PlannedBreak;

import java.util.List;

/// The breaks the last plan placed.
@Repository(entity = PlannedBreak.class, key = String.class)
public interface PlannedBreakRepository extends CrudRepository<PlannedBreak, String> {
    @Query("select b from PlannedBreak b where b.endAt > :from and b.startAt < :to order by b.startAt asc")
    List<PlannedBreak> overlapping(@Param("from") long from, @Param("to") long to);
}
