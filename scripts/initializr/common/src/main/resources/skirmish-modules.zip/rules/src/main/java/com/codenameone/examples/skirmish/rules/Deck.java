package com.codenameone.examples.skirmish.rules;

/// Deck constants and the starter deck every new account receives.
public final class Deck {
    public static final int SIZE = 8;
    public static final int HAND = 4;

    private Deck() {
    }

    public static String[] starter() {
        return new String[] {"squire", "twin-archers", "ogre", "bat-swarm",
            "sharpshooter", "spearmen", "fire-orb", "arrow-rain"};
    }
}
