/// The game's rules: a deterministic simulation shared by the app, the server and
/// the replay viewer. Nothing here may touch a clock, a float, the UI or the network.
package com.codenameone.examples.skirmish.rules;
