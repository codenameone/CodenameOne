package com.codenameone.examples.skirmish.rules;

import java.util.ArrayList;
import java.util.List;

/// A splitter on one character. `String.split` takes a regular expression, which
/// not every Codename One runtime implements the same way; this one is plain.
final class Text {
    private Text() {
    }

    static String[] split(String s, char sep) {
        List<String> out = new ArrayList<String>();
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == sep) {
                out.add(s.substring(start, i));
                start = i + 1;
            }
        }
        out.add(s.substring(start));
        return out.toArray(new String[out.size()]);
    }
}
