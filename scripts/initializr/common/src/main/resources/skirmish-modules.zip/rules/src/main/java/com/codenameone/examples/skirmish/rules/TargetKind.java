package com.codenameone.examples.skirmish.rules;

/// What a card's attack may hit. Ints rather than an enum so the rules stay
/// trivially hashable and serializable.
public final class TargetKind {
    public static final int GROUND = 1;
    public static final int AIR = 2;
    public static final int BUILDINGS = 4;
    public static final int GROUND_AND_AIR = GROUND | AIR;

    private TargetKind() {
    }
}
