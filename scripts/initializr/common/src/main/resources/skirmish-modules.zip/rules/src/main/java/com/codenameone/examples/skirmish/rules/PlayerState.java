package com.codenameone.examples.skirmish.rules;

/// One side's elixir, deck cycle and crowns.
public final class PlayerState {
    /// Elixir is counted in ticks of regeneration: one elixir is 56 ticks, 2.8 seconds.
    public static final int ELIXIR_UNIT = 56;
    public static final int MAX_ELIXIR = 10 * ELIXIR_UNIT;
    public static final int START_ELIXIR = 5 * ELIXIR_UNIT;

    final String[] order;
    int elixir = START_ELIXIR;
    int crowns;

    PlayerState(String[] deck, Rng rng) {
        order = new String[deck.length];
        System.arraycopy(deck, 0, order, 0, deck.length);
        for (int i = order.length - 1; i > 0; i--) {
            int j = rng.nextInt(i + 1);
            String t = order[i];
            order[i] = order[j];
            order[j] = t;
        }
    }

    /// The raw elixir counter; divide by [#ELIXIR_UNIT] for whole elixir.
    public int elixir() { return elixir; }
    public int wholeElixir() { return elixir / ELIXIR_UNIT; }
    public int crowns() { return crowns; }

    /// Card in hand slot `i`, `0 <= i < Deck.HAND`.
    public String hand(int i) { return order[i]; }

    /// The card that enters the hand next.
    public String next() { return order[Deck.HAND]; }

    int handSlotOf(String cardId) {
        for (int i = 0; i < Deck.HAND; i++) {
            if (order[i].equals(cardId)) {
                return i;
            }
        }
        return -1;
    }

    /// Plays the card in `slot`: it goes to the back of the queue and the front of
    /// the queue takes its place in the hand.
    void cycle(int slot) {
        String played = order[slot];
        order[slot] = order[Deck.HAND];
        for (int i = Deck.HAND; i < order.length - 1; i++) {
            order[i] = order[i + 1];
        }
        order[order.length - 1] = played;
    }
}
