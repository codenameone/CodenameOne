package com.codenameone.examples.skirmish.rules.forge;

import java.util.ArrayList;
import java.util.List;

/// Missions played in order. Each one opens when the one before it has been won,
/// and the story is told between them.
public final class CampaignDef {
    public String id = "";
    public String name = "";
    /// Shown before the first mission.
    public String intro = "";
    /// Shown after the last one is won.
    public String outro = "";
    /// Mission ids of the same pack, in the order they are played.
    public List<String> missions = new ArrayList<String>();
    /// Stars needed in total before the last mission opens, 0 for none.
    public int finaleStars;

    /// Whether mission `index` is open, given the stars won on each mission so far.
    public boolean isOpen(int index, int[] starsByMission) {
        if (index == 0) {
            return true;
        }
        if (index < 0 || index >= missions.size() || starsByMission[index - 1] <= 0) {
            return false;
        }
        if (index == missions.size() - 1 && finaleStars > 0) {
            int total = 0;
            for (int i = 0; i < index; i++) {
                total += starsByMission[i];
            }
            return total >= finaleStars;
        }
        return true;
    }
}
