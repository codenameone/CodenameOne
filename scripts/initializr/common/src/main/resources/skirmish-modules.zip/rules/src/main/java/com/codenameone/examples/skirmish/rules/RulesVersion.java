package com.codenameone.examples.skirmish.rules;

/// Identifies the rules a replay was recorded under. Bump it whenever a change to
/// [Cards] or [Match] would make an old replay play out differently; the server
/// refuses to match two clients whose versions differ, and the replay viewer warns
/// when it re-runs a replay under newer rules.
public final class RulesVersion {
    public static final String ID = "1";

    private RulesVersion() {
    }
}
