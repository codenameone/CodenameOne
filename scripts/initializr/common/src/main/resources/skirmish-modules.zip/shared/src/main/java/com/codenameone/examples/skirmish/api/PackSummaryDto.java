package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// A pack as a browse list shows it. `rating` is the average of the stars
/// players gave it, times ten; `status` is draft, published or hidden.
@Mapped
public record PackSummaryDto(String id, String name, String author, String owner, String description, int version, String hash, boolean official, String status, int plays, int rating, int ratings, int missions, int cards, boolean pendingAssets, long updatedAt) {
}
