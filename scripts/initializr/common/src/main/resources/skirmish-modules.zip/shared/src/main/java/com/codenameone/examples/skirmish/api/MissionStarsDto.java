package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// The most stars a player has won on one mission.
@Mapped
public record MissionStarsDto(String packId, String missionId, int stars) {
}
