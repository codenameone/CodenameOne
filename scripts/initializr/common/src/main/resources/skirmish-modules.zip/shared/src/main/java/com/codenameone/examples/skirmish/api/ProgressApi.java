package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

/// Levels, daily quests, chests, achievements and the tutorial. The server
/// keeps the score: every reward is decided and granted there.
@RestClient
public interface ProgressApi {
    @GET("/api/progress")
    void progress(OnComplete<Response<ProgressDto>> callback);

    @POST("/api/progress/quest")
    void claimQuest(@Body ClaimDto quest, OnComplete<Response<RewardDto>> callback);

    @POST("/api/progress/chest")
    void openChest(OnComplete<Response<RewardDto>> callback);

    @POST("/api/progress/tutorial")
    void tutorialDone(OnComplete<Response<RewardDto>> callback);
}
