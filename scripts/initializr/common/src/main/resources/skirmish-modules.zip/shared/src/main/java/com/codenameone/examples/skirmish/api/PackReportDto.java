package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// A player telling the moderators about a pack.
@Mapped
public record PackReportDto(String packId, String reason) {
}
