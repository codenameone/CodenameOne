package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// A push notification sent to a segment of players. `segment` is `all`,
/// `lapsed` (not seen for `days`), `new` (joined in the last `days`) or
/// `invited` (joined through a friend). `screen` and `campaign` travel in
/// the push's data, so the app opens the right screen and reports the open
/// under the campaign. `targets` is how many players it reached.
@Mapped
public record BroadcastDto(String id, String segment, int days, String title, String body, String screen,
        String campaign, int targets, String sentBy, long sentAt) {
}
