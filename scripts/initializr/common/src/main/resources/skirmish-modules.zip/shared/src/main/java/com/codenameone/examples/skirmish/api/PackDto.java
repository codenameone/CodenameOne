package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// A pack's content, as the Forge's JSON, with what a browse list shows about it.
@Mapped
public record PackDto(PackSummaryDto summary, String content) {
}
