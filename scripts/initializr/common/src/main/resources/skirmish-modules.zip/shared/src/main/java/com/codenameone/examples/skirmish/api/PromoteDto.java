package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// What the console's Promote tab shows from the game's own records: players,
/// the invites the server credited, the players who bring others in, the
/// pushes sent and the home banner. Engagement, retention and revenue are not
/// here: they are in Codename One analytics, where the app reports them.
@Mapped
public record PromoteDto(int players, int joinedThisWeek, int invited, int invitedPlayed,
        List<InviterDto> inviters, List<BroadcastDto> broadcasts, SpotlightDto spotlight) {
}
