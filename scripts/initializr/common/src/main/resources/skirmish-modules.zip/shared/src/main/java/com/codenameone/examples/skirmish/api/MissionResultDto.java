package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// A finished mission: the replay the app recorded. The server plays it again
/// before it believes the result.
@Mapped
public record MissionResultDto(String replay) {
}
