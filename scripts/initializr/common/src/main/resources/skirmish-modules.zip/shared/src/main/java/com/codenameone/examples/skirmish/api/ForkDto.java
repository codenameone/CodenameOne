package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// Copies a published pack into a new draft named `newId`.
@Mapped
public record ForkDto(String newId) {
}
