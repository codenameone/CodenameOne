package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// Someone who joined through the player's invite. `state` is `joined`
/// until their first battle, then `played`; `rewarded` says whether that
/// battle paid the inviter.
@Mapped
public record FriendDto(String displayName, int trophies, String state, boolean rewarded, long joinedAt) {
}
