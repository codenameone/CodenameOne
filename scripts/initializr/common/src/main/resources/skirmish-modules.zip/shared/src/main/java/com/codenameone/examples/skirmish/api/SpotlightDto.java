package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// The banner every home screen shows: a line of text and, optionally, where a
/// tap on it goes -- a Forge pack, or a screen such as the shop. An empty
/// text hides it.
@Mapped
public record SpotlightDto(String text, String packId, String screen, long updatedAt) {
}
