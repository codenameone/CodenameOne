package com.codenameone.examples.skirmish.api;

import com.codename1.annotations.Mapped;

/// What a mission result earned. `stars` is this battle's, `best` the most
/// ever won on the mission.
@Mapped
public record MissionOutcomeDto(String packId, String missionId, int stars, int best, RewardDto reward) {
}
