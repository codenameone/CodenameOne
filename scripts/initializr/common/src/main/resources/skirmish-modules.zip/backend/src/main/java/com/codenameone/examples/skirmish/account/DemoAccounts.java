package com.codenameone.examples.skirmish.account;

import com.codename1.backend.Config;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.PostConstruct;
import com.codename1.backend.annotations.Value;
import com.codenameone.examples.skirmish.admin.Flags;
import com.codenameone.examples.skirmish.progress.Progression;
import java.io.IOException;

/// The accounts a development server starts with: two players to challenge
/// each other, one flagged player for the console to find, and an admin.
/// Anywhere else only the admin is made, and only when
/// `myappname.admin.email` and `myappname.admin.password` say who.
@Component
public class DemoAccounts {
    public static final String PLAYER = "player@myappname.example";
    public static final String RIVAL = "rival@myappname.example";
    public static final String TROUBLE = "trouble@myappname.example";
    public static final String ADMIN = "admin@myappname.example";
    public static final String PASSWORD = "myappname-demo";

    private final Accounts accounts;
    private final Flags flags;
    private final Progression progression;
    private final Config config;
    private final String adminEmail;
    private final String adminPassword;

    public DemoAccounts(Accounts accounts, Flags flags, Progression progression, Config config,
            @Value("${myappname.admin.email:}") String adminEmail,
            @Value("${myappname.admin.password:}") String adminPassword) {
        this.accounts = accounts;
        this.flags = flags;
        this.progression = progression;
        this.config = config;
        this.adminEmail = adminEmail;
        this.adminPassword = adminPassword;
    }

    @PostConstruct
    public void seed() throws IOException {
        if (!config.isDevelopmentProfile()) {
            if (adminEmail.length() > 0 && adminPassword.length() >= 8
                    && !accounts.exists(Accounts.email(adminEmail))) {
                accounts.create(Accounts.email(adminEmail), adminPassword, "Administrator", true);
            }
            return;
        }
        add(PLAYER, "Riley", false);
        add(RIVAL, "Morgan", false);
        add(ADMIN, "Game Master", true);
        if (!accounts.exists(TROUBLE)) {
            add(TROUBLE, "Sore Loser", false);
            flags.auto(TROUBLE, "Left three matches in a row", null);
        }
    }

    private void add(String username, String name, boolean admin) throws IOException {
        if (!accounts.exists(username)) {
            accounts.create(username, PASSWORD, name, admin);
            progression.seedDemo(username);
        }
    }
}
