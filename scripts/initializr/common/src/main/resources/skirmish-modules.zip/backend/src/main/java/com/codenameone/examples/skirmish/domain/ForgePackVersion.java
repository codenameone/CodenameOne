package com.codenameone.examples.skirmish.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// One published version of a pack, kept for good: replays and mission results
/// name the version they were played on.
@Entity
public class ForgePackVersion {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(60)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String packId = "";

    @Column(nullable = false)
    private int version;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String hash = "";

    @Column(nullable = false)
    private String content = "";

    @Column(nullable = false)
    private Instant publishedAt = Instant.EPOCH;

    public ForgePackVersion() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPackId() {
        return packId;
    }

    public void setPackId(String packId) {
        this.packId = packId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Instant getPublishedAt() {
        return publishedAt;
    }

    public void setPublishedAt(Instant publishedAt) {
        this.publishedAt = publishedAt;
    }
}
