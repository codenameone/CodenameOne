package com.codenameone.examples.skirmish.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A player who joined through someone's invite, keyed by that player: one
/// inviter each, for good.
@Entity
public class Referral {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String invitee = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String inviter = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String code = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String campaign = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String channel = "";

    @Column(nullable = false, type = "VARCHAR(20)")
    private String matchType = "";

    @Column(nullable = false, type = "VARCHAR(10)")
    private String state = "";

    @Column(nullable = false)
    private boolean rewarded;

    @Column(nullable = false)
    private long joinedAt;

    @Column(nullable = false)
    private long playedAt;

    public Referral() {
    }

    public String getInvitee() {
        return invitee;
    }

    public void setInvitee(String invitee) {
        this.invitee = invitee;
    }

    public String getInviter() {
        return inviter;
    }

    public void setInviter(String inviter) {
        this.inviter = inviter;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCampaign() {
        return campaign;
    }

    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getMatchType() {
        return matchType;
    }

    public void setMatchType(String matchType) {
        this.matchType = matchType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public boolean isRewarded() {
        return rewarded;
    }

    public void setRewarded(boolean rewarded) {
        this.rewarded = rewarded;
    }

    public long getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(long joinedAt) {
        this.joinedAt = joinedAt;
    }

    public long getPlayedAt() {
        return playedAt;
    }

    public void setPlayedAt(long playedAt) {
        this.playedAt = playedAt;
    }
}
