package com.codenameone.examples.skirmish;

/// Wall-clock time, in one place so day boundaries are computed the same way
/// everywhere (UTC days).
public final class Clock {
    public static final long DAY = 24L * 60 * 60 * 1000;

    private Clock() {
    }

    public static long now() {
        return System.currentTimeMillis();
    }

    /// Midnight UTC at the start of the day `millis` falls in.
    public static long dayOf(long millis) {
        return millis - millis % DAY;
    }
}
