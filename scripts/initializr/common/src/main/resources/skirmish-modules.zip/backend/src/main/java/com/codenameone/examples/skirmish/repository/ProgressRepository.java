package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.Progress;

/// Each account's levels, quests, chests and achievements.
@Repository(entity = Progress.class, key = String.class)
public interface ProgressRepository extends CrudRepository<Progress, String> {
}
