package com.codenameone.examples.skirmish.shop;

/// Development and tests: accepts the receipts the simulator's store produces,
/// which carry no signature to check. Refused outside development profiles.
public class SimulatedReceipts implements ReceiptValidator {
    @Override
    public String verify(String store, String sku, String transactionId, String receipt) {
        if (transactionId == null || transactionId.length() == 0 || sku == null) {
            return null;
        }
        return "sim:" + transactionId;
    }
}
