package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.Flag;
import java.util.List;

@Repository(entity = Flag.class, key = String.class)
public interface FlagRepository extends CrudRepository<Flag, String> {
    @Query("select f from Flag f where f.pending = :pending order by f.createdAt desc, f.id asc")
    List<Flag> inState(@Param("pending") boolean pending, PageRequest page);

    @Query("select f from Flag f where f.username = :u order by f.createdAt desc, f.id asc")
    List<Flag> of(@Param("u") String username, PageRequest page);

    long countByPendingTrue();

    long countByUsernameAndPendingTrue(String username);

    long countByReporterAndMatchId(String reporter, String matchId);
}
