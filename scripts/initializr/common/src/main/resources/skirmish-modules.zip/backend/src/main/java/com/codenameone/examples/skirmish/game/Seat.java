package com.codenameone.examples.skirmish.game;

import com.codename1.backend.WebSocketSession;

/// One side of a [MatchRoom]: a player and the socket they are on now, which
/// changes when they reconnect, or the server's bot.
final class Seat {
    final String username;
    final String name;
    final String[] deck;
    final int trophies;
    WebSocketSession session;
    /// Ticks at which this seat's recent plays arrived, for flood detection.
    final int[] recent = new int[8];
    int recentCount;
    int rejected;
    int floods;
    int desyncs;

    Seat(String username, String name, String[] deck, int trophies, WebSocketSession session) {
        this.username = username;
        this.name = name;
        this.deck = deck;
        this.trophies = trophies;
        this.session = session;
    }

    boolean isBot() {
        return username.length() == 0;
    }
}
