package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.MatchRecord;
import java.util.List;

@Repository(entity = MatchRecord.class, key = String.class)
public interface MatchRecordRepository extends CrudRepository<MatchRecord, String> {
    @Query("select m from MatchRecord m where m.player0 = :u or m.player1 = :u "
            + "order by m.endedAt desc, m.id asc")
    List<MatchRecord> of(@Param("u") String username, PageRequest page);

    long countByEndedAtGreaterThan(long since);
}
