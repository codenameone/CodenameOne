package com.codenameone.examples.skirmish.progress;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.skirmish.Caller;
import com.codenameone.examples.skirmish.api.ClaimDto;
import com.codenameone.examples.skirmish.api.ProgressApiServer;
import com.codenameone.examples.skirmish.api.ProgressDto;
import com.codenameone.examples.skirmish.api.RewardDto;

@Component
public class ProgressEndpoint implements ProgressApiServer {
    private final Progression progression;

    public ProgressEndpoint(Progression progression) {
        this.progression = progression;
    }

    @Override
    public ProgressDto progress() throws Exception {
        return progression.view(Caller.name());
    }

    @Override
    public RewardDto claimQuest(ClaimDto quest) throws Exception {
        return progression.claim(Caller.name(), quest == null ? null : quest.questId());
    }

    @Override
    public RewardDto openChest() throws Exception {
        return progression.openChest(Caller.name());
    }

    @Override
    public RewardDto tutorialDone() throws Exception {
        return progression.tutorialDone(Caller.name());
    }
}
