package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.Profile;
import java.util.List;

@Repository(entity = Profile.class, key = String.class)
public interface ProfileRepository extends CrudRepository<Profile, String> {
    /// Locks the row for the rest of the transaction; answers 0 when there is none.
    @Modifying
    @Query("update Profile p set p.createdAt = p.createdAt where p.username = :username")
    int hold(@Param("username") String username);

    @Query("select p from Profile p where p.banned = false order by p.trophies desc, p.username asc")
    List<Profile> leaders(PageRequest page);

    @Query("select p from Profile p where p.username like :q or p.displayName like :q "
            + "order by p.lastSeen desc, p.username asc")
    List<Profile> search(@Param("q") String like, PageRequest page);

    long countByFlaggedTrue();

    @Query("select count(p) from Profile p where p.banned = true or p.suspendedUntil > :now")
    Long suspended(@Param("now") long now);
}
