package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.ForgePackVersion;
import java.util.List;

@Repository(entity = ForgePackVersion.class, key = String.class)
public interface ForgePackVersionRepository extends CrudRepository<ForgePackVersion, String> {
    @Query("select v from ForgePackVersion v where v.packId = :p order by v.version desc")
    List<ForgePackVersion> of(@Param("p") String packId, PageRequest page);
}
