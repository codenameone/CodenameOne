package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.ForgeRating;

@Repository(entity = ForgeRating.class, key = String.class)
public interface ForgeRatingRepository extends CrudRepository<ForgeRating, String> {
}
