package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.ForgeEarning;

@Repository(entity = ForgeEarning.class, key = String.class)
public interface ForgeEarningRepository extends CrudRepository<ForgeEarning, String> {
}
