package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.MissionStars;
import java.util.List;

@Repository(entity = MissionStars.class, key = String.class)
public interface MissionStarsRepository extends CrudRepository<MissionStars, String> {
    @Query("select m from MissionStars m where m.username = :u and m.packId = :p order by m.missionId asc")
    List<MissionStars> of(@Param("u") String username, @Param("p") String packId, PageRequest page);
}
