package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.StorePurchase;
import java.util.List;

@Repository(entity = StorePurchase.class, key = String.class)
public interface StorePurchaseRepository extends CrudRepository<StorePurchase, String> {
    @Query("select s from StorePurchase s where s.username = :u order by s.createdAt desc, s.id asc")
    List<StorePurchase> of(@Param("u") String username);

    @Query("select s from StorePurchase s where s.createdAt >= :since")
    List<StorePurchase> since(@Param("since") long since);
}
