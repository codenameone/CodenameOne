package com.codenameone.examples.skirmish.social;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.skirmish.api.FriendDto;
import com.codenameone.examples.skirmish.api.InviteClaimDto;
import com.codenameone.examples.skirmish.api.InviteDto;
import com.codenameone.examples.skirmish.api.RewardDto;
import com.codenameone.examples.skirmish.api.SocialApiServer;
import com.codenameone.examples.skirmish.api.SpotlightDto;
import java.util.List;

@Component
public class SocialEndpoint implements SocialApiServer {
    private final Referrals referrals;
    private final Promotion promotion;

    public SocialEndpoint(Referrals referrals, Promotion promotion) {
        this.referrals = referrals;
        this.promotion = promotion;
    }

    @Override
    public InviteDto invite() throws Exception {
        return referrals.invite(Caller.name());
    }

    @Override
    public RewardDto claim(InviteClaimDto claim) throws Exception {
        return referrals.claim(Caller.name(), claim);
    }

    @Override
    public List<FriendDto> friends() throws Exception {
        return referrals.friends(Caller.name());
    }

    @Override
    public SpotlightDto spotlight() throws Exception {
        return promotion.spotlight();
    }
}
