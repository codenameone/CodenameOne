package com.codenameone.examples.skirmish.shop;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.skirmish.Caller;
import com.codenameone.examples.skirmish.api.AdRewardDto;
import com.codenameone.examples.skirmish.api.BuyDto;
import com.codenameone.examples.skirmish.api.EquipDto;
import com.codenameone.examples.skirmish.api.ReceiptDto;
import com.codenameone.examples.skirmish.api.ShopApiServer;
import com.codenameone.examples.skirmish.api.ShopItemDto;
import com.codenameone.examples.skirmish.api.WalletDto;
import java.util.List;

@Component
public class ShopEndpoint implements ShopApiServer {
    private final Shop shop;

    public ShopEndpoint(Shop shop) {
        this.shop = shop;
    }

    @Override
    public List<ShopItemDto> items() throws Exception {
        return Catalog.items();
    }

    @Override
    public WalletDto wallet() throws Exception {
        return shop.wallet(Caller.name());
    }

    @Override
    public WalletDto buy(BuyDto item) throws Exception {
        return shop.buy(Caller.name(), item == null ? null : item.itemId());
    }

    @Override
    public WalletDto equip(EquipDto arena) throws Exception {
        return shop.equip(Caller.name(), arena == null ? null : arena.arena());
    }

    @Override
    public WalletDto receipt(ReceiptDto receipt) throws Exception {
        return shop.receipt(Caller.name(), receipt);
    }

    @Override
    public WalletDto adReward(AdRewardDto reward) throws Exception {
        return shop.adReward(Caller.name());
    }
}
