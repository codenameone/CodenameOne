package com.codenameone.examples.skirmish.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A device an account is sent push notifications on.
///
/// Keyed by the hash of its provider and token, so a token is on one account at
/// a time: the phone belongs to whoever signed in on it last.
@Entity
public class PushDevice {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(64)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    /// `fcm`, `apns`, `huawei`, `wns` or `web`.
    @Column(nullable = false, type = "VARCHAR(16)")
    private String provider = "";

    @Column(nullable = false, type = "VARCHAR(1024)")
    private String token = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String platform = "";

    @Column(nullable = false)
    private long updatedAt;

    public PushDevice() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }
}
