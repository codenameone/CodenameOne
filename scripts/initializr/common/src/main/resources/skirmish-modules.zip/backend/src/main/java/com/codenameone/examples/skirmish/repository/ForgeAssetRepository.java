package com.codenameone.examples.skirmish.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.skirmish.domain.ForgeAsset;
import java.util.List;

@Repository(entity = ForgeAsset.class, key = String.class)
public interface ForgeAssetRepository extends CrudRepository<ForgeAsset, String> {
    @Query("select a from ForgeAsset a where a.status = :s order by a.createdAt asc, a.sha256 asc")
    List<ForgeAsset> inStatus(@Param("s") String status, PageRequest page);

    long countByOwnerAndCreatedAtGreaterThan(String owner, long since);
}
