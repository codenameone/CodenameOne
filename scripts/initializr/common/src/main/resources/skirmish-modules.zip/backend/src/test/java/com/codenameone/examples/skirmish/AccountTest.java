package com.codenameone.examples.skirmish;

import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codename1.backend.test.MockMvc;
import com.codenameone.examples.skirmish.account.Accounts;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

import static com.codename1.backend.test.MockMvcRequestBuilders.get;
import static com.codename1.backend.test.MockMvcRequestBuilders.post;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/// Opening an account, naming yourself and building a deck.
@BackendTest
class AccountTest {
    @Autowired
    private MockMvc mvc;
    @Autowired
    private Accounts accounts;

    @Test
    void aNewPlayerStartsWithTheStarterDeckAndAPurse() throws Exception {
        Map me = Api.json(mvc, Api.body(post("/api/account/register"),
                "{\"email\":\"newcomer@test.example\",\"password\":\"" + Api.PASSWORD
                        + "\",\"displayName\":\"Newcomer\"}"));
        String who = (String) me.get("username");
        assertEquals("Newcomer", me.get("displayName"));
        assertEquals(8, ((List) me.get("deck")).size());
        assertEquals(100L, Api.number(me, "coins"));
        assertEquals(20L, Api.number(me, "gems"));
        assertEquals(Boolean.FALSE, me.get("admin"));

        Map again = Api.json(mvc, Api.as(get("/api/me"), who));
        assertEquals(who, again.get("username"));
    }

    @Test
    void aNameHasToBeReadable() throws Exception {
        String who = Api.player(accounts, "renamer");
        assertEquals(400, Api.statusOf(mvc, Api.as(Api.body(post("/api/me/profile"),
                "{\"displayName\":\"x\"}"), who)));
        Map me = Api.json(mvc, Api.as(Api.body(post("/api/me/profile"),
                "{\"displayName\":\"Sir Renamer\"}"), who));
        assertEquals("Sir Renamer", me.get("displayName"));
    }

    @Test
    void aDeckIsEightDifferentPlayableCards() throws Exception {
        String who = Api.player(accounts, "deckbuilder");
        assertEquals(400, Api.statusOf(mvc, Api.as(Api.body(post("/api/deck"),
                "{\"cards\":[\"squire\",\"squire\",\"ogre\",\"drake\",\"imp-den\",\"fire-orb\","
                        + "\"arrow-rain\",\"spearmen\"]}"), who)));
        assertEquals(400, Api.statusOf(mvc, Api.as(Api.body(post("/api/deck"),
                "{\"cards\":[\"squire\",\"ogre\"]}"), who)));
        assertEquals(400, Api.statusOf(mvc, Api.as(Api.body(post("/api/deck"),
                "{\"cards\":[\"imp\",\"squire\",\"ogre\",\"drake\",\"imp-den\",\"fire-orb\","
                        + "\"arrow-rain\",\"spearmen\"]}"), who)));
        String good = "[\"bat-swarm\",\"squire\",\"ogre\",\"drake\",\"imp-den\",\"fire-orb\","
                + "\"arrow-rain\",\"spearmen\"]";
        Api.json(mvc, Api.as(Api.body(post("/api/deck"), "{\"cards\":" + good + "}"), who));
        List deck = (List) Api.json(mvc, Api.as(get("/api/deck"), who)).get("cards");
        assertEquals("bat-swarm", deck.get(0));
        assertTrue(deck.contains("drake"));
        assertFalse(deck.contains("twin-archers"));
    }

    @Test
    void theApiNeedsAToken() throws Exception {
        assertEquals(401, Api.statusOf(mvc, get("/api/me")));
        assertEquals(401, Api.statusOf(mvc, get("/api/deck")));
    }
}
