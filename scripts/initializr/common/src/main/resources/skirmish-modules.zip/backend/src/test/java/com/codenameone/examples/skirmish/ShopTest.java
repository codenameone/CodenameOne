package com.codenameone.examples.skirmish;

import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codename1.backend.test.MockMvc;
import com.codenameone.examples.skirmish.account.Accounts;
import com.codenameone.examples.skirmish.shop.Shop;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

import static com.codename1.backend.test.MockMvcRequestBuilders.get;
import static com.codename1.backend.test.MockMvcRequestBuilders.post;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/// Spending coins and gems, store receipts and rewarded ads. The test profile
/// checks receipts with the simulated store, which accepts any of them.
@BackendTest
class ShopTest {
    @Autowired
    private MockMvc mvc;
    @Autowired
    private Accounts accounts;

    @Test
    void anItemCostsWhatTheCatalogSaysAndIsOwnedOnce() throws Exception {
        String who = Api.player(accounts, "shopper");
        assertTrue(Api.list(mvc, Api.as(get("/api/shop"), who)).size() >= 6);
        // 100 coins buys nothing that costs 500.
        assertEquals(402, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/buy"),
                "{\"itemId\":\"arena-desert\"}"), who)));
        // A real-money item is never sold for coins.
        assertEquals(404, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/buy"),
                "{\"itemId\":\"gems-80\"}"), who)));
        assertEquals(402, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/buy"),
                "{\"itemId\":\"emotes-taunt\"}"), who)));
        Api.json(mvc, Api.as(Api.body(post("/api/shop/receipt"), "{\"store\":\"play\",\"sku\":"
                + "\"myappname.gems_80\",\"transactionId\":\"tx-shopper\",\"receipt\":\"r\"}"), who));
        Map wallet = Api.json(mvc, Api.as(Api.body(post("/api/shop/buy"),
                "{\"itemId\":\"emotes-taunt\"}"), who));
        assertEquals(70L, Api.number(wallet, "gems"));
        assertTrue(((List) wallet.get("owned")).size() >= 2);
        assertEquals(403, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/equip"),
                "{\"arena\":\"arena-frost\"}"), who)));
    }

    @Test
    void aReceiptIsRedeemedOnceAndOnlyByItsOwner() throws Exception {
        String who = Api.player(accounts, "buyer");
        String thief = Api.player(accounts, "thief");
        String receipt = "{\"store\":\"itunes\",\"sku\":\"myappname.gems_80\","
                + "\"transactionId\":\"tx-1001\",\"receipt\":\"opaque\"}";
        Map first = Api.json(mvc, Api.as(Api.body(post("/api/shop/receipt"), receipt), who));
        assertEquals(100L, Api.number(first, "gems"));
        // The app retries after a lost answer: the same purchase, granted once.
        Map again = Api.json(mvc, Api.as(Api.body(post("/api/shop/receipt"), receipt), who));
        assertEquals(100L, Api.number(again, "gems"));
        assertEquals(409, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/receipt"),
                receipt), thief)));
        assertEquals(404, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/receipt"),
                "{\"store\":\"itunes\",\"sku\":\"nope\",\"transactionId\":\"tx-2\",\"receipt\":\"r\"}"),
                who)));
    }

    @Test
    void rewardedAdsAreCappedPerDay() throws Exception {
        String who = Api.player(accounts, "watcher");
        long coins = 100;
        for (int i = 0; i < Shop.AD_REWARDS_PER_DAY; i++) {
            Map w = Api.json(mvc, Api.as(Api.body(post("/api/shop/ad-reward"), "{\"nonce\":\"n" + i
                    + "\"}"), who));
            coins += Shop.AD_REWARD_COINS;
            assertEquals(coins, Api.number(w, "coins"));
        }
        assertEquals(429, Api.statusOf(mvc, Api.as(Api.body(post("/api/shop/ad-reward"),
                "{\"nonce\":\"more\"}"), who)));
    }
}
