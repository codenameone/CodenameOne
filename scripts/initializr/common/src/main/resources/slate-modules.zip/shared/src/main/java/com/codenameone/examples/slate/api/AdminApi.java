package com.codenameone.examples.slate.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Accounts, for the OWNER role: who is a client, who is booked and who runs the business,
/// and who is blocked.
@RestClient
public interface AdminApi {
    @GET("/api/admin/users")
    void users(OnComplete<Response<List<UserDto>>> callback);

    @GET("/api/admin/users/{username}")
    void user(@Path("username") String username, OnComplete<Response<UserDetailDto>> callback);

    @POST("/api/admin/users/{username}/roles")
    void setRoles(@Path("username") String username, @Body RoleChangeDto roles,
            OnComplete<Response<UserDto>> callback);

    /// Blocks an account, or lifts the block.
    @POST("/api/admin/users/{username}/suspend")
    void suspend(@Path("username") String username, @Body SuspendDto suspend,
            OnComplete<Response<UserDto>> callback);

    @POST("/api/admin/users/{username}/flag")
    void flag(@Path("username") String username, @Body FlagDto flag,
            OnComplete<Response<UserDto>> callback);
}
