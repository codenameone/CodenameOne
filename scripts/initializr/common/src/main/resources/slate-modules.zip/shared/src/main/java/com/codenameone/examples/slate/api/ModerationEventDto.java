package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Something an owner did to an account, and why.
///
/// @param at Milliseconds since the epoch.
/// @param by The owner who did it.
/// @param action `flag`, `unflag`, `block`, `unblock`, `approve`, `reject`, `roles`.
@Mapped
public record ModerationEventDto(long at, String by, String action, String reason) {
}
