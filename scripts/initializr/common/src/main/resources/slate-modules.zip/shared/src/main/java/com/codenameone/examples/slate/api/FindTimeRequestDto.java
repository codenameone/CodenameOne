package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Asks for times that suit several providers at once, for a meeting. `providers` must
/// all be free; `days` is how many days from `fromDay` to look through.
@Mapped
public record FindTimeRequestDto(
        String serviceId,
        String locationId,
        String fromDay,
        int days,
        List<String> providers) {
}
