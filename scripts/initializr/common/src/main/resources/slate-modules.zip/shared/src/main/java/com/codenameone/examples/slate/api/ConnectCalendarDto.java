package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Connects a calendar. For GOOGLE and MICROSOFT, `credential` is the authorization code
/// and `redirectUri` the address it was issued to; for ICS it is the feed address; for
/// DEVICE it is empty.
@Mapped
public record ConnectCalendarDto(
        String kind,
        String label,
        String credential,
        String redirectUri,
        String calendars,
        String writeCalendar) {
}
