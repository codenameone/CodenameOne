package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A start that can be booked. `providers` are the account names the slot would go to,
/// `providerNames` the same people as clients see them.
@Mapped
public record SlotDto(
        long start,
        long end,
        List<String> providers,
        List<String> providerNames,
        int seatsLeft) {
}
