package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What a rule change would do to one day: the starts tried, as minutes after midnight,
/// and each provider's verdict on each.
@Mapped
public record PreviewDto(
        String day,
        String serviceId,
        List<Integer> starts,
        List<PreviewRowDto> rows,
        int bookable) {
}
