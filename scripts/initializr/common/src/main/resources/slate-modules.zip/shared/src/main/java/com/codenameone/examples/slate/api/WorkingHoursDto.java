package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// One stretch of a provider's week. Weekday 1 is Monday; minutes are after midnight at
/// the location.
@Mapped
public record WorkingHoursDto(
        String id,
        String locationId,
        int weekday,
        int startMinute,
        int endMinute) {
}
