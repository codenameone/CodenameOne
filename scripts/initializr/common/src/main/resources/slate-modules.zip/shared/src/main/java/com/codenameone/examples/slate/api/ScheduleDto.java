package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A provider's days: the shifts, the appointments and the rest of their busy time.
@Mapped
public record ScheduleDto(
        String username,
        String displayName,
        String color,
        long from,
        long to,
        List<ShiftDto> shifts,
        List<AppointmentDto> appointments,
        List<BusyDto> busy) {
}
