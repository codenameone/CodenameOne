package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A card as typed into the app. Read by the simulated processor only, which
/// keeps the brand and the last four digits and nothing else; with a real
/// processor the card never reaches the app or this server.
@Mapped
public record CardDto(String number, int expMonth, int expYear, String cvc, String holder) {
}
