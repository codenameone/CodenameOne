package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Completes a held booking. `methodId` pays the deposit, when there is one; `guests` are
/// e-mail addresses invited to it.
@Mapped
public record ConfirmDto(
        String methodId,
        String note,
        List<String> guests) {
}
