package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A booking as the client and the provider see it. Times are epoch milliseconds;
/// `freeCancelUntil` is when cancelling starts to cost the deposit and `rescheduleUntil`
/// when it can no longer be moved. `icsUrl` is the address of its calendar file.
@Mapped
public record AppointmentDto(
        String id,
        String serviceId,
        String serviceName,
        String locationId,
        String locationName,
        String client,
        String clientName,
        long start,
        long end,
        long blockStart,
        long blockEnd,
        String state,
        long holdExpiresAt,
        long priceCents,
        long depositCents,
        String currency,
        String paymentState,
        String note,
        boolean online,
        String meetingUrl,
        List<PartyDto> parties,
        long freeCancelUntil,
        long rescheduleUntil,
        String icsUrl,
        String color) {
}
