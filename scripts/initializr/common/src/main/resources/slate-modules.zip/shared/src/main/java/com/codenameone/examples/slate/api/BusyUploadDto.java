package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The busy time a phone read from one DEVICE link, for the stretch `from` to `to`. It
/// replaces what that link sent before for the stretch.
@Mapped
public record BusyUploadDto(
        String linkId,
        long from,
        long to,
        List<IntervalDto> busy) {
}
