package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A day to preview under rules that are not saved yet.
@Mapped
public record PreviewRequestDto(
        String serviceId,
        String locationId,
        String day,
        PolicyDto policy) {
}
