package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The starts one day offers for a service. `emptyReason` is why there are none, as a
/// rule code (see `SlotEngine`), or empty.
@Mapped
public record DaySlotsDto(
        String day,
        String timeZone,
        List<SlotDto> slots,
        String emptyReason) {
}
