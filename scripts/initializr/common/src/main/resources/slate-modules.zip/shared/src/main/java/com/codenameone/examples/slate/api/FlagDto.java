package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Marks an account for a closer look, or clears the mark.
@Mapped
public record FlagDto(boolean flagged, String reason) {
}
