package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A provider, resource or guest an appointment involves.
@Mapped
public record PartyDto(
        String kind,
        String ref,
        String name) {
}
