package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A stretch of busy time, and nothing else about it.
@Mapped
public record IntervalDto(
        long start,
        long end) {
}
