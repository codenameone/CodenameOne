package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Moves a booking to another start, with the providers that start was offered with.
@Mapped
public record RescheduleDto(
        long start,
        List<String> providers) {
}
