package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A place where appointments happen.
@Mapped
public record LocationDto(
        String id,
        String name,
        String address,
        String timeZone,
        boolean active) {
}
