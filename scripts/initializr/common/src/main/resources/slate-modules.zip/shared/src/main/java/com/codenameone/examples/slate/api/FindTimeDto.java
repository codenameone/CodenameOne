package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The first starts that suit everyone asked for, soonest first, across the days looked
/// through.
@Mapped
public record FindTimeDto(
        List<SlotDto> slots) {
}
