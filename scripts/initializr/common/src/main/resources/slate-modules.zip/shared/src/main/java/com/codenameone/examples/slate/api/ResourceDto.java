package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A chair, a room: something a service needs one of.
@Mapped
public record ResourceDto(
        String id,
        String locationId,
        String kind,
        String name,
        boolean active) {
}
