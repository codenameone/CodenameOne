package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Time taken on a provider's day. `kind` is APPOINTMENT, TIME_OFF or CALENDAR; `label`
/// says what it is to the provider only.
@Mapped
public record BusyDto(
        long start,
        long end,
        String kind,
        String label,
        String ref) {
}
