package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A name and a number, for a chart.
@Mapped
public record NameCountDto(
        String name,
        int count) {
}
