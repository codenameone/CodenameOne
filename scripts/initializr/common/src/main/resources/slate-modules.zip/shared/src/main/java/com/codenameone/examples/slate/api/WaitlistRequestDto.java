package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Asks to be told when a time comes free. Days are `yyyy-MM-dd`; minutes are after
/// midnight; an empty provider is anyone.
@Mapped
public record WaitlistRequestDto(
        String serviceId,
        String provider,
        String fromDay,
        String toDay,
        int fromMinute,
        int toMinute) {
}
