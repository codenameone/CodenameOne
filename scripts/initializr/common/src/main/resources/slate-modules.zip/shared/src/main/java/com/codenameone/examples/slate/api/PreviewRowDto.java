package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One provider's day in the owner's preview: the reason each start was turned down, or
/// OK, in the order of the preview's starts.
@Mapped
public record PreviewRowDto(
        String provider,
        String name,
        List<String> reasons) {
}
