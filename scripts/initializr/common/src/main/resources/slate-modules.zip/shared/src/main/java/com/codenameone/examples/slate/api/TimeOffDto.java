package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Time a provider is not working.
@Mapped
public record TimeOffDto(
        String id,
        long start,
        long end,
        String reason) {
}
