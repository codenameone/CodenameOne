package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// The business, and what its vertical calls things. `providerNoun` is "Stylist", "Tutor"
/// and so on; the plurals are given, never made by adding an s.
@Mapped
public record BusinessDto(
        String name,
        String vertical,
        String about,
        String timeZone,
        String currency,
        String providerNoun,
        String providersNoun,
        String clientNoun,
        String serviceNoun,
        String resourceNoun,
        String accent) {
}
