package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Something that can be booked. `providers` names who offers it. Policy values of -1 are
/// the business's own.
@Mapped
public record ServiceDto(
        String id,
        String name,
        String description,
        String category,
        int minutes,
        long priceCents,
        String currency,
        int bufferBefore,
        int bufferAfter,
        int capacity,
        int providersNeeded,
        String resourceKind,
        boolean online,
        int minNoticeMinutes,
        int depositPercent,
        String color,
        String intakePrompt,
        boolean active,
        List<String> providers) {
}
