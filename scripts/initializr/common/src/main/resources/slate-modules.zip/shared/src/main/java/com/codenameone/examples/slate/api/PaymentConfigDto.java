package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// How this server takes payments, so the app knows which way to add a card.
///
/// @param provider `simulated` or `stripe`.
@Mapped
public record PaymentConfigDto(String provider, String currency) {
}
