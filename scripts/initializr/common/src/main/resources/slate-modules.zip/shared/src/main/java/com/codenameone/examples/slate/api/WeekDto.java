package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A provider's whole working week.
@Mapped
public record WeekDto(
        List<WorkingHoursDto> hours) {
}
