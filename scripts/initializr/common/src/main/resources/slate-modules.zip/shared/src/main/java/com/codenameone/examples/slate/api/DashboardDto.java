package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The owner's numbers for the last 30 days. Utilisation is booked minutes per hundred
/// working minutes.
@Mapped
public record DashboardDto(
        int booked,
        int completed,
        int noShows,
        int cancelled,
        long revenueCents,
        String currency,
        int utilisation,
        List<Integer> bookedByDay,
        List<NameCountDto> topServices,
        List<NameCountDto> providerLoad) {
}
