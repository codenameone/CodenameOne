package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Why a booking is cancelled, which the other side is told.
@Mapped
public record CancelDto(
        String reason) {
}
