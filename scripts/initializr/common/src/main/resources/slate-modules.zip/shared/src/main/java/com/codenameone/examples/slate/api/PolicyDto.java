package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// The booking rules. Every value is in whole minutes, hours or percent as named; see the
/// `business` table for what each one does.
@Mapped
public record PolicyDto(
        int stepMinutes,
        int minNoticeMinutes,
        int horizonDays,
        int holdMinutes,
        int cancelHours,
        int rescheduleHours,
        int depositPercent,
        int noShowFeePercent,
        int clientGapMinutes,
        int clientPerDay,
        int minUsableGapMinutes,
        String packing,
        int reminderHours) {
}
