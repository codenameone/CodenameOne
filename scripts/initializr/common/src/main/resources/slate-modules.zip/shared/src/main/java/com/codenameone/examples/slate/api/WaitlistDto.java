package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A place on the waitlist. `offered` is the appointment held for the client while the
/// state is OFFERED.
@Mapped
public record WaitlistDto(
        String id,
        String serviceId,
        String serviceName,
        String provider,
        String fromDay,
        String toDay,
        int fromMinute,
        int toMinute,
        String state,
        String offered,
        long createdAt) {
}
