package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// One stretch of a provider's working day.
@Mapped
public record ShiftDto(
        long start,
        long end,
        String locationId) {
}
