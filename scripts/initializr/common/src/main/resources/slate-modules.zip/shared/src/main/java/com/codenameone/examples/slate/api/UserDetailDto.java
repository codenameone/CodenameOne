package com.codenameone.examples.slate.api;

import java.util.List;

import com.codename1.annotations.Mapped;

/// One account in full, for the owner deciding what to do about it.
///
/// @param appointments Bookings the account made, ever, whatever became of them.
/// @param noShows Bookings it did not turn up to, ever.
/// @param spent Cents taken from its cards, ever.
@Mapped
public record UserDetailDto(
        UserDto user,
        int appointments,
        int noShows,
        long spent,
        List<ModerationEventDto> events) {
}
