package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// Which calendars the server can read itself, and the client ids the app starts their
/// sign-in with. Empty means not configured.
@Mapped
public record CalendarConfigDto(
        String googleClientId,
        String microsoftClientId,
        String feedUrl) {
}
