package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// A calendar a provider connected. `serverSync` is true when the server reads it itself;
/// a DEVICE link is kept fresh by the phone. The credential is never sent back.
@Mapped
public record CalendarLinkDto(
        String id,
        String kind,
        String label,
        String calendars,
        String writeCalendar,
        boolean serverSync,
        long lastSyncedAt,
        String lastError) {
}
