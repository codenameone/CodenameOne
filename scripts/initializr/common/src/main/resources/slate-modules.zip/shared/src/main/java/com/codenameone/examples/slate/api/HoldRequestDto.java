package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Asks for a slot to be kept while the client finishes booking. `providers` is who the
/// slot was offered with.
@Mapped
public record HoldRequestDto(
        String serviceId,
        String locationId,
        long start,
        List<String> providers) {
}
