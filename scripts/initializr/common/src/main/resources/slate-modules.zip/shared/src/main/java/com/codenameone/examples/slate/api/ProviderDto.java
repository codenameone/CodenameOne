package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Someone who is booked. `services` names what they offer.
@Mapped
public record ProviderDto(
        String username,
        String displayName,
        String title,
        String bio,
        String color,
        String defaultLocation,
        int maxPerDay,
        int maxContinuousMinutes,
        int breakMinutes,
        boolean active,
        List<String> services) {
}
