package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// The roles an owner gives an account, or takes away. Every account is a
/// client whatever is set here.
@Mapped
public record RoleChangeDto(boolean provider, boolean owner) {
}
