package com.codenameone.examples.slate.api;

import com.codename1.annotations.Mapped;

/// How one person wants the app and its reminders. Kept on the server, so it
/// follows the account to another phone.
///
/// @param language `en`, `es`, `fr`, `de` or `he`.
/// @param theme `system`, `light` or `dark`.
/// @param units `km` or `mi`, for distances run.
/// @param notifyBookings Reminders before a booked class, and a place opening up from a waitlist.
/// @param notifyPromotions Nudges: a class with room in it, a friend's invitation, a campaign.
/// @param defaultPaymentMethodId A saved card's id; deposits are taken from it.
/// @param quietFrom Hour of the day, 0 to 23, from which no nudge is sent.
/// @param quietTo Hour at which nudges may start again. Equal to `quietFrom` means no quiet hours.
@Mapped
public record PreferencesDto(
        String language,
        String theme,
        String units,
        boolean notifyBookings,
        boolean notifyReceipts,
        boolean notifyPromotions,
        String defaultPaymentMethodId,
        int quietFrom,
        int quietTo) {
}
