package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.Provider;

import java.util.List;

@Repository(entity = Provider.class, key = String.class)
public interface ProviderRepository extends CrudRepository<Provider, String> {
    List<Provider> findByActiveOrderByDisplayNameAsc(boolean active);

    @Query("select t from Provider t order by t.displayName asc")

    List<Provider> everyByName();

    Provider findFirstByFeedToken(String feedToken);

    /// Holds the provider's row until the transaction ends. Every booking that
    /// takes this provider, and every change to their hours, holds it first,
    /// so the rules that count their day -- the most per day, the break --
    /// are checked against the bookings that are really there.
    @Modifying
    @Query("update Provider p set p.active = p.active where p.username = :username")
    int hold(@Param("username") String username);
}
