package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.Location;

import java.util.List;

@Repository(entity = Location.class, key = String.class)
public interface LocationRepository extends CrudRepository<Location, String> {
    List<Location> findByActiveOrderByNameAsc(boolean active);

    @Query("select t from Location t order by t.name asc")

    List<Location> everyByName();
}
