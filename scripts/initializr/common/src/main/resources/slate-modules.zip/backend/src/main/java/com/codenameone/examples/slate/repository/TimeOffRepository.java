package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.TimeOff;

import java.time.Instant;
import java.util.List;

@Repository(entity = TimeOff.class, key = String.class)
public interface TimeOffRepository extends CrudRepository<TimeOff, String> {
    List<TimeOff> findByUsernameOrderByStartsAtAsc(String username);

    TimeOff findFirstByIdAndUsername(String id, String username);

    /// Time off that overlaps `[from, to)`.
    @Query("select t from TimeOff t where t.username in :users and t.startsAt < :to"
            + " and t.endsAt > :from")
    List<TimeOff> overlapping(@Param("users") List<String> usernames, @Param("from") Instant from,
            @Param("to") Instant to);

    int deleteByUsername(String username);
}
