package com.codenameone.examples.slate.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// Five minutes of one provider's or resource's time, taken by one
/// appointment. The key is the party and the cell, so a second appointment
/// over the same five minutes is refused by the database itself, whatever
/// arrives at once.
@Entity
public class SlotClaim {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(240)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String appointmentId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String ref = "";

    @Column(nullable = false)
    private long cell;

    public SlotClaim() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public long getCell() {
        return cell;
    }

    public void setCell(long cell) {
        this.cell = cell;
    }
}
