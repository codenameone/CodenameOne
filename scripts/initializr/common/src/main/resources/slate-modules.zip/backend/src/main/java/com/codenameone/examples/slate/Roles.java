package com.codenameone.examples.slate;

/// The roles an account can hold. Every account is a client and can book;
/// taking bookings and running the business are granted on top of that, and
/// the app offers a mode for each role the account holds.
public final class Roles {
    public static final String CLIENT = "CLIENT";
    /// Takes bookings: keeps their hours, time off and calendars, and works
    /// through their day.
    public static final String PROVIDER = "PROVIDER";
    /// Runs the business: services, people, places, rules, numbers, accounts.
    public static final String OWNER = "OWNER";

    private Roles() {
    }
}
