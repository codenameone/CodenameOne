package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.Business;


@Repository(entity = Business.class, key = String.class)
public interface BusinessRepository extends CrudRepository<Business, String> {
    /// Holds the business row until the transaction ends, so that two owners
    /// saving the rules at once save them one after the other.
    @Modifying
    @Query("update Business b set b.updatedAt = b.updatedAt where b.id = :id")
    int hold(@Param("id") String id);
}
