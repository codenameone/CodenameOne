package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.Waitlist;

import java.time.Instant;
import java.util.List;

@Repository(entity = Waitlist.class, key = String.class)
public interface WaitlistRepository extends CrudRepository<Waitlist, String> {
    List<Waitlist> findByClientAndStateInOrderByCreatedAtAsc(String client, List<String> states);

    Waitlist findFirstByIdAndClient(String id, String client);

    List<Waitlist> findByServiceIdAndStateOrderByCreatedAtAsc(String serviceId, String state);

    Waitlist findFirstByOffered(String offered);

    @Modifying
    @Query("update Waitlist w set w.state = :to, w.updatedAt = :now where w.id = :id"
            + " and w.state = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to,
            @Param("now") Instant now);

    int deleteByClient(String client);
}
