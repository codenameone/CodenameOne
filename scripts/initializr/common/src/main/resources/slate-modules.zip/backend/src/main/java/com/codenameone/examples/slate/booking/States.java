package com.codenameone.examples.slate.booking;

/// The words the booking tables store. They live here rather than on the
/// entities so that nothing on an entity is anything but a column.
public final class States {
    // Appointment.state
    public static final String HELD = "HELD";
    public static final String CONFIRMED = "CONFIRMED";
    public static final String COMPLETED = "COMPLETED";
    public static final String NO_SHOW = "NO_SHOW";
    public static final String CANCELLED = "CANCELLED";

    // Appointment.paymentState
    public static final String PAY_NONE = "NONE";
    public static final String PAY_PENDING = "PENDING";
    public static final String PAY_AUTHORIZED = "AUTHORIZED";
    public static final String PAY_CAPTURED = "CAPTURED";
    public static final String PAY_RELEASED = "RELEASED";
    public static final String PAY_FAILED = "FAILED";

    // AppointmentParty.kind
    public static final String PROVIDER = "PROVIDER";
    public static final String RESOURCE = "RESOURCE";
    public static final String GUEST = "GUEST";

    // Waitlist.state
    public static final String WAITING = "WAITING";
    public static final String OFFERED = "OFFERED";
    public static final String BOOKED = "BOOKED";
    public static final String EXPIRED = "EXPIRED";

    private States() {
    }
}
