package com.codenameone.examples.slate;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

/// Time on line cut at midnight, which is how a provider's hours are credited.
class DaysTest {
    /// 2026-03-01 00:00:00 UTC.
    private static final long MIDNIGHT = 20513L * Days.MILLIS;

    @Test
    void aStretchAcrossMidnightIsCreditedHalfToEachDay() {
        // 23:59:40 to 00:00:20: twenty seconds on each side. Credited whole to
        // the day it ended in, the new day had all forty.
        long day = Days.number(MIDNIGHT);
        assertArrayEquals(new long[] {day - 1, 20000L, day, 20000L},
                Days.split(MIDNIGHT - 20000L, MIDNIGHT + 20000L));
    }

    @Test
    void aStretchWithinOneDayIsThatDays() {
        long day = Days.number(MIDNIGHT);
        assertArrayEquals(new long[] {day, 40000L},
                Days.split(MIDNIGHT + 1000L, MIDNIGHT + 41000L));
        // Ending exactly at midnight is all the old day's.
        assertArrayEquals(new long[] {day - 1, 40000L},
                Days.split(MIDNIGHT - 40000L, MIDNIGHT));
        // Starting exactly at it is all the new one's.
        assertArrayEquals(new long[] {day, 40000L}, Days.split(MIDNIGHT, MIDNIGHT + 40000L));
        assertArrayEquals(new long[0], Days.split(MIDNIGHT, MIDNIGHT));
    }
}
