package com.codenameone.examples.slate.sync;

import com.codename1.backend.Web;

import java.io.IOException;
import java.time.ZoneId;
import java.util.List;

/// A calendar a provider publishes as a feed: the "secret address in iCal
/// format" Google, Outlook and Apple calendars all offer. No sign-in, and no
/// client id to register, which makes it the way to connect a calendar on a
/// server nobody has set OAuth up for.
final class IcsFeed implements ExternalCalendar {
    private final ZoneId zone;

    IcsFeed(ZoneId zone) {
        this.zone = zone;
    }

    @Override
    public String kind() {
        return CalendarLinks.ICS;
    }

    /// Checks the address is one and answers it, with `webcal:` read as
    /// `https:`. Plain `http:` is refused: the address is a secret, and the
    /// feed lists the provider's day.
    @Override
    public String connect(String given, String redirectUri) throws IOException {
        String url = given == null ? "" : given.trim();
        if (url.regionMatches(true, 0, "webcal://", 0, 9)) {
            url = "https://" + url.substring(9);
        }
        if (!url.regionMatches(true, 0, "https://", 0, 8) || url.length() > 1900) {
            throw new IOException("Paste the calendar's https or webcal address");
        }
        fetch(url);
        return url;
    }

    @Override
    public List<long[]> busy(String credential, String calendars, long from, long to)
            throws IOException {
        return Ics.busy(fetch(credential), zone, from, to);
    }

    private static String fetch(String url) throws IOException {
        Web.Result answer = Web.get(url);
        if (answer.getStatus() / 100 != 2) {
            throw new IOException("The calendar address answered " + answer.getStatus());
        }
        String body = answer.getBodyAsString();
        if (body == null || body.indexOf("BEGIN:VCALENDAR") < 0) {
            throw new IOException("That address is not a calendar");
        }
        return body;
    }
}
