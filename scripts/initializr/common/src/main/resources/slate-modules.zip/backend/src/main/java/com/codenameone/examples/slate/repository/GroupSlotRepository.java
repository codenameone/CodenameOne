package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.GroupSlot;


@Repository(entity = GroupSlot.class, key = String.class)
public interface GroupSlotRepository extends CrudRepository<GroupSlot, String> {
    /// Takes a seat. 1 when it did, 0 when the slot is full.
    @Modifying
    @Query("update GroupSlot g set g.seats = g.seats + 1 where g.id = :id and g.seats < g.capacity")
    int take(@Param("id") String id);

    @Modifying
    @Query("update GroupSlot g set g.seats = g.seats - 1 where g.id = :id and g.seats > 0")
    int give(@Param("id") String id);
}
