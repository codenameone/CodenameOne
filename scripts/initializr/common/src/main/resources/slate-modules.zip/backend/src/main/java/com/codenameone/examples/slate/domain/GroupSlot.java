package com.codenameone.examples.slate.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The seats taken in one slot of a group service. `seats` only ever changes
/// by a conditional update against `capacity`.
@Entity
public class GroupSlot {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(120)")
    private String id = "";

    /// The first seat, whose claims hold the provider.
    @Column(nullable = false, type = "VARCHAR(32)")
    private String appointmentId = "";

    @Column(nullable = false)
    private int seats;

    @Column(nullable = false)
    private int capacity;

    public GroupSlot() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
}
