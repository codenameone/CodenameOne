package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.PaymentMethod;

import java.time.Instant;
import java.util.List;

/// The cards accounts saved.
@Repository(entity = PaymentMethod.class, key = String.class)
public interface PaymentMethodRepository extends CrudRepository<PaymentMethod, String> {
    /// An account's saved cards, oldest first.
    List<PaymentMethod> findByUsernameOrderByCreatedAtAscIdAsc(String username);

    long countByUsername(String username);

    /// The card an account pays with by default, or null when that is cash.
    PaymentMethod findFirstByUsernameAndPreferredTrue(String username);

    /// One of an account's cards, or null when the id is not a card of theirs.
    PaymentMethod findFirstByIdAndUsername(String id, String username);

    /// When the newest of an account's cards was added, or null with none.
    @Query("select max(m.createdAt) from PaymentMethod m where m.username = :username")
    Instant newestAt(@Param("username") String username);

    int deleteByUsername(String username);
}
