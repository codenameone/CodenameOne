package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.TravelTime;

import java.util.List;

@Repository(entity = TravelTime.class, key = String.class)
public interface TravelTimeRepository extends CrudRepository<TravelTime, String> {
    @Query("select t from TravelTime t order by t.id asc")
    List<TravelTime> everyById();
}
