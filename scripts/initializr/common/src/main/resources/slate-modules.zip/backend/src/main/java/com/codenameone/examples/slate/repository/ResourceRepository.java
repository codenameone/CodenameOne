package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.Resource;

import java.util.List;

@Repository(entity = Resource.class, key = String.class)
public interface ResourceRepository extends CrudRepository<Resource, String> {
    List<Resource> findByLocationIdAndKindAndActiveOrderByIdAsc(String locationId, String kind,
            boolean active);

    @Query("select t from Resource t order by t.locationId asc, t.name asc")

    List<Resource> everyByLocation();
}
