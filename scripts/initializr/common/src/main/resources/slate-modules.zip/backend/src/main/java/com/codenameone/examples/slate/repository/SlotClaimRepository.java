package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.SlotClaim;


@Repository(entity = SlotClaim.class, key = String.class)
public interface SlotClaimRepository extends CrudRepository<SlotClaim, String> {
    int deleteByAppointmentId(String appointmentId);

    long countByAppointmentId(String appointmentId);
}
