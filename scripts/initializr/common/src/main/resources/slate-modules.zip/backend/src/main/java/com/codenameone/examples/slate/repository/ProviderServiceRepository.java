package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.ProviderService;

import java.util.List;

@Repository(entity = ProviderService.class, key = String.class)
public interface ProviderServiceRepository extends CrudRepository<ProviderService, String> {
    List<ProviderService> findByServiceId(String serviceId);

    List<ProviderService> findByUsername(String username);

    @Query("select t from ProviderService t order by t.id asc")

    List<ProviderService> everyById();

    int deleteByUsername(String username);

    int deleteByServiceId(String serviceId);
}
