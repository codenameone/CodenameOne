package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.CalendarLink;

import java.util.List;

@Repository(entity = CalendarLink.class, key = String.class)
public interface CalendarLinkRepository extends CrudRepository<CalendarLink, String> {
    List<CalendarLink> findByUsernameOrderByCreatedAtAsc(String username);

    CalendarLink findFirstByIdAndUsername(String id, String username);

    List<CalendarLink> findByKindIn(List<String> kinds);

    int deleteByUsername(String username);
}
