package com.codenameone.examples.slate;

/// Shortening a value to fit its column.
///
/// The app kit's `Text` refuses a value that is too long, which is right for
/// what a person typed. This is for what a person did not type -- a calendar's
/// error message, a name copied from an account -- where the row is still
/// worth writing with the end cut off.
public final class Clip {
    private Clip() {
    }

    /// The value cut to `max` characters, or empty for null.
    public static String cut(String value, int max) {
        if (value == null) {
            return "";
        }
        return value.length() > max ? value.substring(0, max) : value;
    }
}
