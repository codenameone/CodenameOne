package com.codenameone.examples.slate.account;

import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.Transactional;
import com.codenameone.examples.slate.Text;
import com.codenameone.examples.slate.api.PreferencesDto;
import com.codenameone.examples.slate.domain.Preference;
import com.codenameone.examples.slate.domain.Profile;
import com.codenameone.examples.slate.pay.Payments;
import com.codenameone.examples.slate.repository.PreferenceRepository;
import com.codenameone.examples.slate.repository.ProfileRepository;

import java.io.IOException;

/// How one person wants the app: language, theme, units, what they are told
/// about and when they are not to be disturbed, and the card their
/// deposits are taken from.
///
/// Kept on the server so that they follow the account from one phone to the
/// next. Two of them live elsewhere, because something else reads them: the
/// language is in the profile, where the owner sees it, and the default way to
/// pay is the mark on the saved card itself, so that removing a card cannot
/// leave a preference pointing at it.
@Component
public class Preferences {
    private static final String[] LANGUAGES = {"en", "es", "fr", "de", "he"};
    private static final String[] THEMES = {"system", "light", "dark"};
    private static final String[] UNITS = {"km", "mi"};
    /// The quiet hours someone who never opened the settings gets: from ten
    /// at night to seven in the morning, the server's time.
    public static final int QUIET_FROM = 22;
    public static final int QUIET_TO = 7;

    private final ProfileRepository profiles;
    private final PreferenceRepository preferences;
    private final Payments payments;

    public Preferences(ProfileRepository profiles, PreferenceRepository preferences,
            Payments payments) {
        this.profiles = profiles;
        this.preferences = preferences;
        this.payments = payments;
    }

    @Transactional(readOnly = true)
    public PreferencesDto get(String username) throws IOException {
        Profile profile = profiles.findById(username);
        if (profile == null) {
            throw new ResponseStatusException(404, "No such account");
        }
        Preference row = preferences.findById(username);
        String language = profile.getLanguage();
        String method = payments.defaultMethod(username);
        if (row == null) {
            // What someone who never opened the settings gets.
            return new PreferencesDto(language, THEMES[0], UNITS[0], true, true, true, method,
                    QUIET_FROM, QUIET_TO);
        }
        return new PreferencesDto(language, row.getTheme(), row.getUnits(), row.isNotifyBookings(),
                row.isNotifyReceipts(), row.isNotifyPromotions(), method, row.getQuietFrom(),
                row.getQuietTo());
    }

    /// Saves all of them. Each is checked against the values it can take: these
    /// are words the server later acts on, not text to show back. One
    /// transaction, so a value that is refused leaves none of the others saved.
    @Transactional
    public PreferencesDto save(String username, PreferencesDto wanted) throws IOException {
        if (wanted == null) {
            throw new ResponseStatusException(400, "Nothing to save");
        }
        // First, before anything is read: two saves sent together for an
        // account with no row of settings yet would each find none and each
        // insert one, and the second insert fails on the key. The profile is
        // there from registration, so held, one save waits and finds the
        // other's row.
        profiles.hold(username);
        // Hours of the day, from and to; the same hour twice means no quiet
        // hours at all.
        if (wanted.quietFrom() < 0 || wanted.quietFrom() > 23 || wanted.quietTo() < 0
                || wanted.quietTo() > 23) {
            throw new ResponseStatusException(400, "Quiet hours are hours of the day, 0 to 23");
        }
        String theme = Text.oneOf(wanted.theme(), THEMES, THEMES[0], "the theme");
        String units = Text.oneOf(wanted.units(), UNITS, UNITS[0], "the units");
        String language = Text.oneOf(wanted.language(), LANGUAGES, LANGUAGES[0], "the language");
        String method = wanted.defaultPaymentMethodId() == null ? ""
                : wanted.defaultPaymentMethodId().trim();
        if (method.length() > 0 && !method.equals(payments.defaultMethod(username))) {
            // Answers 404 for a card that is not this user's, before anything
            // else is saved.
            payments.makeDefault(username, method);
        }
        // Read after the card was marked, not before: marking one may be a
        // statement over every card of the account, and what was read before
        // such a statement is no longer the session's to write.
        Profile profile = profiles.findById(username);
        if (profile == null) {
            throw new ResponseStatusException(404, "No such account");
        }
        profile.setLanguage(language);
        Preference row = preferences.findById(username);
        boolean unsaved = row == null;
        if (unsaved) {
            row = new Preference();
            row.setUsername(username);
        }
        row.setTheme(theme);
        row.setUnits(units);
        row.setNotifyBookings(wanted.notifyBookings());
        row.setNotifyReceipts(wanted.notifyReceipts());
        row.setNotifyPromotions(wanted.notifyPromotions());
        row.setQuietFrom(wanted.quietFrom());
        row.setQuietTo(wanted.quietTo());
        if (unsaved) {
            preferences.insert(row);
        }
        return get(username);
    }

    /// Whether `hour` falls in someone's quiet hours, which may run past
    /// midnight. Nudges are held back then; what they asked for -- a waitlist
    /// place, a class cancelled -- is not.
    public static boolean quiet(int from, int to, int hour) {
        if (from == to) {
            return false;
        }
        return from < to ? hour >= from && hour < to : hour >= from || hour < to;
    }
}
