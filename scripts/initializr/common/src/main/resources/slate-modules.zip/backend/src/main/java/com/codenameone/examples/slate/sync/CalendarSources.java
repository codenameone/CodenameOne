package com.codenameone.examples.slate.sync;

import java.time.ZoneId;

/// The calendars this server can read, chosen once from its settings by
/// `Services`. A kind with no client set up is simulated on a development
/// profile and missing anywhere else, where connecting one answers that the
/// server is not set up for it.
public final class CalendarSources {
    private final ExternalCalendar google;
    private final ExternalCalendar microsoft;
    private final ExternalCalendar ics;
    private final String googleClientId;
    private final String microsoftClientId;

    public CalendarSources(String googleClientId, String googleSecret, String microsoftClientId,
            String microsoftSecret, boolean simulate, ZoneId zone) {
        this.googleClientId = googleSecret.length() > 0 ? googleClientId : "";
        this.microsoftClientId = microsoftSecret.length() > 0 ? microsoftClientId : "";
        google = this.googleClientId.length() > 0
                ? new GoogleCalendar(googleClientId, googleSecret)
                : simulate ? new SimulatedCalendar(CalendarLinks.GOOGLE, zone) : null;
        microsoft = this.microsoftClientId.length() > 0
                ? new MicrosoftCalendar(microsoftClientId, microsoftSecret)
                : simulate ? new SimulatedCalendar(CalendarLinks.MICROSOFT, zone) : null;
        ics = new IcsFeed(zone);
    }

    /// The calendar that reads links of `kind`, or null.
    public ExternalCalendar of(String kind) {
        if (CalendarLinks.GOOGLE.equals(kind)) {
            return google;
        }
        if (CalendarLinks.MICROSOFT.equals(kind)) {
            return microsoft;
        }
        if (CalendarLinks.ICS.equals(kind)) {
            return ics;
        }
        return null;
    }

    /// The client id the app opens Google's consent screen with: empty when
    /// the server simulates Google, and the app then skips the screen.
    public String googleClientId() {
        return googleClientId;
    }

    public String microsoftClientId() {
        return microsoftClientId;
    }
}
