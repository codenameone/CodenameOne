package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.Service;

import java.util.List;

@Repository(entity = Service.class, key = String.class)
public interface ServiceRepository extends CrudRepository<Service, String> {
    List<Service> findByActiveOrderBySortOrderAsc(boolean active);

    @Query("select t from Service t order by t.sortOrder asc")

    List<Service> everyInOrder();
}
