package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.WorkingHours;

import java.util.List;

@Repository(entity = WorkingHours.class, key = String.class)
public interface WorkingHoursRepository extends CrudRepository<WorkingHours, String> {
    List<WorkingHours> findByUsernameOrderByWeekdayAscStartMinuteAsc(String username);

    List<WorkingHours> findByUsernameIn(List<String> usernames);

    int deleteByUsername(String username);
}
