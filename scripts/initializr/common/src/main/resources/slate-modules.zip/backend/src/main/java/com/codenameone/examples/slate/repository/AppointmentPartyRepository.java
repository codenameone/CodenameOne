package com.codenameone.examples.slate.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.slate.domain.AppointmentParty;

import java.util.List;

@Repository(entity = AppointmentParty.class, key = String.class)
public interface AppointmentPartyRepository extends CrudRepository<AppointmentParty, String> {
    List<AppointmentParty> findByAppointmentId(String appointmentId);

    List<AppointmentParty> findByAppointmentIdIn(List<String> appointmentIds);

    int deleteByAppointmentId(String appointmentId);
}
