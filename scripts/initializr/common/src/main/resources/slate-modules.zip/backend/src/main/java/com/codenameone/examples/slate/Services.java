package com.codenameone.examples.slate;

import com.codename1.appkit.server.security.AccountSecurity;

import com.codename1.backend.Config;
import com.codename1.backend.annotations.Bean;
import com.codename1.backend.annotations.Configuration;
import com.codename1.backend.annotations.Value;
import com.codename1.backend.push.CloudPush;
import com.codenameone.examples.slate.catalog.Catalog;
import com.codenameone.examples.slate.pay.MisconfiguredPayments;
import com.codenameone.examples.slate.pay.PaymentProvider;
import com.codenameone.examples.slate.pay.SimulatedPayments;
import com.codenameone.examples.slate.pay.StripePayments;
import com.codename1.appkit.server.push.CloudPushSender;
import com.codename1.appkit.server.push.ConsolePushSender;
import com.codename1.appkit.server.push.MisconfiguredPushSender;
import com.codename1.appkit.server.push.PushSender;
import com.codename1.appkit.server.push.RecordingPushSender;
import com.codenameone.examples.slate.sms.ConsoleSmsSender;
import com.codenameone.examples.slate.sms.MessageBirdSmsSender;
import com.codenameone.examples.slate.sms.MisconfiguredSmsSender;
import com.codenameone.examples.slate.sms.SmsSender;
import com.codenameone.examples.slate.sms.TwilioSmsSender;
import com.codenameone.examples.slate.sms.VonageSmsSender;
import com.codenameone.examples.slate.sync.CalendarSources;

import java.io.IOException;

/// The services this server reaches outside itself for, each behind an
/// interface and each chosen here from the settings.
///
/// Each is named by one setting -- `myappname.sms.provider`,
/// `myappname.payments.provider` and `myappname.push.provider` -- and, when that is
/// not set, a development profile (dev, test, local) gets the one that needs no
/// account: codes and notifications printed on the console, cards simulated. Any other profile gets the real provider,
/// and when its settings are missing the server still starts, logs a
/// configuration error naming each missing setting, and fails every call to
/// that provider with the same message. It never quietly falls back to a
/// development stand-in.
///
/// Every setting is also read from the environment, in upper case with `_`
/// for each `.` (`MYAPPNAME_SMS_TWILIO_TOKEN`), which is where secrets belong.
@Configuration
public class Services {
    /// `myappname.sms.provider` is one of:
    ///
    /// - `twilio`: `myappname.sms.twilio.sid`, `.token` and `.from`
    /// - `vonage`: `myappname.sms.vonage.key`, `.secret` and `.from`
    /// - `messagebird`: `myappname.sms.messagebird.key` and `.originator`
    /// - `console`: prints the message, on a development profile only
    ///
    /// Unset, it is `console` on a development profile and `twilio` otherwise.
    @Bean
    public SmsSender smsSender(Config config,
            @Value("${myappname.sms.provider:}") String chosen,
            @Value("${myappname.sms.twilio.sid:}") String twilioSid,
            @Value("${myappname.sms.twilio.token:}") String twilioToken,
            @Value("${myappname.sms.twilio.from:}") String twilioFrom,
            @Value("${myappname.sms.vonage.key:}") String vonageKey,
            @Value("${myappname.sms.vonage.secret:}") String vonageSecret,
            @Value("${myappname.sms.vonage.from:}") String vonageFrom,
            @Value("${myappname.sms.messagebird.key:}") String birdKey,
            @Value("${myappname.sms.messagebird.originator:}") String birdOriginator) {
        String kind = chosen.trim().length() > 0 ? chosen.trim()
                : config.isDevelopmentProfile() ? "console" : "twilio";
        if ("console".equalsIgnoreCase(kind)) {
            if (!config.isDevelopmentProfile()) {
                return new MisconfiguredSmsSender("myappname.sms.provider=console only prints codes "
                        + "and is refused on the '" + config.getProfile() + "' profile; set it to "
                        + "twilio, vonage or messagebird");
            }
            return new ConsoleSmsSender();
        }
        if ("twilio".equalsIgnoreCase(kind)) {
            String missing = missing("myappname.sms.twilio.", new String[] {"sid", twilioSid,
                "token", twilioToken, "from", twilioFrom});
            return missing.length() > 0 ? new MisconfiguredSmsSender(unset("SMS", "twilio",
                    missing)) : new TwilioSmsSender(twilioSid, twilioToken, twilioFrom);
        }
        if ("vonage".equalsIgnoreCase(kind)) {
            String missing = missing("myappname.sms.vonage.", new String[] {"key", vonageKey,
                "secret", vonageSecret, "from", vonageFrom});
            return missing.length() > 0 ? new MisconfiguredSmsSender(unset("SMS", "vonage",
                    missing)) : new VonageSmsSender(vonageKey, vonageSecret, vonageFrom);
        }
        if ("messagebird".equalsIgnoreCase(kind)) {
            String missing = missing("myappname.sms.messagebird.", new String[] {"key", birdKey,
                "originator", birdOriginator});
            return missing.length() > 0 ? new MisconfiguredSmsSender(unset("SMS", "messagebird",
                    missing)) : new MessageBirdSmsSender(birdKey, birdOriginator);
        }
        return new MisconfiguredSmsSender("myappname.sms.provider is '" + kind + "', which is "
                + "none of twilio, vonage, messagebird or console");
    }

    /// `myappname.payments.provider` is one of:
    ///
    /// - `stripe`: [StripePayments], an untested stub over Stripe's REST API.
    ///   It needs `myappname.payments.stripe.secret`.
    /// - `simulated`: test card numbers, and no money moves.
    ///
    /// Unset, it is `simulated` on a development profile and `stripe` otherwise.
    ///
    /// With Stripe a card is typed into Stripe's own page, which then sends the
    /// browser back to `/pay/return` on this server. That address has to be the
    /// one a phone can reach, so it is `myappname.public.url` when that is set
    /// and the issuer -- the public address of this server, which a deployment
    /// sets anyway -- when it is not.
    @Bean
    public PaymentProvider paymentProvider(Config config,
            @Value("${myappname.payments.provider:}") String chosen,
            @Value("${myappname.payments.stripe.secret:}") String secret,
            @Value("${myappname.public.url:}") String publicUrl,
            @Value("${" + AccountSecurity.ISSUER_KEY + ":}") String issuer) {
        String kind = chosen.trim().length() > 0 ? chosen.trim()
                : config.isDevelopmentProfile() ? "simulated" : "stripe";
        if ("simulated".equalsIgnoreCase(kind)) {
            return new SimulatedPayments();
        }
        if (!"stripe".equalsIgnoreCase(kind)) {
            return new MisconfiguredPayments(kind, "myappname.payments.provider is '" + kind
                    + "', which is neither stripe nor simulated");
        }
        String address = publicUrl.length() > 0 ? publicUrl : issuer;
        String missing = missing("", new String[] {"myappname.payments.stripe.secret", secret,
            "myappname.public.url (or " + AccountSecurity.ISSUER_KEY + ")", address});
        if (missing.length() > 0) {
            return new MisconfiguredPayments("stripe", unset("payments", "stripe", missing));
        }
        while (address.endsWith("/")) {
            address = address.substring(0, address.length() - 1);
        }
        return new StripePayments(secret, address + "/pay/return");
    }

    /// The calendars the server reads for providers.
    ///
    /// - Google: `myappname.calendar.google.id` and `myappname.calendar.google.secret`,
    ///   an OAuth client of type "Web application" with the Calendar API on and
    ///   the `calendar.freebusy` scope.
    /// - Microsoft: `myappname.calendar.microsoft.id` and
    ///   `myappname.calendar.microsoft.secret`, an Entra app registration with the
    ///   delegated `Calendars.ReadBasic` and `offline_access` permissions.
    /// - A published iCalendar feed needs nothing.
    ///
    /// On a development profile a kind with no client is simulated, so the
    /// demo connects calendars without an account anywhere. Elsewhere it is
    /// not offered. `myappname.timezone` is the zone a feed's all-day events and
    /// the simulated busy time are read in.
    @Bean
    public CalendarSources calendarSources(Config config,
            @Value("${myappname.calendar.google.id:}") String googleId,
            @Value("${myappname.calendar.google.secret:}") String googleSecret,
            @Value("${myappname.calendar.microsoft.id:}") String microsoftId,
            @Value("${myappname.calendar.microsoft.secret:}") String microsoftSecret,
            @Value("${myappname.timezone:Europe/London}") String zone) {
        return new CalendarSources(googleId.trim(), googleSecret.trim(), microsoftId.trim(),
                microsoftSecret.trim(), config.isDevelopmentProfile(), Catalog.zone(zone));
    }

    /// `myappname.push.provider` is one of:
    ///
    /// - `cloud`: the Codename One push service. It needs `myappname.push.app`,
    ///   the app's push id, and `myappname.push.key`, a server key with the push
    ///   scope; both are in the Push section of the Codename One console.
    /// - `console`: prints each notification, on a development profile only.
    /// - `recording`: keeps each notification for the tests to read, on a
    ///   development profile only.
    ///
    /// Unset, it is `recording` on the `test` profile, `console` on the other
    /// development profiles and `cloud` otherwise. A server whose push settings
    /// are missing still starts and still serves deliveries: it logs a configuration
    /// error at start-up and again for every notification it could not send.
    @Bean
    public PushSender pushSender(Config config,
            @Value("${myappname.push.provider:}") String chosen,
            @Value("${myappname.push.app:}") String app,
            @Value("${myappname.push.key:}") String key,
            @Value("${myappname.push.url:}") String url) {
        String kind = chosen.trim().length() > 0 ? chosen.trim()
                : "test".equals(config.getProfile()) ? "recording"
                : config.isDevelopmentProfile() ? "console" : "cloud";
        if ("console".equalsIgnoreCase(kind) || "recording".equalsIgnoreCase(kind)) {
            if (!config.isDevelopmentProfile()) {
                return new MisconfiguredPushSender("myappname.push.provider=" + kind
                        + " sends nothing and is refused on the '" + config.getProfile()
                        + "' profile; set it to cloud");
            }
            return "console".equalsIgnoreCase(kind) ? new ConsolePushSender()
                    : new RecordingPushSender();
        }
        if (!"cloud".equalsIgnoreCase(kind)) {
            return new MisconfiguredPushSender("myappname.push.provider is '" + kind
                    + "', which is none of cloud, console or recording");
        }
        String missing = missing("myappname.push.", new String[] {"app", app, "key", key});
        if (missing.length() > 0) {
            return new MisconfiguredPushSender(unset("push", "cloud", missing));
        }
        try {
            CloudPush push = new CloudPush(app.trim(), key.trim());
            return new CloudPushSender(url.trim().length() > 0 ? push.withEndpoint(url.trim())
                    : push);
        } catch (IllegalArgumentException err) {
            return new MisconfiguredPushSender("push provider 'cloud' is misconfigured: "
                    + err.getMessage());
        }
    }

    /// The names, after `prefix`, of the settings in `namesAndValues` whose
    /// value is empty, separated by commas.
    private static String missing(String prefix, String[] namesAndValues) {
        StringBuilder out = new StringBuilder();
        for (int iter = 0; iter + 1 < namesAndValues.length; iter += 2) {
            if (namesAndValues[iter + 1] == null || namesAndValues[iter + 1].trim().length() == 0) {
                if (out.length() > 0) {
                    out.append(", ");
                }
                out.append(prefix).append(namesAndValues[iter]);
            }
        }
        return out.toString();
    }

    private static String unset(String service, String provider, String missing) {
        return service + " provider '" + provider + "' is not configured; set " + missing;
    }
}
