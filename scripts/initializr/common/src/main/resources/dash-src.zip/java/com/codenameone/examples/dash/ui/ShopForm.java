package com.codenameone.examples.dash.ui;

import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.CN;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.dash.api.BuyDto;
import com.codenameone.examples.dash.api.EquipDto;
import com.codenameone.examples.dash.api.ShopItemDto;
import com.codenameone.examples.dash.api.WalletDto;
import com.codenameone.examples.dash.engage.Store;
import com.codenameone.examples.dash.engage.Telemetry;
import com.codenameone.examples.dash.net.Api;
import com.codenameone.examples.dash.net.Net;
import com.codenameone.examples.dash.net.Session;
import java.util.List;

/// The shop. Gems and the Royal Pass are real-money purchases through the
/// platform store ([Store]); runners, trails and emotes cost coins or gems and are
/// bought from the game's own server. Either way the server holds the wallet.
public final class ShopForm {
    private ShopForm() {
    }

    public static void show() {
        final Form f = Ui.form("Shop", "shop");
        Ui.back(f, Nav::home);
        Store.listen(wallet -> {
            Ui.toast("Purchase complete");
            Session.refreshUser(() -> Ui.later(ShopForm::show), Ui::failed);
        });
        Api.shop().wallet(Net.to(wallet -> Api.shop().items(Net.to(items -> Ui.later(() -> {
            if (Session.user() == null) {
                // Signed out while the shop was loading.
                return;
            }
            // The wallet just fetched, not the player cached at sign-in:
            // the shop is where the balance has to be right.
            f.add(Ui.wallet(Session.user().trophies(), wallet.coins(), wallet.gems()));
            fill(f, items, wallet);
            f.revalidate();
        }), Ui::failed)), Ui::failed));
        f.show();
    }

    private static void fill(Form f, List<ShopItemDto> items, WalletDto wallet) {
        for (final ShopItemDto item : items) {
            boolean owned = wallet.owned() != null && wallet.owned().contains(item.id());
            Container row = new Container(new BorderLayout());
            row.setUIID("ShopItem");
            row.add(BorderLayout.WEST, new Label(Kit.shopArt(item.id(), CN.convertToPixels(13)), "ShopArt"));
            Container text = new Container(BoxLayout.y());
            text.add(Ui.text(item.name(), "ShopItemName"));
            text.add(new Label(kindOf(item), "ShopItemKind"));
            row.add(BorderLayout.CENTER, text);
            if (item.sku() != null && item.sku().length() > 0) {
                if (owned) {
                    row.add(BorderLayout.EAST, FlowLayout.encloseMiddle(new Label("Owned", "Owned")));
                } else {
                    String price = Store.price(item.sku());
                    row.add(BorderLayout.EAST, FlowLayout.encloseMiddle(Ui.button(price == null ? "Buy" : price,
                            "GemButton", "buy-" + item.id(),
                            e -> Store.buy(item.sku()))));
                }
            } else if (owned) {
                boolean on = item.id().equals(wallet.outfit());
                row.add(BorderLayout.EAST, FlowLayout.encloseMiddle(item.id().startsWith("trail-") && !on
                        ? Ui.button("Use", "GhostButton", "equip-" + item.id(), e -> equip(item.id()))
                        : new Label(on ? "In use" : "Owned", "Owned")));
            } else {
                String price = item.priceGems() > 0 ? item.priceGems() + " gems" : item.priceCoins() + " coins";
                row.add(BorderLayout.EAST, FlowLayout.encloseMiddle(Ui.button(price, "PriceButton", "buy-" + item.id(),
                        e -> buy(item))));
            }
            f.add(row);
        }
    }

    private static String kindOf(ShopItemDto item) {
        if (item.id().startsWith("runner-")) {
            return "RUNNER";
        }
        if (item.id().startsWith("trail-")) {
            return "TRAIL";
        }
        if ("gems-500".equals(item.id())) {
            // The biggest pack is the one that is cheapest per gem.
            return "BEST VALUE";
        }
        if (item.id().startsWith("gems-")) {
            return "GEM PACK";
        }
        return item.sku() != null && item.sku().length() > 0 ? "SEASON PASS" : "ITEM";
    }

    private static void buy(ShopItemDto item) {
        Api.shop().buy(new BuyDto(item.id()), Net.to(wallet -> {
            Telemetry.itemBought(item.id(), item.priceGems() > 0 ? "gems" : "coins");
            Session.refreshUser(() -> Ui.later(ShopForm::show), Ui::failed);
        }, Ui::failed));
    }

    private static void equip(String outfit) {
        Api.shop().equip(new EquipDto(outfit), Net.to(wallet -> Session.refreshUser(() -> Ui.later(ShopForm::show),
                Ui::failed), Ui::failed));
    }
}
