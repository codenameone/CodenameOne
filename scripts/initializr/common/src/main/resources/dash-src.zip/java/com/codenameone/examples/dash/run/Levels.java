package com.codenameone.examples.dash.run;

import com.codenameone.examples.dash.rules.Catalog;
import com.codenameone.examples.dash.rules.CityRoute;
import com.codenameone.examples.dash.rules.Content;
import com.codenameone.examples.dash.rules.LevelDef;
import com.codenameone.examples.dash.rules.forge.ContentPack;
import com.codenameone.examples.dash.rules.forge.ContentRef;
import com.codenameone.examples.dash.rules.forge.LevelRun;
import com.codenameone.examples.dash.rules.forge.PackCodec;
import com.codenameone.examples.dash.rules.forge.Samples;
import java.util.HashMap;
import java.util.Map;

/// The levels this device can play, by the name a replay or a race gives them:
/// a bare id for an official level, `pack@hash#level` for a community one.
///
/// Community packs arrive from the server ([#remember]) when a browser screen
/// opens one, a party picks one or a replay names one; a reference to a pack
/// that was never fetched resolves to null, and the caller fetches it.
public final class Levels {
    /// A playable level and the catalog its placements name.
    public static final class Playable {
        public final String ref;
        public final LevelDef level;
        public final Catalog catalog;

        Playable(String ref, LevelDef level, Catalog catalog) {
            this.ref = ref;
            this.level = level;
            this.catalog = catalog;
        }
    }

    private static final Map<String, ContentPack> PACKS = new HashMap<String, ContentPack>();
    private static final Map<String, CityRoute> CITIES = new HashMap<String, CityRoute>();
    private static final Map<String, CityPath> PATHS = new HashMap<String, CityPath>();

    private Levels() {
    }

    /// Keeps `pack` for later references to it; returns it.
    public static ContentPack remember(ContentPack pack) {
        PACKS.put(pack.id + "@" + pack.hash(), pack);
        PACKS.put(pack.id, pack);
        return pack;
    }

    /// Decodes a pack the server sent and keeps it.
    public static ContentPack remember(String content) {
        return remember(PackCodec.read(content));
    }

    public static Playable official(String levelId) {
        LevelDef l = Content.level(levelId);
        return l == null ? null : new Playable(levelId, l, Content.catalog());
    }

    /// `levelId` of `pack`, named the way a replay names it.
    public static Playable of(ContentPack pack, String levelId) {
        if (Samples.OFFICIAL_ID.equals(pack.id)) {
            return official(levelId);
        }
        LevelDef l = pack.level(levelId);
        return l == null ? null : new Playable(LevelRun.replayLevelId(pack, levelId), l, pack.catalog());
    }

    /// A level of a pack still being edited, for a playtest. Its reference
    /// names the pack as it is right now, which the server has never
    /// published, so a playtest is never submitted.
    public static Playable draft(ContentPack pack, LevelDef level) {
        return new Playable(pack.id + "@" + pack.hash() + "#" + level.id, level, pack.catalog());
    }

    /// A city route's level, kept so a run of it can be submitted with its
    /// route, run again and replayed. `path` is the street map's line for the
    /// minimap, or null.
    public static Playable city(CityRoute route, CityPath path) {
        LevelDef l = route.level();
        // Only the routes of this session's last few runs are kept.
        if (CITIES.size() >= 16 && !CITIES.containsKey(l.id)) {
            CITIES.clear();
            PATHS.clear();
        }
        CITIES.put(l.id, route);
        if (path != null) {
            PATHS.put(l.id, path);
        }
        return new Playable(l.id, l, Content.catalog());
    }

    /// The encoded route of the city level `levelId`, or null when it is not
    /// one.
    public static String citySpec(String levelId) {
        CityRoute r = levelId == null ? null : CITIES.get(levelId);
        return r == null ? null : r.encode();
    }

    /// The route of the city level `levelId`, or null when it is not one
    /// this app built.
    public static CityRoute cityRoute(String levelId) {
        return levelId == null ? null : CITIES.get(levelId);
    }

    /// The minimap line of the city level `levelId`, or null.
    public static CityPath cityPath(String levelId) {
        return levelId == null ? null : PATHS.get(levelId);
    }

    /// The level a replay or race calls `ref`, or null when its pack is not
    /// here yet (see [#packOf]).
    public static Playable resolve(String ref) {
        if (ref == null) {
            return null;
        }
        if (ref.startsWith(CityRoute.ID_PREFIX)) {
            CityRoute r = CITIES.get(ref);
            return r == null ? null : city(r, null);
        }
        if (ref.indexOf('@') < 0) {
            return official(ref);
        }
        ContentRef r = ContentRef.parse(ref);
        ContentPack p = PACKS.get(r.pack + "@" + r.hash);
        return p == null ? null : of(p, r.level);
    }

    /// The pack id a community reference names, for fetching it; null for an
    /// official level.
    public static String packOf(String ref) {
        int at = ref == null ? -1 : ref.indexOf('@');
        return at <= 0 ? null : ref.substring(0, at);
    }
}
