package com.codenameone.examples.dash.ui;

import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.dash.api.LeaderDto;
import com.codenameone.examples.dash.net.Api;
import com.codename1.appkit.Net;

/// The top players by trophies.
public final class LeaderboardForm {
    private LeaderboardForm() {
    }

    public static void show() {
        final Form f = Ui.form("Leaders", "leaders");
        Ui.back(f, Nav::home);
        Api.game().leaderboard(50, Net.to(list -> Ui.later(() -> {
            for (LeaderDto l : list) {
                Container row = new Container(new BorderLayout());
                row.setUIID(l.rank() <= 3 ? "LeaderTop" : "LeaderRow");
                row.add(BorderLayout.WEST, new Label("#" + l.rank(), "LeaderRank"));
                row.add(BorderLayout.CENTER, new Label(l.displayName(), "LeaderName"));
                row.add(BorderLayout.EAST, new Label(String.valueOf(l.trophies()), "Trophies"));
                f.add(row);
            }
            f.revalidate();
        }), Ui::failed));
        f.show();
    }
}
