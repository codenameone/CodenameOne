package com.codenameone.examples.dash.run;

import com.codenameone.examples.dash.rules.Replay;
import com.codenameone.examples.dash.rules.Run;

/// Feeds a recorded [Replay] into a [Run] one tick at a time, in step with
/// whatever else is running: a ghost beside the player, or the replay viewer.
final class ReplayFeed {
    private final Replay replay;
    private final int[] inputs;
    private int next;

    ReplayFeed(Replay replay) {
        this.replay = replay;
        this.inputs = new int[replay.runners()];
    }

    /// Steps `run` once with the inputs recorded for its current tick.
    void step(Run run) {
        if (run.over()) {
            return;
        }
        for (int i = 0; i < inputs.length; i++) {
            inputs[i] = 0;
        }
        int tick = run.tick();
        while (next < replay.eventCount()) {
            int[] e = replay.event(next);
            if (e[0] > tick) {
                break;
            }
            if (e[0] == tick && e[1] >= 0 && e[1] < inputs.length) {
                inputs[e[1]] |= e[2];
            }
            next++;
        }
        run.step(inputs);
    }
}
