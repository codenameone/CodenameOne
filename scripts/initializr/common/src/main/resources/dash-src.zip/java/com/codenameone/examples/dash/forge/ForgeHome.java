package com.codenameone.examples.dash.forge;

import com.codename1.components.MultiButton;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.GridLayout;
import com.codenameone.examples.dash.api.PackSummaryDto;
import com.codenameone.examples.dash.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.dash.ui.Nav;
import com.codenameone.examples.dash.ui.Ui;

/// The track editor's front door: the game's own levels, what other players
/// made, and the player's own packs, with a button to start a new one.
public final class ForgeHome {
    private static final String[] SCOPES = {"official", "popular", "new", "mine"};
    private static final String[] TITLES = {"Official", "Popular", "New", "Yours"};

    private ForgeHome() {
    }

    public static void show() {
        show("official");
    }

    static void show(final String scope) {
        final Form f = Ui.form("Forge", "forge");
        Ui.back(f, Nav::home);
        Container tabs = new Container(new GridLayout(1, SCOPES.length));
        for (int i = 0; i < SCOPES.length; i++) {
            final String s = SCOPES[i];
            Button b = Ui.button(TITLES[i], s.equals(scope) ? "ForgeTabOn" : "ForgeTab", "forge-" + s,
                    e -> show(s));
            tabs.add(b);
        }
        f.add(tabs);
        f.add(Ui.primary("Create a pack", "forgeCreate", e -> PackEditor.create()));
        Api.forge().packs(scope, Net.to(list -> Ui.later(() -> {
            if (list.isEmpty()) {
                f.add(Ui.text("mine".equals(scope)
                        ? "Nothing yet. A pack holds your own levels and obstacles; create one and "
                        + "share it with friends."
                        : "No packs here yet.", "Empty"));
            }
            for (final PackSummaryDto p : list) {
                f.add(row(p, "mine".equals(scope)));
            }
            if ("official".equals(scope)) {
                f.add(Ui.text("Levels players make show up under Popular and New. "
                        + "Make your own with Create a pack.", "Empty"));
            }
            f.revalidate();
        }), Ui::failed));
        f.show();
    }

    private static MultiButton row(final PackSummaryDto p, boolean mine) {
        MultiButton b = new MultiButton(p.name().length() == 0 ? p.id() : p.name());
        b.setUIID("HistoryRow");
        b.setUIIDLine1(p.official() ? "ForgeOfficial" : "HistoryDraw");
        StringBuilder line = new StringBuilder("by ").append(p.author()).append("  ")
                .append(p.levels()).append(p.levels() == 1 ? " level" : " levels");
        if (p.ratings() > 0) {
            line.append("  ").append(p.rating() / 10).append('.').append(p.rating() % 10).append(" stars");
        }
        b.setTextLine2(line.toString());
        if (mine) {
            b.setTextLine3(p.version() == 0 ? "Draft, not published" : "Version " + p.version() + ", "
                    + p.status() + (p.pendingAssets() ? ", files waiting for review" : ""));
        }
        // A lit view of a track as the pack's cover, its theme picked by the
        // pack's id so a pack keeps its cover.
        String[] themes = {"neon", "ember", "daybreak"};
        int pick = (p.id().hashCode() & 0x7fffffff) % themes.length;
        int th = com.codename1.ui.CN.convertToPixels(12);
        b.setIcon(com.codenameone.examples.dash.ui.Kit.thumb(themes[pick], th * 3 / 5, th));
        b.setName("pack-" + p.id());
        b.addActionListener(e -> {
            if (mine && p.version() == 0) {
                PackEditor.open(p.id());
            } else {
                PackScreen.show(p.id());
            }
        });
        return b;
    }
}
