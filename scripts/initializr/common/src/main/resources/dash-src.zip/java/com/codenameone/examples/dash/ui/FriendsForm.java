package com.codenameone.examples.dash.ui;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codenameone.examples.dash.api.FriendDto;
import com.codenameone.examples.dash.api.InviteDto;
import com.codenameone.examples.dash.engage.Friends;
import com.codenameone.examples.dash.engage.Telemetry;
import com.codenameone.examples.dash.net.Api;
import com.codenameone.examples.dash.net.Net;
import java.util.List;

/// Invite a friend: the player's link, what an invite pays, and everyone who
/// joined through it.
///
/// The link itself is made on the device by Codename One's invite links
/// ([Friends#share]); the server only knows the code inside it, and pays
/// both players once the friend has run a race.
public final class FriendsForm {
    private FriendsForm() {
    }

    public static void show() {
        final Form f = Ui.form("Friends", "friends");
        Ui.back(f, Nav::home);
        Telemetry.screen("friends");
        final Container col = Ui.column();
        f.add(Ui.centeredColumn(col));
        f.show();
        Api.social().invite(Net.to(mine -> Ui.later(() -> {
            fillInvite(col, mine);
            f.revalidate();
            Api.social().friends(Net.to(list -> Ui.later(() -> {
                fillFriends(col, list);
                f.revalidate();
            }), Ui::failed));
        }), Ui::failed));
    }

    private static void fillInvite(Container col, final InviteDto mine) {
        // The crew they could race, in front: who an invite brings in.
        col.add(SignInForm.heroes());
        col.add(Ui.label("Invite a friend", "SectionTitle"));
        col.add(Ui.text("Your friend starts with " + mine.friendCoins() + " coins. When they have played "
                + "their first race, you get " + mine.inviterCoins() + " coins, for up to "
                + mine.maxRewarded() + " friends.", "ForgeHelpText"));
        Label code = Ui.label(mine.code(), "InviteCode");
        code.setName("inviteCode");
        Container codeCard = new Container(BoxLayout.y());
        codeCard.setUIID("InviteCard");
        codeCard.add(Ui.centered(Ui.label("YOUR INVITE CODE", "InviteCaption")));
        codeCard.add(Ui.centered(code));
        col.add(codeCard);
        col.add(Ui.primary("Invite friends", "inviteButton", e -> Friends.share(mine)));
        Label count = Ui.label(mine.joined() + " joined, " + mine.rewarded() + " rewarded", "LeagueName");
        count.setName("inviteCount");
        col.add(count);
    }

    private static void fillFriends(Container col, List<FriendDto> list) {
        col.add(Ui.label("Joined through you", "SectionTitle"));
        if (list.isEmpty()) {
            col.add(Ui.label("Nobody yet. Share your link!", "Empty"));
            return;
        }
        for (FriendDto d : list) {
            Container c = new Container(new BorderLayout());
            c.setUIID("AchievementRow");
            Label icon = new Label("", "Container");
            icon.setIcon(FontImage.createMaterial(d.rewarded() ? FontImage.MATERIAL_MONETIZATION_ON
                    : FontImage.MATERIAL_HOURGLASS_EMPTY, d.rewarded() ? "RewardAchievement" : "XpText", 6));
            c.add(BorderLayout.WEST, icon);
            Container text = new Container(BoxLayout.y());
            text.add(new Label(d.displayName(), "QuestTitle"));
            text.add(new Label(d.trophies() + " trophies, "
                    + ("played".equals(d.state()) ? "has played" : "has not played yet"), "XpText"));
            c.add(BorderLayout.CENTER, text);
            col.add(c);
        }
    }
}
