package com.codenameone.examples.dash.ui;

import com.codename1.ui.CN;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codenameone.examples.dash.AppConfig;
import com.codenameone.examples.dash.net.Session;

/// Signing in, and the way to the practice arena without an account.
public final class SignInForm {
    private SignInForm() {
    }

    public static void show() {
        Form f = Ui.form("", "signin");
        f.setLayout(new com.codename1.ui.layouts.LayeredLayout());
        f.setScrollable(false);
        f.add(Kit.backdrop());
        f.getToolbar().hideToolbar();
        Container col = Ui.column();
        col.add(heroes());
        col.add(Ui.label("MYAPPNAME", "Logo"));
        col.add(Ui.label("Run. Race. Build.", "Tagline"));
        final TextField email = field("Email", TextField.EMAILADDR, "email");
        final TextField password = field("Password", TextField.PASSWORD, "password");
        // Fields and both buttons share one panel, so they share one width.
        col.add(Ui.panel(email, password,
                Ui.primary("Sign in", "signInButton", e -> {
                    Session.signIn(email.getText().trim(), password.getText(),
                            () -> Ui.later(Nav::signedIn), Ui::failed);
                }),
                Ui.secondary("Create an account", "registerButton", e -> RegisterForm.show())));
        col.add(Ui.button("Try a level without an account", "LinkButton", "practiceButton",
                e -> RunForm.solo(com.codenameone.examples.dash.run.Levels.official(
                        com.codenameone.examples.dash.rules.Content.CAUSEWAY), 1L, "guest", null, SignInForm::show)));
        if (AppConfig.serverSwitchable()) {
            col.add(Ui.button("Server: " + AppConfig.serverUrl(), "LinkButton", "serverButton",
                    e -> SettingsForm.chooseServer()));
        }
        Container safe = Ui.centeredColumn(col);
        safe.setSafeArea(true);
        Container front = new Container(BoxLayout.yCenter());
        front.setScrollableY(true);
        front.add(safe);
        f.add(front);
        f.show();
    }

    /// Three runners mid-stride, the middle one in front: the first thing a
    /// new player sees is who they will race.
    static Container heroes() {
        int h = CN.convertToPixels(26);
        Label left = new Label(Portraits.figure("runner-nova", h * 4 / 5), "SignInHero");
        Label mid = new Label(Portraits.figure("runner-myappname", h), "SignInHero");
        Label right = new Label(Portraits.figure("runner-kite", h * 4 / 5), "SignInHero");
        Container c = new Container(new FlowLayout(Component.CENTER, Component.BOTTOM));
        c.add(left).add(mid).add(right);
        c.setName("heroes");
        return c;
    }

    static TextField field(String hint, int constraint, String name) {
        TextField t = new TextField("", hint, 20, constraint);
        t.setUIID("GameField");
        t.setName(name);
        return t;
    }
}
