package com.codenameone.examples.dash.ui;

import com.codename1.ui.CN;
import com.codenameone.examples.dash.AppConfig;
import com.codenameone.examples.dash.admin.AdminConsole;
import com.codenameone.examples.dash.engage.Friends;
import com.codenameone.examples.dash.engage.Notifications;
import com.codenameone.examples.dash.engage.Store;
import com.codenameone.examples.dash.engage.Telemetry;
import com.codenameone.examples.dash.forge.ForgeHome;
import com.codenameone.examples.dash.forge.PackScreen;
import com.codenameone.examples.dash.net.Session;

/// Where the app goes. Every screen change that is not a plain "back" comes
/// through here, so a push notification, a challenge link and a button all
/// land on the same screen the same way.
public final class Nav {
    private static String pendingChallenge;
    private static String pendingPack;

    private Nav() {
    }

    /// The first screen: the stored session decides between home and sign-in.
    public static void launch() {
        pendingChallenge = AppConfig.challengeCode();
        pendingPack = AppConfig.packId();
        Session.onSignedOut(() -> CN.callSerially(SignInForm::show));
        Session.restore(() -> CN.callSerially(Nav::enter),
                () -> CN.callSerially(SignInForm::show),
                () -> CN.callSerially(() -> {
                    SignInForm.show();
                    Ui.toast("The server did not answer. Is it running?");
                }));
    }

    /// Signed in: a challenge or pack link opened the app wins, then the admin
    /// console for an administrator who was last there, then home.
    public static void enter() {
        Notifications.signedIn();
        Store.resend();
        if (pendingChallenge != null) {
            String code = pendingChallenge;
            pendingChallenge = null;
            challenge(code);
            return;
        }
        if (pendingPack != null) {
            String id = pendingPack;
            pendingPack = null;
            PackScreen.show(id);
            return;
        }
        if (Session.user() != null && Session.user().admin()
                && "admin".equals(AppConfig.mode(Session.user().username()))) {
            adminConsole();
            return;
        }
        home();
    }

    public static void signedIn() {
        Telemetry.signedIn();
        Friends.claimPending();
        enter();
    }

    public static void home() {
        AppConfig.setMode("player", Session.user() == null ? "" : Session.user().username());
        HomeForm.show();
    }

    public static void challenge(String code) {
        RaceLobby.join(code);
    }

    public static void adminConsole() {
        AppConfig.setMode("admin", Session.user().username());
        AdminConsole.show();
    }

    /// A screen named by a push or the admin's broadcast composer; the names
    /// are the server's `Promotion.SCREENS`.
    public static void screen(String name) {
        if ("shop".equals(name)) {
            shop();
        } else if ("friends".equals(name)) {
            FriendsForm.show();
        } else if ("forge".equals(name)) {
            ForgeHome.show();
        } else if ("runner".equals(name)) {
            RunnerForm.show();
        } else if ("race".equals(name)) {
            RaceLobby.quick(null);
        } else if ("daily".equals(name)) {
            RunForm.daily();
        } else if ("crews".equals(name)) {
            CrewsForm.show();
        } else if (name != null && name.startsWith("level:")) {
            // "A friend beat your score": that level's board, to see by how much.
            ScoresForm.show(name.substring(6), null);
        } else {
            home();
        }
    }

    public static void shop() {
        ShopForm.show();
    }

    public static void signOut() {
        Notifications.signingOut(() -> Session.signOut(() -> CN.callSerially(SignInForm::show)));
    }
}
