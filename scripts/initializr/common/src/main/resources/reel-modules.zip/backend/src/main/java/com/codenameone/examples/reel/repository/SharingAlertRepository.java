package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.SharingAlert;

import java.util.List;

/// The sharing_alert rows.
@Repository(entity = SharingAlert.class, key = String.class)
public interface SharingAlertRepository extends CrudRepository<SharingAlert, String> {
    int deleteByUsername(String username);

    List<SharingAlert> findByUsernameAndStatus(String username, String status);

    List<SharingAlert> findByStatusOrderByCreatedAtDesc(String status);

    List<SharingAlert> findByCreatedAtGreaterThanOrderByCreatedAtDesc(long since);

    List<SharingAlert> findByUsernameOrderByCreatedAtDesc(String username);
}
