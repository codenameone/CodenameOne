package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Interaction;

import java.util.List;

/// The interaction rows.
@Repository(entity = Interaction.class, key = String.class)
public interface InteractionRepository extends CrudRepository<Interaction, String> {
    List<Interaction> findByVideoIdOrderByAtSecondsAsc(String videoId);

    int deleteByVideoId(String videoId);
}
