package com.codenameone.examples.reel.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A sign an account is used beyond its household.
@Entity
public class SharingAlert {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String kind = "";

    @Column(nullable = false, type = "VARCHAR(255)")
    private String detail = "";

    @Column(nullable = false)
    private int distinctIps;

    @Column(nullable = false)
    private int distinctCountries;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String status = "";

    @Column(nullable = false)
    private long createdAt;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String decidedBy = "";

    @Column(nullable = false, type = "VARCHAR(255)")
    private String note = "";

    public SharingAlert() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public int getDistinctIps() {
        return distinctIps;
    }

    public void setDistinctIps(int distinctIps) {
        this.distinctIps = distinctIps;
    }

    public int getDistinctCountries() {
        return distinctCountries;
    }

    public void setDistinctCountries(int distinctCountries) {
        this.distinctCountries = distinctCountries;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public String getDecidedBy() {
        return decidedBy;
    }

    public void setDecidedBy(String decidedBy) {
        this.decidedBy = decidedBy;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
