package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Plan;

/// The plan rows.
@Repository(entity = Plan.class, key = String.class)
public interface PlanRepository extends CrudRepository<Plan, String> {
}
