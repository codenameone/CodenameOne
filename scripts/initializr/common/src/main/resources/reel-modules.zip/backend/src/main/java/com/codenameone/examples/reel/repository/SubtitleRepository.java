package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Subtitle;

import java.util.List;

/// The subtitle rows.
@Repository(entity = Subtitle.class, key = String.class)
public interface SubtitleRepository extends CrudRepository<Subtitle, String> {
    List<Subtitle> findByVideoIdOrderByLanguageAsc(String videoId);

    Subtitle findByVideoIdAndLanguage(String videoId, String language);

    int deleteByVideoIdAndLanguage(String videoId, String language);

    int deleteByVideoId(String videoId);
}
