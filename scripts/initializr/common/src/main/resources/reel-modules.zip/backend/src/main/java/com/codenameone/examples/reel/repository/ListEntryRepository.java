package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.ListEntry;

import java.util.List;

/// The list_entry rows.
@Repository(entity = ListEntry.class, key = String.class)
public interface ListEntryRepository extends CrudRepository<ListEntry, String> {
    int deleteByProfileId(String profileId);

    List<ListEntry> findByProfileIdOrderByAddedAtDesc(String profileId);

    ListEntry findFirstByProfileIdAndTitleId(String profileId, String titleId);

    List<ListEntry> findByTitleId(String titleId);
}
