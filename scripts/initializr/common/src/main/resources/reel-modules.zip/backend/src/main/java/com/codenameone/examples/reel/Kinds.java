package com.codenameone.examples.reel;

/// The values of the catalog's status and kind columns, in one place so the
/// studio, the worker, moderation and playback agree on them.
public final class Kinds {
    public static final String MOVIE = "MOVIE";
    public static final String SERIES = "SERIES";
    public static final String COURSE = "COURSE";

    /// A title the creator is still editing; nobody else sees it.
    public static final String DRAFT = "DRAFT";
    /// Submitted, waiting for a moderator.
    public static final String IN_REVIEW = "IN_REVIEW";
    public static final String PUBLISHED = "PUBLISHED";
    public static final String REJECTED = "REJECTED";
    /// Taken down after publication (a report upheld, or by an admin).
    public static final String REMOVED = "REMOVED";

    public static final String FEATURE = "FEATURE";
    public static final String EPISODE = "EPISODE";
    public static final String LESSON = "LESSON";
    public static final String TRAILER = "TRAILER";
    public static final String AD = "AD";

    public static final String UPLOADING = "UPLOADING";
    public static final String QUEUED = "QUEUED";
    public static final String PROCESSING = "PROCESSING";
    public static final String READY = "READY";
    public static final String FAILED = "FAILED";
    /// The worker's frame hashes matched the blocklist.
    public static final String BLOCKED = "BLOCKED";

    public static final String OPEN = "OPEN";
    public static final String UPHELD = "UPHELD";
    public static final String DISMISSED = "DISMISSED";

    private Kinds() {
    }
}
