package com.codenameone.examples.reel;

import com.codename1.backend.security.SecurityExchange;

/// What the request being served says about where it came from.
///
/// The app names its device in two headers it sends with every call:
/// `X-Reel-Device`, an id it made once and keeps, and `X-Reel-Device-Name`.
/// The country is the one a CDN in front of the server puts in `CF-IPCountry`;
/// without such a CDN it is empty and sharing detection works on addresses
/// alone.
public final class Requests {
    public static final String DEVICE = "X-Reel-Device";
    public static final String DEVICE_NAME = "X-Reel-Device-Name";
    public static final String PLATFORM = "X-Reel-Platform";
    public static final String PROFILE_KEY = "X-Reel-Profile-Key";

    private Requests() {
    }

    public static String header(String name) {
        SecurityExchange exchange = SecurityExchange.current();
        String value = exchange == null ? null : exchange.getRequest().getHeader(name);
        return value == null ? "" : value.trim();
    }

    /// The device id, cut to what the column holds; empty when not sent.
    public static String deviceId() {
        return clean(header(DEVICE), 64);
    }

    public static String deviceName() {
        String name = clean(header(DEVICE_NAME), 80);
        return name.length() == 0 ? "Unknown device" : name;
    }

    public static String platform() {
        return clean(header(PLATFORM), 32);
    }

    public static String ip() {
        SecurityExchange exchange = SecurityExchange.current();
        String address = exchange == null ? null : exchange.getRequest().getRemoteAddress();
        return address == null ? "" : clean(address, 64);
    }

    public static String country() {
        return clean(header("CF-IPCountry"), 8);
    }

    /// Printable ASCII only, at most `max` characters: these go into columns,
    /// logs and admin screens.
    static String clean(String value, int max) {
        StringBuilder out = new StringBuilder();
        for (int iter = 0; iter < value.length() && out.length() < max; iter++) {
            char c = value.charAt(iter);
            if (c >= ' ' && c <= '~') {
                out.append(c);
            }
        }
        return out.toString().trim();
    }
}
