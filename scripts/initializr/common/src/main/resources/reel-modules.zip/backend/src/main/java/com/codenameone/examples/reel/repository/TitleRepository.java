package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Title;

import java.util.List;

/// The title rows.
@Repository(entity = Title.class, key = String.class)
public interface TitleRepository extends CrudRepository<Title, String> {
    List<Title> findByCreatorOrderByCreatedAtDesc(String creator);

    List<Title> findByStatus(String status);

    long countByStatus(String status);
}
