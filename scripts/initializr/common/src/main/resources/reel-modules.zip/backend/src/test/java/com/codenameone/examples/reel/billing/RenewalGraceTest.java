package com.codenameone.examples.reel.billing;

import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codenameone.examples.reel.domain.Subscription;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/// A declined renewal waits a day before the card is tried again, so the
/// three tries spread over the grace period instead of three sweeps.
@BackendTest
class RenewalGraceTest {
    @Autowired
    private Billing billing;

    @Test
    void aPastDueSubscriptionIsNotRetriedBeforeItsTime() {
        long now = System.currentTimeMillis();
        Subscription sub = new Subscription();
        sub.setUsername("nobody");
        sub.setPlanCode("basic");
        sub.setStatus(Entitlements.PAST_DUE);
        sub.setPeriodEndsAt(now - 60000L);
        sub.setFailedAttempts(1);
        sub.setNextRetryAt(now + Billing.RETRY_MILLIS);
        billing.renewOne(sub, now);
        assertEquals(Entitlements.PAST_DUE, sub.getStatus());
        assertEquals(1, sub.getFailedAttempts());
    }
}
