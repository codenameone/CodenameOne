package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Household;

import java.util.List;

/// The household rows.
@Repository(entity = Household.class, key = String.class)
public interface HouseholdRepository extends CrudRepository<Household, String> {
    List<Household> findByUsernameOrderByCreatedAtAsc(String username);

    long countByUsername(String username);

    int deleteByUsername(String username);
}
