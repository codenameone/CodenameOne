package com.codenameone.examples.reel.moderation;

import java.util.List;

/// A content classifier: a second opinion on a title's text before a person
/// reviews it, such as a hosted moderation API.
///
/// Reel ships none, because every such service needs an account; the default
/// answers nothing and the keyword blocklist and the frame hash blocklist are
/// the automatic checks. A deployment that has one supplies a bean of this
/// type, and its signals are shown to the moderator with the item and raise its
/// place in the queue. A classifier never publishes or rejects by itself.
public interface ContentClassifier {
    /// Signals for a title's text, such as `violence:0.82`; empty when clean.
    List<String> classify(String name, String synopsis, List<String> tags);
}
