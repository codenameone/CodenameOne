package com.codenameone.examples.reel.learning;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.reel.Caller;
import com.codenameone.examples.reel.api.AnswerDto;
import com.codenameone.examples.reel.api.AnswerResultDto;
import com.codenameone.examples.reel.api.CertificateDto;
import com.codenameone.examples.reel.api.CourseProgressDto;
import com.codenameone.examples.reel.api.LearningApiServer;

import java.util.List;

@Component
public class LearningEndpoint implements LearningApiServer {
    private final Learning learning;

    public LearningEndpoint(Learning learning) {
        this.learning = learning;
    }

    @Override
    public AnswerResultDto answer(AnswerDto answer) throws Exception {
        return learning.answer(Caller.name(), answer);
    }

    @Override
    public List<CourseProgressDto> progress(String profile) throws Exception {
        return learning.progress(Caller.name(), profile);
    }

    @Override
    public List<CertificateDto> certificates() throws Exception {
        return learning.certificates(Caller.name());
    }

    /// Public (see SecurityConfig): what an employer checking a certificate
    /// calls.
    @Override
    public CertificateDto verify(String code) throws Exception {
        return learning.verify(code);
    }
}
