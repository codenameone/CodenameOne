package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Answer;

import java.util.List;

/// The answer rows.
@Repository(entity = Answer.class, key = String.class)
public interface AnswerRepository extends CrudRepository<Answer, String> {
    int deleteByUsername(String username);

    List<Answer> findByTitleId(String titleId);

    List<Answer> findByUsernameAndTitleId(String username, String titleId);

    List<Answer> findByInteractionId(String interactionId);

    List<Answer> findByUsernameAndInteractionId(String username, String interactionId);
}
