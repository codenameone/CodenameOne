package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Setting;

/// The setting rows.
@Repository(entity = Setting.class, key = String.class)
public interface SettingRepository extends CrudRepository<Setting, String> {
}
