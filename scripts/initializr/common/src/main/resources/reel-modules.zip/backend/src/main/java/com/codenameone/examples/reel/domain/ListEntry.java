package com.codenameone.examples.reel.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A title on a profile's list. The id is the profile id and the title id.
@Entity
public class ListEntry {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(80)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String profileId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String titleId = "";

    @Column(nullable = false)
    private long addedAt;

    public ListEntry() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getTitleId() {
        return titleId;
    }

    public void setTitleId(String titleId) {
        this.titleId = titleId;
    }

    public long getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(long addedAt) {
        this.addedAt = addedAt;
    }
}
