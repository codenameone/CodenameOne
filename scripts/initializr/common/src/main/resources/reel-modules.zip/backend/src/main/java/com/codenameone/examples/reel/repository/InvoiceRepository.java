package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Invoice;

import java.util.List;

/// The invoice rows.
@Repository(entity = Invoice.class, key = String.class)
public interface InvoiceRepository extends CrudRepository<Invoice, String> {
    List<Invoice> findByUsernameOrderByCreatedAtDesc(String username);

    List<Invoice> findByCreatedAtGreaterThan(long since);

    int deleteByUsername(String username);

    List<Invoice> findByTitleIdAndCreatedAtGreaterThan(String titleId, long since);
}
