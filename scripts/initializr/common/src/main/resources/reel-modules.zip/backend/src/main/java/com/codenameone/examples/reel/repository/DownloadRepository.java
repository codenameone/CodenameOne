package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Download;

import java.util.List;

/// The download rows.
@Repository(entity = Download.class, key = String.class)
public interface DownloadRepository extends CrudRepository<Download, String> {
    int deleteByUsername(String username);

    List<Download> findByUsernameAndDeviceId(String username, String deviceId);

    List<Download> findByUsername(String username);

    long countByUsernameAndDeviceId(String username, String deviceId);
}
