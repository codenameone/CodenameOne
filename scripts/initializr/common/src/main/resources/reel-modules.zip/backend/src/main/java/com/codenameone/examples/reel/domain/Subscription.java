package com.codenameone.examples.reel.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// An account's subscription. One row per account, kept after it ends.
@Entity
public class Subscription {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String planCode = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String status = "";

    @Column(nullable = false)
    private Instant startedAt = Instant.EPOCH;

    @Column(nullable = false)
    private Instant periodEndsAt = Instant.EPOCH;

    @Column(nullable = false)
    private boolean cancelAtPeriodEnd;

    @Column(nullable = false, type = "VARCHAR(32)")
    private String pendingPlanCode = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String couponCode = "";

    @Column(nullable = false)
    private int couponPeriodsLeft;

    @Column(nullable = false, type = "VARCHAR(32)")
    private String paymentMethodId = "";

    @Column(nullable = false)
    private int failedAttempts;

    @Column(nullable = false)
    private Instant nextRetryAt = Instant.EPOCH;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String store = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String storeRef = "";

    @Column(nullable = false)
    private Instant updatedAt = Instant.EPOCH;

    public Subscription() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public Instant getPeriodEndsAt() {
        return periodEndsAt;
    }

    public void setPeriodEndsAt(Instant periodEndsAt) {
        this.periodEndsAt = periodEndsAt;
    }

    public boolean isCancelAtPeriodEnd() {
        return cancelAtPeriodEnd;
    }

    public void setCancelAtPeriodEnd(boolean cancelAtPeriodEnd) {
        this.cancelAtPeriodEnd = cancelAtPeriodEnd;
    }

    public String getPendingPlanCode() {
        return pendingPlanCode;
    }

    public void setPendingPlanCode(String pendingPlanCode) {
        this.pendingPlanCode = pendingPlanCode;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public int getCouponPeriodsLeft() {
        return couponPeriodsLeft;
    }

    public void setCouponPeriodsLeft(int couponPeriodsLeft) {
        this.couponPeriodsLeft = couponPeriodsLeft;
    }

    public String getPaymentMethodId() {
        return paymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getStoreRef() {
        return storeRef;
    }

    public void setStoreRef(String storeRef) {
        this.storeRef = storeRef;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getNextRetryAt() {
        return nextRetryAt;
    }

    public void setNextRetryAt(Instant nextRetryAt) {
        this.nextRetryAt = nextRetryAt;
    }
}
