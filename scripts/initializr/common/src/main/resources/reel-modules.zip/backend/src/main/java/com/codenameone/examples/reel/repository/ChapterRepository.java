package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Chapter;

import java.util.List;

/// The chapter rows.
@Repository(entity = Chapter.class, key = String.class)
public interface ChapterRepository extends CrudRepository<Chapter, String> {
    List<Chapter> findByVideoIdOrderByStartSecondsAsc(String videoId);

    int deleteByVideoId(String videoId);
}
