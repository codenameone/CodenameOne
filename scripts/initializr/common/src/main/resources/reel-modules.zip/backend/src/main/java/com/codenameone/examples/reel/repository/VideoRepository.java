package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Video;

import java.util.List;

/// The video rows.
@Repository(entity = Video.class, key = String.class)
public interface VideoRepository extends CrudRepository<Video, String> {
    List<Video> findByTitleIdOrderBySeasonAscNumberAsc(String titleId);

    List<Video> findByStatus(String status);

    int deleteByTitleId(String titleId);
}
