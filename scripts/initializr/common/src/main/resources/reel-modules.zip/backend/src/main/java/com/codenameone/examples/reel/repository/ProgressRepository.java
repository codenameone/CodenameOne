package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Progress;

import java.util.List;

/// The progress rows.
@Repository(entity = Progress.class, key = String.class)
public interface ProgressRepository extends CrudRepository<Progress, String> {
    int deleteByUsername(String username);

    List<Progress> findTop50ByProfileIdOrderByUpdatedAtDesc(String profileId);

    List<Progress> findByProfileIdAndTitleId(String profileId, String titleId);

    List<Progress> findByTitleId(String titleId);

    List<Progress> findByProfileIdAndVideoId(String profileId, String videoId);

    int deleteByProfileIdAndTitleId(String profileId, String titleId);

    List<Progress> findByUsernameAndTitleId(String username, String titleId);
}
