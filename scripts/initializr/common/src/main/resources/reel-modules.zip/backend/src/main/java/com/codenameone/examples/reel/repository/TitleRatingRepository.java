package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.TitleRating;

import java.util.List;

/// The title_rating rows.
@Repository(entity = TitleRating.class, key = String.class)
public interface TitleRatingRepository extends CrudRepository<TitleRating, String> {
    int deleteByUsername(String username);

    TitleRating findFirstByProfileIdAndTitleId(String profileId, String titleId);

    List<TitleRating> findByProfileId(String profileId);
}
