package com.codenameone.examples.reel.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// That an account used a coupon. Keyed by the code and the account together,
/// so the insert itself refuses a second use.
@Entity
public class CouponRedemption {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(230)")
    private String id = "";

    @Column(nullable = false)
    private long redeemedAt;

    public CouponRedemption() {
    }

    public static String key(String code, String username) {
        return code + ":" + username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getRedeemedAt() {
        return redeemedAt;
    }

    public void setRedeemedAt(long redeemedAt) {
        this.redeemedAt = redeemedAt;
    }
}
