package com.codenameone.examples.reel.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// That an account used a coupon. Keyed by the code and the account together,
/// so the insert itself refuses a second use.
@Entity
public class CouponRedemption {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(230)")
    private String id = "";

    @Column(nullable = false)
    private Instant redeemedAt = Instant.EPOCH;

    public CouponRedemption() {
    }

    public static String key(String code, String username) {
        return code + ":" + username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Instant getRedeemedAt() {
        return redeemedAt;
    }

    public void setRedeemedAt(Instant redeemedAt) {
        this.redeemedAt = redeemedAt;
    }
}
