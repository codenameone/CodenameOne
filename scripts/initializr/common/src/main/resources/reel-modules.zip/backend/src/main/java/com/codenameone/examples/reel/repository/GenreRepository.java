package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Genre;

import java.util.List;

/// The genre rows.
@Repository(entity = Genre.class, key = String.class)
public interface GenreRepository extends CrudRepository<Genre, String> {
    List<Genre> findByPositionGreaterThanEqualOrderByPositionAsc(int from);
}
