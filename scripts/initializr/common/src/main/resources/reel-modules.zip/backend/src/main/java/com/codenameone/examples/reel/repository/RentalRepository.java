package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Rental;

import java.util.List;

/// The rental rows.
@Repository(entity = Rental.class, key = String.class)
public interface RentalRepository extends CrudRepository<Rental, String> {
    List<Rental> findByUsernameAndTitleId(String username, String titleId);

    List<Rental> findByUsernameOrderByCreatedAtDesc(String username);

    int deleteByUsername(String username);
}
