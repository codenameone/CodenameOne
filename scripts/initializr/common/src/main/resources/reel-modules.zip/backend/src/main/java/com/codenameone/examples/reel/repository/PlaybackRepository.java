package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Playback;
import java.time.Instant;
import java.util.List;

/// The playback rows.
@Repository(entity = Playback.class, key = String.class)
public interface PlaybackRepository extends CrudRepository<Playback, String> {
    int deleteByUsername(String username);

    List<Playback> findByUsernameAndEndedAt(String username, Instant endedAt);

    List<Playback> findByEndedAtOrderByStartedAtDesc(Instant endedAt);

    List<Playback> findByEndedAtAndLastHeartbeatAtLessThan(Instant endedAt, Instant before);

    List<Playback> findByUsernameAndStartedAtGreaterThan(String username, Instant since);

    List<Playback> findByStartedAtGreaterThan(Instant since);

    List<Playback> findByTitleIdAndStartedAtGreaterThan(String titleId, Instant since);

    long countByEndedAt(Instant endedAt);
}
