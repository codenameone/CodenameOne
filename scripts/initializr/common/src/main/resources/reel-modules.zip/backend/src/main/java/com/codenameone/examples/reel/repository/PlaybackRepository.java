package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Playback;

import java.util.List;

/// The playback rows.
@Repository(entity = Playback.class, key = String.class)
public interface PlaybackRepository extends CrudRepository<Playback, String> {
    int deleteByUsername(String username);

    List<Playback> findByUsernameAndEndedAt(String username, long endedAt);

    List<Playback> findByEndedAtOrderByStartedAtDesc(long endedAt);

    List<Playback> findByEndedAtAndLastHeartbeatAtLessThan(long endedAt, long before);

    List<Playback> findByUsernameAndStartedAtGreaterThan(String username, long since);

    List<Playback> findByStartedAtGreaterThan(long since);

    List<Playback> findByTitleIdAndStartedAtGreaterThan(String titleId, long since);

    long countByEndedAt(long endedAt);
}
