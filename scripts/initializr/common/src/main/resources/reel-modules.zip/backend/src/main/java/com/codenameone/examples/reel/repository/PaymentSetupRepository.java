package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.PaymentSetup;
import java.time.Instant;

/// The card setups accounts began with the payment processor.
@Repository(entity = PaymentSetup.class, key = String.class)
public interface PaymentSetupRepository extends CrudRepository<PaymentSetup, String> {
    /// A card setup an account began, or null.
    PaymentSetup findFirstByIdAndUsername(String id, String username);

    /// Marks a setup finished, if it is not yet.
    ///
    /// @return 1 for the one caller that finished it
    @Modifying
    @Query("update PaymentSetup s set s.completed = TRUE where s.id = :id and s.completed = FALSE")
    int claim(@Param("id") String id);

    /// How many setups an account began after `since` and has not finished.
    long countByUsernameAndCompletedFalseAndCreatedAtGreaterThan(String username, Instant since);

    int deleteByUsername(String username);

    /// Deletes the setups that saved their card.
    int deleteByCompletedTrue();

    /// Deletes the setups begun before `before`, finished or not.
    int deleteByCreatedAtLessThan(Instant before);
}
