package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Device;

import java.util.List;

/// The device rows.
@Repository(entity = Device.class, key = String.class)
public interface DeviceRepository extends CrudRepository<Device, String> {
    List<Device> findByUsernameOrderByLastSeenAtDesc(String username);

    Device findFirstByIdAndUsername(String id, String username);

    long countByUsernameAndRevokedAt(String username, long revokedAt);

    int deleteByUsername(String username);
}
