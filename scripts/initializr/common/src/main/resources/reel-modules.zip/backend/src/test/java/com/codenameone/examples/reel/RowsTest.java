package com.codenameone.examples.reel;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

/// The hand-written cuts the compiled server uses in place of regular
/// expressions, held to what String.split and SimpleDateFormat answered.
class RowsTest {
    @Test
    void splitCutsLikeStringSplit() {
        assertEquals(Arrays.asList("a", "", "b"), Rows.split("a::b", ':'));
        assertEquals(Arrays.asList("a", "b"), Rows.split("a:b::", ':'));
        assertEquals(Arrays.asList(""), Rows.split("", ':'));
        assertEquals(Arrays.asList("#EXTM3U", "v720.m3u8"), Rows.split("#EXTM3U\nv720.m3u8\n", '\n'));
    }

    @Test
    void wordsAreTheRunsOfLettersAndDigits() {
        assertEquals(Arrays.asList("big", "buck", "bunny", "2008"), Rows.words("  big-buck, bunny (2008)!"));
        assertEquals(Arrays.asList(), Rows.words("--"));
    }

    @Test
    void utcDayIsTheCalendarDay() {
        assertEquals("1970-01-01", Rows.utcDay(0L));
        assertEquals("1969-12-31", Rows.utcDay(-1L));
        assertEquals("2026-03-01", Rows.utcDay(20513L * 86400000L));
        assertEquals("2024-02-29", Rows.utcDay(19782L * 86400000L + 86399999L));
    }
}
