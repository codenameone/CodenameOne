package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.AdEvent;

import java.util.List;

/// The ad_event rows.
@Repository(entity = AdEvent.class, key = String.class)
public interface AdEventRepository extends CrudRepository<AdEvent, String> {
    long countBySessionIdAndCampaignIdAndEvent(String sessionId, String campaignId, String event);

    @Query("select count(e) from AdEvent e where e.event = :event and e.createdAt >= :since")
    Long countSince(@Param("event") String event, @Param("since") long since);

    @Query("select e.createdAt from AdEvent e where e.event = :event and e.createdAt >= :since")
    List<Long> timesSince(@Param("event") String event, @Param("since") long since);

    List<AdEvent> findByEventAndCreatedAtGreaterThan(String event, long since);
}
