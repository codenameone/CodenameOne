package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.FrameHash;

import java.util.List;

/// The frame_hash rows.
@Repository(entity = FrameHash.class, key = String.class)
public interface FrameHashRepository extends CrudRepository<FrameHash, String> {
    List<FrameHash> findByVideoIdOrderByPositionAsc(String videoId);

    int deleteByVideoId(String videoId);
}
