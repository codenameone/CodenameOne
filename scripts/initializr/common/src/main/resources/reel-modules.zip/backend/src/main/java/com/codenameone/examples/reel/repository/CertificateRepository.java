package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Certificate;

import java.util.List;

/// The certificate rows.
@Repository(entity = Certificate.class, key = String.class)
public interface CertificateRepository extends CrudRepository<Certificate, String> {
    int deleteByUsername(String username);

    long countByTitleId(String titleId);

    List<Certificate> findByUsernameOrderByIssuedAtDesc(String username);

    List<Certificate> findByUsernameAndTitleId(String username, String titleId);

    Certificate findFirstByVerifyCode(String verifyCode);
}
