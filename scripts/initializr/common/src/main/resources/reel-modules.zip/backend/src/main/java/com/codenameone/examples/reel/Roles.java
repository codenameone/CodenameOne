package com.codenameone.examples.reel;

import com.codename1.appkit.server.Caller;

/// The roles, as the backend's user store names them (without `ROLE_`). The
/// shared [com.codenameone.examples.reel.api.Roles] holds the same names for the app.
public final class Roles {
    public static final String VIEWER = com.codenameone.examples.reel.api.Roles.VIEWER;
    public static final String CREATOR = com.codenameone.examples.reel.api.Roles.CREATOR;
    public static final String MODERATOR = com.codenameone.examples.reel.api.Roles.MODERATOR;
    public static final String ADMIN = com.codenameone.examples.reel.api.Roles.ADMIN;

    /// Whether the caller moderates or administers: staff can play any title,
    /// published or not, without a plan, to review it.
    public static boolean isStaff() {
        return Caller.hasRole(ADMIN) || Caller.hasRole(MODERATOR);
    }

    private Roles() {
    }
}
