package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.VideoKey;

/// The video_key rows.
@Repository(entity = VideoKey.class, key = String.class)
public interface VideoKeyRepository extends CrudRepository<VideoKey, String> {
}
