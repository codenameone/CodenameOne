package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.BlockedItem;

import java.util.List;

/// The blocked_item rows.
@Repository(entity = BlockedItem.class, key = String.class)
public interface BlockedItemRepository extends CrudRepository<BlockedItem, String> {
    List<BlockedItem> findByKind(String kind);
}
