package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Upload;
import java.time.Instant;
import java.util.List;

/// The upload rows.
@Repository(entity = Upload.class, key = String.class)
public interface UploadRepository extends CrudRepository<Upload, String> {
    List<Upload> findByVideoIdOrderByCreatedAtDesc(String videoId);

    List<Upload> findByStatusAndUpdatedAtLessThan(String status, Instant before);
}
