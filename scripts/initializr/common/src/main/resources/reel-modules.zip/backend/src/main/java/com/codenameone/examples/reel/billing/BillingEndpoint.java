package com.codenameone.examples.reel.billing;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.reel.api.BillingApiServer;
import com.codenameone.examples.reel.api.CouponCheckDto;
import com.codenameone.examples.reel.api.InvoiceDto;
import com.codenameone.examples.reel.api.PlanDto;
import com.codenameone.examples.reel.api.PurchaseReceiptDto;
import com.codenameone.examples.reel.api.RentDto;
import com.codenameone.examples.reel.api.RentalDto;
import com.codenameone.examples.reel.api.SubscribeDto;
import com.codenameone.examples.reel.api.SubscriptionDto;

import java.util.List;

@Component
public class BillingEndpoint implements BillingApiServer {
    private final Billing billing;

    public BillingEndpoint(Billing billing) {
        this.billing = billing;
    }

    /// Public: the plan picker is shown before signing up.
    @Override
    public List<PlanDto> plans() throws Exception {
        return billing.plans(false);
    }

    @Override
    public SubscriptionDto subscription() throws Exception {
        return billing.subscription(Caller.name());
    }

    @Override
    public SubscriptionDto subscribe(SubscribeDto subscribe) throws Exception {
        return billing.subscribe(Caller.name(), subscribe);
    }

    @Override
    public SubscriptionDto cancel() throws Exception {
        return billing.cancel(Caller.name());
    }

    @Override
    public SubscriptionDto resume() throws Exception {
        return billing.resume(Caller.name());
    }

    @Override
    public CouponCheckDto checkCoupon(String code, String plan) throws Exception {
        Caller.name();
        return billing.checkCoupon(code, plan);
    }

    @Override
    public List<InvoiceDto> invoices() throws Exception {
        return billing.invoices(Caller.name());
    }

    @Override
    public List<RentalDto> rentals() throws Exception {
        return billing.rentals(Caller.name());
    }

    @Override
    public RentalDto rent(RentDto rent) throws Exception {
        return billing.rent(Caller.name(), rent);
    }

    @Override
    public SubscriptionDto verifyReceipt(PurchaseReceiptDto receipt) throws Exception {
        return billing.storePurchase(Caller.name(), receipt);
    }
}
