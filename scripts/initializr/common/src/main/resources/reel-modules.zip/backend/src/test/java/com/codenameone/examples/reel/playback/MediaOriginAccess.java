package com.codenameone.examples.reel.playback;

/// Opens the package-private playlist rewrite to the tests in another package.
public final class MediaOriginAccess {
    private MediaOriginAccess() {
    }

    public static String preferAudio(String master, String track) {
        return MediaOrigin.preferAudio(master, track);
    }
}
