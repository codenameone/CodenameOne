package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.CouponRedemption;

/// Which accounts used which coupons.
@Repository(entity = CouponRedemption.class, key = String.class)
public interface CouponRedemptionRepository extends CrudRepository<CouponRedemption, String> {
}
