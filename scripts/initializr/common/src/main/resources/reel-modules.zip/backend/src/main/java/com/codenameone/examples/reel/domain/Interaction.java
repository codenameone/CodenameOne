package com.codenameone.examples.reel.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A pause point in a video: a quiz, a poll, a branch or a note. `options` are one per line.
@Entity
public class Interaction {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String videoId = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String kind = "";

    @Column(nullable = false)
    private int atSeconds;

    @Column(nullable = false, type = "VARCHAR(500)")
    private String prompt = "";

    @Column(nullable = false, type = "TEXT")
    private String options = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String answers = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String explanation = "";

    @Column(nullable = false)
    private boolean required;

    @Column(nullable = false, type = "VARCHAR(255)")
    private String branchTargets = "";

    @Column(nullable = false)
    private int position;

    public Interaction() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public int getAtSeconds() {
        return atSeconds;
    }

    public void setAtSeconds(int atSeconds) {
        this.atSeconds = atSeconds;
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public String getAnswers() {
        return answers;
    }

    public void setAnswers(String answers) {
        this.answers = answers;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public String getBranchTargets() {
        return branchTargets;
    }

    public void setBranchTargets(String branchTargets) {
        this.branchTargets = branchTargets;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
