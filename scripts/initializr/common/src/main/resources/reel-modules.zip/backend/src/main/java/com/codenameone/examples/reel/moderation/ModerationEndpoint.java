package com.codenameone.examples.reel.moderation;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.reel.account.Moderation;
import com.codenameone.examples.reel.api.BlocklistEntryDto;
import com.codenameone.examples.reel.api.ModerationApiServer;
import com.codenameone.examples.reel.api.ModerationDecisionDto;
import com.codenameone.examples.reel.api.ModerationEventDto;
import com.codenameone.examples.reel.api.ModerationItemDto;

import java.util.List;

/// The moderator's console. `/api/moderation/**` is limited to moderators and
/// admins in [com.codenameone.examples.reel.SecurityConfig].
@Component
public class ModerationEndpoint implements ModerationApiServer {
    private final Reviews reviews;
    private final Moderation history;

    public ModerationEndpoint(Reviews reviews, Moderation history) {
        this.reviews = reviews;
        this.history = history;
    }

    @Override
    public List<ModerationItemDto> queue(String kind) throws Exception {
        return reviews.queue(kind);
    }

    @Override
    public ModerationItemDto decide(String id, ModerationDecisionDto decision) throws Exception {
        return reviews.decide(Caller.name(), id, decision);
    }

    @Override
    public List<BlocklistEntryDto> blocklist() throws Exception {
        return reviews.blocklist();
    }

    @Override
    public BlocklistEntryDto block(BlocklistEntryDto entry) throws Exception {
        return reviews.block(Caller.name(), entry);
    }

    @Override
    public String unblock(String id) throws Exception {
        reviews.unblock(id);
        return "ok";
    }

    @Override
    public List<ModerationEventDto> events(String username) throws Exception {
        return history.events(username);
    }
}
