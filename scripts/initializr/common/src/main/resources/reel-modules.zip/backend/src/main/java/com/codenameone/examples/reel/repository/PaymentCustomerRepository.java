package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.PaymentCustomer;

/// The payment processor's names for accounts.
@Repository(entity = PaymentCustomer.class, key = String.class)
public interface PaymentCustomerRepository extends CrudRepository<PaymentCustomer, String> {
    /// Writes an account's row without changing it, which holds the row until
    /// the transaction ends: whatever else writes it waits its turn.
    @Modifying
    @Query("update PaymentCustomer c set c.reference = c.reference where c.username = :username")
    int hold(@Param("username") String username);

    int deleteByUsername(String username);
}
