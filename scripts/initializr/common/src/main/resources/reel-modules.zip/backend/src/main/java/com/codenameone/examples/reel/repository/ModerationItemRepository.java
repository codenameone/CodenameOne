package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.ModerationItem;

import java.util.List;

/// The moderation_item rows.
@Repository(entity = ModerationItem.class, key = String.class)
public interface ModerationItemRepository extends CrudRepository<ModerationItem, String> {
    List<ModerationItem> findByStatusOrderByCreatedAtAsc(String status);

    List<ModerationItem> findByStatusAndKindOrderByCreatedAtAsc(String status, String kind);

    List<ModerationItem> findBySubjectIdAndStatus(String subjectId, String status);

    List<ModerationItem> findBySubjectIdOrderByCreatedAtDesc(String subjectId);

    long countByStatus(String status);
}
