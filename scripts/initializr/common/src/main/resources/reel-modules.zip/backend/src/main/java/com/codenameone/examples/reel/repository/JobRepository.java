package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Job;

import java.util.List;

/// The job rows.
@Repository(entity = Job.class, key = String.class)
public interface JobRepository extends CrudRepository<Job, String> {
    List<Job> findByStatusOrderByCreatedAtAsc(String status);

    List<Job> findByVideoIdOrderByCreatedAtDesc(String videoId);

    List<Job> findByStatusAndLeaseUntilLessThan(String status, long before);

    List<Job> findTop200ByCreatedAtGreaterThanOrderByCreatedAtDesc(long since);

    long countByStatus(String status);
}
