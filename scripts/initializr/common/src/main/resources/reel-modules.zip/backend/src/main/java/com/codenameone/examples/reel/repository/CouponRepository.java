package com.codenameone.examples.reel.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.reel.domain.Coupon;

/// The coupon rows.
@Repository(entity = Coupon.class, key = String.class)
public interface CouponRepository extends CrudRepository<Coupon, String> {
}
