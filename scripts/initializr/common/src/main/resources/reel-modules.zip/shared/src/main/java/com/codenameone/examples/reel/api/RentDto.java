package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Rents a title.
@Mapped
public record RentDto(
        String titleId,
        String paymentMethodId) {
}
