package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A thumbs or stars rating; 0 clears it.
@Mapped
public record RatingDto(
        int stars) {
}
