package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The admin charts.
@Mapped
public record StatsSeriesDto(
        List<SeriesPointDto> signups,
        List<SeriesPointDto> minutes,
        List<SeriesPointDto> revenue,
        List<SeriesPointDto> churn,
        List<NameCountDto> topTitles) {
}
