package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Whether a coupon applies, and the price it makes.
@Mapped
public record CouponCheckDto(
        String code,
        boolean valid,
        String reason,
        long priceCents,
        int percentOff) {
}
