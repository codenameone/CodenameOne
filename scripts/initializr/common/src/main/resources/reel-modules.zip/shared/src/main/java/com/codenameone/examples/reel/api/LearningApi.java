package com.codenameone.examples.reel.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Interactive video and courses: answers, progress and certificates.
@RestClient
public interface LearningApi {
    @POST("/api/learning/answer")
    void answer(@Body AnswerDto answer, OnComplete<Response<AnswerResultDto>> callback);

    @GET("/api/learning/progress")
    void progress(@Query("profile") String profile, OnComplete<Response<List<CourseProgressDto>>> callback);

    @GET("/api/learning/certificates")
    void certificates(OnComplete<Response<List<CertificateDto>>> callback);

    /// Anyone may check a certificate by its code; no sign-in.
    @GET("/api/verify/{code}")
    void verify(@Path("code") String code, OnComplete<Response<CertificateDto>> callback);
}
