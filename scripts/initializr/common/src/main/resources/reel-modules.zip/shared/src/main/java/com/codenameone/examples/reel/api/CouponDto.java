package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A coupon: a percent off for a number of billing periods.
@Mapped
public record CouponDto(
        String code,
        int percentOff,
        int periods,
        int maxRedemptions,
        int redemptions,
        long expiresAt,
        boolean active) {
}
