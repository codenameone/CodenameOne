package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// An audio track of a video: its language and what the menu calls it. `id`
/// is what a playback request names to hear it.
@Mapped
public record AudioTrackDto(
        String id,
        String language,
        String label) {
}
