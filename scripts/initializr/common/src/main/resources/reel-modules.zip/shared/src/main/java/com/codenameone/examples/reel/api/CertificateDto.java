package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A course completion certificate; `verifyCode` lets anyone confirm it at /verify.
@Mapped
public record CertificateDto(
        String id,
        String titleId,
        String titleName,
        String holderName,
        int scorePercent,
        long issuedAt,
        String verifyCode,
        String pdfUrl) {
}
