package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A feature preset: the flags that make Reel a streaming service, a video platform or an academy.
@Mapped
public record PresetDto(
        String id,
        String name,
        String description,
        boolean active) {
}
