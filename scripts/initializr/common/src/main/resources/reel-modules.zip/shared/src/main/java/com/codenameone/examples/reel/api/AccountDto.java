package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The signed-in account: who it is, what it may do, and what it pays for.
@Mapped
public record AccountDto(
        String username,
        String name,
        String email,
        List<String> roles,
        String planCode,
        String planName,
        String subscriptionStatus,
        long periodEndsAt,
        boolean adSupported,
        int maxStreams,
        String maxQuality,
        boolean downloadsAllowed,
        boolean suspended) {
}
