package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// An account as the admin console lists it.
@Mapped
public record UserDto(
        String username,
        String name,
        String email,
        List<String> roles,
        String planCode,
        String subscriptionStatus,
        boolean suspended,
        boolean flagged,
        int devices,
        int streamsNow,
        long createdAt,
        long lastSeenAt) {
}
