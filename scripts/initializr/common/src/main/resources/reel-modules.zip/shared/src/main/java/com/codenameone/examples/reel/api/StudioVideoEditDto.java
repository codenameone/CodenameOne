package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Creates or edits a video's metadata.
@Mapped
public record StudioVideoEditDto(
        String role,
        int season,
        int number,
        String name,
        String synopsis) {
}
