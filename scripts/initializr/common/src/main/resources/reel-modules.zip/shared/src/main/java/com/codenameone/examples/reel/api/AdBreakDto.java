package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// An ad break the player must show; `offsetSeconds` 0 is a pre-roll.
@Mapped
public record AdBreakDto(
        String id,
        int offsetSeconds,
        String vastUrl,
        int skippableAfterSeconds) {
}
