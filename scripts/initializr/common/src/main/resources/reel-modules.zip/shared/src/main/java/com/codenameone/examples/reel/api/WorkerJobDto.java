package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A job a packaging worker claimed: where the source is and what to produce.
@Mapped
public record WorkerJobDto(
        String id,
        String videoId,
        String kind,
        String sourceUrl,
        String keyId,
        String keyHex,
        String ivHex,
        List<String> renditions,
        int segmentSeconds) {
}
