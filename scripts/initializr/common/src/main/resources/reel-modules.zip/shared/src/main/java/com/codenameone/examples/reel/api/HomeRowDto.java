package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One row of the home screen: "Continue watching", "Because you watched X", a genre.
@Mapped
public record HomeRowDto(
        String id,
        String title,
        String kind,
        List<TitleCardDto> titles) {
}
