package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Starts playback. `schemes` are the DRM schemes the device answered yes to, strongest first.
@Mapped
public record PlaybackRequestDto(
        String titleId,
        String episodeId,
        String profileId,
        String deviceId,
        List<String> schemes,
        String maxQuality,
        String audioTrack,
        boolean offline) {
}
