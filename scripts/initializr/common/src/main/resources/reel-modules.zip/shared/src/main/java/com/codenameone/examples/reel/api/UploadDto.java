package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A resumable upload: send chunks of at most `chunkBytes` until `receivedBytes` is `totalBytes`.
@Mapped
public record UploadDto(
        String id,
        String videoId,
        String fileName,
        long totalBytes,
        long receivedBytes,
        int chunkBytes,
        String status) {
}
