package com.codenameone.examples.reel.api;

/// What a title's classification says beside its rating: the content that
/// earned it. A creator picks from this list in the studio; a title's page
/// lists them under the rating, and a profile's maturity limit is still the
/// rating alone.
public final class Advisories {
    public static final String VIOLENCE = "violence";
    public static final String FRIGHTENING = "frightening";
    public static final String LANGUAGE = "language";
    public static final String SEXUAL_CONTENT = "sexual";
    public static final String SUBSTANCES = "substances";
    public static final String FLASHING_LIGHTS = "flashing";

    /// Every advisory, in the order a page lists them.
    public static final String[] ALL = {VIOLENCE, FRIGHTENING, LANGUAGE, SEXUAL_CONTENT, SUBSTANCES, FLASHING_LIGHTS};

    /// What each of [#ALL] is called, in the same order.
    public static final String[] LABELS = {"Violence", "Frightening scenes", "Strong language", "Sexual content",
        "Drug or alcohol use", "Flashing lights"};

    private Advisories() {
    }

    /// What `code` is called, or null when it is not one of [#ALL].
    public static String label(String code) {
        for (int iter = 0; iter < ALL.length; iter++) {
            if (ALL[iter].equals(code)) {
                return LABELS[iter];
            }
        }
        return null;
    }
}
