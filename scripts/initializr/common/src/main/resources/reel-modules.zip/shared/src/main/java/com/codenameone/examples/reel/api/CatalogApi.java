package com.codenameone.examples.reel.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Browsing: the home screen, a title's page, genres and search. Every call is per profile.
@RestClient
public interface CatalogApi {
    @GET("/api/home")
    void home(@Query("profile") String profile, OnComplete<Response<HomeDto>> callback);

    @GET("/api/titles/{id}")
    void title(@Path("id") String id, @Query("profile") String profile,
            OnComplete<Response<TitleDto>> callback);

    @GET("/api/genres")
    void genres(OnComplete<Response<List<GenreDto>>> callback);

    @GET("/api/genres/{id}")
    void genre(@Path("id") String id, @Query("profile") String profile,
            OnComplete<Response<List<TitleCardDto>>> callback);

    @GET("/api/search")
    void search(@Query("q") String q, @Query("profile") String profile,
            OnComplete<Response<SearchResultDto>> callback);

    /// Reports a title to the moderators.
    @POST("/api/titles/{id}/report")
    void report(@Path("id") String id, @Body ReportDto report, OnComplete<Response<String>> callback);
}
