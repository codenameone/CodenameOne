package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A sign that an account's password is shared beyond its household.
@Mapped
public record SharingAlertDto(
        String id,
        String username,
        String kind,
        String detail,
        int distinctIps,
        int distinctCountries,
        String status,
        long createdAt) {
}
