package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Subscribes, or changes plan. `coupon` is optional.
@Mapped
public record SubscribeDto(
        String planCode,
        String coupon,
        String paymentMethodId) {
}
