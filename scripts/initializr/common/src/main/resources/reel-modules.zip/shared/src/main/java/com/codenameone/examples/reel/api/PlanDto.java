package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A subscription plan.
@Mapped
public record PlanDto(
        String code,
        String name,
        String description,
        long priceCents,
        String currency,
        String interval,
        int maxStreams,
        String maxQuality,
        boolean adSupported,
        boolean downloads,
        int trialDays,
        boolean active) {
}
