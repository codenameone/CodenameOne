package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A genre or academy subject.
@Mapped
public record GenreDto(
        String id,
        String name,
        int titleCount) {
}
