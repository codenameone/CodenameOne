package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A title as it appears in a row: enough to draw the tile and open the details.
@Mapped
public record TitleCardDto(
        String id,
        String kind,
        String name,
        String posterUrl,
        String backdropUrl,
        int year,
        String rating,
        int durationSeconds,
        double score,
        int progressPercent,
        String badge,
        boolean free,
        boolean rentable) {
}
