package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A banned perceptual hash or keyword.
@Mapped
public record BlocklistEntryDto(
        String id,
        String kind,
        String value,
        String note,
        long createdAt) {
}
