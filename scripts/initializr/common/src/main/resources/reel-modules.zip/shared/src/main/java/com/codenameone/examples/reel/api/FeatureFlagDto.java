package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A feature switch and its current value.
@Mapped
public record FeatureFlagDto(
        String key,
        String label,
        String group,
        boolean enabled,
        String value) {
}
