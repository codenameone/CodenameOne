package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// The account's subscription.
@Mapped
public record SubscriptionDto(
        String planCode,
        String planName,
        String status,
        long startedAt,
        long periodEndsAt,
        boolean cancelAtPeriodEnd,
        long priceCents,
        String currency,
        String couponCode,
        int discountPercent,
        String pendingPlanCode) {
}
