package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A named point in a video; academy titles also gate quizzes on them.
@Mapped
public record ChapterDto(
        String id,
        int startSeconds,
        String title) {
}
