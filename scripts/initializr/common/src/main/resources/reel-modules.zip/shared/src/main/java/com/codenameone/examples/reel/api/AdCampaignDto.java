package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// An ad campaign.
@Mapped
public record AdCampaignDto(
        String id,
        String advertiser,
        String name,
        String creativeUrl,
        int durationSeconds,
        int skippableAfterSeconds,
        String clickUrl,
        long cpmCents,
        long budgetCents,
        long spentCents,
        int impressions,
        int clicks,
        List<String> genres,
        boolean active,
        long startsAt,
        long endsAt) {
}
