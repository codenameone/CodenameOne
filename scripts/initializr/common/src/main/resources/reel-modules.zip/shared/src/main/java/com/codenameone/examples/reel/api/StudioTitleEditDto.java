package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Creates or edits a title.
@Mapped
public record StudioTitleEditDto(
        String kind,
        String name,
        String synopsis,
        int year,
        String rating,
        List<String> advisories,
        List<String> genres,
        List<String> tags,
        String access,
        long rentalPriceCents,
        boolean certificate,
        int passPercent) {
}
