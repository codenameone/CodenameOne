package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A packaging job: an upload turned into a streamable, protected ladder.
@Mapped
public record JobDto(
        String id,
        String videoId,
        String kind,
        String status,
        int progressPercent,
        String worker,
        String error,
        long createdAt,
        long startedAt,
        long finishedAt) {
}
