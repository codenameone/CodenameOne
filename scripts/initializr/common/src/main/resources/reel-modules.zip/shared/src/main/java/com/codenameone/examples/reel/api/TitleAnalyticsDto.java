package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// How a title performs.
@Mapped
public record TitleAnalyticsDto(
        String titleId,
        String titleName,
        int views,
        int uniqueViewers,
        long minutesWatched,
        int completionPercent,
        double averageRating,
        long revenueCents,
        int quizAttempts,
        int quizPassPercent,
        int certificates,
        List<Integer> retention,
        List<NameCountDto> countries) {
}
