package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Something an admin did to an account, and why.
///
/// @param at Milliseconds since the epoch.
/// @param by The admin who did it.
/// @param action `flag`, `unflag`, `block`, `unblock`, `approve`, `reject`, `roles`.
@Mapped
public record ModerationEventDto(long at, String by, String action, String reason) {
}
