package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// The admin's action on a sharing alert.
@Mapped
public record SharingDecisionDto(
        String action,
        String note) {
}
