package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Something waiting for a moderator: a title, a comment, a report or an appeal.
@Mapped
public record ModerationItemDto(
        String id,
        String kind,
        String subjectId,
        String subjectName,
        String owner,
        String reason,
        String detail,
        List<String> signals,
        double score,
        String thumbnailUrl,
        String status,
        long createdAt) {
}
