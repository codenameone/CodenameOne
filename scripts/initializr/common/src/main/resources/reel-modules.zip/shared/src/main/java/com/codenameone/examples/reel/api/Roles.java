package com.codenameone.examples.reel.api;

/// The roles an account can hold. Every account is a viewer; the others are
/// granted from the admin console.
public final class Roles {
    /// Watches, rates, subscribes.
    public static final String VIEWER = "VIEWER";
    /// Uploads and publishes titles through the studio.
    public static final String CREATOR = "CREATOR";
    /// Works the moderation queue.
    public static final String MODERATOR = "MODERATOR";
    /// Everything, including the admin console.
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
