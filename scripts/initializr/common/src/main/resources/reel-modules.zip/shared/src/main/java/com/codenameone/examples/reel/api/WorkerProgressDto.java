package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A worker's progress report.
@Mapped
public record WorkerProgressDto(
        int progressPercent,
        String status,
        String error) {
}
