package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A creator's appeal of a moderation decision.
@Mapped
public record AppealDto(
        String titleId,
        String text) {
}
