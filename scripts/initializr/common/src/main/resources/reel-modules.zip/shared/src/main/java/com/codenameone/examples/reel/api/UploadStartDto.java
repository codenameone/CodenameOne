package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Opens an upload for a video.
@Mapped
public record UploadStartDto(
        String videoId,
        String fileName,
        long totalBytes,
        String sha256) {
}
