package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// An interaction as its author writes it: `answers` are the correct option indexes.
@Mapped
public record InteractionEditDto(
        String id,
        String kind,
        int atSeconds,
        String prompt,
        List<String> options,
        List<Integer> answers,
        String explanation,
        boolean required,
        List<String> branchTargets) {
}
