package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A playback in progress somewhere on the account, or one the admin console watches.
@Mapped
public record SessionDto(
        String id,
        String username,
        String profileId,
        String profileName,
        String titleId,
        String titleName,
        String deviceName,
        String ip,
        String country,
        long startedAt,
        long lastHeartbeatAt) {
}
