package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A viewer's progress through a course.
@Mapped
public record CourseProgressDto(
        String titleId,
        String titleName,
        int lessonsTotal,
        int lessonsCompleted,
        int quizScorePercent,
        boolean certificateEarned,
        String certificateId) {
}
