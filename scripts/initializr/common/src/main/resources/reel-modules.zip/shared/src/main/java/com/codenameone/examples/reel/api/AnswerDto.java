package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A viewer's answer to an interaction.
@Mapped
public record AnswerDto(
        String interactionId,
        String sessionId,
        List<Integer> choices,
        String text) {
}
