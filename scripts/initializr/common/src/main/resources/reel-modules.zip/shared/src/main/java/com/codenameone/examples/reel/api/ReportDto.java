package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A viewer report of a title.
@Mapped
public record ReportDto(
        String titleId,
        String reason,
        String detail) {
}
