package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A video of a title: the feature, an episode or lesson, or the trailer.
@Mapped
public record StudioVideoDto(
        String id,
        String role,
        int season,
        int number,
        String name,
        String synopsis,
        String status,
        int progressPercent,
        String error,
        int durationSeconds,
        String thumbnailUrl,
        List<SubtitleDto> subtitles,
        List<ChapterDto> chapters,
        List<InteractionEditDto> interactions) {
}
