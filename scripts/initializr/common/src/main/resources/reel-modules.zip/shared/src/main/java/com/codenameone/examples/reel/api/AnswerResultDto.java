package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Whether an answer was right, the poll tally, or the episode a branch leads to.
@Mapped
public record AnswerResultDto(
        boolean correct,
        String explanation,
        List<Integer> tally,
        String nextEpisodeId,
        int scorePercent) {
}
