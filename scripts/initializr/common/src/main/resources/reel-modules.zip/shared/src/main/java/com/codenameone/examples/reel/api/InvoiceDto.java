package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A billing record: a subscription period, a rental, a refund.
@Mapped
public record InvoiceDto(
        String id,
        String kind,
        String description,
        long amountCents,
        String currency,
        String status,
        long createdAt,
        String titleId) {
}
