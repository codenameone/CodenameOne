package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// An ad tracking event: impression, quartile, skip, click, complete.
@Mapped
public record AdEventDto(
        String sessionId,
        String adId,
        String campaignId,
        String event) {
}
