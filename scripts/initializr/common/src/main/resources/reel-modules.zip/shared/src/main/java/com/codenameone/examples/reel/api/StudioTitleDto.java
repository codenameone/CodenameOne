package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A title as its creator edits it.
@Mapped
public record StudioTitleDto(
        String id,
        String kind,
        String name,
        String synopsis,
        int year,
        String rating,
        List<String> advisories,
        List<String> genres,
        List<String> tags,
        String access,
        long rentalPriceCents,
        String status,
        String moderationStatus,
        String moderationNote,
        String posterUrl,
        boolean interactive,
        boolean certificate,
        int passPercent,
        long createdAt,
        long publishedAt,
        List<StudioVideoDto> videos) {
}
