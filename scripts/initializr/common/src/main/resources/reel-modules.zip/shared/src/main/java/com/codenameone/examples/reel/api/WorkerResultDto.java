package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What a worker produced.
@Mapped
public record WorkerResultDto(
        int durationSeconds,
        int width,
        int height,
        List<String> renditions,
        List<String> frameHashes,
        String posterPath,
        String spritePath) {
}
