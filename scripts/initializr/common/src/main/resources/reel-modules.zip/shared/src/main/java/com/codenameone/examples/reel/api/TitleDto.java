package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A title's details page.
@Mapped
public record TitleDto(
        String id,
        String kind,
        String name,
        String synopsis,
        String posterUrl,
        String backdropUrl,
        int year,
        String rating,
        List<String> advisories,
        int maxHeight,
        List<String> audioLanguages,
        List<String> subtitleLanguages,
        String shareUrl,
        List<String> genres,
        List<String> tags,
        String creator,
        String creatorName,
        int durationSeconds,
        double averageRating,
        int ratingCount,
        int myRating,
        boolean inMyList,
        int resumeSeconds,
        String access,
        long rentalPriceCents,
        String currency,
        boolean entitled,
        boolean downloadable,
        boolean interactive,
        boolean certificate,
        String trailerVideoId,
        List<ChapterDto> chapters,
        List<EpisodeDto> episodes,
        List<TitleCardDto> similar) {
}
