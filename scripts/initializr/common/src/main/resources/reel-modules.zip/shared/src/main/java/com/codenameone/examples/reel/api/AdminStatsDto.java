package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// The headline numbers.
@Mapped
public record AdminStatsDto(
        int accounts,
        int activeSubscriptions,
        int trialing,
        long mrrCents,
        String currency,
        int streamsNow,
        long minutesToday,
        int titles,
        int pendingModeration,
        int jobsQueued,
        int jobsFailed,
        int sharingAlerts,
        long adImpressionsToday,
        long adRevenueCentsToday) {
}
