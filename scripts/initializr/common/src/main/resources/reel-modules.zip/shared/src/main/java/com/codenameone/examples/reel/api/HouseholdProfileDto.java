package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A viewer inside an account: its own list, history, recommendations and rating limit.
///
/// `key` is set only by an unlock: the app sends it back as `X-Reel-Profile-Key`
/// with every request made as a PIN-protected profile, and with profile edits.
@Mapped
public record HouseholdProfileDto(
        String id,
        String name,
        String avatar,
        boolean kids,
        String maxRating,
        boolean pinProtected,
        String language,
        String key) {
}
