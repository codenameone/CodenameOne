package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Creates or edits a household profile. An empty `pin` leaves the PIN as it is; `clearPin` removes it.
@Mapped
public record ProfileEditDto(
        String name,
        String avatar,
        boolean kids,
        String maxRating,
        String pin,
        boolean clearPin,
        String language) {
}
