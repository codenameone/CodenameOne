package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// The service's name and colours, set from the admin console.
@Mapped
public record BrandingDto(
        String serviceName,
        String tagline,
        String primaryColor,
        String accentColor,
        String logoUrl) {
}
