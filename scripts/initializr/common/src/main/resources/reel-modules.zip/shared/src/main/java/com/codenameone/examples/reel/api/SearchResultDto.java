package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A page of search results.
@Mapped
public record SearchResultDto(
        String query,
        int total,
        List<TitleCardDto> titles) {
}
