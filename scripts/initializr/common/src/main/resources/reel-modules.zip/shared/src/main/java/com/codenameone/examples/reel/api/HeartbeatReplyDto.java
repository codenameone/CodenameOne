package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// The server's answer to a heartbeat: carry on, or stop because the lease went elsewhere.
@Mapped
public record HeartbeatReplyDto(
        boolean ok,
        String reason,
        long expiresAt) {
}
