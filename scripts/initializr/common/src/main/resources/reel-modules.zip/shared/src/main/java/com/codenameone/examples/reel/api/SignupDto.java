package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A new account; the e-mail is its sign-in name.
@Mapped
public record SignupDto(
        String email,
        String password,
        String name) {
}
