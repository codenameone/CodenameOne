package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What the client needs before sign-in: branding, the active preset and the flags.
@Mapped
public record AppConfigDto(
        BrandingDto branding,
        String preset,
        List<FeatureFlagDto> flags,
        PaymentConfigDto payment) {
}
