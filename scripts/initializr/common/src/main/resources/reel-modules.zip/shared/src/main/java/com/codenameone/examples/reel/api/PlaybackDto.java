package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What the player needs: the manifest, the protection, the ads and where to resume.
@Mapped
public record PlaybackDto(
        String sessionId,
        String manifestUrl,
        String scheme,
        String licenseUrl,
        String certificateUrl,
        String contentId,
        String licenseToken,
        int resumeSeconds,
        int heartbeatSeconds,
        List<AdBreakDto> adBreaks,
        List<SubtitleDto> subtitles,
        List<ChapterDto> chapters,
        List<InteractionDto> interactions,
        String watermark,
        long expiresAt) {
}
