package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What the player needs: the manifest, the protection, the ads and where to resume.
@Mapped
public record PlaybackDto(
        String sessionId,
        String titleName,
        String episodeName,
        String posterUrl,
        int durationSeconds,
        String nextEpisodeId,
        String manifestUrl,
        String scheme,
        String licenseUrl,
        String certificateUrl,
        String contentId,
        String licenseToken,
        int resumeSeconds,
        int heartbeatSeconds,
        List<AdBreakDto> adBreaks,
        List<SubtitleDto> subtitles,
        List<AudioTrackDto> audioTracks,
        String audioTrack,
        List<Integer> qualities,
        int maxHeight,
        List<ChapterDto> chapters,
        List<InteractionDto> interactions,
        String watermark,
        long expiresAt) {
}
