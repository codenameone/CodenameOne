package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A rental: a title the account may play until it expires.
@Mapped
public record RentalDto(
        String id,
        String titleId,
        String titleName,
        long priceCents,
        String currency,
        long expiresAt,
        boolean started) {
}
