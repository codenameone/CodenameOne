package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A profile PIN, to unlock a protected profile.
@Mapped
public record PinDto(
        String pin) {
}
