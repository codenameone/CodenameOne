package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// One day of a chart.
@Mapped
public record SeriesPointDto(
        String day,
        long value) {
}
