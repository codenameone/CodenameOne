package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A title the profile watched.
@Mapped
public record HistoryEntryDto(
        String titleId,
        String titleName,
        String episodeId,
        String posterUrl,
        int positionSeconds,
        int durationSeconds,
        long watchedAt) {
}
