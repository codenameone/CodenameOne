package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A moderator's decision on an item.
@Mapped
public record ModerationDecisionDto(
        String action,
        String note) {
}
