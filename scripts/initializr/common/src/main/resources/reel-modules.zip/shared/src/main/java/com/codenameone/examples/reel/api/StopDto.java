package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// Ends a playback session.
@Mapped
public record StopDto(
        String sessionId,
        int positionSeconds,
        boolean completed) {
}
