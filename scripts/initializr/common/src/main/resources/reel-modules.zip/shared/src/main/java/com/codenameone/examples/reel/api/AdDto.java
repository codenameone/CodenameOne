package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A resolved ad creative, parsed from the VAST document.
@Mapped
public record AdDto(
        String id,
        String campaignId,
        String mediaUrl,
        int durationSeconds,
        int skippableAfterSeconds,
        String clickUrl,
        String advertiser,
        List<String> impressionUrls) {
}
