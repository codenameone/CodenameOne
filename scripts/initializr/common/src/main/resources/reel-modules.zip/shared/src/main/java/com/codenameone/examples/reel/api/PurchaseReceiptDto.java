package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// An app-store receipt for the server to verify and turn into a subscription.
@Mapped
public record PurchaseReceiptDto(
        String store,
        String productId,
        String receipt,
        String transactionId) {
}
