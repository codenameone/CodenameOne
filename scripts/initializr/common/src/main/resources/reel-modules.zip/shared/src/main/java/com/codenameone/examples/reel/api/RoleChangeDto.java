package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Replaces an account's roles.
@Mapped
public record RoleChangeDto(
        List<String> roles) {
}
