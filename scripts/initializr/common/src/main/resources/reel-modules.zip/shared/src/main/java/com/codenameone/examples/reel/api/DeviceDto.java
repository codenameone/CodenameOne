package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A device that has signed in to the account; the account owner may sign it out.
@Mapped
public record DeviceDto(
        String id,
        String name,
        String platform,
        String lastIp,
        String lastCountry,
        long lastSeenAt,
        boolean current) {
}
