package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A subtitle track a creator adds: what the player's menu calls it, and the
/// WebVTT file itself.
@Mapped
public record SubtitleUploadDto(
        String label,
        String vtt) {
}
