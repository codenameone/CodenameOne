package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// The player's lease renewal and progress report.
@Mapped
public record HeartbeatDto(
        String sessionId,
        int positionSeconds,
        boolean paused,
        int bitrateKbps,
        int bufferingMillis) {
}
