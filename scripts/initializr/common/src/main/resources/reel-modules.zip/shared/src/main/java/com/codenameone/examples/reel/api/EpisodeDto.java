package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// An episode of a series, or a lesson of a course.
@Mapped
public record EpisodeDto(
        String id,
        int season,
        int number,
        String name,
        String synopsis,
        String thumbnailUrl,
        int durationSeconds,
        int progressPercent,
        boolean completed,
        boolean locked) {
}
