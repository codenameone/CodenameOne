package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A pause point in a video: a quiz, a poll, a branching choice or a note.
@Mapped
public record InteractionDto(
        String id,
        String kind,
        int atSeconds,
        String prompt,
        List<String> options,
        boolean required,
        int passPercent,
        List<String> branchTargets) {
}
