package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Replaces a video's chapters.
@Mapped
public record ChaptersDto(
        List<ChapterDto> chapters) {
}
