package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Everything the admin may see of one account.
@Mapped
public record UserDetailDto(
        UserDto user,
        List<DeviceDto> devices,
        List<SessionDto> sessions,
        List<InvoiceDto> invoices,
        List<ModerationEventDto> moderation,
        List<SharingAlertDto> sharingAlerts) {
}
