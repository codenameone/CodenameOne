package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Replaces a video's interactions.
@Mapped
public record InteractionsDto(
        List<InteractionEditDto> interactions) {
}
