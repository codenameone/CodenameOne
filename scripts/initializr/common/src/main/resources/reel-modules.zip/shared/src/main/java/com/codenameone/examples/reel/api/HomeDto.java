package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The home screen for one profile: the hero title and its rows.
@Mapped
public record HomeDto(
        TitleCardDto hero,
        List<HomeRowDto> rows) {
}
