package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// A subtitle track.
@Mapped
public record SubtitleDto(
        String language,
        String label,
        String url) {
}
