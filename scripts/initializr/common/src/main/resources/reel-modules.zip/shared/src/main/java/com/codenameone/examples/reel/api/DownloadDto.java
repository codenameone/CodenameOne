package com.codenameone.examples.reel.api;

import com.codename1.annotations.Mapped;

/// An offline download: the license it plays under expires even if the file stays.
@Mapped
public record DownloadDto(
        String id,
        String titleId,
        String titleName,
        String episodeId,
        String manifestUrl,
        String scheme,
        String licenseToken,
        long licenseExpiresAt,
        long sizeBytes,
        String deviceId) {
}
