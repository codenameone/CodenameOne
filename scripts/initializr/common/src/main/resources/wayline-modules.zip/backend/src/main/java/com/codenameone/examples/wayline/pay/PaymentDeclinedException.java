package com.codenameone.examples.wayline.pay;

import java.io.IOException;

/// A card was refused, or a setup was not finished: the processor was asked
/// and said no. The message is written for the person paying and is safe to
/// show them -- unlike that of a plain `IOException` from a provider, which
/// describes a fault and goes to the log.
public class PaymentDeclinedException extends IOException {
    public PaymentDeclinedException(String message) {
        super(message);
    }
}
