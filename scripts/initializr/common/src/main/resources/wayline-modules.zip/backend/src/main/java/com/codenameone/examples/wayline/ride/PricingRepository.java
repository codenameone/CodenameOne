package com.codenameone.examples.wayline.ride;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.Pricing;

/// Where the admin's prices are kept: one row, or none while the prices are
/// still the settings'.
@Component
public class PricingRepository {
    private static final Integer ONLY = Integer.valueOf(1);

    private final Session session;

    public PricingRepository(Session session) {
        this.session = session;
    }

    /// The prices the admin set, or null when they have set none.
    public Pricing find() {
        return session.find(Pricing.class, ONLY);
    }

    /// Stores the admin's prices for the first time, as the one row there is.
    /// Changing them afterwards needs no call: the transaction writes what
    /// changed in the row [#find] answered.
    public void add(Pricing pricing) {
        pricing.id = ONLY.intValue();
        session.persist(pricing);
    }
}
