package com.codenameone.examples.wayline.geo;

import java.io.IOException;

/// Percent-encodes text for a query string or a form body.
public final class UrlText {
    private static final char[] HEX = "0123456789ABCDEF".toCharArray();

    private UrlText() {
    }

    /// Everything but the unreserved characters of RFC 3986 is escaped, as the
    /// bytes of its UTF-8 form.
    public static String encode(String text) throws IOException {
        byte[] bytes = text.getBytes("UTF-8");
        StringBuilder out = new StringBuilder(bytes.length + 16);
        for (int iter = 0; iter < bytes.length; iter++) {
            int b = bytes[iter] & 0xff;
            if ((b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9')
                    || b == '-' || b == '.' || b == '_' || b == '~') {
                out.append((char) b);
            } else {
                out.append('%').append(HEX[b >> 4]).append(HEX[b & 0xf]);
            }
        }
        return out.toString();
    }
}
