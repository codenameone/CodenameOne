package com.codenameone.examples.wayline.account;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.ModerationEvent;

import java.util.List;

/// Where the record of what the admins did is read from and written to.
@Component
public class ModerationRepository {
    private final Session session;

    public ModerationRepository(Session session) {
        this.session = session;
    }

    /// When the newest event of an account was written, or null when it has
    /// none.
    public Long newest(String username) {
        return session.createQuery("select max(e.createdAt) from ModerationEvent e "
                + "where e.username = :username", Long.class)
                .setParameter("username", username).first();
    }

    public void add(ModerationEvent event) {
        session.persist(event);
    }

    /// An account's events, newest first, and no more than `limit` of them.
    public List<ModerationEvent> of(String username, int limit) {
        return session.query(ModerationEvent.class).eq("username", username)
                .orderBy("createdAt", false).orderBy("id", true).limit(limit).list();
    }

    /// Deletes every event of an account. A bulk statement: whatever the
    /// session had loaded before it is stale afterwards.
    public void removeAll(String username) {
        session.createQuery("delete from ModerationEvent e where e.username = :username")
                .setParameter("username", username).executeUpdate();
    }
}
