package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One payment of earnings to a driver.
@Entity(table = "wl_payout")
public class Payout {
    @Id(autoIncrement = false)
    @Column(name = "id", nullable = false)
    public String id = "";

    @Column(name = "driver", nullable = false)
    public String driver = "";

    @Column(name = "amount_cents", nullable = false)
    public long amountCents;

    @Column(name = "status", nullable = false)
    public String status = "";

    @Column(name = "created_at", nullable = false)
    public long createdAt;

    @Column(name = "destination", nullable = false)
    public String destination = "";

    public Payout() {
    }
}
