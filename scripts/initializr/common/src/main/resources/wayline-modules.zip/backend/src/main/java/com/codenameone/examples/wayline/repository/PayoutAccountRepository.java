package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.PayoutAccount;

/// Where each driver is paid, keyed by the driver.
@Repository(entity = PayoutAccount.class, key = String.class)
public interface PayoutAccountRepository extends CrudRepository<PayoutAccount, String> {
    /// Makes the rest of the transaction wait its turn behind any other that
    /// holds the same driver's payout account.
    ///
    /// @return 1, or 0 for a driver who has not said where to be paid
    @Modifying
    @Query("update PayoutAccount a set a.last4 = a.last4 where a.username = :driver")
    int hold(@Param("driver") String driver);

    int deleteByUsername(String username);
}
