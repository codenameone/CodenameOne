package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.Payout;

import java.util.List;

/// The payouts made to drivers.
@Repository(entity = Payout.class, key = String.class)
public interface PayoutRepository extends CrudRepository<Payout, String> {
    /// The last hundred payouts made to a driver, newest first.
    List<Payout> findTop100ByDriverOrderByCreatedAtDescIdAsc(String driver);

    /// Everything ever paid out to a driver. A sum over no rows is nothing at
    /// all to a database, hence the zero to fall back on.
    @Query("select coalesce(sum(p.amountCents), 0) from Payout p where p.driver = :driver")
    Long paidOut(@Param("driver") String driver);
}
