package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// How long a driver was on line on one day, counted in UTC days.
@Entity(table = "wl_driver_hours")
public class DriverHours {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Id(autoIncrement = false)
    @Column(name = "day_number", nullable = false)
    public long dayNumber;

    @Column(name = "millis", nullable = false)
    public long millis;

    public DriverHours() {
    }
}
