package com.codenameone.examples.wayline.geo;

/// Distances on the ground.
public final class Geo {
    private static final double EARTH_RADIUS_METERS = 6371000d;
    /// Metres in a degree of latitude, anywhere. A degree of longitude is this
    /// times the cosine of the latitude.
    public static final double METERS_PER_DEGREE = 111320d;

    private Geo() {
    }

    /// The great-circle distance between two points, in metres.
    public static double meters(double lat1, double lng1, double lat2, double lng2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double sinLat = Math.sin(dLat / 2);
        double sinLng = Math.sin(dLng / 2);
        double a = sinLat * sinLat + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * sinLng * sinLng;
        return 2 * EARTH_RADIUS_METERS * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0d, 1 - a)));
    }

    public static boolean isPoint(double lat, double lng) {
        return lat >= -90d && lat <= 90d && lng >= -180d && lng <= 180d
                && !(lat == 0d && lng == 0d);
    }
}
