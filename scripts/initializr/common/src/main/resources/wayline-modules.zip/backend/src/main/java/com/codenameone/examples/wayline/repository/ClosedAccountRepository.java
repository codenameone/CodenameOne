package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.ClosedAccount;

/// The hashes of the e-mails that had an account once and may not have another.
@Repository(entity = ClosedAccount.class, key = String.class)
public interface ClosedAccountRepository extends CrudRepository<ClosedAccount, String> {

}
