package com.codenameone.examples.wayline.push;

import com.codename1.backend.push.PushNotification;
import com.codename1.backend.push.PushTarget;

import java.util.List;

/// What the server sends with when the push settings are incomplete: nothing
/// goes out, and the log says why.
///
/// The problem is logged once when the server starts and again on every send,
/// naming the settings to fix. Unlike a text message, a notification that does
/// not go out costs nobody a sign-in, so it is not an error to the caller.
public class MisconfiguredPushSender implements PushSender {
    private final String problem;

    /// @param problem what is wrong, naming the settings to fix
    public MisconfiguredPushSender(String problem) {
        this.problem = problem;
        System.err.println("[config] " + problem);
    }

    @Override
    public void send(List<PushTarget> targets, PushNotification message, Runnable delivered) {
        if (targets != null && !targets.isEmpty()) {
            System.err.println("[config] a push notification was not sent: " + problem);
        }
    }
}
