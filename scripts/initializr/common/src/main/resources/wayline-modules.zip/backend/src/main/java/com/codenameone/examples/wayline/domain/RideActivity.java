package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// The Live Activity a rider's phone shows a ride in, while the ride lasts.
@Entity
public class RideActivity {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String rideId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    /// The id the phone's platform gave the activity.
    @Column(nullable = false, type = "VARCHAR(190)")
    private String activityId = "";

    /// When the server last sent it a state, for spacing out the updates.
    @Column(nullable = false)
    private Instant sentAt = Instant.EPOCH;

    /// When its ride ended, 0 while the ride lasts. An ended activity is kept
    /// until the phone has been told to end it.
    @Column(nullable = false)
    private Instant endedAt = Instant.EPOCH;

    public RideActivity() {
    }

    public String getRideId() {
        return rideId;
    }

    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }

    public Instant getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(Instant endedAt) {
        this.endedAt = endedAt;
    }
}
