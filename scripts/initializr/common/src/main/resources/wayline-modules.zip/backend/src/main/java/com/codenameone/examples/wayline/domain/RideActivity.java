package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The Live Activity a rider's phone shows a ride in, while the ride lasts.
@Entity
public class RideActivity {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String rideId = "";

    @Column(nullable = false)
    private String username = "";

    /// The id the phone's platform gave the activity.
    @Column(nullable = false)
    private String activityId = "";

    /// When the server last sent it a state, for spacing out the updates.
    @Column(nullable = false)
    private long sentAt;

    /// When its ride ended, 0 while the ride lasts. An ended activity is kept
    /// until the phone has been told to end it.
    @Column(nullable = false)
    private long endedAt;

    public RideActivity() {
    }

    public String getRideId() {
        return rideId;
    }

    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public long getSentAt() {
        return sentAt;
    }

    public void setSentAt(long sentAt) {
        this.sentAt = sentAt;
    }

    public long getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(long endedAt) {
        this.endedAt = endedAt;
    }
}
