package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A saved card: what the provider calls it and what to show for it. The
/// number itself is never here.
@Entity(table = "wl_payment_method")
public class PaymentMethod {
    @Id(autoIncrement = false)
    @Column(name = "id", nullable = false)
    public String id = "";

    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "brand", nullable = false)
    public String brand = "";

    @Column(name = "last4", nullable = false)
    public String last4 = "";

    @Column(name = "exp_month", nullable = false)
    public int expMonth;

    @Column(name = "exp_year", nullable = false)
    public int expYear;

    @Column(name = "token", nullable = false)
    public String token = "";

    @Column(name = "is_default", nullable = false)
    public boolean preferred;

    @Column(name = "created_at", nullable = false)
    public long createdAt;

    public PaymentMethod() {
    }
}
