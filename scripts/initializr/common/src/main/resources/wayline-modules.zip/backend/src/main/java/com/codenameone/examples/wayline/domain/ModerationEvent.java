package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One thing an admin did to an account, and why. Written once, never changed.
@Entity(table = "wl_moderation_event")
public class ModerationEvent {
    @Id(autoIncrement = false)
    @Column(name = "id", nullable = false)
    public String id = "";

    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "created_at", nullable = false)
    public long createdAt;

    @Column(name = "actor", nullable = false)
    public String actor = "";

    @Column(name = "action", nullable = false)
    public String action = "";

    @Column(name = "reason", nullable = false)
    public String reason = "";

    public ModerationEvent() {
    }
}
