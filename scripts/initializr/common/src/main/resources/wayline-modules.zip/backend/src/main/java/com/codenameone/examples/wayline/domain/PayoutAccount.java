package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// Where a driver's earnings are paid out to.
@Entity(table = "wl_payout_account")
public class PayoutAccount {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "holder", nullable = false)
    public String holder = "";

    @Column(name = "bank_name", nullable = false)
    public String bankName = "";

    @Column(name = "last4", nullable = false)
    public String last4 = "";

    public PayoutAccount() {
    }
}
