package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The verification code an account was last sent, as its hash.
@Entity(table = "wl_phone_code")
public class PhoneCode {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "code_hash", nullable = false)
    public String codeHash = "";

    @Column(name = "expires_at", nullable = false)
    public long expiresAt;

    @Column(name = "attempts", nullable = false)
    public int attempts;

    @Column(name = "sent_at", nullable = false)
    public long sentAt;

    public PhoneCode() {
    }
}
