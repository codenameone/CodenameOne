package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The verification code an account was last sent, as its hash.
@Entity(table = "wl_phone_code")
public class PhoneCode {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "code_hash", nullable = false)
    public String codeHash = "";

    @Column(name = "expires_at", nullable = false)
    public long expiresAt;

    @Column(name = "attempts", nullable = false)
    public int attempts;

    @Column(name = "sent_at", nullable = false)
    public long sentAt;

    /// The code sent before this one, while it is still good, or empty.
    @Column(name = "previous_hash", nullable = false)
    public String previousHash = "";

    @Column(name = "previous_expires_at", nullable = false)
    public long previousExpiresAt;

    /// The guesses already taken at the code before, which keeps the budget
    /// it had rather than starting a new one when another code is sent.
    @Column(name = "previous_attempts", nullable = false)
    public int previousAttempts;

    public PhoneCode() {
    }
}
