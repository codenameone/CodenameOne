package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A card being added on the provider's page, until the browser comes back.
@Entity(table = "wl_payment_setup")
public class PaymentSetup {
    @Id(autoIncrement = false)
    @Column(name = "id", nullable = false)
    public String id = "";

    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "reference", nullable = false)
    public String reference = "";

    @Column(name = "created_at", nullable = false)
    public long createdAt;

    @Column(name = "completed", nullable = false)
    public boolean completed;

    public PaymentSetup() {
    }
}
