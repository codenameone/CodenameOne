package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// How one person wants the app and their rides, when they have said.
@Entity(table = "wl_preferences")
public class Preference {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "theme", nullable = false)
    public String theme = "";

    @Column(name = "units", nullable = false)
    public String units = "";

    @Column(name = "notify_rides", nullable = false)
    public boolean notifyRides;

    @Column(name = "notify_receipts", nullable = false)
    public boolean notifyReceipts;

    @Column(name = "notify_promotions", nullable = false)
    public boolean notifyPromotions;

    @Column(name = "driver_gender", nullable = false)
    public String driverGender = "";

    @Column(name = "quiet_ride", nullable = false)
    public boolean quietRide;

    @Column(name = "wheelchair", nullable = false)
    public boolean wheelchair;

    @Column(name = "pet_friendly", nullable = false)
    public boolean petFriendly;

    @Column(name = "default_tip", nullable = false)
    public int defaultTip;

    @Column(name = "share_trips_with", nullable = false)
    public String shareTripsWith = "";

    public Preference() {
    }
}
