package com.codenameone.examples.wayline.account;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.Preference;

/// Where an account's preferences are read from and written to.
@Component
public class PreferenceRepository {
    private final Session session;

    public PreferenceRepository(Session session) {
        this.session = session;
    }

    /// The preferences of an account, or null for someone who never saved any.
    public Preference find(String username) {
        return session.find(Preference.class, username);
    }

    public void add(Preference preference) {
        session.persist(preference);
    }
}
