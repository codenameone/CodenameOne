package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A document an applicant uploaded, one of each kind. `data` is the file in
/// Base64, which is text on every database.
@Entity(table = "wl_driver_document")
public class DriverDocument {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Id(autoIncrement = false)
    @Column(name = "kind", nullable = false)
    public String kind = "";

    @Column(name = "content_type", nullable = false)
    public String contentType = "";

    @Column(name = "status", nullable = false)
    public String status = "";

    @Column(name = "uploaded_at", nullable = false)
    public long uploadedAt;

    @Column(name = "data", nullable = false)
    public String data = "";

    public DriverDocument() {
    }
}
