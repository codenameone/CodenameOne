package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codename1.orm.session.Identifier;
import com.codenameone.examples.wayline.domain.RidePassed;

import java.util.List;

/// The drivers who passed on a ride or let its offer lapse, keyed by
/// `Identifier.of(rideId, driver)`.
@Repository(entity = RidePassed.class, key = Identifier.class)
public interface RidePassedRepository extends CrudRepository<RidePassed, Identifier> {
    List<RidePassed> findByRideId(String rideId);

    long countByDriver(String driver);

    /// How many offers each driver has passed on or let lapse, as `{driver,
    /// count}`.
    @Query("select p.driver, count(p.rideId) from RidePassed p group by p.driver")
    List<Object[]> countByDriver();
}
