package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.LiveTicket;

/// The tickets that open a live connection. Only the hash of a ticket is
/// stored, and it is the row's key.
@Repository(entity = LiveTicket.class, key = String.class)
public interface LiveTicketRepository extends CrudRepository<LiveTicket, String> {
    /// Deletes a ticket and answers how many rows that removed: 1 for the one
    /// caller that used it, 0 for anyone presenting it after. A statement and
    /// not a read followed by a removal, because that count is the whole
    /// point.
    int deleteByTicketHash(String ticketHash);

    /// Deletes the tickets that went stale before `now`.
    int deleteByExpiresAtLessThan(long now);

    int deleteByUsername(String username);
}
