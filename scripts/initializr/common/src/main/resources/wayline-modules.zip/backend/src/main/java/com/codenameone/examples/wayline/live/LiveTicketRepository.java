package com.codenameone.examples.wayline.live;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.LiveTicket;

/// Where live-channel tickets are kept. Only the hash of a ticket is stored,
/// and it is the row's key.
@Component
public class LiveTicketRepository {
    private final Session session;

    public LiveTicketRepository(Session session) {
        this.session = session;
    }

    public void add(LiveTicket ticket) {
        session.persist(ticket);
    }

    /// The ticket with this hash, or null.
    public LiveTicket find(String hash) {
        return session.find(LiveTicket.class, hash);
    }

    /// Deletes a ticket and answers how many rows that removed: 1 for the one
    /// caller that used it, 0 for anyone presenting it after. A statement and
    /// not `session.remove`, because that count is the whole point.
    public int delete(String hash) {
        return session.createQuery("delete from LiveTicket t where t.ticketHash = :hash")
                .setParameter("hash", hash).executeUpdate();
    }

    /// Deletes the tickets that went stale before `now`.
    public int deleteExpired(long now) {
        return session.createQuery("delete from LiveTicket t where t.expiresAt < :now")
                .setParameter("now", Long.valueOf(now)).executeUpdate();
    }

    public int deleteOf(String username) {
        return session.createQuery("delete from LiveTicket t where t.username = :username")
                .setParameter("username", username).executeUpdate();
    }
}
