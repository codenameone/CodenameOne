package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// Where a driver's car is, whether they are on line, and what riders made of them.
@Entity(table = "wl_driver")
public class DriverState {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "online", nullable = false)
    public boolean online;

    @Column(name = "lat", nullable = false)
    public double lat;

    @Column(name = "lng", nullable = false)
    public double lng;

    @Column(name = "heading", nullable = false)
    public double heading;

    @Column(name = "last_seen", nullable = false)
    public long lastSeen;

    @Column(name = "rating_sum", nullable = false)
    public long ratingSum;

    @Column(name = "rating_count", nullable = false)
    public long ratingCount;

    public DriverState() {
    }

    /// The mean of the stars given, or 5 before any were.
    public double rating() {
        return ratingCount == 0 ? 5d : Math.round(ratingSum * 10d / ratingCount) / 10d;
    }
}
