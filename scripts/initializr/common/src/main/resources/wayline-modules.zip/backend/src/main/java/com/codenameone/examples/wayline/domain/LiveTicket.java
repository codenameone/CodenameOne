package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A ticket for one connection to the live channel, as its hash.
@Entity(table = "wl_live_ticket")
public class LiveTicket {
    @Id(autoIncrement = false)
    @Column(name = "ticket_hash", nullable = false)
    public String ticketHash = "";

    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "expires_at", nullable = false)
    public long expiresAt;

    public LiveTicket() {
    }
}
