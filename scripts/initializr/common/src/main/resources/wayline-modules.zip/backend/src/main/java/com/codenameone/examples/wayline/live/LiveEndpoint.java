package com.codenameone.examples.wayline.live;

import com.codename1.backend.WebSocket;
import com.codename1.backend.WebSocketSession;
import com.codename1.backend.annotations.WebSocketMapping;
import com.codenameone.examples.wayline.account.Accounts;
import com.codenameone.examples.wayline.api.UserDto;

/// The live channel: one WebSocket per signed-in app, down which the server
/// says what changed ([LiveHub]).
///
/// No filter chain covers this path, deliberately: the handshake cannot carry
/// the bearer token on every platform. The connection is let in by the ticket
/// in its address instead ([LiveTickets]), and one that presents none, or one
/// already used, is closed before it is told anything.
@WebSocketMapping("/ws/live")
public class LiveEndpoint implements WebSocket {
    private final LiveTickets tickets;
    private final Accounts accounts;
    private final LiveHub hub;

    public LiveEndpoint(LiveTickets tickets, Accounts accounts, LiveHub hub) {
        this.tickets = tickets;
        this.accounts = accounts;
        this.hub = hub;
    }

    @Override
    public void onOpen(WebSocketSession session) throws Exception {
        String username = tickets.redeem(ticket(session.getQuery()));
        UserDto user = username == null ? null : accounts.describe(username);
        if (user == null || user.suspended) {
            session.close(4401, "ticket");
            return;
        }
        // Who this connection is, kept on the connection: the one piece of
        // state a WebSocket has that a request does not.
        session.setAttachment(username);
        hub.add(username, user.admin, session);
        session.sendText("{\"type\":\"ready\"}");
    }

    @Override
    public void onText(WebSocketSession session, String message) throws Exception {
        // The app says one thing, to learn the connection is still alive on a
        // network that drops idle ones without telling either end.
        if (session.getAttachment() != null && message != null
                && message.indexOf("\"ping\"") >= 0) {
            session.sendText("{\"type\":\"pong\"}");
        }
    }

    @Override
    public void onBinary(WebSocketSession session, byte[] message, int offset, int length)
            throws Exception {
        session.close(1003, "text only");
    }

    @Override
    public void onClose(WebSocketSession session, int code, String reason) {
        Object username = session.getAttachment();
        if (username instanceof String) {
            hub.remove((String) username, session);
        }
    }

    /// The `ticket` parameter of a query string, or null. A ticket is hex, so
    /// there is nothing in it to decode.
    static String ticket(String query) {
        if (query == null) {
            return null;
        }
        int at = 0;
        while (at < query.length()) {
            int end = query.indexOf('&', at);
            if (end < 0) {
                end = query.length();
            }
            if (query.startsWith("ticket=", at)) {
                return query.substring(at + 7, end);
            }
            at = end + 1;
        }
        return null;
    }
}
