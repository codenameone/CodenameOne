package com.codenameone.examples.wayline.push;

import com.codename1.backend.push.PushNotification;
import com.codename1.backend.push.PushTarget;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/// Keeps every notification instead of sending it, for the tests to read.
///
/// What the `test` profile gets: a test signs a phone in, drives a ride, and
/// asks this what each device was sent. Refused on any profile that is not a
/// development one.
public class RecordingPushSender implements PushSender {
    private final List<Sent> sent = new ArrayList<Sent>();

    /// One notification as one device was sent it.
    public static final class Sent {
        private final String provider;
        private final String token;
        private final Map<String, Object> message;

        Sent(String provider, String token, Map<String, Object> message) {
            this.provider = provider;
            this.token = token;
            this.message = message;
        }

        public String provider() {
            return provider;
        }

        public String token() {
            return token;
        }

        /// The notification as it would go on the wire: `title`, `body`,
        /// `data`, `surface` and the rest.
        public Map<String, Object> message() {
            return message;
        }
    }

    @Override
    public synchronized void send(List<PushTarget> targets, PushNotification message) {
        if (targets == null) {
            return;
        }
        for (PushTarget target : targets) {
            sent.add(new Sent(target.getProvider(), target.getToken(), message.toMap()));
        }
    }

    /// What the device with `token` was sent, oldest first.
    public synchronized List<Sent> sentTo(String token) {
        List<Sent> out = new ArrayList<Sent>();
        for (Sent each : sent) {
            if (each.token.equals(token)) {
                out.add(each);
            }
        }
        return out;
    }

    /// Everything sent so far, oldest first.
    public synchronized List<Sent> all() {
        return new ArrayList<Sent>(sent);
    }

    public synchronized void clear() {
        sent.clear();
    }
}
