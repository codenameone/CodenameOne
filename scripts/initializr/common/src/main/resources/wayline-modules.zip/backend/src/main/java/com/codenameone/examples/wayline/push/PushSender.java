package com.codenameone.examples.wayline.push;

import com.codename1.backend.push.PushNotification;
import com.codename1.backend.push.PushTarget;

import java.util.List;

/// Sends push notifications to devices.
///
/// [com.codenameone.examples.wayline.Services] chooses the implementation from
/// `myappname.push.provider`. A notification is a courtesy on top of what the
/// app reads from the server, so sending one never fails the ride it is about:
/// an implementation logs what went wrong and returns.
public interface PushSender {
    /// Sends `message` to every one of `targets`. Returns at once; the sending
    /// itself may happen later, on another thread.
    ///
    /// @param delivered run once the push service has taken the message, on
    ///     whatever thread learnt it; never when it was refused or could not be
    ///     sent. Null when nobody needs to know.
    void send(List<PushTarget> targets, PushNotification message, Runnable delivered);
}
