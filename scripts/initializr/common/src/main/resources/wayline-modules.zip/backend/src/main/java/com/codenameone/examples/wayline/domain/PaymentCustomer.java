package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The payment provider's name for an account.
@Entity(table = "wl_payment_customer")
public class PaymentCustomer {
    @Id(autoIncrement = false)
    @Column(name = "username", nullable = false)
    public String username = "";

    @Column(name = "reference", nullable = false)
    public String reference = "";

    public PaymentCustomer() {
    }
}
