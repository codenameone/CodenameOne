package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// What is left of an account that was closed: the hash of its e-mail, kept so
/// that the address cannot be registered again.
@Entity(table = "wl_closed_account")
public class ClosedAccount {
    @Id(autoIncrement = false)
    @Column(name = "username_hash", nullable = false)
    public String usernameHash = "";

    @Column(name = "closed_at", nullable = false)
    public long closedAt;

    public ClosedAccount() {
    }
}
