package com.codenameone.examples.wayline.account;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.Profile;

import java.util.List;

/// Where profiles are read from and written to.
///
/// A repository holds the queries of one kind of entity and nothing else: no
/// rule about who may do what, and no transaction of its own. It works on the
/// session of the transaction its caller opened, so a service method marked
/// `@Transactional` is what makes several of these calls one unit of work.
@Component
public class ProfileRepository {
    private final Session session;

    public ProfileRepository(Session session) {
        this.session = session;
    }

    /// The profile of an account, or null when the name has none.
    public Profile find(String username) {
        if (username == null || username.length() == 0 || username.length() > 190) {
            return null;
        }
        return session.find(Profile.class, username);
    }

    /// Every profile, newest first.
    public List<Profile> all() {
        return session.query(Profile.class).orderBy("createdAt", false)
                .orderBy("username", true).list();
    }

    /// Stores a new profile. One already read from here needs no call at all:
    /// the transaction writes whatever changed in it when it commits.
    public void add(Profile profile) {
        session.persist(profile);
    }

    public void remove(Profile profile) {
        session.remove(profile);
    }
}
