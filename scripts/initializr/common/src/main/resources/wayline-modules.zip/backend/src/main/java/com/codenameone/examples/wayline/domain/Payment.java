package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// What a completed ride was charged, and what was given back.
@Entity(table = "wl_payment")
public class Payment {
    @Id(autoIncrement = false)
    @Column(name = "ride_id", nullable = false)
    public String rideId = "";

    @Column(name = "amount_cents", nullable = false)
    public long amountCents;

    @Column(name = "currency", nullable = false)
    public String currency = "";

    @Column(name = "status", nullable = false)
    public String status = "";

    @Column(name = "provider_ref", nullable = false)
    public String providerRef = "";

    @Column(name = "created_at", nullable = false)
    public long createdAt;

    @Column(name = "tip_ref", nullable = false)
    public String tipRef = "";

    @Column(name = "refund_ref", nullable = false)
    public String refundRef = "";

    @Column(name = "refund_reason", nullable = false)
    public String refundReason = "";

    @Column(name = "refunded_at", nullable = false)
    public long refundedAt;

    public Payment() {
    }
}
