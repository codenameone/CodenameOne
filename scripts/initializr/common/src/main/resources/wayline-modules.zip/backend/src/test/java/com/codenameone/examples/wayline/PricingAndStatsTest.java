package com.codenameone.examples.wayline;

import com.codename1.backend.DataSource;
import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codename1.backend.test.MockMvc;
import com.codename1.backend.test.MockRequestBuilder;
import com.codenameone.examples.wayline.account.Accounts;
import com.codenameone.examples.wayline.account.DemoAccounts;
import com.codenameone.examples.wayline.api.PricingDto;
import com.codenameone.examples.wayline.ride.Fares;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static com.codename1.backend.test.MockMvcRequestBuilders.get;
import static com.codename1.backend.test.MockMvcRequestBuilders.post;
import static com.codename1.backend.test.MockMvcRequestBuilders.put;
import static com.codename1.backend.test.MockMvcResultMatchers.jsonPath;
import static com.codename1.backend.test.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/// What an admin runs the service by: the prices, and the figures the
/// dashboard draws.
@BackendTest
class PricingAndStatsTest {
    @Autowired
    private MockMvc mvc;
    @Autowired
    private Accounts accounts;
    @Autowired
    private Fares fares;
    @Autowired
    private DataSource db;

    private MockRequestBuilder admin(MockRequestBuilder request) {
        return People.asAdmin(request, DemoAccounts.ADMIN);
    }

    private long quoted(String rider) throws Exception {
        return Trips.number(Trips.json(mvc, People.asRider(Trips.body(post("/api/rides/quote"),
                People.ride(50.0755, 14.4378, 50.0900, 14.4600)), rider)), "amountCents");
    }

    @Test
    void aChangeOfPriceChangesTheNextQuote() throws Exception {
        // Prague.
        String rider = People.rider(accounts, "prg-rider");
        String before = mvc.perform(admin(get("/api/admin/pricing"))).andExpect(status().isOk())
                .andExpect(jsonPath("$.currency").value("USD"))
                .andExpect(jsonPath("$.baseFare").value(250))
                .andExpect(jsonPath("$.perKm").value(120))
                .andExpect(jsonPath("$.minimumFare").value(500))
                .andExpect(jsonPath("$.surgeMultiplier").value(1.0))
                .andReturn().getResponse().getContentAsString();
        long was = quoted(rider);
        // The other tests share these prices, so they are put back whatever
        // happens here.
        try {
            mvc.perform(admin(Trips.body(put("/api/admin/pricing"), "{\"baseFare\":1250,"
                            + "\"perKm\":120,\"perMinute\":30,\"minimumFare\":500,"
                            + "\"serviceFeePercent\":10,\"commissionPercent\":20,"
                            + "\"surgeMultiplier\":1,\"comfortMultiplier\":1.35,"
                            + "\"xlMultiplier\":1.7}")))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.baseFare").value(1250));
            assertEquals(was + 1000L, quoted(rider));
            mvc.perform(admin(Trips.body(put("/api/admin/pricing"), "{\"baseFare\":250,"
                            + "\"perKm\":120,\"perMinute\":30,\"minimumFare\":500,"
                            + "\"serviceFeePercent\":10,\"commissionPercent\":20,"
                            + "\"surgeMultiplier\":2,\"comfortMultiplier\":1.35,"
                            + "\"xlMultiplier\":1.7}")))
                    .andExpect(status().isOk());
            // Part by part, each rounded, so twice the fare to within a cent
            // or two.
            long surged = quoted(rider);
            assertTrue(Math.abs(surged - was * 2L) <= 2L, "surged to " + surged);
            // Prices that could only be a mistake change nothing.
            mvc.perform(admin(Trips.body(put("/api/admin/pricing"), "{\"baseFare\":-1,"
                            + "\"perKm\":120,\"perMinute\":30,\"minimumFare\":500,"
                            + "\"serviceFeePercent\":10,\"commissionPercent\":20,"
                            + "\"surgeMultiplier\":1,\"comfortMultiplier\":1.35,"
                            + "\"xlMultiplier\":1.7}")))
                    .andExpect(status().isBadRequest());
            mvc.perform(admin(Trips.body(put("/api/admin/pricing"), "{\"baseFare\":250,"
                            + "\"perKm\":120,\"perMinute\":30,\"minimumFare\":500,"
                            + "\"serviceFeePercent\":10,\"commissionPercent\":95,"
                            + "\"surgeMultiplier\":1,\"comfortMultiplier\":1.35,"
                            + "\"xlMultiplier\":1.7}")))
                    .andExpect(status().isBadRequest());
            assertEquals(surged, quoted(rider));
            // And they are an admin's to change.
            mvc.perform(People.asRider(Trips.body(put("/api/admin/pricing"), before), rider))
                    .andExpect(status().isForbidden());
        } finally {
            mvc.perform(admin(Trips.body(put("/api/admin/pricing"), before)))
                    .andExpect(status().isOk());
        }
        assertEquals(was, quoted(rider));
    }

    @Test
    void adminsSavingPricesTogetherAllSave() throws Exception {
        // As a fresh server has it: the row a migration created, which nobody
        // has saved over. The prices are the settings' until somebody does.
        PricingDto before = fares.pricing();
        db.execute("UPDATE pricing SET updated_at = 0 WHERE id = 1", new Object[0]);
        assertEquals(250L, fares.pricing().baseFare());
        Map rows = db.queryOne("SELECT COUNT(*) AS n FROM pricing", new Object[0]);
        assertEquals(1L, ((Number) rows.get("n")).longValue());

        // Several admins save at once. When the first save created the row,
        // they all found none, all inserted it, and all but one failed.
        final int admins = 6;
        final AtomicInteger saved = new AtomicInteger();
        final AtomicInteger ready = new AtomicInteger();
        final AtomicBoolean go = new AtomicBoolean();
        final Throwable[] failed = new Throwable[admins];
        Thread[] threads = new Thread[admins];
        try {
            for (int iter = 0; iter < admins; iter++) {
                final int slot = iter;
                threads[iter] = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ready.incrementAndGet();
                        long giveUp = System.currentTimeMillis() + 30000L;
                        while (!go.get() && System.currentTimeMillis() < giveUp) {
                            Thread.yield();
                        }
                        try {
                            fares.save(DemoAccounts.ADMIN, new PricingDto("USD", 300L + slot,
                                    120L, 30L, 500L, 10d, 20d, 1d, 1.35d, 1.7d));
                            saved.incrementAndGet();
                        } catch (Throwable err) {
                            failed[slot] = err;
                        }
                    }
                }, "pricing-" + iter);
                threads[iter].start();
            }
            long giveUp = System.currentTimeMillis() + 30000L;
            while (ready.get() < admins) {
                assertTrue(System.currentTimeMillis() < giveUp, "the threads started");
                Thread.sleep(1L);
            }
            go.set(true);
            for (int iter = 0; iter < admins; iter++) {
                threads[iter].join(60000L);
                if (failed[iter] != null) {
                    throw new AssertionError("save " + iter + " failed", failed[iter]);
                }
            }
            assertEquals(admins, saved.get(), "every save was saved");
            long base = fares.pricing().baseFare();
            assertTrue(base >= 300L && base < 300L + admins, "one of them is in force: " + base);
            rows = db.queryOne("SELECT COUNT(*) AS n FROM pricing", new Object[0]);
            assertEquals(1L, ((Number) rows.get("n")).longValue(), "and there is one row");
        } finally {
            // The other tests share these prices.
            fares.save(DemoAccounts.ADMIN, before);
        }
    }

    @Test
    void theDashboardsSeriesHasEveryDayAndEveryHour() throws Exception {
        Map week = Trips.json(mvc, admin(get("/api/admin/stats/series?days=7")));
        List days = (List) week.get("days");
        assertEquals(7, days.size());
        // Oldest first, ending today, and a day with nothing in it is there.
        Map last = (Map) days.get(6);
        assertEquals(Days.iso(System.currentTimeMillis()), last.get("date"));
        assertEquals(Days.iso(System.currentTimeMillis() - 6L * 86400000L),
                ((Map) days.get(0)).get("date"));
        for (int iter = 0; iter < days.size(); iter++) {
            Map day = (Map) days.get(iter);
            assertTrue(Trips.number(day, "rides") >= Trips.number(day, "completed")
                    + Trips.number(day, "cancelled"), "day " + iter);
            assertTrue(Trips.number(day, "revenue") >= 0L);
            assertNotNull(day.get("newUsers"));
        }
        assertEquals(24, ((List) week.get("byHour")).size());
        List products = (List) week.get("byProduct");
        assertEquals(3, products.size());
        assertEquals("standard", ((Map) products.get(0)).get("name"));
        assertEquals("comfort", ((Map) products.get(1)).get("name"));
        assertEquals("xl", ((Map) products.get(2)).get("name"));
        assertEquals("USD", week.get("currency"));
        assertNotNull(week.get("byState"));
        assertTrue(((List) week.get("topDrivers")).size() <= 5);
        // The demo data has somebody waiting to be reviewed and somebody
        // flagged, and a fortnight of rides behind them.
        assertTrue(Trips.number(week, "pendingApplications") >= 1L);
        assertTrue(Trips.number(week, "flaggedUsers") >= 1L);
        assertTrue(Trips.number(week, "averageFare") > 0L);
        double rate = ((Number) week.get("completionRate")).doubleValue();
        assertTrue(rate > 0d && rate <= 1d, "completion rate " + rate);
        long rides = 0L;
        for (int iter = 0; iter < days.size(); iter++) {
            rides += Trips.number((Map) days.get(iter), "rides");
        }
        assertTrue(rides > 0L, "the week has rides in it");

        // A silly number is the fortnight; and there is a most.
        mvc.perform(admin(get("/api/admin/stats/series?days=0")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.days.length()").value(14));
        mvc.perform(admin(get("/api/admin/stats/series?days=1000")))
                .andExpect(jsonPath("$.days.length()").value(90))
                .andExpect(jsonPath("$.byHour.length()").value(24));
    }
}
