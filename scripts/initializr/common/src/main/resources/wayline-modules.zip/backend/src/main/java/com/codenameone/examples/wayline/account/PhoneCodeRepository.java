package com.codenameone.examples.wayline.account;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.PhoneCode;

/// Where the code an account was texted is kept. An account has at most one.
@Component
public class PhoneCodeRepository {
    private final Session session;

    public PhoneCodeRepository(Session session) {
        this.session = session;
    }

    /// The code an account is waiting to type, or null when it has none.
    public PhoneCode find(String username) {
        return session.find(PhoneCode.class, username);
    }

    public void add(PhoneCode code) {
        session.persist(code);
    }

    public void remove(PhoneCode code) {
        session.remove(code);
    }

    /// Takes one of the guesses an account's code allows. The database does
    /// the sum and applies the limit in the same statement, so of any number of
    /// guesses sent at once only as many as are left are let through; nothing
    /// is read and written back. Answers false when none is left, or when the
    /// account has no code to guess at.
    public boolean takeGuess(String username, int most) {
        return session.createQuery("update PhoneCode c set c.attempts = c.attempts + 1 "
                + "where c.username = :username and c.attempts < :most")
                .setParameter("username", username).setParameter("most", Integer.valueOf(most))
                .executeUpdate() == 1;
    }
}
