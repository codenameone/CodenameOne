package com.codenameone.examples.wayline.account;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.PhoneCode;

/// Where the code an account was texted is kept. An account has at most one.
@Component
public class PhoneCodeRepository {
    private final Session session;

    public PhoneCodeRepository(Session session) {
        this.session = session;
    }

    /// The code an account is waiting to type, or null when it has none.
    public PhoneCode find(String username) {
        return session.find(PhoneCode.class, username);
    }

    public void add(PhoneCode code) {
        session.persist(code);
    }

    public void remove(PhoneCode code) {
        session.remove(code);
    }

    /// Counts one guess against an account's code. The database does the sum,
    /// so two guesses sent at once each take one; nothing is read and written
    /// back. Answers false when the account has no code to guess at.
    public boolean countGuess(String username) {
        return session.increment(PhoneCode.class, username, "attempts", 1L);
    }
}
