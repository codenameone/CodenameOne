package com.codenameone.examples.wayline.sms;

/// Writes the message to the server's log instead of sending it. What a server
/// with no SMS account uses.
public class LoggingSmsSender implements SmsSender {
    @Override
    public void send(String phone, String text) {
        System.out.println("[sms] to " + phone + ": " + text);
    }

    @Override
    public boolean delivers() {
        return false;
    }
}
