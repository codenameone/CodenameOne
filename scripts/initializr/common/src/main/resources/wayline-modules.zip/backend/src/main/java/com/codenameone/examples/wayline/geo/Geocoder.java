package com.codenameone.examples.wayline.geo;

import com.codenameone.examples.wayline.api.PlaceDto;

import java.io.IOException;
import java.util.List;

/// Turns text into places and a point into an address.
///
/// The app never talks to a geocoding service itself. It asks this server,
/// which asks whichever service is configured: no key ships inside the app, the
/// service can be replaced without a new release, and the server is where its
/// use can be limited.
public interface Geocoder {
    /// Places matching `text`, best first, favouring those near the point.
    List<PlaceDto> search(String text, double lat, double lng) throws IOException;

    /// The address at a point, or null when the service knows of none.
    PlaceDto reverse(double lat, double lng) throws IOException;
}
