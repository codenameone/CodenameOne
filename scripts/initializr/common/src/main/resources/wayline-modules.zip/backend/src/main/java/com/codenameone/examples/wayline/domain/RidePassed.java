package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A driver who passed on a ride, or let its offer lapse, and is not asked again.
@Entity(table = "wl_ride_passed")
public class RidePassed {
    @Id(autoIncrement = false)
    @Column(name = "ride_id", nullable = false)
    public String rideId = "";

    @Id(autoIncrement = false)
    @Column(name = "driver", nullable = false)
    public String driver = "";

    public RidePassed() {
    }
}
