package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.RideActivity;

/// The Live Activities riders follow their rides in, by ride.
@Repository(entity = RideActivity.class, key = String.class)
public interface RideActivityRepository extends CrudRepository<RideActivity, String> {
    int deleteByRideId(String rideId);

    int deleteByUsername(String username);

    /// Records that a state went out, unless one went out after `before`:
    /// 1 for the caller who gets to send, 0 for anyone else at the same moment.
    @Modifying
    @Query("update RideActivity a set a.sentAt = :now "
            + "where a.rideId = :rideId and a.sentAt < :before")
    int claim(@Param("rideId") String rideId, @Param("now") long now,
            @Param("before") long before);
}
