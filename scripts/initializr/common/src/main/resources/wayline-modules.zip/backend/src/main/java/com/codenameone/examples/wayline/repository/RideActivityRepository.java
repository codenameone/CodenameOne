package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.RideActivity;

import java.time.Instant;
import java.util.List;

/// The Live Activities riders follow their rides in, by ride.
@Repository(entity = RideActivity.class, key = String.class)
public interface RideActivityRepository extends CrudRepository<RideActivity, String> {
    int deleteByRideId(String rideId);

    int deleteByUsername(String username);

    /// Records that a state went out, unless one went out after `before`:
    /// 1 for the caller who gets to send, 0 for anyone else at the same moment.
    @Modifying
    @Query("update RideActivity a set a.sentAt = :now "
            + "where a.rideId = :rideId and a.sentAt < :before")
    int claim(@Param("rideId") String rideId, @Param("now") Instant now,
            @Param("before") Instant before);

    /// Records that the ride ended at `now`, unless that is already recorded.
    /// `none` is the epoch, which an end not yet recorded holds.
    @Modifying
    @Query("update RideActivity a set a.endedAt = :now "
            + "where a.rideId = :rideId and a.endedAt = :none")
    int markEnded(@Param("rideId") String rideId, @Param("now") Instant now,
            @Param("none") Instant none);

    /// The activities whose ride ended before `before` and that are still
    /// here, because the phone was not told: oldest first.
    @Query("select a from RideActivity a where a.endedAt > :none and a.endedAt < :before "
            + "order by a.endedAt")
    List<RideActivity> leftBehind(@Param("before") Instant before, @Param("none") Instant none,
            PageRequest page);

    /// Forgets the activities whose ride ended before `before`.
    @Modifying
    @Query("delete from RideActivity a where a.endedAt > :none and a.endedAt < :before")
    int dropEndedBefore(@Param("before") Instant before, @Param("none") Instant none);
}
