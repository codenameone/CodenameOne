package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import com.codenameone.examples.wayline.api.RideState;
import java.time.Instant;

/// One change of a ride's state: what it became, who made it so, and when.
@Entity
public class RideEvent {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String rideId = "";

    @Column(nullable = false, type = "VARCHAR(24)")
    private RideState state;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String actor = "";

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public RideEvent() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRideId() {
        return rideId;
    }

    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    public RideState getState() {
        return state;
    }

    public void setState(RideState state) {
        this.state = state;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
