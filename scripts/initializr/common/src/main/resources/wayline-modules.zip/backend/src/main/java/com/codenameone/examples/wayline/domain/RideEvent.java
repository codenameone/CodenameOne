package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One change of a ride's state: what it became, who made it so, and when.
@Entity(table = "wl_ride_event")
public class RideEvent {
    @Id(autoIncrement = false)
    @Column(name = "id", nullable = false)
    public String id = "";

    @Column(name = "ride_id", nullable = false)
    public String rideId = "";

    @Column(name = "state", nullable = false)
    public String state = "";

    @Column(name = "actor", nullable = false)
    public String actor = "";

    @Column(name = "created_at", nullable = false)
    public long createdAt;

    public RideEvent() {
    }
}
