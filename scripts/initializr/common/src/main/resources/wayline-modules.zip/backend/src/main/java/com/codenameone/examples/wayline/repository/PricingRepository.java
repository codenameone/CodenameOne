package com.codenameone.examples.wayline.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.wayline.domain.Pricing;

/// The admin's prices: one row, whose key is [#ONLY], or none while the prices
/// are still the settings'.
@Repository(entity = Pricing.class, key = Integer.class)
public interface PricingRepository extends CrudRepository<Pricing, Integer> {
    /// The key of the one row there is.
    Integer ONLY = Integer.valueOf(1);
}
