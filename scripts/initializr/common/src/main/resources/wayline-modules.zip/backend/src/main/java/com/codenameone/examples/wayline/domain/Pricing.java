package com.codenameone.examples.wayline.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The prices an admin set. One row, with the id 1, once they have set any.
@Entity(table = "wl_pricing")
public class Pricing {
    @Id(autoIncrement = false)
    @Column(name = "id", nullable = false)
    public int id;

    @Column(name = "base_cents", nullable = false)
    public long baseCents;

    @Column(name = "per_km_cents", nullable = false)
    public long perKmCents;

    @Column(name = "per_minute_cents", nullable = false)
    public long perMinuteCents;

    @Column(name = "minimum_cents", nullable = false)
    public long minimumCents;

    @Column(name = "fee_percent", nullable = false)
    public double feePercent;

    @Column(name = "commission_percent", nullable = false)
    public double commissionPercent;

    @Column(name = "surge", nullable = false)
    public double surge;

    @Column(name = "comfort", nullable = false)
    public double comfort;

    @Column(name = "xl", nullable = false)
    public double xl;

    @Column(name = "updated_at", nullable = false)
    public long updatedAt;

    @Column(name = "updated_by", nullable = false)
    public String updatedBy = "";

    public Pricing() {
    }
}
