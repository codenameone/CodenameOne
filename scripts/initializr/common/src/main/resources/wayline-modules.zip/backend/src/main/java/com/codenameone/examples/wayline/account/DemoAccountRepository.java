package com.codenameone.examples.wayline.account;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.DriverApplication;
import com.codenameone.examples.wayline.domain.DriverDocument;

/// What the demo accounts write that nobody using the server could: an
/// application to drive dated in the past, and documents that were accepted
/// without anybody having looked at them.
///
/// Only [DemoAccounts] uses it. Everything an account can really do to an
/// application goes through the service that owns applications.
@Component
public class DemoAccountRepository {
    private final Session session;

    public DemoAccountRepository(Session session) {
        this.session = session;
    }

    /// An account's application to drive, or null when it has none.
    public DriverApplication application(String username) {
        return session.find(DriverApplication.class, username);
    }

    public void add(DriverDocument document) {
        session.persist(document);
    }
}
