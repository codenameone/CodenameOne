package com.codenameone.examples.wayline;

/// The roles an account can hold. Every account is a rider; driving and
/// administering are granted on top of that, and the app offers a mode for each
/// role the account holds.
public final class Roles {
    public static final String RIDER = "RIDER";
    public static final String DRIVER = "DRIVER";
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
