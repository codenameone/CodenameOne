package com.codenameone.examples.wayline.driver;

import com.codename1.backend.annotations.Component;
import com.codename1.orm.session.Identifier;
import com.codename1.orm.session.Session;
import com.codenameone.examples.wayline.domain.DriverHours;
import com.codenameone.examples.wayline.domain.DriverState;
import com.codenameone.examples.wayline.domain.Payout;
import com.codenameone.examples.wayline.domain.PayoutAccount;
import com.codenameone.examples.wayline.domain.Ride;
import com.codenameone.examples.wayline.domain.RideEvent;
import com.codenameone.examples.wayline.domain.RidePassed;

import java.util.List;

/// Where payouts and the accounts they are paid into are read from and written
/// to, with the sums over a driver's rides that their earnings are made of.
///
/// A sum over no rows is nothing at all to a database, so each one here is
/// asked for with a zero to fall back on and always answers with a number.
@Component
public class PayoutRepository {
    private final Session session;

    public PayoutRepository(Session session) {
        this.session = session;
    }

    // --------------------------------------------------------------- payouts

    /// The payouts made to a driver, newest first.
    public List<Payout> payouts(String driver) {
        return session.query(Payout.class).eq("driver", driver).orderBy("createdAt", false)
                .orderBy("id", true).limit(100).list();
    }

    public Payout payout(String id) {
        return session.find(Payout.class, id);
    }

    public void add(Payout payout) {
        session.persist(payout);
    }

    public void remove(Payout payout) {
        session.remove(payout);
    }

    /// Everything ever paid out to a driver.
    public long paidOut(String driver) {
        return session.createQuery("select coalesce(sum(p.amountCents), 0) from Payout p "
                + "where p.driver = :driver", Long.class).setParameter("driver", driver)
                .first().longValue();
    }

    /// Where a driver is paid, or null before they have said.
    public PayoutAccount account(String driver) {
        return session.find(PayoutAccount.class, driver);
    }

    public void add(PayoutAccount account) {
        session.persist(account);
    }

    // -------------------------------------------------------------- earnings

    /// A driver's completed rides that ended at or after a time.
    public List<Ride> completedSince(String driver, long since) {
        return session.createQuery("select r from Ride r where r.driver = :driver "
                + "and r.state = 'COMPLETED' and r.updatedAt >= :since", Ride.class)
                .setParameter("driver", driver).setParameter("since", Long.valueOf(since)).list();
    }

    /// The ids of a driver's rides, among those [#completedSince] answers,
    /// whose tip was put on a card and whose charge has come back. The other
    /// half of what [#tips] counts, by ride, for the sums that are by day.
    public List<String> tipChargedSince(String driver, long since) {
        return session.createQuery("select r.id from Ride r where r.driver = :driver "
                + "and r.state = 'COMPLETED' and r.updatedAt >= :since "
                + "and r.methodId <> 'cash' and r.paymentStatus = 'PAID' and r.id in "
                + "(select p.rideId from Payment p where p.tipRef <> '')", String.class)
                .setParameter("driver", driver).setParameter("since", Long.valueOf(since)).list();
    }

    /// Makes the rest of the transaction wait its turn behind any other that
    /// holds the same driver's payout account.
    ///
    /// @return false for a driver who has not said where to be paid
    public boolean holdAccount(String driver) {
        return session.createQuery("update PayoutAccount a set a.last4 = a.last4 "
                + "where a.username = :driver").setParameter("driver", driver)
                .executeUpdate() == 1;
    }

    /// How many rides a driver has completed.
    public long trips(String driver) {
        return session.createQuery("select count(r) from Ride r where r.driver = :driver "
                + "and r.state = 'COMPLETED'", Long.class).setParameter("driver", driver)
                .first().longValue();
    }

    /// The driver's share of the fares of every ride they completed and that
    /// was paid for -- in cash, or by a card whose charge came back. A charge
    /// that failed, was refunded, or has not been answered yet is no money of
    /// the service's, so it is not the driver's to cash out either; the
    /// dashboard's totals ([com.codenameone.examples.wayline.ride.RideRepository])
    /// count the same rides.
    public long fares(String driver) {
        return session.createQuery("select coalesce(sum(r.driverCents), 0) from Ride r "
                + "where r.driver = :driver and r.state = 'COMPLETED' "
                + "and r.paymentStatus = 'PAID'", Long.class)
                .setParameter("driver", driver).first().longValue();
    }

    /// The tips a driver has been given: those handed over in cash, and those
    /// put on a card whose charge has come back.
    ///
    /// A card tip sits on its ride from the moment it is asked for, and stays
    /// there with no charge recorded when the processor did not answer. It is
    /// not money yet -- the card may never have been charged -- so it is not
    /// counted, and so cannot be cashed out, until the charge is on record.
    /// A tip is charged only to a paid ride, and a refund returns it with the
    /// fare while its charge stays on record, so a card tip also counts only
    /// while its ride is still paid.
    public long tips(String driver) {
        long cash = session.createQuery("select coalesce(sum(r.tipCents), 0) from Ride r "
                + "where r.driver = :driver and r.state = 'COMPLETED' "
                + "and r.methodId = 'cash'", Long.class)
                .setParameter("driver", driver).first().longValue();
        long charged = session.createQuery("select coalesce(sum(r.tipCents), 0) from Ride r "
                + "where r.driver = :driver and r.state = 'COMPLETED' "
                + "and r.methodId <> 'cash' and r.paymentStatus = 'PAID' and r.id in "
                + "(select p.rideId from Payment p where p.tipRef <> '')", Long.class)
                .setParameter("driver", driver).first().longValue();
        return cash + charged;
    }

    /// How long a driver was on line on one day, in milliseconds.
    public long onlineMillis(String driver, long dayNumber) {
        DriverHours hours = session.find(DriverHours.class,
                Identifier.of(driver, Long.valueOf(dayNumber)));
        return hours == null ? 0L : hours.millis;
    }

    /// A driver's car and ratings, or null for someone who never drove.
    public DriverState state(String driver) {
        return session.find(DriverState.class, driver);
    }

    /// How many offers a driver took.
    public long accepted(String driver) {
        return session.query(RideEvent.class).eq("actor", driver).eq("state", "ACCEPTED").count();
    }

    /// How many offers a driver passed on or let lapse.
    public long passed(String driver) {
        return session.query(RidePassed.class).eq("driver", driver).count();
    }
}
