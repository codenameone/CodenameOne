package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A free driver near a point, for the cars on the rider's map. Says where and
/// what, and not who.
@Mapped
public record NearbyDriverDto(double lat, double lng, double heading, String product) {
}
