package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// The numbers on the admin dashboard.
@Mapped
public record AdminStatsDto(
        int users,
        int drivers,
        int driversOnline,
        int ridesToday,
        int ridesActive,
        int ridesCompleted,
        long revenueCents,
        String currency) {
}
