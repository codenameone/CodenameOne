package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A way to pay. Cash is always one of them, under the id `cash`.
@Mapped
public class PaymentMethodDto {
    public String id;
    /// `card` or `cash`.
    public String kind;
    public String brand;
    public String last4;
    public int expMonth;
    public int expYear;
    public boolean isDefault;
    /// The method as a person would name it: "Visa 4242", "Cash".
    public String label;

    public PaymentMethodDto() {
    }
}
