package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A place a search or a reverse lookup found.
@Mapped
public record PlaceDto(String name, String address, double lat, double lng) {
}
