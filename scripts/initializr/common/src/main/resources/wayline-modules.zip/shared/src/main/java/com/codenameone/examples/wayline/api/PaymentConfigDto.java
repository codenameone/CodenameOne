package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// How this server takes payments, so the app knows which way to add a card.
@Mapped
public class PaymentConfigDto {
    /// `simulated` or `stripe`.
    public String provider;
    public String currency;

    public PaymentConfigDto() {
    }
}
