package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// The Live Activity a rider's phone started for a ride, by the id the
/// platform gave it. The server addresses its updates to that id.
@Mapped
public record RideActivityDto(String activityId) {
}
