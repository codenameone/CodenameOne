package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// An attempt to add a card, begun.
///
/// When `hosted` is true the card is typed into the payment processor's own page
/// at `url`: open it in the browser, and call complete when the user returns.
/// Otherwise the app collects a [CardDto] itself and sends it with complete.
@Mapped
public class PaymentSetupDto {
    public String id;
    public boolean hosted;
    public String url;

    public PaymentSetupDto() {
    }
}
