package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// What a driver has earned.
@Mapped
public record EarningsDto(
        long todayCents,
        long weekCents,
        long totalCents,
        int rides,
        String currency) {
}
