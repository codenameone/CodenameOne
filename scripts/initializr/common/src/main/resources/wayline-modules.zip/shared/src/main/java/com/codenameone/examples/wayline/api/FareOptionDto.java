package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// One product a ride can be taken as, priced for the ride being quoted.
@Mapped
public class FareOptionDto {
    /// `standard`, `comfort` or `xl`.
    public String product;
    public String name;
    public String description;
    public int seats;
    /// Cents. `total` is what the rider would pay: `fare` plus `serviceFee`.
    public long fare;
    public long serviceFee;
    public long total;
    /// Drivers of this product in reach, and minutes for the nearest to arrive; 0
    /// and 0 when there is none.
    public int driversNearby;
    public int etaMinutes;

    public FareOptionDto() {
    }
}
