package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// What rides cost. Amounts are cents; the percentages are of the fare.
///
/// @param serviceFeePercent Added to the fare and paid by the rider.
/// @param commissionPercent Kept from the fare; the rest is the driver's.
/// @param surgeMultiplier Multiplies every fare while demand is high; 1 otherwise.
@Mapped
public record PricingDto(
        String currency,
        long baseFare,
        long perKm,
        long perMinute,
        long minimumFare,
        double serviceFeePercent,
        double commissionPercent,
        double surgeMultiplier,
        double comfortMultiplier,
        double xlMultiplier) {
}
