package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A single-use ticket for opening the live channel.
///
/// A WebSocket handshake cannot carry the bearer token on every platform, so the
/// app asks for a ticket over the authenticated API and presents it in the
/// connection address. It is good for one connection and for a few seconds.
@Mapped
public class TicketDto {
    public String ticket;
    public int expiresInSeconds;

    public TicketDto() {
    }
}
