package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// One day of a driver's earnings.
@Mapped
public class DayAmountDto {
    /// `yyyy-MM-dd`, in UTC.
    public String date;
    public long amount;
    public int trips;

    public DayAmountDto() {
    }
}
