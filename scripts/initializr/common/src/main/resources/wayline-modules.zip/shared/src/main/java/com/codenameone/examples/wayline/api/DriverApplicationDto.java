package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// An application to drive: who, which car, and the papers that prove both.
@Mapped
public class DriverApplicationDto {
    public String username;
    public String name;
    /// `none`, `draft`, `pending`, `approved` or `rejected`.
    public String status;
    public String legalName;
    /// Dates are `yyyy-MM-dd`.
    public String dateOfBirth;
    public String licenceNumber;
    public String licenceExpiry;
    public String vehicleMake;
    public String vehicleModel;
    public int vehicleYear;
    public String vehicleColor;
    public String vehiclePlate;
    public int vehicleSeats;
    /// `standard`, `comfort` or `xl`.
    public String product;
    /// Whether the car takes a wheelchair.
    public boolean accessible;
    /// Whether a rider's pet is welcome in the car.
    public boolean petFriendly;
    /// One entry for each kind of document asked for, uploaded or not.
    public List<DocumentDto> documents;
    public String rejectionReason;
    /// Milliseconds since the epoch; 0 for a step not reached.
    public long submittedAt;
    public long reviewedAt;
    public String reviewedBy;

    public DriverApplicationDto() {
    }
}
