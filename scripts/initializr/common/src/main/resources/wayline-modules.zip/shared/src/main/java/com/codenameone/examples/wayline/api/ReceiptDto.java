package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// What a ride cost and how it was paid. Every amount is in cents.
///
/// @param baseFare The part of the fare that does not depend on the trip.
/// @param distanceFare The part of the fare charged by distance.
/// @param timeFare The part of the fare charged by time.
/// @param total The fare, the service fee and the tip, less the discount.
/// @param status `pending`, `paid`, `failed`, `refunded` or `cash`; while a refund the processor
///     took has not finished, `refund_pending`, and `refund_failed` when it then did not return the
///     money.
/// @param paidAt Milliseconds since the epoch, or 0 while unpaid.
/// @param riderUsername Who paid. Filled for an admin; a rider's own receipts leave it empty.
@Mapped
public record ReceiptDto(
        String rideId,
        String currency,
        long baseFare,
        long distanceFare,
        long timeFare,
        long serviceFee,
        long tip,
        long discount,
        long total,
        String methodLabel,
        String status,
        long paidAt,
        String pickupName,
        String dropoffName,
        double distanceMeters,
        double durationSeconds,
        String driverName,
        String vehicle,
        String riderUsername) {
}
