package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// What a ride cost and how it was paid. Every amount is in cents.
@Mapped
public class ReceiptDto {
    public String rideId;
    public String currency;
    /// The three parts of the fare.
    public long baseFare;
    public long distanceFare;
    public long timeFare;
    public long serviceFee;
    public long tip;
    public long discount;
    /// The fare, the service fee and the tip, less the discount.
    public long total;
    public String methodLabel;
    /// `pending`, `paid`, `failed`, `refunded` or `cash`.
    public String status;
    /// Milliseconds since the epoch, or 0 while unpaid.
    public long paidAt;
    public String pickupName;
    public String dropoffName;
    public double distanceMeters;
    public double durationSeconds;
    public String driverName;
    public String vehicle;
    /// Who paid. Filled for an admin; a rider's own receipts leave it empty.
    public String riderUsername;

    public ReceiptDto() {
    }
}
