package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// One of the documents of a driving application. The picture itself is read
/// separately, and only by the applicant and the admins.
@Mapped
public class DocumentDto {
    /// `photo_id`, `licence`, `selfie`, `vehicle_registration` or `insurance`.
    public String kind;
    /// `missing`, `uploaded`, `accepted` or `rejected`.
    public String status;
    /// Milliseconds since the epoch, or 0 when missing.
    public long uploadedAt;

    public DocumentDto() {
    }
}
