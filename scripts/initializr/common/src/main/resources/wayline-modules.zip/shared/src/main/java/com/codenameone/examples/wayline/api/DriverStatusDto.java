package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A driver going on or off line, or reporting where the car is.
@Mapped
public record DriverStatusDto(boolean online, double lat, double lng, double heading) {
}
