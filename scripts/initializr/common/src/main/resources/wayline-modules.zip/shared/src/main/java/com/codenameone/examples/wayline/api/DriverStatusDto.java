package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A driver going on or off line, or reporting where the car is.
@Mapped
public class DriverStatusDto {
    public boolean online;
    public double lat;
    public double lng;
    public double heading;

    public DriverStatusDto() {
    }
}
