package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// Where a ride starts and ends, and how the rider wants it, for a quote and for
/// the request itself.
@Mapped
public class RideRequestDto {
    public double pickupLat;
    public double pickupLng;
    public String pickupAddress;
    public double dropoffLat;
    public double dropoffLng;
    public String dropoffAddress;
    /// The length and duration of the route the app drew, when it has one. The
    /// server prices from these only while they are plausible for the two points;
    /// otherwise it prices from its own estimate.
    public double distanceMeters;
    public double durationSeconds;
    /// A saved method's id, or `cash`. Empty means the rider's default method, and
    /// cash when there is none.
    public String paymentMethodId;
    /// `standard`, `comfort` or `xl`; empty reads as standard.
    public String product;
    /// `any` or `women`; empty reads as any.
    public String driverGender;
    public boolean quietRide;
    public boolean accessibleVehicle;
    /// Whether a pet is coming: only drivers who take pets are offered the ride.
    public boolean petFriendly;
    /// A few words for the driver: which door, what to look for.
    public String note;

    public RideRequestDto() {
    }
}
