package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// Blocks an account, or lifts the block.
@Mapped
public class SuspendDto {
    public boolean suspended;
    /// Why, for the moderation record. May be empty.
    public String reason;

    public SuspendDto() {
    }
}
