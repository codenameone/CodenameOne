package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// Marks an account for a closer look, or clears the mark.
@Mapped
public class FlagDto {
    public boolean flagged;
    public String reason;

    public FlagDto() {
    }
}
