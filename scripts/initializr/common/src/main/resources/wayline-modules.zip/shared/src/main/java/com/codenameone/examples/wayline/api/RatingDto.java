package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A rider's rating of a completed ride.
@Mapped
public record RatingDto(int stars) {
}
