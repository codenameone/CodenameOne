package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// Money sent to a driver's bank.
///
/// @param status `paid`.
/// @param createdAt Milliseconds since the epoch.
/// @param destination The account it went to, as its owner would recognise it.
@Mapped
public record PayoutDto(String id, long amount, String status, long createdAt, String destination) {
}
