package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// What opening an account takes. The password travels once, in the body of a
/// request over TLS, and the server keeps only its hash.
///
/// @param driver The older spelling of [#wantsToDrive()], kept for apps built before it. It no
///     longer grants anything: it opens a driving application like the newer flag.
/// @param wantsToDrive Opens a driving application with the account. The account is a rider until
///     an admin approves the application.
/// @param gender `unspecified`, `female`, `male` or `nonbinary`; empty reads as unspecified.
@Mapped
public record RegisterDto(
        String email,
        String password,
        String displayName,
        String phone,
        boolean driver,
        String vehicle,
        String plate,
        boolean wantsToDrive,
        String gender) {
}
