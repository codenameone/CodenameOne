package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What a ride would cost and how soon a driver could be there.
///
/// @param amountCents The fare of the product asked for, before the service fee.
/// @param driversNearby Drivers online within reach of the pickup right now.
/// @param etaSeconds A rough time for the nearest of them to arrive, or 0 when there is none.
/// @param options The same ride priced as each product, cheapest first.
@Mapped
public record FareQuoteDto(
        long amountCents,
        String currency,
        double distanceMeters,
        double durationSeconds,
        int driversNearby,
        int etaSeconds,
        List<FareOptionDto> options) {
}
