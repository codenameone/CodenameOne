package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A stored document, picture included.
@Mapped
public class DocumentContentDto {
    public String kind;
    public String contentType;
    public String dataBase64;

    public DocumentContentDto() {
    }
}
