package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A stored document, picture included.
@Mapped
public record DocumentContentDto(String kind, String contentType, String dataBase64) {
}
