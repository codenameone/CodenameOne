package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A picture of a document, sent as base64. JPEG or PNG, and small: the app
/// shrinks a photograph before sending it.
@Mapped
public class DocumentUploadDto {
    public String kind;
    /// `image/jpeg` or `image/png`.
    public String contentType;
    public String dataBase64;

    public DocumentUploadDto() {
    }
}
