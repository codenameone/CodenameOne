package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One account in full, for the admin deciding what to do about it.
@Mapped
public class UserDetailDto {
    public UserDto user;
    /// Rides taken part in, as rider or driver, and how many of them were cancelled.
    public int rides;
    public int cancellations;
    /// As a driver; 0 for an account that has not driven.
    public double rating;
    /// Cents paid as a rider and earned as a driver.
    public long spent;
    public long earned;
    /// Newest first.
    public List<ModerationEventDto> events;

    public UserDetailDto() {
    }
}
