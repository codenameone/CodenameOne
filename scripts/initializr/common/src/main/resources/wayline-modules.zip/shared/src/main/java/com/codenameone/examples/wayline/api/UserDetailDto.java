package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One account in full, for the admin deciding what to do about it.
///
/// @param rides Rides taken part in, as rider or driver.
/// @param cancellations How many of those rides were cancelled.
/// @param rating As a driver; 0 for an account that has not driven.
/// @param spent Cents paid as a rider.
/// @param earned Cents earned as a driver.
/// @param events Newest first.
@Mapped
public record UserDetailDto(
        UserDto user,
        int rides,
        int cancellations,
        double rating,
        long spent,
        long earned,
        List<ModerationEventDto> events) {
}
