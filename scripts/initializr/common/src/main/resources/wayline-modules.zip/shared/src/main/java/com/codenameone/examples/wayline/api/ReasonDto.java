package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// Why an admin did something: rejected an application, cancelled a ride,
/// refunded one.
@Mapped
public record ReasonDto(String reason) {
}
