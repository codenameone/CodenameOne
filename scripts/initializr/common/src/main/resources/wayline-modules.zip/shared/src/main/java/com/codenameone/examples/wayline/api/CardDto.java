package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// A card as typed into the app. Read by the simulated processor only, which
/// keeps the brand and the last four digits and nothing else; with a real
/// processor the card never reaches the app or this server.
@Mapped
public class CardDto {
    public String number;
    public int expMonth;
    public int expYear;
    public String cvc;
    public String holder;

    public CardDto() {
    }
}
