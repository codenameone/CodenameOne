package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// One day of the service.
@Mapped
public class DayStatsDto {
    /// `yyyy-MM-dd`, in UTC.
    public String date;
    public int rides;
    public int completed;
    public int cancelled;
    /// Cents: the fares of the day's completed, paid rides.
    public long revenue;
    public int newUsers;

    public DayStatsDto() {
    }
}
