package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The admin's charts: how the service did, day by day.
///
/// @param days Oldest first, every day present.
/// @param byHour Rides asked for in each hour of the day (UTC), 24 numbers.
/// @param topDrivers The drivers who completed the most rides in the period; `rides` is that count.
/// @param averageFare Cents.
/// @param averageWaitSeconds From a ride being asked for to a driver taking it.
/// @param completionRate Completed rides over rides asked for, 0 to 1.
@Mapped
public record StatsSeriesDto(
        List<DayStatsDto> days,
        List<Integer> byHour,
        List<NameCountDto> byState,
        List<NameCountDto> byProduct,
        List<DriverDto> topDrivers,
        long averageFare,
        double averageWaitSeconds,
        double completionRate,
        int pendingApplications,
        int flaggedUsers,
        String currency) {
}
