package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The admin's charts: how the service did, day by day.
@Mapped
public class StatsSeriesDto {
    /// Oldest first, every day present.
    public List<DayStatsDto> days;
    /// Rides asked for in each hour of the day (UTC), 24 numbers.
    public List<Integer> byHour;
    public List<NameCountDto> byState;
    public List<NameCountDto> byProduct;
    /// The drivers who completed the most rides in the period; `rides` is that count.
    public List<DriverDto> topDrivers;
    /// Cents.
    public long averageFare;
    /// From a ride being asked for to a driver taking it.
    public double averageWaitSeconds;
    /// Completed rides over rides asked for, 0 to 1.
    public double completionRate;
    public int pendingApplications;
    public int flaggedUsers;
    public String currency;

    public StatsSeriesDto() {
    }
}
