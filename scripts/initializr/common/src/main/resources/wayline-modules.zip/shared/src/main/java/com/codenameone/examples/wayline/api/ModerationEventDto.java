package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// Something an admin did to an account, and why.
@Mapped
public class ModerationEventDto {
    /// Milliseconds since the epoch.
    public long at;
    public String by;
    /// `flag`, `unflag`, `block`, `unblock`, `approve`, `reject`, `roles`.
    public String action;
    public String reason;

    public ModerationEventDto() {
    }
}
