package com.codenameone.examples.wayline.api;

import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Finding places. The server asks a geocoding service on the app's behalf, so
/// the app holds no key for one and the service can be changed in one place.
@RestClient
public interface GeoApi {
    /// Places matching `text`, nearest to the given point first.
    @GET("/api/geo/search")
    void search(@Query("q") String text, @Query("lat") double lat, @Query("lng") double lng,
            OnComplete<Response<List<PlaceDto>>> callback);

    /// The address at a point.
    @GET("/api/geo/reverse")
    void reverse(@Query("lat") double lat, @Query("lng") double lng,
            OnComplete<Response<PlaceDto>> callback);
}
