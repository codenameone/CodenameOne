package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// How one person wants the app and their rides. Kept on the server, so it
/// follows the account to another phone.
///
/// @param language `en`, `es`, `fr`, `de` or `he`.
/// @param theme `system`, `light` or `dark`.
/// @param units `km` or `mi`.
/// @param driverGender `any` or `women`: whom a ride may be offered to.
/// @param defaultPaymentMethodId A saved method's id, or `cash`.
/// @param defaultTipPercent 0, 10, 15 or 20.
/// @param shareTripsWith The phone number trips are shared with, or empty.
@Mapped
public record PreferencesDto(
        String language,
        String theme,
        String units,
        boolean notifyRideUpdates,
        boolean notifyReceipts,
        boolean notifyPromotions,
        String driverGender,
        boolean quietRide,
        boolean accessibleVehicle,
        boolean petFriendly,
        String defaultPaymentMethodId,
        int defaultTipPercent,
        String shareTripsWith) {
}
