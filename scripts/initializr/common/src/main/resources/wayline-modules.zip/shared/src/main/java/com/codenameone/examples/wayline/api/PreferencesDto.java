package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// How one person wants the app and their rides. Kept on the server, so it
/// follows the account to another phone.
@Mapped
public class PreferencesDto {
    /// `en`, `es`, `fr`, `de` or `he`.
    public String language;
    /// `system`, `light` or `dark`.
    public String theme;
    /// `km` or `mi`.
    public String units;
    public boolean notifyRideUpdates;
    public boolean notifyReceipts;
    public boolean notifyPromotions;
    /// `any` or `women`: whom a ride may be offered to.
    public String driverGender;
    public boolean quietRide;
    public boolean accessibleVehicle;
    public boolean petFriendly;
    /// A saved method's id, or `cash`.
    public String defaultPaymentMethodId;
    /// 0, 10, 15 or 20.
    public int defaultTipPercent;
    /// The phone number trips are shared with, or empty.
    public String shareTripsWith;

    public PreferencesDto() {
    }
}
