package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// The code the user typed in.
@Mapped
public record PhoneCodeDto(String code) {
}
