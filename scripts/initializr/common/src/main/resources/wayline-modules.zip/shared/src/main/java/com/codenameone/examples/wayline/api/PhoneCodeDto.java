package com.codenameone.examples.wayline.api;

import com.codename1.annotations.Mapped;

/// The code the user typed in.
@Mapped
public class PhoneCodeDto {
    public String code;

    public PhoneCodeDto() {
    }
}
