package com.codenameone.examples.papercut.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import java.time.Instant;
import java.util.List;
import com.codenameone.examples.papercut.domain.DailySeed;

/// Days an admin picked the seed for.
@Repository(entity = DailySeed.class, key = String.class)
public interface DailySeedRepository extends CrudRepository<DailySeed, String> {
}
