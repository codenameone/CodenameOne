package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// A friend and their best classic score.
@Mapped
public record FriendDto(String username, String displayName, long bestClassic, String quill) {
}
