package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// The player's ink coins, spare erasers and papers.
@Mapped
public record WalletDto(int inkCoins, int erasers, List<String> owned, String quill) {
}
