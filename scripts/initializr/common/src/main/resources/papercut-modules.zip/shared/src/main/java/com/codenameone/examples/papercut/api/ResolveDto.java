package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Closes a flag: KEEP leaves the run on the boards, REMOVE strikes it.
@Mapped
public record ResolveDto(String verdict) {
}
