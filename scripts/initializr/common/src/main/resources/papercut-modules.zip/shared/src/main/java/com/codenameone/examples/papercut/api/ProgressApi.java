package com.codenameone.examples.papercut.api;

import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;
import java.util.List;

/// Achievements, worked out by the server from the runs it accepted.
@RestClient
public interface ProgressApi {
    @GET("/api/achievements")
    void achievements(OnComplete<Response<List<AchievementDto>>> callback);
}
