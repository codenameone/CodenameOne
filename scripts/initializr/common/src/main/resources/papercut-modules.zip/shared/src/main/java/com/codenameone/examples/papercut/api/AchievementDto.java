package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// A goal, and how far the player is toward it.
@Mapped
public record AchievementDto(String id, String name, String description, boolean unlocked, long progress, long goal) {
}
