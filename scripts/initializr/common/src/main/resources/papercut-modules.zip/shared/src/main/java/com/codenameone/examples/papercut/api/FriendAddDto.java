package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Adds or removes a friend by username or display name.
@Mapped
public record FriendAddDto(String name) {
}
