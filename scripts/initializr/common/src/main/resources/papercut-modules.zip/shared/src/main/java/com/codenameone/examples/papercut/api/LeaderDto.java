package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// One row of a leaderboard. `me` marks the player asking.
@Mapped
public record LeaderDto(int rank, String username, String displayName, long score, String quill, boolean me) {
}
