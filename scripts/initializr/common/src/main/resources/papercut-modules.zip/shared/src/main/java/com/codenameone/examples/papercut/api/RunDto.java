package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// A finished run, as the app reports it. The server holds it to `ScoreBounds`.
@Mapped
public record RunDto(String token, String mode, long score, int kills, int gates, int seconds, int peakMultiplier) {
}
