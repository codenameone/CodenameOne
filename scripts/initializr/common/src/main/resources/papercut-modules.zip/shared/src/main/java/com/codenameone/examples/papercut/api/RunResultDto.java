package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// What became of a submitted run. `rank` is on the all-time board of its mode, 0 when
/// it was refused; `coinsEarned` went into the wallet.
@Mapped
public record RunResultDto(boolean accepted, boolean flagged, boolean newBest, long best, int rank, int coinsEarned, String message) {
}
