/// The REST contract between the app and its server: every route as a `@RestClient`
/// interface and every object it carries as a `@Mapped` record, plus `ScoreBounds`, the
/// arithmetic both sides hold a run to.
package com.codenameone.examples.papercut.api;
