package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Permission to submit one run: the token the result must carry, and for the daily the seed
/// every player is dealt that day.
@Mapped
public record RunTicketDto(String token, String mode, long seed, long expiresAt) {
}
