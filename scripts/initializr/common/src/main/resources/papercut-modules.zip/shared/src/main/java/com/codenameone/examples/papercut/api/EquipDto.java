package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Equips an owned paper.
@Mapped
public record EquipDto(String quill) {
}
