package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// The console's front page.
@Mapped
public record AdminStatsDto(int players, int activeToday, int runsToday, int flagsOpen, long topScore, long dailySeed, int purchases) {
}
