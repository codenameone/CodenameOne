package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// A run worth a person's look: past `ScoreBounds#suspicious`, or a player reported.
@Mapped
public record FlagDto(String id, String username, String displayName, String mode, long score, int kills, int seconds, String reason, long createdAt, boolean open) {
}
