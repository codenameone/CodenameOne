package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Today's sheet: the date, the seed every player is dealt, the asker's best and the day's top.
@Mapped
public record DailyDto(String date, long seed, long myBest, long topScore, String topName, int players) {
}
