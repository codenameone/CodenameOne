package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Asks for a ticket to play `mode` (CLASSIC, FOLD or DAILY).
@Mapped
public record StartRunDto(String mode) {
}
