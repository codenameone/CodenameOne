package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Buying a shop item with ink coins.
@Mapped
public record BuyDto(String itemId) {
}
