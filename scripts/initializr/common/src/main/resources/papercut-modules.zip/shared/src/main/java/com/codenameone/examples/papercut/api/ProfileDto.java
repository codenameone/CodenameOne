package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// What a player may change about themselves.
@Mapped
public record ProfileDto(String displayName, String quill) {
}
