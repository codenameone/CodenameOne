package com.codenameone.examples.papercut.api;

import com.codename1.annotations.Mapped;

/// Overrides today's seed, for a sheet an admin has picked.
@Mapped
public record DailySeedDto(long seed) {
}
