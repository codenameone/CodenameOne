package com.codenameone.examples.bastion.ui;

import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.Toolbar;
import com.codenameone.examples.bastion.api.UserDto;
import com.codenameone.examples.bastion.net.Session;

/// The way around the app: the side menu every signed-in screen has, and the
/// screen each entry leads to.
///
/// The admin entry is shown only to an account with the role, and that is a
/// courtesy, not the protection: the server refuses `/api/admin/**` to anyone
/// else whatever the app shows.
public final class Nav {
    private static Runnable signedOut;

    private Nav() {
    }

    /// What to show once the user has signed out, or been signed out.
    public static void install(Runnable whenSignedOut) {
        signedOut = whenSignedOut;
    }

    /// Adds the side menu to `form`.
    public static void menu(Form form) {
        Toolbar bar = form.getToolbar();
        UserDto user = Session.user();
        if (user != null) {
            Label who = new Label(user.displayName() == null ? user.username() : user.displayName(),
                    "BnMenuHeader");
            bar.addComponentToSideMenu(who);
        }
        bar.addMaterialCommandToSideMenu(Lang.tr("Accounts"), FontImage.MATERIAL_ACCOUNT_BALANCE,
                evt -> home());
        bar.addMaterialCommandToSideMenu(Lang.tr("Move money"), FontImage.MATERIAL_SWAP_HORIZ,
                evt -> TransferForm.show(null, false, Nav::home));
        bar.addMaterialCommandToSideMenu(Lang.tr("Payees"), FontImage.MATERIAL_PEOPLE,
                evt -> PayeesForm.show(null));
        bar.addMaterialCommandToSideMenu(Lang.tr("Cards"), FontImage.MATERIAL_CREDIT_CARD,
                evt -> CardsForm.show(null));
        bar.addMaterialCommandToSideMenu(Lang.tr("Exchange"), FontImage.MATERIAL_SHOW_CHART,
                evt -> ExchangeForm.show(null));
        bar.addMaterialCommandToSideMenu(Lang.tr("Send crypto"), FontImage.MATERIAL_CALL_MADE,
                evt -> WithdrawForm.show(null, Nav::home));
        bar.addMaterialCommandToSideMenu(Lang.tr("Security Center"), FontImage.MATERIAL_SECURITY,
                evt -> SecurityCenterForm.show(Nav::home));
        bar.addMaterialCommandToSideMenu(Lang.tr("Settings"), FontImage.MATERIAL_SETTINGS,
                evt -> SettingsForm.show(null));
        if (staff(user)) {
            bar.addMaterialCommandToSideMenu(Lang.tr(user.admin() ? "Administration" : "Audit"),
                    FontImage.MATERIAL_ADMIN_PANEL_SETTINGS, evt -> ConsoleForm.show());
        }
        bar.addMaterialCommandToSideMenu(Lang.tr("Sign out"), FontImage.MATERIAL_LOGOUT,
                evt -> signOut());
    }

    /// Whether `user` works for the bank: an administrator or an auditor.
    public static boolean staff(UserDto user) {
        return user != null && (user.admin() || user.auditor());
    }

    /// The dashboard; for staff with no customer accounts, the console.
    public static void home() {
        UserDto user = Session.user();
        if (user != null && !user.customer() && staff(user)) {
            ConsoleForm.show();
        } else {
            HomeForm.show();
        }
    }

    public static void signOut() {
        Session.signOut(signedOut);
    }

    /// A form of the signed-in app. There is one way out of a screen, never
    /// two: a screen reached from the menu (`back` null) is a top-level
    /// screen and has the menu button; a screen pushed from another one has
    /// a back arrow to `back`, and no menu. A back arrow beside a menu
    /// button leaves the user guessing which of them is "up".
    public static Form form(String title, Runnable back) {
        Form form = Ui.form(title, back);
        if (back == null) {
            menu(form);
        }
        return form;
    }
}
