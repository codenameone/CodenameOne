package com.codenameone.examples.bastion.net;

import com.codename1.io.rest.RestClients;
import com.codenameone.examples.bastion.api.AccountApi;
import com.codenameone.examples.bastion.api.AdminApi;
import com.codenameone.examples.bastion.api.BankingApi;
import com.codenameone.examples.bastion.api.ExchangeApi;

/// The typed clients, generated at build time from the contracts in the
/// `shared` module. Nothing else in the app builds an API URL.
public final class Api {
    private static AccountApi account;
    private static BankingApi banking;
    private static ExchangeApi exchange;
    private static AdminApi admin;

    private Api() {
    }

    static void connect(String baseUrl) {
        account = RestClients.create(AccountApi.class, baseUrl);
        banking = RestClients.create(BankingApi.class, baseUrl);
        exchange = RestClients.create(ExchangeApi.class, baseUrl);
        admin = RestClients.create(AdminApi.class, baseUrl);
    }

    public static AccountApi account() {
        return account;
    }

    public static BankingApi banking() {
        return banking;
    }

    public static ExchangeApi exchange() {
        return exchange;
    }

    public static AdminApi admin() {
        return admin;
    }
}
