package com.codenameone.examples.bastion.security;

import com.codename1.security.DeviceIntegrity;
import com.codename1.security.TapjackingPolicy;
import com.codename1.security.shield.ShieldSignal;
import com.codename1.security.shield.ShieldSignals;
import com.codename1.ui.CN;
import com.codename1.ui.Display;
import com.codenameone.examples.bastion.AppConfig;

/// Screen and input protection.
///
/// - **Sensitive screens** (balances, card numbers, codes) set the platform's
///   secure-window flag while they are showing: no screenshots, no screen
///   recording, and a blank card in the recent-apps list (Android
///   `FLAG_SECURE`; on iOS, `ios.blockScreenshotsOnEnterBackground` covers the
///   app switcher).
/// - **Tapjacking**: a touch that arrives through another app's overlay is
///   dropped ([TapjackingPolicy#BLOCK]), and overlay windows are hidden while
///   the app is in front where the OS allows it (Android 12+).
/// - **Clipboard**: an account number or address the user copies is wiped
///   from the clipboard after [AppConfig#CLIPBOARD_CLEAR_MILLIS], unless
///   something else was copied in the meantime.
public final class Protect {
    private static boolean secure;
    private static String copied;

    private Protect() {
    }

    public static void install() {
        DeviceIntegrity.setTapjackingProtection(TapjackingPolicy.BLOCK);
        if (DeviceIntegrity.isHideOverlayWindowsSupported()) {
            DeviceIntegrity.setHideOverlayWindows(true);
        }
        DeviceIntegrity.addTapjackingListener(evt ->
                ShieldSignals.add(ShieldSignal.TAPJACK, 2, "a touch through an overlay was blocked"));
    }

    /// Called as each form shows: `sensitive` forms block screenshots.
    public static void screen(boolean sensitive) {
        if (sensitive != secure) {
            secure = sensitive;
            DeviceIntegrity.setSecureScreen(sensitive);
        }
    }

    public static boolean isSecureScreen() {
        return secure;
    }

    /// Copies `text`, and clears it again later.
    public static void copy(final String text) {
        Display.getInstance().copyToClipboard(text);
        copied = text;
        // CN.setTimeout, not a UITimer: a UITimer runs only while the form it
        // is bound to is showing, and the user moves on after copying.
        CN.setTimeout((int) AppConfig.CLIPBOARD_CLEAR_MILLIS, () -> {
            Object now = Display.getInstance().getPasteDataFromClipboard();
            // Only what this app put there: never wipe something the user
            // copied from elsewhere since.
            if (now instanceof String && now.equals(text) && text.equals(copied)) {
                Display.getInstance().copyToClipboard("");
                copied = null;
            }
        });
    }
}
