package com.codenameone.examples.bastion.net;

import com.codename1.ui.plaf.UIManager;
import com.codenameone.examples.bastion.api.Refusal;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;
import com.codenameone.examples.bastion.ui.Lang;

/// Makes a call through a generated client and sorts out what came back.
///
/// A generated method answers with a `Response` whatever happened: null when
/// the server could not be reached, and otherwise a status with either the
/// typed result or, for a refusal, the server's reason as text. This turns that
/// into one of two callbacks, so a screen writes what to do with the result and
/// what to do with a failure, and nothing else.
///
/// ```java
/// Api.orders().order(id, Net.to(order -> show(order), Ui::fail));
/// ```
public final class Net {
    private static String lastCode;

    /// A call to a generated client method, waiting for its callback.
    public interface Call<T> {
        void run(OnComplete<Response<T>> callback);
    }

    public interface Ok<T> {
        void got(T value);
    }

    public interface Failed {
        /// @param status the HTTP status, or 0 when the server was not reached
        /// @param message something to show the user
        void failed(int status, String message);
    }

    private Net() {
    }

    /// The callback to hand a generated method: `ok` gets the result, `failed`
    /// everything else.
    ///
    /// Both are dropped when the session epoch moved on while the call was
    /// out (the app locked, or the user signed out or in again): the answer
    /// belongs to a session that is no longer on screen.
    public static <T> OnComplete<Response<T>> to(final Ok<T> ok, final Failed failed) {
        final int epoch = Session.epoch();
        return new OnComplete<Response<T>>() {
            @Override
            public void completed(Response<T> response) {
                if (epoch != Session.epoch()) {
                    return;
                }
                if (response == null) {
                    lastCode = null;
                    failed.failed(0, Lang.tr("Could not reach the server. Check your connection."));
                    return;
                }
                int status = response.getResponseCode();
                if (status >= 200 && status < 300) {
                    ok.got(response.getResponseData());
                    return;
                }
                failed.failed(status, reason(response, status));
            }
        };
    }

    /// Makes a call that was handed over as a value, which is how one screen
    /// serves several calls of the same shape.
    public static <T> void send(Call<T> call, Ok<T> ok, Failed failed) {
        call.run(to(ok, failed));
    }

    /// What the server said when it refused. Read as an `Object` and tested,
    /// never cast to the type the call was declared with: on a refusal the body
    /// is text whatever that type is.
    private static String reason(Response<?> response, int status) {
        lastCode = null;
        Object body = response.getResponseData();
        if (body instanceof String && ((String) body).length() > 0
                && ((String) body).length() < 300 && ((String) body).indexOf('<') < 0
                && ((String) body).indexOf('{') < 0) {
            lastCode = Refusal.code((String) body);
            return localize((String) body);
        }
        if (status == 401) {
            return Lang.tr("Please sign in again.");
        }
        if (status == 403) {
            return Lang.tr("Your account is not allowed to do that.");
        }
        if (status == 429) {
            return Lang.tr("Too many attempts. Wait a moment and try again.");
        }
        return Lang.tr("Something went wrong ({0}). Try again.", String.valueOf(status));
    }

    /// A refusal in the user's language: the server sends a stable code with
    /// its English sentence ([Refusal]), the bundle has the code as
    /// `error.<code>`. A code this app does not know yet (a newer server)
    /// is shown in the server's English rather than not at all.
    public static String localize(String body) {
        String code = Refusal.code(body);
        if (code == null) {
            return body;
        }
        String key = "error." + code;
        String pattern = UIManager.getInstance().localize(key, null);
        if (pattern == null || pattern.length() == 0 || pattern.equals(key)) {
            return Refusal.english(body);
        }
        return Refusal.fill(pattern, Refusal.values(body));
    }

    /// The stable code of the refusal being reported, or null: read inside a
    /// [Failed] callback, which runs on the EDT right after it is set, to
    /// tell one refusal from another without comparing translated text.
    public static String refusalCode() {
        return lastCode;
    }
}
