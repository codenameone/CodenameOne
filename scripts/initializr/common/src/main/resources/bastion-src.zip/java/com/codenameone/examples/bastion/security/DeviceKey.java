package com.codenameone.examples.bastion.security;

import com.codename1.io.Preferences;
import com.codename1.security.DeviceIntegrity;
import com.codename1.security.KeyGenerator;
import com.codename1.security.KeyPair;
import com.codename1.security.PrivateKey;
import com.codename1.security.PublicKey;
import com.codename1.security.vault.AssociatedData;
import com.codename1.security.vault.SecureEnvelope;
import com.codename1.ui.CN;
import com.codename1.util.Base64;
import com.codename1.util.SuccessCallback;
import com.codenameone.examples.bastion.api.DeviceDto;
import com.codenameone.examples.bastion.api.DeviceRegistrationDto;
import com.codenameone.examples.bastion.net.Api;
import com.codenameone.examples.bastion.net.Net;
import com.codenameone.examples.bastion.ui.Lang;

/// This device's signing key: the second thing, after the session, that the
/// server asks for before money leaves an account.
///
/// The key is an EC P-256 pair from [KeyGenerator#ecP256()], made by the
/// platform's own crypto provider; the server gets its X.509 public half and
/// the PKCS#8 private half never leaves the device. It is kept sealed: an
/// AES-256-GCM [SecureEnvelope] whose associated data names the account and
/// purpose (so a blob copied to another account's slot does not open), under
/// the app key ([Keys]), which the OS releases only after a biometric check
/// or which the user's PIN opens -- whichever they set up. The sealed blob
/// alone, in the app's preferences, is useless without one of those.
///
/// In the simulator the OS store is an ordinary file, and the Security
/// Center says so.
public final class DeviceKey {
    private static final String SEALED_KEY = "myappname.device.sealed";
    private static final String ID_KEY = "myappname.device.id";
    private static final String OWNER_KEY = "myappname.device.owner";

    private static PrivateKey cached;

    private DeviceKey() {
    }

    /// The id the server gave this device, or null before registration.
    public static String deviceId() {
        String id = Preferences.get(ID_KEY, "");
        return id.length() == 0 ? null : id;
    }

    /// The account the key was registered for, or null.
    public static String owner() {
        String owner = Preferences.get(OWNER_KEY, "");
        return owner.length() == 0 ? null : owner;
    }

    /// The private key, unsealed, or null when there is none (or the wrapping
    /// key is gone: a restored backup on a new phone, which is then simply a
    /// device to register again).
    public static PrivateKey privateKey() {
        if (Lock.isLocked()) {
            return null;
        }
        if (cached != null) {
            return cached;
        }
        String sealed = Preferences.get(SEALED_KEY, "");
        String owner = owner();
        byte[] wrap = Keys.current();
        if (sealed.length() == 0 || owner == null || wrap == null) {
            return null;
        }
        try {
            cached = PrivateKey.fromPkcs8(PublicKey.EC,
                    SecureEnvelope.parse(Base64.decodeUrlSafe(sealed)).open(wrap, aad(owner)));
            return cached;
        } catch (RuntimeException tamperedOrForeign) {
            // A blob that does not open under this device's key, or for this
            // account, is not this device's key.
            forget();
            return null;
        }
    }

    /// Drops the unsealed key from memory: the app lock calls this.
    public static void dropFromMemory() {
        cached = null;
    }

    /// Forgets the key on this device; the server keeps its record until the
    /// device is removed there (Security Center, or another device).
    public static void forget() {
        cached = null;
        Preferences.delete(SEALED_KEY);
        Preferences.delete(ID_KEY);
        Preferences.delete(OWNER_KEY);
    }

    /// Makes a new key and registers its public half for `owner`. `password`
    /// is asked for when the account has no authenticator app (the server
    /// wants a second proof that it is the owner adding a device); null
    /// otherwise. The sign-in must be a few minutes old.
    public static void register(final String owner, final String password,
            final Net.Ok<DeviceDto> done, final Net.Failed failed) {
        KeyPair pair = KeyGenerator.ecP256();
        final PrivateKey key = pair.getPrivateKey();
        final String publicKey = Base64.encodeUrlSafe(pair.getPublicKey().getEncoded());
        final boolean rooted = DeviceIntegrity.isDeviceCompromised();
        if (DeviceIntegrity.isAttestationSupported()) {
            // Play Integrity / App Attest over the public key, so the token is
            // bound to this key and cannot be replayed for another.
            DeviceIntegrity.requestIntegrityToken(publicKey).ready(new SuccessCallback<String>() {
                @Override
                public void onSucess(String token) {
                    send(owner, password, key, publicKey, rooted, token, done, failed);
                }
            }).except(new SuccessCallback<Throwable>() {
                @Override
                public void onSucess(Throwable err) {
                    send(owner, password, key, publicKey, rooted, null, done, failed);
                }
            });
            return;
        }
        send(owner, password, key, publicKey, rooted, null, done, failed);
    }

    private static void send(final String owner, String password, final PrivateKey key,
            String publicKey, boolean rooted, String token, final Net.Ok<DeviceDto> done,
            Net.Failed failed) {
        DeviceRegistrationDto request = new DeviceRegistrationDto(publicKey,
                CN.getPlatformName(), rooted, token != null, token, password);
        Api.banking().registerDevice(request, Net.to(device -> {
            byte[] wrap = Keys.current();
            if (wrap == null) {
                failed.failed(0, Lang.tr("Unlock Bastion first."));
                return;
            }
            byte[] sealed = SecureEnvelope.seal(wrap, "device-key", 1, aad(owner), key.getEncoded());
            Preferences.set(SEALED_KEY, Base64.encodeUrlSafe(sealed));
            Preferences.set(ID_KEY, device.id());
            Preferences.set(OWNER_KEY, owner);
            cached = key;
            done.got(device);
        }, failed));
    }

    private static AssociatedData aad(String owner) {
        return AssociatedData.of("myappname", "device", owner, "request-signing");
    }
}
