package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// An invitation to a party. Whoever opens `url` (it opens the web build) joins
/// the party, and races with it when the host starts.
@Mapped
public record ChallengeDto(String code, String url, int expiresInSeconds) {
}
