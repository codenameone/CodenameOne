package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// An invite the app recovered through `com.codename1.analytics.invite.Invites`:
/// the code the inviter's link carried in its payload, and how it was matched.
@Mapped
public record InviteClaimDto(String code, String campaign, String channel, String match) {
}
