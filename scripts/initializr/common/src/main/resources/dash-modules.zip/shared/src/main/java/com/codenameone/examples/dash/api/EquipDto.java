package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// Equips an owned outfit; the shop sells them.
@Mapped
public record EquipDto(String outfit) {
}
