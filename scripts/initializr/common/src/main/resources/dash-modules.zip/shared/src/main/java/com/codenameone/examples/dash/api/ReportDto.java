package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A player reporting their fellow racer after a race.
@Mapped
public record ReportDto(String raceId, String player, String reason) {
}
