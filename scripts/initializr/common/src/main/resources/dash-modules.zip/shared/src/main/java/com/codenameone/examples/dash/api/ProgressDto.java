package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// Everything the home screen shows about a player's progress: the level and
/// how far into it they are, chests waiting, today's quests and the
/// achievements, unlocked or not.
@Mapped
public record ProgressDto(int level, int xp, int levelStart, int levelEnd, boolean tutorialDone, int chests,
        int coins, int gems, int streak, int wins, List<QuestDto> quests, List<AchievementDto> achievements) {
}
