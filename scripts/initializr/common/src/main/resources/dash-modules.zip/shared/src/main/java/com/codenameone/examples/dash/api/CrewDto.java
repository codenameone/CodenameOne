package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A crew: a standing group of friends that races together and has its own
/// leaderboards.
@Mapped
public record CrewDto(String code, String name, String owner, List<String> members, List<String> names) {
}
