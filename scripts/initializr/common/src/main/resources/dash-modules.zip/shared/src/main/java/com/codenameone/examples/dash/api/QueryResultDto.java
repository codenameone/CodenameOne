package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// How many players a query matched, and the first of them.
@Mapped
public record QueryResultDto(int count, List<PlayerDto> players) {
}
