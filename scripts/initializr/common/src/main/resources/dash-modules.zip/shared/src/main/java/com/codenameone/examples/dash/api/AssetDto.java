package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// An uploaded file. `status` is pending until a moderator approves it, and
/// `data` is only filled when the file itself was asked for.
@Mapped
public record AssetDto(String sha256, String name, String kind, int bytes, String status, List<String> animations, String data) {
}
