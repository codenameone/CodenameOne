package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A query over the players: every condition must hold.
@Mapped
public record QueryDto(List<ConditionDto> conditions) {
}
