package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// What a verified run earned: stars, the personal best, the leaderboard rank
/// and the reward.
@Mapped
public record LevelOutcomeDto(String packId, String levelId, int stars, int score, int best, int rank, RewardDto reward) {
}
