package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A model or image for a pack, base64 encoded.
@Mapped
public record AssetUploadDto(String name, String kind, String data) {
}
