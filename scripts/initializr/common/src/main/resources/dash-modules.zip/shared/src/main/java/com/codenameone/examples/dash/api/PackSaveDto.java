package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A draft to keep: the whole pack, as JSON. Drafts are not validated.
@Mapped
public record PackSaveDto(String content) {
}
