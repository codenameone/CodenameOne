package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A recorded race. `replay` is the shared rules' own encoding: the level, a seed
/// and every runner's inputs, nothing else.
@Mapped
public record ReplayDto(String id, String level, List<String> names, List<Integer> scores, String replay, String rulesVersion, long endedAt) {
}
