package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A finished solo run: the replay the app recorded. The server plays it again
/// before it believes the score.
@Mapped
public record LevelResultDto(String replay) {
}
