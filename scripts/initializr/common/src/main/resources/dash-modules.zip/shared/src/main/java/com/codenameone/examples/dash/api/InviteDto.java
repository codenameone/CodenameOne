package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// The player's own invite code and how far it has got them: friends who
/// joined through it, how many of those have played and been paid for, and
/// what each side earns.
@Mapped
public record InviteDto(String code, int joined, int rewarded, int maxRewarded, int inviterCoins,
        int friendCoins) {
}
