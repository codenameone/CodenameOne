package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// The runner a player has chosen: a built-in character id, or `asset:<sha256>`
/// for a glTF model they uploaded.
@Mapped
public record RunnerDto(String runner) {
}
