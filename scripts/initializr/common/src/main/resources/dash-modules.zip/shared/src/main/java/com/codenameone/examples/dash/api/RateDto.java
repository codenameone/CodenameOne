package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// One to five stars for a pack; rating again replaces the earlier stars.
@Mapped
public record RateDto(String packId, int stars) {
}
