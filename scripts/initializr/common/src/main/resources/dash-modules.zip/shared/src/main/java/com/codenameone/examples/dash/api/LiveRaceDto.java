package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A race in progress, for the admin console.
@Mapped
public record LiveRaceDto(String id, String level, List<String> players, List<String> names, int tick, String leader, int bots) {
}
