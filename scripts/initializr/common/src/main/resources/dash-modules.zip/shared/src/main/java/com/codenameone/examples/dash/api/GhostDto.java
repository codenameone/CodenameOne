package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A leaderboard run to race against: its replay, re-simulated by the app.
@Mapped
public record GhostDto(String displayName, int score, String replay) {
}
