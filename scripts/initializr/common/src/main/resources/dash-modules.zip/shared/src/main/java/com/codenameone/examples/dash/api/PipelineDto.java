package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// An engagement pipeline: when a player matches the conditions, do the
/// action, at most once per `cooldownDays` for each player. The server runs
/// every enabled pipeline once an hour.
///
/// @param action `push` (sends title and body, opening screen) or `gems` (gives amount gems, with a push saying so)
/// @param reached players acted on, ever
/// @param lastRun when the pipeline last ran, in milliseconds, or 0
@Mapped
public record PipelineDto(String id, String name, boolean enabled, List<ConditionDto> conditions, String action,
        String title, String body, String screen, int amount, int cooldownDays, int reached, long lastRun) {
}
