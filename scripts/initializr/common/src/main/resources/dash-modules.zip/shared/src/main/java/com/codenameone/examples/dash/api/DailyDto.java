package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// The daily challenge: one level on one seed for everyone, for `day` (days
/// since the epoch, UTC). The seed travels as text: a 64-bit number does not
/// survive a JavaScript JSON parser.
@Mapped
public record DailyDto(int day, String level, String seed, int secondsLeft) {
}
