package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// One test a player must pass to be in a query or a pipeline's audience,
/// such as `daysAway >= 7`. The fields and operators are listed in the
/// server's `Audience` class; anything else is refused.
@Mapped
public record ConditionDto(String field, String op, int value) {
}
