package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A player's best on one level.
@Mapped
public record LevelStarsDto(String packId, String levelId, int stars, int best) {
}
