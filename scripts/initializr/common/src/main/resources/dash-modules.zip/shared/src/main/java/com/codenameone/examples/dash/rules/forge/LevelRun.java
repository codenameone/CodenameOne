package com.codenameone.examples.dash.rules.forge;

import com.codenameone.examples.dash.rules.Catalog;
import com.codenameone.examples.dash.rules.Content;
import com.codenameone.examples.dash.rules.LevelDef;
import com.codenameone.examples.dash.rules.Replay;
import com.codenameone.examples.dash.rules.Run;
import com.codenameone.examples.dash.rules.RulesVersion;

/// Verifies a submitted run. A client sends only its [Replay]; the server finds
/// the level the replay names, checks it is the same content, and plays the
/// inputs itself. The score on a leaderboard is the score of the server's run,
/// never a number the client reported.
public final class LevelRun {
    private LevelRun() {
    }

    /// The level id a replay of `levelId` in `pack` carries: the bare id for an
    /// official level, a [ContentRef] for anything else.
    public static String replayLevelId(ContentPack pack, String levelId) {
        if (Samples.OFFICIAL_ID.equals(pack.id)) {
            return levelId;
        }
        return new ContentRef(pack.id, pack.hash(), levelId).toString();
    }

    /// Plays `claimed` on `pack`'s level. Throws `IllegalArgumentException` when
    /// the replay was recorded under other rules, on other content or with more
    /// than one runner.
    public static Run verify(ContentPack pack, String levelId, Replay claimed) {
        if (!RulesVersion.ID.equals(claimed.rulesVersion())) {
            throw new IllegalArgumentException("recorded under other rules");
        }
        LevelDef level = pack.level(levelId);
        if (level == null) {
            throw new IllegalArgumentException("no level " + levelId);
        }
        Catalog catalog = Samples.OFFICIAL_ID.equals(pack.id) ? Content.catalog() : pack.catalog();
        return verify(level, catalog, claimed);
    }

    /// Plays `claimed` on `level`, a level the caller built itself -- a city
    /// route, rebuilt from its spec. The same checks as for a pack's level;
    /// that the replay names this level is the caller's to check, since a
    /// pack's level is named by a [ContentRef].
    public static Run verify(LevelDef level, Catalog catalog, Replay claimed) {
        if (!RulesVersion.ID.equals(claimed.rulesVersion())) {
            throw new IllegalArgumentException("recorded under other rules");
        }
        if (level.contentHash() != claimed.levelHash()) {
            throw new IllegalArgumentException("the level changed since this run");
        }
        if (claimed.runners() != 1) {
            throw new IllegalArgumentException("a submitted run has one runner");
        }
        Run run = claimed.play(level, catalog);
        if (!run.over()) {
            throw new IllegalArgumentException("the run did not end");
        }
        return run;
    }
}
