package com.codenameone.examples.dash.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;
import java.util.List;

/// Inviting friends and the home banner. The invite link itself is minted and
/// tracked by `com.codename1.analytics.invite.Invites`; the server only knows
/// whose code a link carried, so it can pay both players once the friend has
/// played.
@RestClient
public interface SocialApi {
    @GET("/api/social/invite")
    void invite(OnComplete<Response<InviteDto>> callback);

    /// Credits an invite to the player who just joined. Accounts older than a
    /// week, a player's own code and a second claim are refused.
    @POST("/api/social/claim")
    void claim(@Body InviteClaimDto claim, OnComplete<Response<RewardDto>> callback);

    @GET("/api/social/friends")
    void friends(OnComplete<Response<List<FriendDto>>> callback);

    @GET("/api/social/spotlight")
    void spotlight(OnComplete<Response<SpotlightDto>> callback);
}
