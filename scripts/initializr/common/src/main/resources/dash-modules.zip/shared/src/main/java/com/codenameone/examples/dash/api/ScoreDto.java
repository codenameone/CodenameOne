package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// One row of a level leaderboard. `replayId` fetches the run that set it, to
/// watch or to race as a ghost.
@Mapped
public record ScoreDto(int rank, String displayName, int score, int distance, int coins, int stars, String replayId) {
}
