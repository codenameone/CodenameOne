package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// One of today's quests: what it asks, how far the player is and what it pays.
@Mapped
public record QuestDto(String id, String title, int progress, int goal, int coins, int xp, boolean claimed) {
}
