package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;

/// A moderator's decision about a pack (`hide`, `restore`, `official`,
/// `unofficial`) or a file (`approve`, `reject`).
@Mapped
public record ForgeActionDto(String target, String action, String reason) {
}
