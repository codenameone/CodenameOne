package com.codenameone.examples.dash.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// The console's reports, read from the game's own records: accounts,
/// races and purchases. The daily series have one entry per day, oldest
/// first, starting at `firstDay`.
///
/// @param firstDay the start of the first day, in milliseconds
/// @param active players who ran at least one race that day
/// @param joined accounts created that day
/// @param races races finished that day
/// @param gems gems sold that day
/// @param funnel joined, played, won, paid and invited a friend
/// @param retention the share of players, in percent, seen again at least 1, 7 and 30 days after joining
/// @param trophies how many players are in each trophy band
@Mapped
public record InsightsDto(long firstDay, List<Integer> active, List<Integer> joined, List<Integer> races,
        List<Integer> gems, List<NameCountDto> funnel, List<NameCountDto> retention, List<NameCountDto> trophies) {
}
