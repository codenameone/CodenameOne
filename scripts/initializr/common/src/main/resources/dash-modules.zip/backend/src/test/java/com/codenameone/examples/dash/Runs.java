package com.codenameone.examples.dash;

import com.codenameone.examples.dash.rules.Bot;
import com.codenameone.examples.dash.rules.Catalog;
import com.codenameone.examples.dash.rules.LevelDef;
import com.codenameone.examples.dash.rules.Recorder;
import com.codenameone.examples.dash.rules.Replay;
import com.codenameone.examples.dash.rules.Run;

/// Solo runs the way the app records them: a bot plays, a [Recorder] keeps
/// every input.
public final class Runs {
    private Runs() {
    }

    public static Replay bot(LevelDef level, Catalog catalog, long seed, int skill) {
        Recorder rec = new Recorder(new Run(level, catalog, seed, 1));
        Bot bot = new Bot(seed, skill);
        while (!rec.run().over()) {
            rec.step(new int[] {bot.decide(rec.run(), 0)});
        }
        return rec.replay();
    }
}
