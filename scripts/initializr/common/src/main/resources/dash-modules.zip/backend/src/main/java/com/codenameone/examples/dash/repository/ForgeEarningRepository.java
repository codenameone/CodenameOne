package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.ForgeEarning;

@Repository(entity = ForgeEarning.class, key = String.class)
public interface ForgeEarningRepository extends CrudRepository<ForgeEarning, String> {
}
