package com.codenameone.examples.dash.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// An uploaded model or image, stored once under the SHA-256 of its bytes.
@Entity
public class ForgeAsset {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(64)")
    private String sha256 = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String owner = "";

    @Column(nullable = false, type = "VARCHAR(80)")
    private String name = "";

    @Column(nullable = false, type = "VARCHAR(8)")
    private String kind = "";

    @Column(nullable = false)
    private int bytes;

    @Column(nullable = false, type = "VARCHAR(10)")
    private String status = "";

    @Column(nullable = false, type = "VARCHAR(2000)")
    private String animations = "";

    @Column(nullable = false)
    private String data = "";

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public ForgeAsset() {
    }

    public String getSha256() {
        return sha256;
    }

    public void setSha256(String sha256) {
        this.sha256 = sha256;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public int getBytes() {
        return bytes;
    }

    public void setBytes(int bytes) {
        this.bytes = bytes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAnimations() {
        return animations;
    }

    public void setAnimations(String animations) {
        this.animations = animations;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
