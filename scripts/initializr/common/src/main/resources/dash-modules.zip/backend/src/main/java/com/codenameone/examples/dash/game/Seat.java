package com.codenameone.examples.dash.game;

import com.codename1.backend.WebSocketSession;

/// One runner of a [RaceRoom]: a player and the socket they are on now, which
/// changes when they reconnect, or one of the server's bots.
final class Seat {
    final String username;
    final String name;
    final String runner;
    final int trophies;
    WebSocketSession session;
    /// Ticks at which this seat's recent inputs arrived, for flood detection.
    final int[] recent = new int[16];
    int recentCount;
    int floods;
    int desyncs;
    /// The player left the race; their runner keeps going with no input.
    boolean left;

    Seat(String username, String name, String runner, int trophies, WebSocketSession session) {
        this.username = username;
        this.name = name;
        this.runner = runner;
        this.trophies = trophies;
        this.session = session;
    }

    boolean isBot() {
        return username.length() == 0;
    }
}
