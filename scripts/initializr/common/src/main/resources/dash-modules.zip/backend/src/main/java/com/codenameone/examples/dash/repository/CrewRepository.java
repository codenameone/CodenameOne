package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.Crew;

@Repository(entity = Crew.class, key = String.class)
public interface CrewRepository extends CrudRepository<Crew, String> {
}
