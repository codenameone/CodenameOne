package com.codenameone.examples.dash.shop;

import java.io.IOException;

/// Asks a store whether a purchase is real. The server grants nothing on the
/// app's word: a modified client can claim any purchase it likes.
public interface ReceiptValidator {
    /// The store's transaction id when `receipt` proves a purchase of `sku`, or
    /// null when it does not.
    String verify(String store, String sku, String transactionId, String receipt) throws IOException;
}
