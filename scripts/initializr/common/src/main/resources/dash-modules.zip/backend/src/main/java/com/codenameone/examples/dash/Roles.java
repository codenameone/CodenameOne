package com.codenameone.examples.dash;

/// The two roles. Every account is a PLAYER; an ADMIN also gets god mode.
public final class Roles {
    public static final String PLAYER = "PLAYER";
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
