package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.Spotlight;

@Repository(entity = Spotlight.class, key = String.class)
public interface SpotlightRepository extends CrudRepository<Spotlight, String> {
}
