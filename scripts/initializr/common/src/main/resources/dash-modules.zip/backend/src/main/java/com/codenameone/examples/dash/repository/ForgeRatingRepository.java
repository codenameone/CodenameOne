package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.ForgeRating;

@Repository(entity = ForgeRating.class, key = String.class)
public interface ForgeRatingRepository extends CrudRepository<ForgeRating, String> {
}
