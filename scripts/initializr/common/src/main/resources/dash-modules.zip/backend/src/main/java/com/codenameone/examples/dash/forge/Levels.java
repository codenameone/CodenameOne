package com.codenameone.examples.dash.forge;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.dash.rules.Catalog;
import com.codenameone.examples.dash.rules.Content;
import com.codenameone.examples.dash.rules.LevelDef;
import com.codenameone.examples.dash.rules.forge.ContentPack;
import com.codenameone.examples.dash.rules.forge.LevelRun;
import com.codenameone.examples.dash.rules.forge.Samples;
import java.io.IOException;

/// Turns the level names the API takes into something to run. A level is an
/// official id (`neon-causeway`) or `pack/level` for a published community
/// pack; a race always runs the pack's current version.
@Component
public class Levels {
    /// A level ready to run, with the id its replays carry.
    public static final class Resolved {
        public final String ref;
        public final String replayLevel;
        public final LevelDef level;
        public final Catalog catalog;

        Resolved(String ref, String replayLevel, LevelDef level, Catalog catalog) {
            this.ref = ref;
            this.replayLevel = replayLevel;
            this.level = level;
            this.catalog = catalog;
        }
    }

    private final Forge forge;

    public Levels(Forge forge) {
        this.forge = forge;
    }

    /// The level's canonical name, or null when it is not one the API takes.
    /// Cheap and lock free: it only checks the shape, [#resolve] does the rest.
    public String normalize(String ref) {
        if (ref == null || ref.length() == 0 || ref.length() > 160) {
            return null;
        }
        int slash = ref.indexOf('/');
        if (slash < 0) {
            return Content.level(ref) == null ? null : ref;
        }
        if (slash == 0 || slash == ref.length() - 1 || ref.indexOf('/', slash + 1) >= 0) {
            return null;
        }
        return ref;
    }

    public Resolved resolve(String ref) throws IOException {
        String r = normalize(ref);
        if (r == null) {
            return null;
        }
        int slash = r.indexOf('/');
        if (slash < 0) {
            return new Resolved(r, r, Content.level(r), Content.catalog());
        }
        String packId = r.substring(0, slash);
        String levelId = r.substring(slash + 1);
        ContentPack pack = forge.published(packId);
        LevelDef level = pack == null ? null : pack.level(levelId);
        if (level == null) {
            return null;
        }
        Catalog catalog = Samples.OFFICIAL_ID.equals(pack.id) ? Content.catalog() : pack.catalog();
        return new Resolved(r, LevelRun.replayLevelId(pack, levelId), level, catalog);
    }
}
