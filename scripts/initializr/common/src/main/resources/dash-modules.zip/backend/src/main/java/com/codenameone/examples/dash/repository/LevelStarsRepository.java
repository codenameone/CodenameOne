package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.LevelStars;
import java.util.List;

@Repository(entity = LevelStars.class, key = String.class)
public interface LevelStarsRepository extends CrudRepository<LevelStars, String> {
    @Query("select m from LevelStars m where m.username = :u and m.packId = :p order by m.levelId asc")
    List<LevelStars> of(@Param("u") String username, @Param("p") String packId, PageRequest page);
}
