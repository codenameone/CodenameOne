package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.ForgePack;
import java.util.List;

@Repository(entity = ForgePack.class, key = String.class)
public interface ForgePackRepository extends CrudRepository<ForgePack, String> {
    @Query("select p from ForgePack p where p.owner = :u order by p.updatedAt desc, p.id asc")
    List<ForgePack> ownedBy(@Param("u") String owner, PageRequest page);

    @Query("select p from ForgePack p where p.status = :s and p.official = :o order by p.name asc, p.id asc")
    List<ForgePack> official(@Param("s") String status, @Param("o") boolean official, PageRequest page);

    /// Published packs every file of which a moderator has approved.
    @Query("select p from ForgePack p where p.status = :s and p.pendingAssets = :pa "
            + "order by p.plays desc, p.id asc")
    List<ForgePack> popular(@Param("s") String status, @Param("pa") boolean pendingAssets, PageRequest page);

    @Query("select p from ForgePack p where p.status = :s and p.pendingAssets = :pa "
            + "order by p.updatedAt desc, p.id asc")
    List<ForgePack> newest(@Param("s") String status, @Param("pa") boolean pendingAssets, PageRequest page);

    /// What a moderator should look at: reported packs and hidden ones.
    @Query("select p from ForgePack p where p.reports > :r or p.status = :s order by p.reports desc, p.id asc")
    List<ForgePack> queue(@Param("r") int minReports, @Param("s") String status, PageRequest page);

    /// Packs still waiting on a file a moderator has not approved.
    @Query("select p from ForgePack p where p.pendingAssets = :pa order by p.id asc")
    List<ForgePack> awaitingAssets(@Param("pa") boolean pendingAssets, PageRequest page);

    long countByOwner(String owner);
}
