package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.RaceEntry;
import java.time.Instant;
import java.util.List;

@Repository(entity = RaceEntry.class, key = String.class)
public interface RaceEntryRepository extends CrudRepository<RaceEntry, String> {
    @Query("select e from RaceEntry e where e.username = :u order by e.endedAt desc, e.id asc")
    List<RaceEntry> history(@Param("u") String username, PageRequest page);

    @Query("select count(e) from RaceEntry e where e.username = :u")
    Long countFor(@Param("u") String username);

    @Query("select count(e) from RaceEntry e where e.username = :u and e.endedAt > :since")
    Long countForSince(@Param("u") String username, @Param("since") Instant since);
}
