package com.codenameone.examples.dash.admin;

import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.Value;
import com.codename1.backend.annotations.Transactional;
import com.codename1.orm.repository.PageRequest;
import com.codenameone.examples.dash.Clock;
import com.codenameone.examples.dash.Ids;
import com.codename1.appkit.server.Text;
import com.codenameone.examples.dash.account.Lists;
import com.codenameone.examples.dash.api.FlagDto;
import com.codenameone.examples.dash.domain.Flag;
import com.codenameone.examples.dash.domain.RaceRecord;
import com.codenameone.examples.dash.domain.Profile;
import com.codenameone.examples.dash.push.GamePushes;
import com.codenameone.examples.dash.repository.FlagRepository;
import com.codenameone.examples.dash.repository.RaceRecordRepository;
import com.codenameone.examples.dash.repository.ProfileRepository;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/// Flags: the queue the admin console works through.
///
/// Two sources fill it. Players report another runner after a race (one report
/// per player per race), and the server raises its own AUTO flags when it sees
/// what an honest client never does: plays it had to refuse, a flood of plays,
/// a state that diverged from the server's, or leaving race after race.
@Component
public class Flags {
    public static final String REPORT = "REPORT";
    public static final String AUTO = "AUTO";

    private final FlagRepository flags;
    private final ProfileRepository profiles;
    private final RaceRecordRepository races;
    private final GamePushes pushes;
    private final AdminChannel channel;
    private final List<String> adminNames;

    public Flags(FlagRepository flags, ProfileRepository profiles, RaceRecordRepository races,
            GamePushes pushes, AdminChannel channel, @Value("${myappname.admin.notify:}") String adminNames) {
        this.flags = flags;
        this.profiles = profiles;
        this.races = races;
        this.pushes = pushes;
        this.channel = channel;
        this.adminNames = com.codenameone.examples.dash.account.Lists.split(adminNames);
    }

    /// A player reporting another runner of a race they ran in. `accused` is
    /// the seat number, as the race's lists number them.
    @Transactional(rollbackFor = IOException.class)
    public FlagDto report(String reporter, String raceId, String accused, String reason) throws IOException {
        RaceRecord m = raceId == null ? null : races.findById(raceId);
        List<String> players = m == null ? new ArrayList<String>() : Lists.fields(m.getPlayers());
        if (!players.contains(reporter)) {
            throw new ResponseStatusException(404, "No such race");
        }
        int seat = accused == null ? -1 : players.indexOf(accused);
        if (seat < 0) {
            int n = accused != null && accused.length() == 1 ? accused.charAt(0) - '0' : -1;
            seat = n >= 0 && n < players.size() ? n : -1;
        }
        String who = seat < 0 ? "" : players.get(seat);
        if (who.length() == 0 || who.equals(reporter)) {
            throw new ResponseStatusException(400, "Pick a runner from that race to report; bots cannot be");
        }
        if (flags.countByReporterAndRaceId(reporter, raceId) > 0) {
            throw new ResponseStatusException(409, "You already reported this race");
        }
        String why = Text.required(reason, 255, "what happened");
        return raise(who, REPORT, why, raceId, reporter);
    }

    /// Something the server noticed itself. Transactional on its own because
    /// the demo seeding calls it with no transaction open; inside one (a race
    /// being recorded) it joins that one.
    @Transactional(rollbackFor = IOException.class)
    public void auto(String username, String reason, String raceId) {
        try {
            raise(username, AUTO, reason, raceId == null ? "" : raceId, "");
        } catch (IOException | RuntimeException failed) {
            System.err.println("[flags] could not flag " + username + ": " + failed);
        }
    }

    FlagDto raise(String username, String kind, String reason, String raceId, String reporter)
            throws IOException {
        Flag f = store(username, kind, reason, raceId, reporter);
        channel.flagged(username, reason);
        pushes.flagRaised(adminNames, username, reason);
        return toDto(f, profiles.findById(username));
    }

    @Transactional(rollbackFor = IOException.class)
    Flag store(String username, String kind, String reason, String raceId, String reporter)
            throws IOException {
        Flag f = new Flag();
        f.setId(Ids.next());
        f.setUsername(username);
        f.setKind(kind);
        f.setReason(reason);
        f.setRaceId(raceId);
        f.setReporter(reporter);
        f.setCreatedAt(Instant.now());
        f.setPending(true);
        flags.insert(f);
        Profile p = profiles.findById(username);
        if (p != null && !p.isFlagged()) {
            p.setFlagged(true);
            profiles.save(p);
        }
        return f;
    }

    @Transactional(rollbackFor = IOException.class)
    public FlagDto resolve(String admin, String id) {
        Flag f = flags.findById(id);
        if (f == null) {
            throw new ResponseStatusException(404, "No such flag");
        }
        f.setPending(false);
        f.setResolvedBy(admin);
        flags.save(f);
        Profile p = profiles.findById(f.getUsername());
        if (p != null && flags.countByUsernameAndPendingTrue(f.getUsername()) == 0) {
            p.setFlagged(false);
            profiles.save(p);
        }
        return toDto(f, p);
    }

    @Transactional(readOnly = true)
    public List<FlagDto> list(boolean pending) {
        List<FlagDto> out = new ArrayList<FlagDto>();
        for (Flag f : flags.inState(pending, new PageRequest(0, 200))) {
            out.add(toDto(f, profiles.findById(f.getUsername())));
        }
        return out;
    }

    @Transactional(readOnly = true)
    public List<FlagDto> of(String username) {
        List<FlagDto> out = new ArrayList<FlagDto>();
        Profile p = profiles.findById(username);
        for (Flag f : flags.of(username, new PageRequest(0, 50))) {
            out.add(toDto(f, p));
        }
        return out;
    }

    public long pendingCount() {
        return flags.countByPendingTrue();
    }

    static FlagDto toDto(Flag f, Profile p) {
        return new FlagDto(f.getId(), f.getUsername(), p == null ? f.getUsername() : p.getDisplayName(),
                f.getKind(), f.getReason(), f.getRaceId(), f.getReporter(), f.getCreatedAt().toEpochMilli(), f.isPending());
    }
}
