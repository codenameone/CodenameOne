package com.codenameone.examples.dash.progress;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.dash.Caller;
import com.codenameone.examples.dash.api.ClaimDto;
import com.codenameone.examples.dash.api.ProgressApiServer;
import com.codenameone.examples.dash.api.ProgressDto;
import com.codenameone.examples.dash.api.RewardDto;
import com.codenameone.examples.dash.social.Referrals;

@Component
public class ProgressEndpoint implements ProgressApiServer {
    private final Progression progression;
    private final Referrals referrals;

    public ProgressEndpoint(Progression progression, Referrals referrals) {
        this.progression = progression;
        this.referrals = referrals;
    }

    @Override
    public ProgressDto progress() throws Exception {
        return progression.view(Caller.name());
    }

    @Override
    public RewardDto claimQuest(ClaimDto quest) throws Exception {
        return progression.claim(Caller.name(), quest == null ? null : quest.questId());
    }

    @Override
    public RewardDto openChest() throws Exception {
        return progression.openChest(Caller.name());
    }

    @Override
    public RewardDto tutorialDone() throws Exception {
        RewardDto reward = progression.tutorialDone(Caller.name());
        // The tutorial run is a race: an invited player who finished it
        // has played, and their inviter is paid.
        referrals.played(Caller.name());
        return reward;
    }
}
