package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.PipelineHit;
import java.util.List;

@Repository(entity = PipelineHit.class, key = String.class)
public interface PipelineHitRepository extends CrudRepository<PipelineHit, String> {
    List<PipelineHit> findByPipeline(String pipeline);
}
