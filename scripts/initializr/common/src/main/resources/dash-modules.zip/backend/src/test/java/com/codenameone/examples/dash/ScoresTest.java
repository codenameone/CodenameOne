package com.codenameone.examples.dash;

import com.codename1.backend.Json;
import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codename1.backend.test.MockMvc;
import com.codenameone.examples.dash.account.Accounts;
import com.codenameone.examples.dash.rules.Content;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

import static com.codename1.backend.test.MockMvcRequestBuilders.get;
import static com.codename1.backend.test.MockMvcRequestBuilders.post;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/// Leaderboards and crews. A daily score counts only on the day's seed, and a
/// crew's board lists only its members.
@BackendTest
class ScoresTest {
    @Autowired
    private MockMvc mvc;
    @Autowired
    private Accounts accounts;

    private static String result(String replay) {
        Map<String, Object> m = new HashMap<>();
        m.put("replay", replay);
        return Json.write(m);
    }

    @Test
    void theDailyBoardTakesOnlyTheDaysSeed() throws Exception {
        String who = Api.player(accounts, "daily-runner");
        Map daily = Api.json(mvc, Api.as(get("/api/daily"), who));
        assertEquals(Content.ENDLESS, daily.get("level"));
        long seed = Long.parseLong((String) daily.get("seed"));
        // A clumsy bot, so the endless level ends soon.
        String today = Runs.bot(Content.endless(), Content.catalog(), seed, 10).encode();
        String other = Runs.bot(Content.endless(), Content.catalog(), seed + 1, 10).encode();
        Api.json(mvc, Api.as(Api.body(post("/api/forge/results"), result(other)), who));
        assertTrue(Api.list(mvc, Api.as(get("/api/scores?level=endless&board=day&limit=10"), who)).isEmpty());
        Api.json(mvc, Api.as(Api.body(post("/api/forge/results"), result(today)), who));
        List board = Api.list(mvc, Api.as(get("/api/scores?level=endless&board=day&limit=10"), who));
        assertEquals(1, board.size());
        // Anyone can watch the run behind a score.
        String id = (String) ((Map) board.get(0)).get("replayId");
        String watcher = Api.player(accounts, "daily-watcher");
        assertEquals(today, Api.json(mvc, Api.as(get("/api/races/" + id), watcher)).get("replay"));
        assertEquals(today, Api.json(mvc, Api.as(get("/api/ghost?level=endless&board=day"), watcher)).get("replay"));
    }

    @Test
    void aCrewBoardListsItsMembersOnly() throws Exception {
        String owner = Api.player(accounts, "crew-owner");
        String mate = Api.player(accounts, "crew-mate");
        String stranger = Api.player(accounts, "crew-stranger");
        Map crew = Api.json(mvc, Api.as(Api.body(post("/api/crews"), "{\"name\":\"Night Owls\"}"), owner));
        String code = (String) crew.get("code");
        Map joined = Api.json(mvc, Api.as(post("/api/crews/" + code + "/join"), mate));
        assertEquals(2, ((List) joined.get("members")).size());
        for (String who : new String[] {owner, mate, stranger}) {
            String run = Runs.bot(Content.tutorial(), Content.catalog(), who.length(), 80).encode();
            Api.json(mvc, Api.as(Api.body(post("/api/forge/results"), result(run)), who));
        }
        List board = Api.list(mvc, Api.as(get("/api/scores?level=first-steps&board=crew%3A" + code + "&limit=50"), owner));
        assertEquals(2, board.size());
        List all = Api.list(mvc, Api.as(get("/api/scores?level=first-steps&board=all&limit=50"), owner));
        assertTrue(all.size() >= 3);
        assertEquals(1, Api.list(mvc, Api.as(get("/api/crews"), mate)).size());
        Api.json(mvc, Api.as(post("/api/crews/" + code + "/leave"), mate));
        assertEquals(0, Api.list(mvc, Api.as(get("/api/crews"), mate)).size());
        assertEquals(404, Api.statusOf(mvc, Api.as(post("/api/crews/NOPE/join"), stranger)));
    }
}
