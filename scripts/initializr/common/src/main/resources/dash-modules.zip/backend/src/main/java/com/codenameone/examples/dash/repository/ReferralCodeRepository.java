package com.codenameone.examples.dash.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.dash.domain.ReferralCode;
import java.util.List;

@Repository(entity = ReferralCode.class, key = String.class)
public interface ReferralCodeRepository extends CrudRepository<ReferralCode, String> {
    List<ReferralCode> findByUsername(String username);
}
