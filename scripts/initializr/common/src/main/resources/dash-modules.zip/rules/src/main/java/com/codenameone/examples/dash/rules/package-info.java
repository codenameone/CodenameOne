/// The game's rules: a deterministic runner simulation shared by the app, the
/// server, the level editor and the replay viewer. Nothing here may touch a clock,
/// a float, the UI or the network.
///
/// The world is one abstract space -- lane, height and distance -- and the 2D and
/// 3D views are two renderings of it. A level that swings its camera from a side
/// view into a chase view mid-run therefore changes nothing about how it plays.
package com.codenameone.examples.dash.rules;
