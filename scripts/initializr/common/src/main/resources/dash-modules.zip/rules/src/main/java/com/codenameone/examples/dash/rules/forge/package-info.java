/// The Forge's content model: a pack of levels with their own obstacles,
/// pickups and uploaded art, how it is written as JSON, the checks every pack
/// passes before it is published, and how a submitted run is verified.
package com.codenameone.examples.dash.rules.forge;
