package com.codenameone.examples.dash.rules;

/// One obstacle or pickup put on the track by a level or a chunk: a distance, a
/// lane and the id of its definition in the [Catalog].
public final class Placement {
    /// Spans every lane. The only kind of placement that reads well in
    /// [ViewMode#SIDE_2D], where lanes collapse into one.
    public static final int ALL_LANES = -1;

    public final int z;
    public final int lane;
    public final String defId;

    public Placement(int z, String defId, int lane) {
        this.z = z;
        this.lane = lane;
        this.defId = defId;
    }
}
