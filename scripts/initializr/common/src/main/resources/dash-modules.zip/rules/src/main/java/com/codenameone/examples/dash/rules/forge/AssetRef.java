package com.codenameone.examples.dash.rules.forge;

/// A file a pack uses that is not part of the app: an uploaded glTF character or
/// a portrait. It is named by the SHA-256 of its bytes, so a pack's hash covers the
/// exact files it was published with, and the same file uploaded twice is stored once.
public final class AssetRef {
    public static final String MODEL = "model";
    public static final String IMAGE = "image";

    /// Lower-case hex SHA-256 of the bytes.
    public String sha256 = "";
    public String kind = MODEL;
    public String name = "";
    public int bytes;

    /// How a level's definitions refer to it, in their `art` field.
    public String ref() {
        return "asset:" + sha256;
    }
}
