package com.codenameone.examples.dash.rules;

/// How the client draws a stretch of track. The simulation never reads it: the
/// same run plays out identically whatever the camera does.
public enum ViewMode {
    /// A flat side-on view, the "faux 2D" a level can open with. Lanes collapse,
    /// so a stretch drawn this way should only hold placements that span every
    /// lane ([Validator] warns otherwise).
    SIDE_2D,
    /// Behind and above the runner, in perspective.
    CHASE_3D,
    /// Straight down on the lanes.
    TOP_DOWN
}
