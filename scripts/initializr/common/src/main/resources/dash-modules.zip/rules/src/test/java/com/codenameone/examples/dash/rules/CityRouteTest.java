package com.codenameone.examples.dash.rules;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/// A route becomes the same level wherever it is built, and a strong runner
/// can finish it.
class CityRouteTest {
    static CityRoute harbour() {
        return new CityRoute("Old Harbour")
                .leg(420, CityRoute.STRAIGHT, "Quay Street")
                .leg(310, CityRoute.LEFT, "Rope Walk")
                .leg(30, CityRoute.RIGHT, "Tide Lane")
                .leg(650, CityRoute.RIGHT, "Lantern Avenue")
                .leg(280, CityRoute.STRAIGHT, "")
                .leg(510, CityRoute.LEFT, "Market Square")
                .leg(900, CityRoute.RIGHT, "Ferry Road");
    }

    @Test
    void theSpecRoundTripsToTheSameLevel() {
        CityRoute r = harbour();
        CityRoute back = CityRoute.decode(r.encode());
        assertEquals(r.encode(), back.encode());
        assertEquals(r.id(), back.id());
        LevelDef a = r.level();
        LevelDef b = back.level();
        assertEquals(a.id, b.id);
        assertEquals(a.contentHash(), b.contentHash());
        assertEquals(a.dialog.size(), b.dialog.size());
        assertTrue(a.id.startsWith(CityRoute.ID_PREFIX));
    }

    @Test
    void aLongRouteRunsToScaleAndAShortOneIsStretched() {
        assertEquals(CityRoute.MAX_METRES * Track.UNIT, harbour().level().length);
        LevelDef shortRun = new CityRoute("Corner").leg(120, CityRoute.STRAIGHT, "A").level();
        assertEquals(CityRoute.MIN_METRES * Track.UNIT, shortRun.length);
    }

    @Test
    void cornersAreCalledByStreetAndBlockTheOtherLanes() {
        LevelDef l = harbour().level();
        boolean left = false;
        boolean right = false;
        for (DialogLine line : l.dialog) {
            left |= line.text.equals("Left onto Rope Walk!") && line.hint == Input.LEFT;
            right |= line.text.startsWith("Right onto ") && line.hint == Input.RIGHT;
        }
        assertTrue(left, "the left turn is called");
        assertTrue(right, "a right turn is called");
        // Tide Lane is 30 m between two turns: the turn out of it is passed,
        // not cornered a few metres after the turn into it.
        for (DialogLine line : l.dialog) {
            assertTrue(!line.text.contains("Lantern Avenue"), "a corner every few metres");
        }
        // Dialog runs in order, so the client can walk it front to back.
        for (int i = 1; i < l.dialog.size(); i++) {
            assertTrue(l.dialog.get(i).at >= l.dialog.get(i - 1).at, "dialog out of order");
        }
    }

    @Test
    void aStrongRunnerFinishesIt() {
        assertTrue(Validator.beatable(harbour().level(), Content.catalog()));
        assertTrue(!Validator.hasErrors(Validator.check(harbour().level(), Content.catalog())));
    }

    @Test
    void anotherRouteIsAnotherLevel() {
        CityRoute other = new CityRoute("Old Harbour").leg(420, CityRoute.STRAIGHT, "Quay Street")
                .leg(310, CityRoute.RIGHT, "Rope Walk");
        assertNotEquals(harbour().id(), other.id());
    }

    @Test
    void namesLoseTheSeparatorsAndJunkIsRefused() {
        CityRoute r = new CityRoute("A~B|C").leg(500, CityRoute.STRAIGHT, "One, Two");
        assertEquals("ABC", r.place);
        assertEquals("One Two", r.legs().get(0).street);
        assertThrows(IllegalArgumentException.class, () -> CityRoute.decode("nonsense"));
        assertThrows(IllegalArgumentException.class, () -> CityRoute.decode("1~x~ten,0,a"));
        assertThrows(IllegalArgumentException.class, () -> CityRoute.decode("1~x~10,7,a"));
        assertThrows(IllegalArgumentException.class, () -> CityRoute.decode(null));
    }

    /// The developer guide's two examples, compiled and run here.
    @Test
    void theGuidesRoutesBuildLevels() {
        CityRoute route = new CityRoute("Old Harbour")
                .leg(420, CityRoute.STRAIGHT, "Quay Street")
                .leg(310, CityRoute.LEFT, "Rope Walk");
        LevelDef level = route.level();
        assertEquals(level.id, route.level().id);
        CityRoute withPlace = new CityRoute("Old Harbour")
                .leg(420, CityRoute.STRAIGHT, "Quay Street")
                .landmark(180, CityRoute.MUSEUM, "Maritime Museum");
        assertTrue(!withPlace.id().equals(new CityRoute("Old Harbour")
                .leg(420, CityRoute.STRAIGHT, "Quay Street").id()));
    }

    @Test
    void landmarksRoundTripAndShowWhereTheyStand() {
        CityRoute r = new CityRoute("City of London").leg(500, CityRoute.STRAIGHT, "Cannon Street")
                .leg(400, CityRoute.LEFT, "Moorgate").leg(300, CityRoute.RIGHT, "London Wall")
                .landmark(250, CityRoute.WORSHIP, "St Paul's Cathedral")
                .landmark(700, CityRoute.MUSEUM, "Bank of England Museum");
        CityRoute back = CityRoute.decode(r.encode());
        assertEquals(r.encode(), back.encode());
        assertEquals(2, back.landmarks().size());
        assertEquals("Moorgate", back.streetAt(600));
        assertEquals("Cannon Street", back.streetAt(10));
        int streets = 0;
        int marks = 0;
        int last = -1;
        for (CityRoute.Sign s : back.signs()) {
            assertTrue(s.metres >= last, "signs in order");
            last = s.metres;
            if (s.kind < 0) {
                streets++;
            } else {
                marks++;
            }
        }
        assertEquals(3, streets);
        assertEquals(2, marks);
        boolean called = false;
        for (DialogLine l : back.level().dialog) {
            called |= l.text.indexOf("St Paul's Cathedral") >= 0;
        }
        assertTrue(called, "the coach names a landmark");
        // A landmark changes the route, so it names another level.
        assertTrue(!r.id().equals(new CityRoute("City of London").leg(500, CityRoute.STRAIGHT, "Cannon Street")
                .leg(400, CityRoute.LEFT, "Moorgate").leg(300, CityRoute.RIGHT, "London Wall").id()));
        assertThrows(IllegalArgumentException.class,
                () -> CityRoute.decode("1~x~@10,0,Tower~100,0,Street"));
        assertThrows(IllegalArgumentException.class, () -> CityRoute.decode("1~x~100,0,Street~@10,9,Tower"));
    }
}
