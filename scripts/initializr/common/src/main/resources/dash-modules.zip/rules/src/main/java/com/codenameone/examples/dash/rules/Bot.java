package com.codenameone.examples.dash.rules;

/// A runner that plays by looking ahead. Used for ghosts when nobody else is
/// online, for the editor's "can this be beaten?" check and for the soak tests.
///
/// It has its own random stream, seeded apart from the run's, so a bot's lapses
/// never change the track; what it decides is recorded as input like a player's.
public final class Bot {
    private final Rng rng;
    /// 0 to 100: how often it reacts in time, and how greedily it chases coins.
    private final int skill;
    /// Ticks between deciding and the input taking effect: 0 when the bot
    /// steps the run itself, the race's input delay when its inputs go
    /// through a server first. It sees everything that much earlier.
    private final int lead;
    private int cooldown;

    public Bot(long seed, int skill) {
        this(seed, skill, 0);
    }

    public Bot(long seed, int skill, int lead) {
        this.rng = new Rng(seed * 31 + 7);
        this.skill = FixedMath.clamp(skill, 0, 100);
        this.lead = Math.max(0, lead);
    }

    public int decide(Run run, int who) {
        Runner r = run.runner(who);
        if (!r.running()) {
            return Input.NONE;
        }
        if (cooldown > 0) {
            cooldown--;
            return Input.NONE;
        }
        int perTick = Math.max(1, r.speed / Run.TICKS_PER_SECOND);
        int look = perTick * (40 + lead);
        Track t = run.track();
        Track.Entry threat = nearestObstacle(t, r, r.lane, look);
        if (threat != null) {
            int dist = threat.z - (r.z + Runner.HALF_DEPTH);
            if (rng.nextInt(100) >= skill + 20) {
                // A lapse: it sees the obstacle a few ticks late.
                cooldown = 3;
                return Input.NONE;
            }
            int bits = respond(run, r, threat, dist, perTick, look);
            if (bits != Input.NONE) {
                cooldown = bits == Input.JUMP ? 6 : 2;
            }
            return bits;
        }
        if (rng.nextInt(100) < skill / 2) {
            return chaseCoins(run, r, look);
        }
        return Input.NONE;
    }

    private int respond(Run run, Runner r, Track.Entry e, int dist, int perTick, int look) {
        Clearance c = e.obstacle.clearance;
        if (c == Clearance.DODGE || (e.obstacle.lethal && !e.spansAllLanes() && dist > perTick * (12 + lead))) {
            int lanes = run.level().lanes;
            int best = -1;
            for (int d = 1; d < lanes && best < 0; d++) {
                for (int s = -1; s <= 1; s += 2) {
                    int l = r.lane + s * d;
                    if (l >= 0 && l < lanes && nearestObstacle(run.track(), r, l, look) == null) {
                        best = l;
                        break;
                    }
                }
            }
            if (best >= 0) {
                return best < r.lane ? Input.LEFT : Input.RIGHT;
            }
            if (c == Clearance.DODGE) {
                return Input.NONE;
            }
        }
        if (c == Clearance.JUMP && dist <= perTick * (14 + lead) && r.y == 0) {
            return Input.JUMP;
        }
        if (c == Clearance.SLIDE && dist <= perTick * (10 + lead) && !r.sliding()) {
            return Input.SLIDE;
        }
        return Input.NONE;
    }

    private static Track.Entry nearestObstacle(Track t, Runner r, int lane, int look) {
        for (int i = r.cursor; i < t.size(); i++) {
            Track.Entry e = t.get(i);
            if (e.obstacle == null || e.z + e.depth < r.z - Runner.HALF_DEPTH) {
                continue;
            }
            if (e.z > r.z + look) {
                break;
            }
            if (e.spansAllLanes() || e.lane == lane) {
                return e;
            }
        }
        return null;
    }

    private static int chaseCoins(Run run, Runner r, int look) {
        Track t = run.track();
        for (int i = r.cursor; i < t.size(); i++) {
            Track.Entry e = t.get(i);
            if (e.z < r.z || e.pickup == null || e.spansAllLanes()) {
                continue;
            }
            if (e.z > r.z + look) {
                break;
            }
            if (e.lane != r.lane && nearestObstacle(t, r, e.lane, look) == null) {
                return e.lane < r.lane ? Input.LEFT : Input.RIGHT;
            }
            return Input.NONE;
        }
        return Input.NONE;
    }
}
