package com.codenameone.examples.dash.rules;

/// What a runner has to do to get past an obstacle.
public enum Clearance {
    /// Be airborne above the obstacle's height while overlapping it.
    JUMP,
    /// Be sliding, on the ground, while overlapping it.
    SLIDE,
    /// Be in another lane: nothing gets past this one.
    DODGE
}
