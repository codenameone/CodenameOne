package com.codenameone.examples.dash.rules;

import java.util.ArrayList;
import java.util.List;

/// A stretch of track the endless part of a level is assembled from. The track
/// picks chunks at random among those whose `minDifficulty` the current distance
/// has reached, and may mirror one across the lanes.
///
/// Placements are relative to the chunk's start and kept sorted by distance, so
/// the track can append them as they are.
public final class Chunk {
    public final String id;
    public final int length;
    public final int minDifficulty;
    private final List<Placement> placements = new ArrayList<Placement>();

    public Chunk(String id, int length, int minDifficulty) {
        this.id = id;
        this.length = length < Track.UNIT ? Track.UNIT : length;
        this.minDifficulty = minDifficulty;
    }

    public Chunk add(int z, String defId, int lane) {
        int i = placements.size();
        while (i > 0 && placements.get(i - 1).z > z) {
            i--;
        }
        placements.add(i, new Placement(z, defId, lane));
        return this;
    }

    public List<Placement> placements() {
        return placements;
    }
}
