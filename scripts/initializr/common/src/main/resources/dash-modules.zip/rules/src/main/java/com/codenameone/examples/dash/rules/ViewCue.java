package com.codenameone.examples.dash.rules;

/// From distance `at` onwards the camera moves to `mode`, blending over
/// `blendMillis` of distance travelled. Blending by distance rather than by time
/// keeps the transition at the same spot on the track at every speed.
public final class ViewCue {
    public final int at;
    public final ViewMode mode;
    public final int blendMillis;

    public ViewCue(int at, ViewMode mode, int blendMillis) {
        this.at = at;
        this.mode = mode;
        this.blendMillis = blendMillis < 0 ? 0 : blendMillis;
    }
}
