package com.codenameone.examples.dash.rules;

import java.util.ArrayList;
import java.util.List;

/// String helpers every runtime agrees on. `String.split` takes a regular
/// expression, which the device class library does not carry.
public final class Text {
    private Text() {
    }

    public static List<String> split(String s, char sep) {
        List<String> out = new ArrayList<String>();
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == sep) {
                out.add(s.substring(start, i));
                start = i + 1;
            }
        }
        out.add(s.substring(start));
        return out;
    }

    /// An unsigned 64-bit hex value, as `Long.toHexString` writes it.
    public static long parseHex(String s) {
        if (s.length() == 0 || s.length() > 16) {
            throw new IllegalArgumentException("hex " + s);
        }
        long v = 0;
        for (int i = 0; i < s.length(); i++) {
            int d = Character.digit(s.charAt(i), 16);
            if (d < 0) {
                throw new IllegalArgumentException("hex " + s);
            }
            v = (v << 4) | d;
        }
        return v;
    }
}
