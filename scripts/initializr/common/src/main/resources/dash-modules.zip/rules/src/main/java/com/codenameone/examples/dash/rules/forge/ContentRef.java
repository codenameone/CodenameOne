package com.codenameone.examples.dash.rules.forge;

/// The name of a level in a published pack version: `pack@hash#level`. A
/// replay and a level result carry it, so the server and a replay viewer load the
/// exact content the run was played on.
public final class ContentRef {
    public final String pack;
    public final String hash;
    public final String level;

    public ContentRef(String pack, String hash, String level) {
        this.pack = pack;
        this.hash = hash;
        this.level = level;
    }

    public static ContentRef parse(String s) {
        int at = s == null ? -1 : s.indexOf('@');
        int hashMark = s == null ? -1 : s.indexOf('#', at + 1);
        if (at <= 0 || hashMark <= at + 1 || hashMark == s.length() - 1) {
            throw new IllegalArgumentException("not a content reference");
        }
        return new ContentRef(s.substring(0, at), s.substring(at + 1, hashMark), s.substring(hashMark + 1));
    }

    @Override
    public String toString() {
        return pack + "@" + hash + "#" + level;
    }
}
