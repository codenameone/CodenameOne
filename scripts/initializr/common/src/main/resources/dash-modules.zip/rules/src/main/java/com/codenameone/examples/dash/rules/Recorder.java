package com.codenameone.examples.dash.rules;

/// Steps a [Run] and records what it was given, so the run can be submitted as a
/// [Replay] when it ends.
public final class Recorder {
    private final Run run;
    private final Replay replay;

    public Recorder(Run run) {
        this(run, run.level().id);
    }

    /// Records under `levelId`, which for a community level is its content
    /// reference (`pack@hash#level`) rather than the bare id the level carries.
    public Recorder(Run run, String levelId) {
        this.run = run;
        this.replay = new Replay(levelId, run.level().contentHash(), run.seed(), run.runnerCount());
    }

    public void step(int[] inputs) {
        if (run.over()) {
            return;
        }
        if (inputs != null) {
            for (int i = 0; i < inputs.length && i < run.runnerCount(); i++) {
                replay.record(run.tick(), i, inputs[i] & Input.ALL);
            }
        }
        run.step(inputs);
    }

    public Run run() {
        return run;
    }

    public Replay replay() {
        return replay;
    }
}
