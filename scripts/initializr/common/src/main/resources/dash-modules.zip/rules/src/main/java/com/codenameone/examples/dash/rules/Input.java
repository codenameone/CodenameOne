package com.codenameone.examples.dash.rules;

/// The bits a runner's input for one tick is made of. Each is an edge -- the
/// moment the player swiped or pressed -- not a held key, so a replay records only
/// the ticks on which something happened.
public final class Input {
    public static final int NONE = 0;
    public static final int LEFT = 1;
    public static final int RIGHT = 2;
    public static final int JUMP = 4;
    public static final int SLIDE = 8;

    /// Every bit an input may carry; anything else is refused by [Replay#decode]
    /// and by the server.
    public static final int ALL = LEFT | RIGHT | JUMP | SLIDE;

    private Input() {
    }

    public static boolean valid(int bits) {
        return (bits & ~ALL) == 0;
    }
}
