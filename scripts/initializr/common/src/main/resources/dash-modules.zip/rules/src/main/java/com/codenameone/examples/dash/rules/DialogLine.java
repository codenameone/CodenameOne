package com.codenameone.examples.dash.rules;

/// A line the client shows when the runner reaches distance `at`. A `hint` names
/// the move it teaches (an [Input] bit, or 0) so the tutorial can draw the swipe.
public final class DialogLine {
    public final int at;
    public final String speaker;
    public final String text;
    public final int hint;

    public DialogLine(int at, String speaker, String text, int hint) {
        this.at = at;
        this.speaker = speaker;
        this.text = text;
        this.hint = hint;
    }
}
