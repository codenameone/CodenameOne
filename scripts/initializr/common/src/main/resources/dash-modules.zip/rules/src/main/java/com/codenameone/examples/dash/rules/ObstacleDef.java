package com.codenameone.examples.dash.rules;

/// A kind of obstacle. Content, not code: the editor creates these from data and
/// a fork re-skins one by giving its id a different model or sprite.
///
/// A non-lethal obstacle makes the runner stumble -- lose a third of their speed
/// -- and two stumbles within [Runner#STUMBLE_WINDOW] ticks end the run.
public final class ObstacleDef {
    public final String id;
    public final Clearance clearance;
    /// Length along the track, in millimetres.
    public final int depth;
    /// For [Clearance#JUMP]: how high the runner's feet must be, in millimetres.
    public final int height;
    public final boolean lethal;

    public ObstacleDef(String id, Clearance clearance, int depth, int height, boolean lethal) {
        this.id = id;
        this.clearance = clearance;
        this.depth = depth < 1 ? 1 : depth;
        this.height = height < 0 ? 0 : height;
        this.lethal = lethal;
    }
}
