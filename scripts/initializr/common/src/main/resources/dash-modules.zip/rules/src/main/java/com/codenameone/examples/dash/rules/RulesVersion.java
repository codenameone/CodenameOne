package com.codenameone.examples.dash.rules;

/// Identifies the rules a replay was recorded under. Bump it whenever a change to
/// [Run], [Runner] or [Content] would make an old replay play out differently;
/// the server refuses a score whose replay names another version, and the replay
/// viewer warns when it re-runs one under newer rules.
public final class RulesVersion {
    public static final String ID = "1";

    private RulesVersion() {
    }
}
