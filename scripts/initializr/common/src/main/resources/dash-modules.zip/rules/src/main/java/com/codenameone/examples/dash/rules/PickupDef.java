package com.codenameone.examples.dash.rules;

/// A kind of pickup.
public final class PickupDef {
    public final String id;
    public final PickupKind kind;
    public final int points;
    /// For timed kinds, how long the effect lasts in ticks.
    public final int ticks;

    public PickupDef(String id, PickupKind kind, int points, int ticks) {
        this.id = id;
        this.kind = kind;
        this.points = points;
        this.ticks = ticks < 0 ? 0 : ticks;
    }
}
