package com.codenameone.examples.dash.rules;

/// What finishes a level. A run that has not finished ends only when the runner
/// falls.
public enum Goal {
    /// Reach the level's length.
    DISTANCE,
    /// Collect `goalValue` coins.
    COINS,
    /// Stay up for `goalValue` ticks.
    SURVIVE,
    /// Nothing finishes it: run until you fall, for the score.
    ENDLESS
}
