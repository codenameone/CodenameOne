package com.codenameone.examples.dash.rules;

/// What collecting a pickup does.
public enum PickupKind {
    /// Counts toward coins and adds its points.
    COIN,
    /// Adds its points only.
    GEM,
    /// Pulls every pickup within reach in from any lane, for its duration.
    MAGNET,
    /// Absorbs the next hit, until it is used or its duration runs out.
    SHIELD,
    /// Half again as fast and untouchable, for its duration.
    BOOST
}
