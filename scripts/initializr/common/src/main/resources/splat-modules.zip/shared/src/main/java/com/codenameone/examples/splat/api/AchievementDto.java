package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// A lifetime goal. Unlocking one pays gems once.
@Mapped
public record AchievementDto(String id, String title, String detail, int progress, int goal, boolean unlocked) {
}
