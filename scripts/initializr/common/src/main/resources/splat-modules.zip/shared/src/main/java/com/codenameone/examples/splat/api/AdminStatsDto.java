package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// The numbers at the top of the admin console.
@Mapped
public record AdminStatsDto(int players, int online, int liveRaces, int racesToday, int openFlags, int suspended, int purchasesToday, int gemsSoldToday) {
}
