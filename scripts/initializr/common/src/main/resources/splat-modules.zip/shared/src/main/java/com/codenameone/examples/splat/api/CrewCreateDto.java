package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// Creates a crew with the caller as its owner.
@Mapped
public record CrewCreateDto(String name) {
}
