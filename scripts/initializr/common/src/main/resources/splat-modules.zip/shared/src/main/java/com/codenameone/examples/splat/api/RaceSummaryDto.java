package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// One finished race from one player's side.
@Mapped
public record RaceSummaryDto(String id, String level, int place, int runners, int score, int trophyChange, long endedAt, int ticks) {
}
