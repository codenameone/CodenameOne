package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// A player whose invites brought others in.
@Mapped
public record InviterDto(String displayName, int joined, int played) {
}
