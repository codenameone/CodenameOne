package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// Claiming the reward for a watched rewarded ad.
@Mapped
public record AdRewardDto(String nonce) {
}
