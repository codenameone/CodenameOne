package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// The quest whose reward is being collected.
@Mapped
public record ClaimDto(String questId) {
}
