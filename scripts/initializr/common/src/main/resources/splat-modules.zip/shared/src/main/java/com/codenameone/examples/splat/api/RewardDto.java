package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// What the player just got: the client turns it into a reward popup, and a
/// level-up or a new achievement into a celebration of its own.
@Mapped
public record RewardDto(String title, int coins, int gems, int xp, int chests, int level, boolean levelUp,
        List<String> unlocked) {
}
