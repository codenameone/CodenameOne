package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// Equips an owned outfit; the shop sells them.
@Mapped
public record EquipDto(String outfit) {
}
