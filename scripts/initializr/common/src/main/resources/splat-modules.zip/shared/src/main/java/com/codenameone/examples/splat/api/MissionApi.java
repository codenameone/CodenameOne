package com.codenameone.examples.splat.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;
import java.util.List;

/// Player-built missions: publish one, list your own and your friends', and
/// fetch one by its code to play or edit. A mission is raced online as the
/// level `m-<code>:<MODE>`.
@RestClient
public interface MissionApi {
    @POST("/api/missions")
    void publishMission(@Body MissionDto mission, OnComplete<Response<MissionDto>> callback);

    @GET("/api/missions")
    void missions(OnComplete<Response<List<MissionDto>>> callback);

    @GET("/api/missions/{code}")
    void mission(@Path("code") String code, OnComplete<Response<MissionDto>> callback);
}
