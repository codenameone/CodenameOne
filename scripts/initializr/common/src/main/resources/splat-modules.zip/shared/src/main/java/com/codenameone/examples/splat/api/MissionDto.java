package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// A player-built mission as the server stores it. `json` is the mission
/// itself (`Mission.toJson`); a listing leaves it empty, and a publish sends
/// only `json` -- the server assigns the code and fills in the rest.
@Mapped
public record MissionDto(String code, String name, String mode, String owner, String ownerName, int plays,
        long createdAt, String json) {
}
