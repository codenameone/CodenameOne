package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// Someone who joined through the player's invite. `state` is `joined`
/// until their first race, then `played`; `rewarded` says whether that
/// race paid the inviter.
@Mapped
public record FriendDto(String displayName, int trophies, String state, boolean rewarded, long joinedAt) {
}
