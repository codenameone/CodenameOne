package com.codenameone.examples.splat.api;

import com.codename1.annotations.Mapped;

/// A named number: a step of a funnel, a retention day, a trophy band.
@Mapped
public record NameCountDto(String name, int count) {
}
