package com.codenameone.examples.splat.rules;

/// One piece of cover: an axis-aligned box standing on the ground.
///
/// Every solid thing on a field is one of these -- an inflatable bunker, a hay
/// bale, the porta-potty, the minivan somebody's dad parked on the field. The
/// `kind` is only a name for the renderer to pick a model by; the rules treat all
/// boxes alike. Coordinates are millimetres, `y` is up.
public final class Box {
    public final String kind;
    public final int x0;
    public final int z0;
    public final int x1;
    public final int z1;
    public final int height;

    public Box(String kind, int x0, int z0, int x1, int z1, int height) {
        this.kind = kind;
        this.x0 = Math.min(x0, x1);
        this.z0 = Math.min(z0, z1);
        this.x1 = Math.max(x0, x1);
        this.z1 = Math.max(z0, z1);
        this.height = height;
    }

    public boolean contains(int x, int y, int z) {
        return x >= x0 && x <= x1 && z >= z0 && z <= z1 && y >= 0 && y <= height;
    }

    /// True when a circle of `radius` at `(x, z)` overlaps the footprint.
    public boolean overlaps(int x, int z, int radius) {
        return x + radius > x0 && x - radius < x1 && z + radius > z0 && z - radius < z1;
    }

    void hash(Hash h) {
        h.add(kind).add(x0).add(z0).add(x1).add(z1).add(height);
    }
}
