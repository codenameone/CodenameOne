package com.codenameone.examples.splat.rules;

/// The only source of randomness a match may use: SplitMix64, seeded by the server.
///
/// `java.util.Random` is not used on purpose. Its algorithm is specified, but the
/// rules have to produce the same numbers on the JVM, on ParparVM and in the browser,
/// and owning the eight lines that do it is cheaper than proving every port agrees.
public final class Rng {
    private long state;

    public Rng(long seed) {
        state = seed;
    }

    public long nextLong() {
        state += 0x9E3779B97F4A7C15L;
        long z = state;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    /// A value in `[0, bound)`; `bound` must be positive.
    public int nextInt(int bound) {
        if (bound <= 0) {
            throw new IllegalArgumentException("bound " + bound);
        }
        long r = nextLong() >>> 1;
        return (int) (r % bound);
    }

    public long state() {
        return state;
    }
}
