package com.codenameone.examples.splat.rules;

import java.util.ArrayList;
import java.util.List;

/// String helpers. `String.split` is a regex on the JDK and absent from the
/// device's class library, so the rules split by hand.
public final class Text {
    private Text() {
    }

    /// Splits on single spaces, dropping empty pieces.
    public static List<String> words(String s) {
        List<String> out = new ArrayList<String>();
        int start = -1;
        for (int i = 0; i <= s.length(); i++) {
            boolean sep = i == s.length() || s.charAt(i) == ' ';
            if (sep) {
                if (start >= 0) {
                    out.add(s.substring(start, i));
                    start = -1;
                }
            } else if (start < 0) {
                start = i;
            }
        }
        return out;
    }

    /// Exactly `count` integers separated by spaces.
    public static int[] ints(String s, int count) {
        List<String> w = words(s);
        if (w.size() != count) {
            throw new IllegalArgumentException("expected " + count + " values: " + s);
        }
        int[] out = new int[count];
        for (int i = 0; i < count; i++) {
            out[i] = Integer.parseInt(w.get(i));
        }
        return out;
    }

    /// The pieces of `s` between occurrences of `sep`, empty ones kept.
    public static List<String> split(String s, char sep) {
        List<String> out = new ArrayList<String>();
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == sep) {
                out.add(s.substring(start, i));
                start = i + 1;
            }
        }
        out.add(s.substring(start));
        return out;
    }
}
