package com.codenameone.examples.splat.rules;

/// The version of the simulation. A client and a server only play together when
/// they agree on it, and a replay records it. Bump it with any change that moves a
/// number in [Catalog] or a line of [Match], then regenerate the golden replays
/// (`-Dmyappname.regolden=true`).
public final class RulesVersion {
    public static final int ID = 1;

    private RulesVersion() {
    }
}
