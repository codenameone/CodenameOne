package com.codenameone.examples.splat.rules;

/// One place on the roster, fixed for the whole match. A bot's inputs are made
/// inside [Match#step], so a replay never records them.
public final class Slot {
    public final String name;
    public final int team;
    public final String marker;
    /// 0 for a human; otherwise the bot's skill, 1 (Uncle Dave) to 100.
    public final int botSkill;

    public Slot(String name, int team, String marker, int botSkill) {
        if (team != 0 && team != 1) {
            throw new IllegalArgumentException("team " + team);
        }
        Catalog.marker(marker);
        this.name = name;
        this.team = team;
        this.marker = marker;
        this.botSkill = FixedMath.clamp(botSkill, 0, 100);
    }

    public boolean bot() {
        return botSkill > 0;
    }

    /// `team marker skill name`; the name is last because it may hold spaces.
    public String encode() {
        return team + " " + marker + " " + botSkill + " " + name;
    }

    public static Slot decode(String s) {
        int a = s.indexOf(' ');
        int b = s.indexOf(' ', a + 1);
        int c = s.indexOf(' ', b + 1);
        return new Slot(s.substring(c + 1), Integer.parseInt(s.substring(0, a)), s.substring(a + 1, b),
                Integer.parseInt(s.substring(b + 1, c)));
    }
}
