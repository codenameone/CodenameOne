package com.codenameone.examples.splat.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// When a pipeline last acted on a player, so it waits its cool-down before
/// acting on them again. The id is the pipeline id, a colon and the username.
@Entity
public class PipelineHit {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(230)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String pipeline = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false)
    private Instant hitAt = Instant.EPOCH;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPipeline() {
        return pipeline;
    }

    public void setPipeline(String pipeline) {
        this.pipeline = pipeline;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Instant getHitAt() {
        return hitAt;
    }

    public void setHitAt(Instant hitAt) {
        this.hitAt = hitAt;
    }
}
