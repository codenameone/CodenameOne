package com.codenameone.examples.splat.mission;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.splat.api.MissionApiServer;
import com.codenameone.examples.splat.api.MissionDto;
import java.util.List;

/// `/api/missions`: signed-in players only, like the rest of `/api/**`.
@Component
public class MissionEndpoint implements MissionApiServer {
    private final Missions missions;

    public MissionEndpoint(Missions missions) {
        this.missions = missions;
    }

    @Override
    public MissionDto publishMission(MissionDto mission) throws Exception {
        return missions.publish(Caller.name(), mission == null ? null : mission.json());
    }

    @Override
    public List<MissionDto> missions() throws Exception {
        return missions.list(Caller.name());
    }

    @Override
    public MissionDto mission(String code) throws Exception {
        return missions.get(code);
    }
}
