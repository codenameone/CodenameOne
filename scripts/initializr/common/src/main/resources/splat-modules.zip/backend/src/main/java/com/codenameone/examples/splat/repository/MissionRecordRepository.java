package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.MissionRecord;
import java.util.List;

@Repository(entity = MissionRecord.class, key = String.class)
public interface MissionRecordRepository extends CrudRepository<MissionRecord, String> {
    @Query("select m from MissionRecord m where m.owner = :o order by m.createdAt desc")
    List<MissionRecord> byOwner(@Param("o") String owner, PageRequest page);
}
