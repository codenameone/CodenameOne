package com.codenameone.examples.splat.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A crew: friends who race together. Joined by its code, which is also how it
/// is shared.
@Entity
public class Crew {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(16)")
    private String code = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String name = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String owner = "";

    @Column(nullable = false)
    private int members;

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public Crew() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getMembers() {
        return members;
    }

    public void setMembers(int members) {
        this.members = members;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
