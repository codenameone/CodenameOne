package com.codenameone.examples.splat.game;

import com.codenameone.examples.splat.rules.Catalog;
import com.codenameone.examples.splat.rules.Mode;

/// A playlist reference: `arena:MODE`, such as `lot7:CAPTURE_THE_FLAG`. It is
/// what a client asks to play and what a match record stores as its level.
public final class Arenas {
    public static final String DEFAULT = "lot7:TEAM_PAINT";

    private Arenas() {
    }

    /// The canonical form of `ref`, or null when it names no arena and mode.
    /// A bare arena id plays Team Paint; null or empty plays the default.
    public static String normalize(String ref) {
        if (ref == null || ref.length() == 0) {
            return DEFAULT;
        }
        int colon = ref.indexOf(':');
        String arena = colon < 0 ? ref : ref.substring(0, colon);
        String mode = colon < 0 ? Mode.TEAM_PAINT.name() : ref.substring(colon + 1);
        try {
            Catalog.arena(arena);
            return arena + ":" + Mode.byName(mode).name();
        } catch (IllegalArgumentException unknown) {
            return null;
        }
    }

    public static String arena(String ref) {
        return ref.substring(0, ref.indexOf(':'));
    }

    public static Mode mode(String ref) {
        return Mode.byName(ref.substring(ref.indexOf(':') + 1));
    }
}
