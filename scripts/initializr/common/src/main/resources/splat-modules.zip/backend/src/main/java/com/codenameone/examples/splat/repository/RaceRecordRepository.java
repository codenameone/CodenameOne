package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.RaceRecord;
import java.time.Instant;
import java.util.List;

@Repository(entity = RaceRecord.class, key = String.class)
public interface RaceRecordRepository extends CrudRepository<RaceRecord, String> {
    long countByEndedAtGreaterThan(Instant since);

    @Query("select r from RaceRecord r where r.endedAt >= :since")
    List<RaceRecord> since(@Param("since") Instant since);
}
