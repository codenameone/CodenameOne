package com.codenameone.examples.splat.social;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.splat.api.FriendDto;
import com.codenameone.examples.splat.api.InviteClaimDto;
import com.codenameone.examples.splat.api.InviteDto;
import com.codenameone.examples.splat.api.RewardDto;
import com.codenameone.examples.splat.api.SocialApiServer;
import com.codenameone.examples.splat.api.SpotlightDto;
import java.util.List;

@Component
public class SocialEndpoint implements SocialApiServer {
    private final Referrals referrals;
    private final Promotion promotion;

    public SocialEndpoint(Referrals referrals, Promotion promotion) {
        this.referrals = referrals;
        this.promotion = promotion;
    }

    @Override
    public InviteDto invite() throws Exception {
        return referrals.invite(Caller.name());
    }

    @Override
    public RewardDto claim(InviteClaimDto claim) throws Exception {
        return referrals.claim(Caller.name(), claim);
    }

    @Override
    public List<FriendDto> friends() throws Exception {
        return referrals.friends(Caller.name());
    }

    @Override
    public SpotlightDto spotlight() throws Exception {
        return promotion.spotlight();
    }
}
