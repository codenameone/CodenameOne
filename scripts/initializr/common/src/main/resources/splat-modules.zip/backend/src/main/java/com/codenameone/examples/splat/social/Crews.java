package com.codenameone.examples.splat.social;

import com.codename1.backend.Crypto;
import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.Transactional;
import com.codename1.orm.repository.PageRequest;
import com.codenameone.examples.splat.Ids;
import com.codenameone.examples.splat.api.CrewDto;
import com.codenameone.examples.splat.domain.Crew;
import com.codenameone.examples.splat.domain.CrewMember;
import com.codenameone.examples.splat.domain.Profile;
import com.codenameone.examples.splat.push.GamePushes;
import com.codenameone.examples.splat.repository.CrewMemberRepository;
import com.codenameone.examples.splat.repository.CrewRepository;
import com.codenameone.examples.splat.repository.ProfileRepository;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/// Crews: small groups of friends with their own leaderboard. A crew is
/// joined by its code, which is also its share link.
@Component
public class Crews {
    public static final int MAX_MEMBERS = 30;
    public static final int MAX_CREWS = 5;

    private final CrewRepository crews;
    private final CrewMemberRepository members;
    private final ProfileRepository profiles;
    private final GamePushes pushes;

    public Crews(CrewRepository crews, CrewMemberRepository members, ProfileRepository profiles,
            GamePushes pushes) {
        this.crews = crews;
        this.members = members;
        this.profiles = profiles;
        this.pushes = pushes;
    }

    /// The host opened a party for their crew: every other member hears about
    /// it. Only a member may call their crew, so a crew code alone cannot be
    /// used to push strangers.
    @Transactional(readOnly = true)
    public void callToRace(String host, String hostName, String code, String party) throws IOException {
        Crew c = code == null ? null : crews.findById(code);
        if (c == null || members.findById(code + "|" + host) == null) {
            return;
        }
        for (CrewMember m : members.members(code, new PageRequest(0, MAX_MEMBERS))) {
            if (!m.getUsername().equals(host)) {
                pushes.crewRacing(m.getUsername(), hostName, c.getName(), party);
            }
        }
    }

    @Transactional(readOnly = true)
    public List<CrewDto> of(String username) throws IOException {
        List<CrewDto> out = new ArrayList<CrewDto>();
        for (CrewMember m : members.crewsOf(username, new PageRequest(0, MAX_CREWS))) {
            Crew c = crews.findById(m.getCode());
            if (c != null) {
                out.add(view(c));
            }
        }
        return out;
    }

    @Transactional(rollbackFor = IOException.class)
    public CrewDto create(String username, String name) throws IOException {
        String n = name == null ? "" : name.trim();
        if (n.length() < 2 || n.length() > 40) {
            throw new ResponseStatusException(400, "A crew name is 2 to 40 characters");
        }
        if (members.crewsOf(username, new PageRequest(0, MAX_CREWS)).size() >= MAX_CREWS) {
            throw new ResponseStatusException(409, "You are in " + MAX_CREWS + " crews already");
        }
        Crew c = new Crew();
        c.setCode(Ids.hex(Crypto.randomBytes(4)).toUpperCase(java.util.Locale.ROOT));
        c.setName(n);
        c.setOwner(username);
        c.setCreatedAt(Instant.now());
        crews.insert(c);
        return join(username, c.getCode());
    }

    @Transactional(rollbackFor = IOException.class)
    public CrewDto join(String username, String code) throws IOException {
        Crew c = code == null ? null : crews.findById(code);
        if (c == null) {
            throw new ResponseStatusException(404, "No crew has that code");
        }
        String id = code + "|" + username;
        if (members.findById(id) == null) {
            if (c.getMembers() >= MAX_MEMBERS) {
                throw new ResponseStatusException(409, "That crew is full");
            }
            if (members.crewsOf(username, new PageRequest(0, MAX_CREWS)).size() >= MAX_CREWS) {
                throw new ResponseStatusException(409, "You are in " + MAX_CREWS + " crews already");
            }
            CrewMember m = new CrewMember();
            m.setId(id);
            m.setCode(code);
            m.setUsername(username);
            m.setJoinedAt(Instant.now());
            members.insert(m);
            // Counted, not incremented: two joins at once must not lose one.
            c.setMembers(count(code));
            crews.save(c);
        }
        return view(c);
    }

    @Transactional(rollbackFor = IOException.class)
    public CrewDto leave(String username, String code) throws IOException {
        Crew c = code == null ? null : crews.findById(code);
        CrewMember m = c == null ? null : members.findById(code + "|" + username);
        if (m == null) {
            throw new ResponseStatusException(404, "You are not in that crew");
        }
        members.deleteById(m.getId());
        c.setMembers(count(code));
        crews.save(c);
        return view(c);
    }

    private CrewDto view(Crew c) {
        List<String> usernames = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        for (CrewMember m : members.members(c.getCode(), new PageRequest(0, MAX_MEMBERS))) {
            Profile p = profiles.findById(m.getUsername());
            usernames.add(m.getUsername());
            names.add(p == null ? m.getUsername() : p.getDisplayName());
        }
        return new CrewDto(c.getCode(), c.getName(), c.getOwner(), usernames, names);
    }

    private int count(String code) {
        return members.members(code, new PageRequest(0, MAX_MEMBERS + 8)).size();
    }
}
