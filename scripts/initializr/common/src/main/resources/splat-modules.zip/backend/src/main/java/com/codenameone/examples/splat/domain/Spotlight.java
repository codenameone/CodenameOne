package com.codenameone.examples.splat.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// The home screen's banner. One row, `home`.
@Entity
public class Spotlight {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(10)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(140)")
    private String message = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String packId = "";

    @Column(nullable = false, type = "VARCHAR(20)")
    private String screen = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String updatedBy = "";

    @Column(nullable = false)
    private Instant updatedAt = Instant.EPOCH;

    public Spotlight() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPackId() {
        return packId;
    }

    public void setPackId(String packId) {
        this.packId = packId;
    }

    public String getScreen() {
        return screen;
    }

    public void setScreen(String screen) {
        this.screen = screen;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }
}
