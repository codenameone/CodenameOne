package com.codenameone.examples.splat.account;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.splat.api.AccountApiServer;
import com.codenameone.examples.splat.api.PlayerDto;
import com.codenameone.examples.splat.api.ProfileDto;
import com.codenameone.examples.splat.api.PushDeviceDto;
import com.codenameone.examples.splat.api.RegisterDto;
import com.codenameone.examples.splat.api.TicketDto;
import com.codenameone.examples.splat.game.GameTickets;
import com.codenameone.examples.splat.push.PushDevices;

@Component
public class AccountEndpoint implements AccountApiServer {
    private final Accounts accounts;
    private final GameTickets tickets;
    private final PushDevices devices;

    public AccountEndpoint(Accounts accounts, GameTickets tickets, PushDevices devices) {
        this.accounts = accounts;
        this.tickets = tickets;
        this.devices = devices;
    }

    @Override
    public PlayerDto register(RegisterDto request) throws Exception {
        return accounts.register(request);
    }

    @Override
    public PlayerDto me() throws Exception {
        return accounts.describe(Caller.name());
    }

    @Override
    public PlayerDto saveProfile(ProfileDto profile) throws Exception {
        return accounts.rename(Caller.name(), profile == null ? null : profile.displayName());
    }

    @Override
    public TicketDto gameTicket() throws Exception {
        return tickets.issue(Caller.name());
    }

    @Override
    public PushDeviceDto registerPush(PushDeviceDto device) throws Exception {
        return devices.register(Caller.name(), device);
    }

    @Override
    public PushDeviceDto unregisterPush(PushDeviceDto device) throws Exception {
        return devices.unregister(Caller.name(), device);
    }
}
