package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.Spotlight;

@Repository(entity = Spotlight.class, key = String.class)
public interface SpotlightRepository extends CrudRepository<Spotlight, String> {
}
