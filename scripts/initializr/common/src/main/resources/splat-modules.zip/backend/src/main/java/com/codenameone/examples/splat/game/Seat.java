package com.codenameone.examples.splat.game;

import com.codename1.backend.WebSocketSession;

/// One place in a [MatchRoom]: a player and the socket they are on now, which
/// changes when they reconnect, or one of the server's bots.
final class Seat {
    final String username;
    final String name;
    final String marker;
    final int trophies;
    final int team;
    WebSocketSession session;
    /// Arrival ticks of recent inputs, for flood detection.
    final int[] recent = new int[48];
    int recentCount;
    int floods;
    /// Inputs that turned further in one tick than a wrist can.
    int snaps;
    /// The newest input sequence number received, and the one the last step used.
    int lastSeq = -1;
    int appliedSeq = -1;
    /// The player left; their paintballer stands there, bewildered, with no input.
    boolean left;

    Seat(String username, String name, String marker, int trophies, int team, WebSocketSession session) {
        this.username = username;
        this.name = name;
        this.marker = marker;
        this.trophies = trophies;
        this.team = team;
        this.session = session;
    }

    boolean isBot() {
        return username.length() == 0;
    }
}
