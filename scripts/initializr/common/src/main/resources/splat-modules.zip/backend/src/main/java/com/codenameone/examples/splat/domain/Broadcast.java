package com.codenameone.examples.splat.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A push an operator sent to a segment of players, kept as the record of it.
@Entity
public class Broadcast {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(10)")
    private String segment = "";

    @Column(nullable = false)
    private int days;

    @Column(nullable = false, type = "VARCHAR(60)")
    private String title = "";

    @Column(nullable = false, type = "VARCHAR(200)")
    private String body = "";

    @Column(nullable = false, type = "VARCHAR(20)")
    private String screen = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String campaign = "";

    @Column(nullable = false)
    private int targets;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String sentBy = "";

    @Column(nullable = false)
    private Instant sentAt = Instant.EPOCH;

    public Broadcast() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getScreen() {
        return screen;
    }

    public void setScreen(String screen) {
        this.screen = screen;
    }

    public String getCampaign() {
        return campaign;
    }

    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    public int getTargets() {
        return targets;
    }

    public void setTargets(int targets) {
        this.targets = targets;
    }

    public String getSentBy() {
        return sentBy;
    }

    public void setSentBy(String sentBy) {
        this.sentBy = sentBy;
    }

    public Instant getSentAt() {
        return sentAt;
    }

    public void setSentAt(Instant sentAt) {
        this.sentAt = sentAt;
    }
}
