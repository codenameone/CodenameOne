package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.PipelineHit;
import java.util.List;

@Repository(entity = PipelineHit.class, key = String.class)
public interface PipelineHitRepository extends CrudRepository<PipelineHit, String> {
    List<PipelineHit> findByPipeline(String pipeline);
}
