package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.Pipeline;
import java.util.List;

@Repository(entity = Pipeline.class, key = String.class)
public interface PipelineRepository extends CrudRepository<Pipeline, String> {
    @Query("select p from Pipeline p order by p.name asc, p.id asc")
    List<Pipeline> byName();
}
