package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.CrewMember;
import java.util.List;

@Repository(entity = CrewMember.class, key = String.class)
public interface CrewMemberRepository extends CrudRepository<CrewMember, String> {
    @Query("select m from CrewMember m where m.username = :u order by m.joinedAt asc")
    List<CrewMember> crewsOf(@Param("u") String username, PageRequest page);

    @Query("select m from CrewMember m where m.code = :c order by m.joinedAt asc")
    List<CrewMember> members(@Param("c") String code, PageRequest page);
}
