package com.codenameone.examples.splat.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.splat.domain.Crew;

@Repository(entity = Crew.class, key = String.class)
public interface CrewRepository extends CrudRepository<Crew, String> {
}
