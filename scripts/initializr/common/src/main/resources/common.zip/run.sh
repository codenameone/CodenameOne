#!/bin/bash
cd -- "$(dirname -- "${BASH_SOURCE[0]}")" || exit 1
MVNW="./mvnw"

function simulator {
  
  "$MVNW" "verify" "-Psimulator" "-DskipTests" "-Dcodename1.platform=javase" "-e"
}
function desktop {
  
  "$MVNW" "verify" "-Prun-desktop" "-DskipTests" "-Dcodename1.platform=javase" "-e"
}
function settings {
  
  "$MVNW" "cn1:settings" "-e"
}
function certificatewizard {

  "$MVNW" "cn1:certificatewizard" "-e"
}
function update {
  
  "$MVNW" "cn1:update" "-U" "-e"
}
function help {
  "echo" "-e" "run.sh [COMMAND]"
  "echo" "-e" "Commands:"
  "echo" "-e" "  simulator"
  "echo" "-e" "    Runs app using Codename One Simulator"
  "echo" "-e" "  desktop"
  "echo" "-e" "    Runs app as a desktop app."
  "echo" "-e" "  settings"
  "echo" "-e" "    Opens Codename One settings"
  "echo" "-e" "  certificatewizard"
  "echo" "-e" "    Opens the Certificate Wizard"
  "echo" "-e" "  update"
  "echo" "-e" "    Update Codename One libraries"
}
CMD=$1

if [ "$CMD" == "" ]; then
  echo "Starting the LOCAL simulator. To submit a cloud build, run ./build.sh javascript_cloud."
  CMD="simulator"
fi
"$CMD"
