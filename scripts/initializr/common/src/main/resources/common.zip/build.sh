#!/bin/bash
set -e
cd -- "$(dirname -- "${BASH_SOURCE[0]}")" || exit 1
MVNW="./mvnw"

function mac_desktop {

  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=javase" "-Dcodename1.buildTarget=mac-os-x-desktop" "-U" "-e"
}
function mac_native {

  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=ios" "-Dcodename1.buildTarget=mac-os-x-native" "-U" "-e"
}
function windows_desktop {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=javase" "-Dcodename1.buildTarget=windows-desktop" "-U" "-e"
}
function windows_device {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=win" "-Dcodename1.buildTarget=windows-device" "-U" "-e"
}
function uwp {
  windows_device
}
function linux_device {

  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=linux" "-Dcodename1.buildTarget=linux-device" "-U" "-e"
}
function linux_local {
  BOARD_ARGS=()
  if [ -n "$CN1_BOARD" ]; then BOARD_ARGS=("-Dcn1.board=$CN1_BOARD"); fi
  "$MVNW" "cn1:buildLinuxLocal" "${BOARD_ARGS[@]}" "-U" "-e"
}
function device {
  DEVICE_ARGS=()
  if [ -n "$CN1_BOARD" ]; then DEVICE_ARGS+=("-Dcn1.board=$CN1_BOARD"); fi
  if [ -n "$CN1_DEVICE_HOST" ]; then DEVICE_ARGS+=("-Dcn1.device.host=$CN1_DEVICE_HOST"); fi
  "$MVNW" "cn1:runOnDevice" "${DEVICE_ARGS[@]}" "-U" "-e"
}
function device_logs {
  DEVICE_ARGS=()
  if [ -n "$CN1_DEVICE_HOST" ]; then DEVICE_ARGS+=("-Dcn1.device.host=$CN1_DEVICE_HOST"); fi
  "$MVNW" "cn1:device-logs" "${DEVICE_ARGS[@]}" "-e"
}
function javascript {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=javascript" "-Dcodename1.buildTarget=local-javascript" "-U" "-e"
}
function javascript_cloud {

  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=javascript" "-Dcodename1.buildTarget=javascript" "-U" "-e"
}
function android {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=android" "-Dcodename1.buildTarget=android-device" "-U" "-e"
}
function xcode {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=ios" "-Dcodename1.buildTarget=ios-source" "-U" "-e"
}
function ios_source {
  "xcode" 
}
function android_source {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=android" "-Dcodename1.buildTarget=android-source" "-U" "-e"
}
function ios {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=ios" "-Dcodename1.buildTarget=ios-device" "-U" "-e"
}
function ios_release {
  
  "$MVNW" "package" "-DskipTests" "-Dcodename1.platform=ios" "-Dcodename1.buildTarget=ios-device-release" "-U" "-e"
}
function jar {
  
  "$MVNW" "-Pexecutable-jar" "package" "-Dcodename1.platform=javase" "-DskipTests" "-U" "-e"
}
function help {
  "echo" "-e" "build.sh [COMMAND]"
  "echo" "-e" "Local Build Commands:"
  "echo" "-e" "  The following commands will build the app locally (i.e. does NOT use the Codename One build server)"
  "echo" "-e" ""
  "echo" "-e" "  jar"
  "echo" "-e" "    Builds app as desktop app executable jar file to javase/target directory"
  "echo" "-e" "  android_source"
  "echo" "-e" "    Generates an android gradle project that can be opened in Android studio"
  "echo" "-e" "    *Requires android development tools installed."
  "echo" "-e" "    *Requires ANDROID_HOME environment variable"
  "echo" "-e" "    *Requires either GRADLE_HOME environment variable, or for gradle to be in PATH"
  "echo" "-e" "  ios_source"
  "echo" "-e" "    Generates an Xcode Project that you can open and build using Apple's development tools"
  "echo" "-e" "    *Requires a Mac with Xcode installed"
  "echo" "-e" "  javascript"
  "echo" "-e" "    Builds the web app locally."
  "echo" "-e" ""
  "echo" "-e" "Build Server Commands:"
  "echo" "-e" "  The following commands will build the app using the Codename One build server, and require"
  "echo" "-e" "  a Codename One account.  See https://www.codenameone.com"
  "echo" "-e" ""
  "echo" "-e" "  ios"
  "echo" "-e" "    Builds iOS app."
  "echo" "-e" "  ios_release"
  "echo" "-e" "    Builds iOS app for submission to Apple appstore."
  "echo" "-e" "  android"
  "echo" "-e" "    Builds android app."
  "echo" "-e" "  mac_desktop"
  "echo" "-e" "    Builds Mac OS desktop app."
  "echo" "-e" "    *Mac OS Desktop builds are a Pro user feature."
  "echo" "-e" "  mac_native"
  "echo" "-e" "    Builds a native Mac app (no JVM)."
  "echo" "-e" "  windows_desktop"
  "echo" "-e" "    Builds Windows desktop app."
  "echo" "-e" "    *Windows Desktop builds are a Pro user feature."
  "echo" "-e" "  windows_device"
  "echo" "-e" "    Builds a native Windows app (no JVM)."
  "echo" "-e" "  linux_device"
  "echo" "-e" "    Builds a native Linux app (ELF, no JVM)."
  "echo" "-e" "  linux_local"
  "echo" "-e" "    Builds a native Linux app locally. CN1_BOARD=rpi5 cross builds for an embedded board."
  "echo" "-e" "  device"
  "echo" "-e" "    Builds locally, deploys to CN1_DEVICE_HOST over SSH and follows the log."
  "echo" "-e" "  device_logs"
  "echo" "-e" "    Follows the app's log on CN1_DEVICE_HOST."
  "echo" "-e" "  javascript_cloud"
  "echo" "-e" "    Builds the web app using the build server."
}
function settings {
  
  "$MVNW" "cn1:settings" "-U" "-e"
}
CMD="$1"

if [ "$CMD" == "" ]; then
  echo "No target selected: building a LOCAL JAR. To submit your first cloud build, run ./build.sh javascript_cloud."
  CMD="jar"
fi
"$CMD"
