package com.codenameone.examples.bazaar.platform;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.ApiKeyApiServer;
import com.codenameone.examples.bazaar.api.ApiKeyDto;

import java.util.List;

/// The server's half of `ApiKeyApi`; [StoreApiKeys] checks the caller.
@Component
public class ApiKeyEndpoint implements ApiKeyApiServer {
    private final StoreApiKeys keys;

    public ApiKeyEndpoint(StoreApiKeys keys) {
        this.keys = keys;
    }

    @Override
    public List<ApiKeyDto> list(String storeId) throws Exception {
        return keys.list(Caller.name(), storeId);
    }

    @Override
    public ApiKeyDto create(String storeId, ApiKeyDto key) throws Exception {
        return keys.create(Caller.name(), storeId, key);
    }

    @Override
    public List<ApiKeyDto> revoke(String storeId, String keyId) throws Exception {
        return keys.revoke(Caller.name(), storeId, keyId);
    }
}
