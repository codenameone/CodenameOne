package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TrialOrder;
import java.time.Instant;
import java.util.List;

/// Reads and writes [TrialOrder] rows.
@Repository(entity = TrialOrder.class, key = String.class)
public interface TrialOrderRepository extends CrudRepository<TrialOrder, String> {
    List<TrialOrder> findByStatusAndEndsAtLessThanEqual(String status, Instant now);
}
