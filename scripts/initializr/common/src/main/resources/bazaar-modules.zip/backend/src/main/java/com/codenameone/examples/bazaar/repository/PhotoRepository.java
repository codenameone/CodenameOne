package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Photo;

import java.util.List;

/// Pictures, by what owns them.
@Repository(entity = Photo.class, key = String.class)
public interface PhotoRepository extends CrudRepository<Photo, String> {
    long countByOwnerId(String ownerId);

    /// An owner's photos as `{id, createdAt}`, without their bytes.
    @Query("select p.id, p.createdAt from Photo p where p.ownerId = :ownerId")
    List<Object[]> stored(@Param("ownerId") String ownerId);
}
