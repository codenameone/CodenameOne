package com.codenameone.examples.bazaar.customer;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.DataExportDto;
import com.codenameone.examples.bazaar.api.DataRequestDto;
import com.codenameone.examples.bazaar.api.DataRequestKindDto;
import com.codenameone.examples.bazaar.api.ShopperDataApiServer;
import com.codenameone.examples.bazaar.cart.Codes;

import java.util.List;

/// The server's half of `ShopperDataApi`: the signed-in shopper's own data.
@Component
public class ShopperDataEndpoint implements ShopperDataApiServer {
    private final CustomerData data;

    public ShopperDataEndpoint(CustomerData data) {
        this.data = data;
    }

    @Override
    public DataExportDto export() throws Exception {
        return data.exportMine(Codes.callerOrNull());
    }

    @Override
    public List<DataRequestDto> requests() throws Exception {
        return data.mine(Codes.callerOrNull());
    }

    @Override
    public DataRequestDto request(String storeId, DataRequestKindDto kind) throws Exception {
        return data.request(Codes.callerOrNull(), storeId, kind == null ? null : kind.kind());
    }
}
