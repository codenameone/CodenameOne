package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Collection;
import java.util.List;

/// Reads and writes [Collection] rows.
@Repository(entity = Collection.class, key = String.class)
public interface CollectionRepository extends CrudRepository<Collection, String> {
    List<Collection> findByStoreIdOrderByPositionAsc(String storeId);

    Collection findByStoreIdAndHandle(String storeId, String handle);
}
