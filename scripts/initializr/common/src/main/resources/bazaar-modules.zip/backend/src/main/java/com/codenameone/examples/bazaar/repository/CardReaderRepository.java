package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CardReader;
import java.util.List;

/// Reads and writes [CardReader] rows.
@Repository(entity = CardReader.class, key = String.class)
public interface CardReaderRepository extends CrudRepository<CardReader, String> {
    List<CardReader> findByStoreId(String storeId);

    List<CardReader> findByStoreIdAndRegisterIdAndStatus(String storeId, String registerId,
            String status);

    List<CardReader> findByProviderRef(String providerRef);
}
