package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ShippingRate;
import java.util.List;

/// Reads and writes [ShippingRate] rows.
@Repository(entity = ShippingRate.class, key = String.class)
public interface ShippingRateRepository extends CrudRepository<ShippingRate, String> {
    List<ShippingRate> findByZoneIdOrderByPositionAsc(String zoneId);

    List<ShippingRate> findByStoreId(String storeId);

    List<ShippingRate> findByStoreIdOrderByPositionAsc(String storeId);

    void deleteByZoneId(String zoneId);
}
