package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MenuLink;
import java.util.List;

/// Reads and writes [MenuLink] rows.
@Repository(entity = MenuLink.class, key = String.class)
public interface MenuLinkRepository extends CrudRepository<MenuLink, String> {
    List<MenuLink> findByStoreIdOrderByPositionAsc(String storeId);
}
