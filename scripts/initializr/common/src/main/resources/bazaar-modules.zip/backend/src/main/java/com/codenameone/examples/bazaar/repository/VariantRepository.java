package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Variant;
import java.util.List;

/// Reads and writes [Variant] rows.
@Repository(entity = Variant.class, key = String.class)
public interface VariantRepository extends CrudRepository<Variant, String> {
    List<Variant> findByProductIdOrderByPositionAsc(String productId);

    List<Variant> findByStoreId(String storeId);

    List<Variant> findByStoreIdAndBarcode(String storeId, String barcode);

    List<Variant> findByStoreIdAndSku(String storeId, String sku);

    List<Variant> findByIdIn(List<String> ids);

    List<Variant> findByProductIdIn(List<String> productIds);
}
