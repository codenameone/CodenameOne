package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.PurchaseOrder;
import java.util.List;

/// Reads and writes [PurchaseOrder] rows.
@Repository(entity = PurchaseOrder.class, key = String.class)
public interface PurchaseOrderRepository extends CrudRepository<PurchaseOrder, String> {
    List<PurchaseOrder> findByStoreIdOrderByCreatedAtDesc(String storeId);

    long countByStoreId(String storeId);

    List<PurchaseOrder> findBySupplierId(String supplierId);
}
