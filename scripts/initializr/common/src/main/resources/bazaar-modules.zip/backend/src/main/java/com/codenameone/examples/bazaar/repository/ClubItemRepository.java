package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ClubItem;

import java.util.List;

/// Reads and writes [ClubItem] rows.
@Repository(entity = ClubItem.class, key = String.class)
public interface ClubItemRepository extends CrudRepository<ClubItem, String> {
    List<ClubItem> findByClubId(String clubId);

    List<ClubItem> findByStoreId(String storeId);

    List<ClubItem> findByProductId(String productId);
}
