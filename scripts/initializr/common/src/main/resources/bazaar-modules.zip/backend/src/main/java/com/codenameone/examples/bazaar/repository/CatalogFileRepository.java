package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CatalogFile;

import java.util.List;

@Repository(entity = CatalogFile.class, key = String.class)
public interface CatalogFileRepository extends CrudRepository<CatalogFile, String> {
    /// `{storeId, kind, name, contentType, sizeBytes}` of a file, without
    /// reading its bytes.
    @Query("select f.storeId, f.kind, f.name, f.contentType, f.sizeBytes from CatalogFile f "
            + "where f.id = :id")
    List<Object[]> meta(@Param("id") String id);
}
