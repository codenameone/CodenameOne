package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.VatLookup;

/// Reads and writes [VatLookup] rows.
@Repository(entity = VatLookup.class, key = String.class)
public interface VatLookupRepository extends CrudRepository<VatLookup, String> {
}
