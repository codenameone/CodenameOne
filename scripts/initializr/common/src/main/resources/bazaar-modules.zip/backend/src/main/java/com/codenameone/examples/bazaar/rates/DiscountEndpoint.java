package com.codenameone.examples.bazaar.rates;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.DiscountApiServer;
import com.codenameone.examples.bazaar.api.DiscountDto;

import java.util.List;

/// The server's half of `DiscountApi`.
@Component
public class DiscountEndpoint implements DiscountApiServer {
    private final RateSettings settings;

    private final DiscountCodes codes;

    public DiscountEndpoint(RateSettings settings, DiscountCodes codes) {
        this.settings = settings;
        this.codes = codes;
    }

    @Override
    public com.codenameone.examples.bazaar.api.ExportDto generateCodes(String storeId,
            String discountId, com.codenameone.examples.bazaar.api.DiscountCodesDto body)
            throws Exception {
        return codes.generate(Caller.name(), storeId, discountId, body);
    }

    @Override
    public com.codenameone.examples.bazaar.api.ExportDto codes(String storeId, String discountId)
            throws Exception {
        return codes.codes(Caller.name(), storeId, discountId);
    }

    @Override
    public List<DiscountDto> list(String storeId) throws Exception {
        return settings.discounts(Caller.name(), storeId);
    }

    @Override
    public DiscountDto save(String storeId, DiscountDto body) throws Exception {
        return settings.saveDiscount(Caller.name(), storeId, body);
    }

    @Override
    public DiscountDto delete(String storeId, String discountId) throws Exception {
        return settings.deleteDiscount(Caller.name(), storeId, discountId);
    }
}
