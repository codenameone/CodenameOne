package com.codenameone.examples.bazaar.rates;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.ShippingApiServer;
import com.codenameone.examples.bazaar.api.ShippingProfileDto;
import com.codenameone.examples.bazaar.api.ShippingRateDto;
import com.codenameone.examples.bazaar.api.ShippingZoneDto;

import java.util.List;

/// The server's half of `ShippingApi`.
@Component
public class ShippingEndpoint implements ShippingApiServer {
    private final RateSettings settings;

    public ShippingEndpoint(RateSettings settings) {
        this.settings = settings;
    }

    @Override
    public List<ShippingZoneDto> zones(String storeId) throws Exception {
        return settings.zones(Caller.name(), storeId);
    }

    @Override
    public ShippingZoneDto saveZone(String storeId, ShippingZoneDto body) throws Exception {
        return settings.saveZone(Caller.name(), storeId, body);
    }

    @Override
    public ShippingZoneDto deleteZone(String storeId, String zoneId) throws Exception {
        return settings.deleteZone(Caller.name(), storeId, zoneId);
    }

    @Override
    public ShippingRateDto saveRate(String storeId, ShippingRateDto body) throws Exception {
        return settings.saveRate(Caller.name(), storeId, body);
    }

    @Override
    public ShippingRateDto deleteRate(String storeId, String rateId) throws Exception {
        return settings.deleteRate(Caller.name(), storeId, rateId);
    }

    @Override
    public List<ShippingProfileDto> profiles(String storeId) throws Exception {
        return settings.profiles(Caller.name(), storeId);
    }

    @Override
    public ShippingProfileDto saveProfile(String storeId, ShippingProfileDto body)
            throws Exception {
        return settings.saveProfile(Caller.name(), storeId, body);
    }

    @Override
    public ShippingProfileDto deleteProfile(String storeId, String profileId) throws Exception {
        return settings.deleteProfile(Caller.name(), storeId, profileId);
    }
}
