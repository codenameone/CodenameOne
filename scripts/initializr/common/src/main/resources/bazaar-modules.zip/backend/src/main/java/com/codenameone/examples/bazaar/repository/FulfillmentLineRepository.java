package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.FulfillmentLine;
import java.util.List;

/// Reads and writes [FulfillmentLine] rows.
@Repository(entity = FulfillmentLine.class, key = String.class)
public interface FulfillmentLineRepository extends CrudRepository<FulfillmentLine, String> {
    List<FulfillmentLine> findByFulfillmentId(String fulfillmentId);
}
