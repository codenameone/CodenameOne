package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Webhook;
import java.util.List;

/// Reads and writes [Webhook] rows.
@Repository(entity = Webhook.class, key = String.class)
public interface WebhookRepository extends CrudRepository<Webhook, String> {
    List<Webhook> findByStoreId(String storeId);

    List<Webhook> findByStoreIdAndTopic(String storeId, String topic);
}
