package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.OrderEdit;
import java.util.List;

/// Reads and writes [OrderEdit] rows.
@Repository(entity = OrderEdit.class, key = String.class)
public interface OrderEditRepository extends CrudRepository<OrderEdit, String> {
    List<OrderEdit> findByOrderIdOrderByCreatedAtAsc(String orderId);
}
