package com.codenameone.examples.bazaar.rates;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.TaxApiServer;
import com.codenameone.examples.bazaar.api.TaxRateDto;

import java.util.List;

/// The server's half of `TaxApi`.
@Component
public class TaxEndpoint implements TaxApiServer {
    private final RateSettings settings;

    public TaxEndpoint(RateSettings settings) {
        this.settings = settings;
    }

    @Override
    public List<TaxRateDto> list(String storeId) throws Exception {
        return settings.taxRates(Caller.name(), storeId);
    }

    @Override
    public TaxRateDto save(String storeId, TaxRateDto body) throws Exception {
        return settings.saveTaxRate(Caller.name(), storeId, body);
    }

    @Override
    public TaxRateDto delete(String storeId, String rateId) throws Exception {
        return settings.deleteTaxRate(Caller.name(), storeId, rateId);
    }
}
