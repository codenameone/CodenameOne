package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Audience;

import java.util.List;

/// Reads and writes [Audience] rows.
@Repository(entity = Audience.class, key = String.class)
public interface AudienceRepository extends CrudRepository<Audience, String> {
    List<Audience> findByStoreIdOrderByNameAsc(String storeId);
}
