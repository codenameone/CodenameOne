package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MetaobjectEntry;
import java.util.List;

/// Reads and writes [MetaobjectEntry] rows.
@Repository(entity = MetaobjectEntry.class, key = String.class)
public interface MetaobjectEntryRepository extends CrudRepository<MetaobjectEntry, String> {
    List<MetaobjectEntry> findByTypeIdOrderByTitleAsc(String typeId);
}
