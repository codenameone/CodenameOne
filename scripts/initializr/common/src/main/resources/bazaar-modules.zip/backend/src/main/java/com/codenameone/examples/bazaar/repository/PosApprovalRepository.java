package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.PosApproval;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import java.util.List;

/// Reads and writes [PosApproval] rows.
@Repository(entity = PosApproval.class, key = String.class)
public interface PosApprovalRepository extends CrudRepository<PosApproval, String> {
    /// Marks an approval used by `subject` only while nothing has used it.
    @Modifying
    @Query("update PosApproval a set a.usedBy = :subject where a.id = :id and a.usedBy = ''")
    int use(@Param("id") String id, @Param("subject") String subject);

    /// Gives back an approval `subject` claimed, when what it was claimed
    /// for failed before anything was paid out.
    @Modifying
    @Query("update PosApproval a set a.usedBy = '' where a.id = :id and a.usedBy = :subject")
    int release(@Param("id") String id, @Param("subject") String subject);
}
