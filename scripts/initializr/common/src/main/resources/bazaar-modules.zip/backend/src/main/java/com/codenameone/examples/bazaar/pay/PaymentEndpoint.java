package com.codenameone.examples.bazaar.pay;

import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.Value;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.bazaar.account.Accounts;
import com.codenameone.examples.bazaar.api.CardDto;
import com.codenameone.examples.bazaar.api.PaymentApiServer;
import com.codenameone.examples.bazaar.api.PaymentConfigDto;
import com.codenameone.examples.bazaar.api.PaymentMethodDto;
import com.codenameone.examples.bazaar.api.PaymentSetupDto;
import com.codenameone.examples.bazaar.api.ReceiptDto;

import java.util.List;

/// The server's half of `PaymentApi`. Every method acts as the signed-in user
/// and on that user's own cards and receipts: whose they are is never a
/// parameter, so there is no id to change to reach someone else's.
@Component
public class PaymentEndpoint implements PaymentApiServer {
    private final Payments payments;
    private final Accounts accounts;
    private final String currency;

    public PaymentEndpoint(Payments payments, Accounts accounts,
            @Value("${myappname.currency:USD}") String currency) {
        this.payments = payments;
        this.accounts = accounts;
        this.currency = currency;
    }

    @Override
    public PaymentConfigDto config() throws Exception {
        Caller.name();
        return payments.config(currency);
    }

    @Override
    public List<PaymentMethodDto> methods() throws Exception {
        return payments.methods(Caller.name());
    }

    @Override
    public PaymentSetupDto startSetup() throws Exception {
        String who = Caller.name();
        return payments.startSetup(who, accounts.describe(who).displayName());
    }

    @Override
    public PaymentMethodDto completeSetup(String id, CardDto card) throws Exception {
        return payments.completeSetup(Caller.name(), id, card);
    }

    @Override
    public PaymentMethodDto makeDefault(String id) throws Exception {
        return payments.makeDefault(Caller.name(), id);
    }

    @Override
    public PaymentMethodDto remove(String id) throws Exception {
        return payments.remove(Caller.name(), id);
    }

    @Override
    public List<ReceiptDto> receipts() throws Exception {
        return payments.receipts(Caller.name());
    }

    @Override
    public ReceiptDto receipt(String orderId) throws Exception {
        return payments.receipt(Caller.name(), false, orderId);
    }

}
