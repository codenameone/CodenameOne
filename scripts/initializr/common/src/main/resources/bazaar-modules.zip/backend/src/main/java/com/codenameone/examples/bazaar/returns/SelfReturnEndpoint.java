package com.codenameone.examples.bazaar.returns;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.ReturnOptionsDto;
import com.codenameone.examples.bazaar.api.ReturnQuoteDto;
import com.codenameone.examples.bazaar.api.SelfReturnApiServer;
import com.codenameone.examples.bazaar.api.SelfReturnDto;

/// The server's half of `SelfReturnApi`.
@Component
public class SelfReturnEndpoint implements SelfReturnApiServer {
    private final SelfReturns returns;

    public SelfReturnEndpoint(SelfReturns returns) {
        this.returns = returns;
    }

    @Override
    public ReturnOptionsDto options(String orderId) throws Exception {
        return returns.options(Caller.name(), orderId);
    }

    @Override
    public ReturnQuoteDto quote(String orderId, SelfReturnDto request) throws Exception {
        return returns.quote(Caller.name(), orderId, request);
    }

    @Override
    public ReturnQuoteDto request(String orderId, SelfReturnDto request) throws Exception {
        return returns.request(Caller.name(), orderId, request);
    }
}
