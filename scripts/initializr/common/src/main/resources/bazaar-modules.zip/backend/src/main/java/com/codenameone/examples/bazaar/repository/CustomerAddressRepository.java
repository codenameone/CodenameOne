package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CustomerAddress;
import java.util.List;

/// Reads and writes [CustomerAddress] rows.
@Repository(entity = CustomerAddress.class, key = String.class)
public interface CustomerAddressRepository extends CrudRepository<CustomerAddress, String> {
    List<CustomerAddress> findByUsername(String username);

    List<CustomerAddress> findByCustomerId(String customerId);

    /// Moves every row of one customer to another (a merge).
    @com.codename1.orm.repository.Modifying(clearAutomatically = true)
    @com.codename1.orm.repository.Query("update CustomerAddress x set x.customerId = :to where x.customerId = :from")
    int moveCustomer(@com.codename1.orm.repository.Param("from") String from,
            @com.codename1.orm.repository.Param("to") String to);
}
