package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MarketingKey;

/// Reads and writes [MarketingKey] rows.
@Repository(entity = MarketingKey.class, key = String.class)
public interface MarketingKeyRepository extends CrudRepository<MarketingKey, String> {
    MarketingKey findByStoreId(String storeId);
}
