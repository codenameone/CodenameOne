package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Register;
import java.util.List;

/// Reads and writes [Register] rows.
@Repository(entity = Register.class, key = String.class)
public interface RegisterRepository extends CrudRepository<Register, String> {
    List<Register> findByStoreId(String storeId);

    List<Register> findByLocationId(String locationId);
}
