package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.JourneyEnrollment;

import java.time.Instant;
import java.util.List;

/// Reads and writes [JourneyEnrollment] rows.
@Repository(entity = JourneyEnrollment.class, key = String.class)
public interface JourneyEnrollmentRepository extends CrudRepository<JourneyEnrollment, String> {
    JourneyEnrollment findByJourneyIdAndCustomerId(String journeyId, String customerId);

    List<JourneyEnrollment> findByJourneyId(String journeyId);

    List<JourneyEnrollment> findByStatusAndResumeAtLessThanEqual(String status, Instant now);

    @Modifying
    @Query("update JourneyEnrollment e set e.updatedAt = :claim where e.id = :id and e.updatedAt = :seen")
    int claim(@Param("id") String id, @Param("seen") Instant seen, @Param("claim") Instant claim);
}
