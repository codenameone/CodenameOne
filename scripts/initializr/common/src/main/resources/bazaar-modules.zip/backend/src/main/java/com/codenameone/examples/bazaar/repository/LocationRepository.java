package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Location;
import java.util.List;

/// Reads and writes [Location] rows.
@Repository(entity = Location.class, key = String.class)
public interface LocationRepository extends CrudRepository<Location, String> {
    List<Location> findByStoreIdOrderByPositionAsc(String storeId);

    long countByStoreId(String storeId);
}
