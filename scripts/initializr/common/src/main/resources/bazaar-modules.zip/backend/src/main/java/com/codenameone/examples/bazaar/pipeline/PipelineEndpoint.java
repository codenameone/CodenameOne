package com.codenameone.examples.bazaar.pipeline;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.PipelineApiServer;
import com.codenameone.examples.bazaar.api.PipelineColumnDto;
import com.codenameone.examples.bazaar.api.PipelineMoveDto;

import java.util.List;

/// The server's half of `PipelineApi`; [Pipeline] checks the caller.
@Component
public class PipelineEndpoint implements PipelineApiServer {
    private final Pipeline pipeline;

    public PipelineEndpoint(Pipeline pipeline) {
        this.pipeline = pipeline;
    }

    @Override
    public List<PipelineColumnDto> board(String storeId, String column, String page)
            throws Exception {
        return pipeline.board(Caller.name(), storeId, column, page(page));
    }

    @Override
    public List<PipelineColumnDto> move(String storeId, PipelineMoveDto move) throws Exception {
        return pipeline.move(Caller.name(), storeId, move);
    }

    static int page(String text) {
        if (text == null || text.trim().length() == 0) {
            return 0;
        }
        try {
            return Math.max(0, Integer.parseInt(text.trim()));
        } catch (NumberFormatException bad) {
            throw new ResponseStatusException(400, "A page is a whole number");
        }
    }
}
