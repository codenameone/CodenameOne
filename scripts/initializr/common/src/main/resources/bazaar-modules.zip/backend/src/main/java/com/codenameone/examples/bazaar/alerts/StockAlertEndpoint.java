package com.codenameone.examples.bazaar.alerts;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.PreorderDto;
import com.codenameone.examples.bazaar.api.StockAlertApiServer;
import com.codenameone.examples.bazaar.api.StockAlertDto;
import com.codenameone.examples.bazaar.cart.Codes;

import java.util.List;

/// The server's half of `StockAlertApi`.
@Component
public class StockAlertEndpoint implements StockAlertApiServer {
    private final StockAlerts alerts;

    public StockAlertEndpoint(StockAlerts alerts) {
        this.alerts = alerts;
    }

    @Override
    public StockAlertDto subscribe(String storeId, StockAlertDto body) throws Exception {
        return alerts.subscribe(Codes.callerOrNull(), storeId, body);
    }

    @Override
    public PreorderDto preorderOf(String storeId, String variantId) throws Exception {
        return alerts.preorderOf(storeId, variantId);
    }

    @Override
    public List<StockAlertDto> list(String storeId) throws Exception {
        return alerts.list(Caller.name(), storeId);
    }

    @Override
    public List<PreorderDto> preorders(String storeId) throws Exception {
        return alerts.preorders(Caller.name(), storeId);
    }

    @Override
    public PreorderDto savePreorder(String storeId, String variantId, PreorderDto body)
            throws Exception {
        return alerts.savePreorder(Caller.name(), storeId, variantId, body);
    }
}
