package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A buyer asking to send something back.
@Entity
public class ReturnRequest {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String orderId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String status = "";

    @Column(nullable = false, type = "VARCHAR(200)")
    private String reason = "";

    @Column(nullable = false, type = "VARCHAR(1000)")
    private String note = "";

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    @Column(nullable = false)
    private Instant updatedAt = Instant.EPOCH;

    @Column(nullable = false, type = "VARCHAR(32)")
    private String returnCarrier = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String returnTracking = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String returnLabelUrl = "";

    /// What the prepaid return label cost the store.
    @Column(nullable = false)
    private long returnLabelCents;

    public ReturnRequest() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getReturnCarrier() {
        return returnCarrier;
    }

    public void setReturnCarrier(String returnCarrier) {
        this.returnCarrier = returnCarrier == null ? "" : returnCarrier;
    }

    public String getReturnTracking() {
        return returnTracking;
    }

    public void setReturnTracking(String returnTracking) {
        this.returnTracking = returnTracking == null ? "" : returnTracking;
    }

    public String getReturnLabelUrl() {
        return returnLabelUrl;
    }

    public void setReturnLabelUrl(String returnLabelUrl) {
        this.returnLabelUrl = returnLabelUrl == null ? "" : returnLabelUrl;
    }

    public long getReturnLabelCents() {
        return returnLabelCents;
    }

    public void setReturnLabelCents(long returnLabelCents) {
        this.returnLabelCents = returnLabelCents;
    }
}
