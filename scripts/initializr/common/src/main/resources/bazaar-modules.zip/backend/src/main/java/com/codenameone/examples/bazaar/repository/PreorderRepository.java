package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Preorder;

import java.util.List;

/// Reads and writes [Preorder] rows.
@Repository(entity = Preorder.class, key = String.class)
public interface PreorderRepository extends CrudRepository<Preorder, String> {
    Preorder findByVariantId(String variantId);

    List<Preorder> findByStoreId(String storeId);
}
