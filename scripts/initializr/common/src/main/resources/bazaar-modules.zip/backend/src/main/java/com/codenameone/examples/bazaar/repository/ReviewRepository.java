package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Review;
import java.util.List;

/// Reads and writes [Review] rows.
@Repository(entity = Review.class, key = String.class)
public interface ReviewRepository extends CrudRepository<Review, String> {
    List<Review> findByProductIdAndStatusOrderByCreatedAtDesc(String productId, String status);

    List<Review> findByStoreIdOrderByCreatedAtDesc(String storeId);

    Review findByProductIdAndUsername(String productId, String username);
    /// A shopper's own reviews, newest first (index `review_username_created_at`).
    List<Review> findByUsernameOrderByCreatedAtDesc(String username);
}
