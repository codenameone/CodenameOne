package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A variant in a sale, with the prices it had before the sale changed them.
@Entity
public class SaleItem {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String saleId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String variantId = "";

    @Column(nullable = false)
    private long saleCents;

    @Column(nullable = false)
    private long originalCents;

    @Column(nullable = false)
    private long originalCompareCents;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String state = "";

    public SaleItem() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getSaleId() {
        return saleId;
    }

    public void setSaleId(String saleId) {
        this.saleId = saleId;
    }

    public String getVariantId() {
        return variantId;
    }

    public void setVariantId(String variantId) {
        this.variantId = variantId;
    }

    public long getSaleCents() {
        return saleCents;
    }

    public void setSaleCents(long saleCents) {
        this.saleCents = saleCents;
    }

    public long getOriginalCents() {
        return originalCents;
    }

    public void setOriginalCents(long originalCents) {
        this.originalCents = originalCents;
    }

    public long getOriginalCompareCents() {
        return originalCompareCents;
    }

    public void setOriginalCompareCents(long originalCompareCents) {
        this.originalCompareCents = originalCompareCents;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
