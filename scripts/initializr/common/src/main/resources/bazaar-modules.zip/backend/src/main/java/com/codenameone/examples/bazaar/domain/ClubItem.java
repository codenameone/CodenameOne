package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A product or collection a club holds back: members only, or early access before `publicFrom`.
@Entity
public class ClubItem {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String clubId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String productId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String collectionId = "";

    @Column(nullable = false)
    private boolean membersOnly;

    @Column(nullable = false)
    private Instant membersFrom = Instant.EPOCH;

    @Column(nullable = false)
    private Instant publicFrom = Instant.EPOCH;

    public ClubItem() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getClubId() {
        return clubId;
    }

    public void setClubId(String clubId) {
        this.clubId = clubId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCollectionId() {
        return collectionId;
    }

    public void setCollectionId(String collectionId) {
        this.collectionId = collectionId;
    }

    public boolean isMembersOnly() {
        return membersOnly;
    }

    public void setMembersOnly(boolean membersOnly) {
        this.membersOnly = membersOnly;
    }

    public Instant getMembersFrom() {
        return membersFrom;
    }

    public void setMembersFrom(Instant membersFrom) {
        this.membersFrom = membersFrom;
    }

    public Instant getPublicFrom() {
        return publicFrom;
    }

    public void setPublicFrom(Instant publicFrom) {
        this.publicFrom = publicFrom;
    }
}
