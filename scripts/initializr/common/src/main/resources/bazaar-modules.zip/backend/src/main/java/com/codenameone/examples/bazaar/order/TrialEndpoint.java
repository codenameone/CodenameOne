package com.codenameone.examples.bazaar.order;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.TrialApiServer;
import com.codenameone.examples.bazaar.api.TrialDto;
import java.util.List;

/// The server's half of `TrialApi`.
@Component
public class TrialEndpoint implements TrialApiServer {
    private final Trials trials;

    public TrialEndpoint(Trials trials) {
        this.trials = trials;
    }

    @Override
    public List<TrialDto> trials(String storeId) throws Exception {
        return trials.list(Caller.name(), storeId);
    }

    @Override
    public List<TrialDto> setTrial(String storeId, String productId, TrialDto trial)
            throws Exception {
        return trials.set(Caller.name(), storeId, productId, trial == null ? 0 : trial.days());
    }
}
