package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.LayawayPayment;
import java.util.List;

/// Reads and writes [LayawayPayment] rows.
@Repository(entity = LayawayPayment.class, key = String.class)
public interface LayawayPaymentRepository extends CrudRepository<LayawayPayment, String> {
    List<LayawayPayment> findByLayawayIdOrderByCreatedAtAsc(String layawayId);
}
