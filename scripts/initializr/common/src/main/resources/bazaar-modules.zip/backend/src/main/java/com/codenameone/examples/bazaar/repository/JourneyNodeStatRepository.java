package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.JourneyNodeStat;

import java.util.List;

/// Reads and writes [JourneyNodeStat] rows.
@Repository(entity = JourneyNodeStat.class, key = String.class)
public interface JourneyNodeStatRepository extends CrudRepository<JourneyNodeStat, String> {
    List<JourneyNodeStat> findByJourneyId(String journeyId);

    JourneyNodeStat findByJourneyIdAndNodeId(String journeyId, String nodeId);

    @Modifying
    @Query("update JourneyNodeStat s set s.passed = s.passed + 1 where s.id = :id")
    int bump(@Param("id") String id);
}
