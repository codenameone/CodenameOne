package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TradeQuoteLine;
import java.util.List;

/// Reads and writes [TradeQuoteLine] rows.
@Repository(entity = TradeQuoteLine.class, key = String.class)
public interface TradeQuoteLineRepository extends CrudRepository<TradeQuoteLine, String> {
    List<TradeQuoteLine> findByQuoteId(String quoteId);
}
