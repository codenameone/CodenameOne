package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Tender;
import java.util.List;

/// Reads and writes [Tender] rows.
@Repository(entity = Tender.class, key = String.class)
public interface TenderRepository extends CrudRepository<Tender, String> {
    List<Tender> findByOrderId(String orderId);

    void deleteByOrderId(String orderId);
}
