package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.StoreTheme;

/// Reads and writes [StoreTheme] rows.
@Repository(entity = StoreTheme.class, key = String.class)
public interface StoreThemeRepository extends CrudRepository<StoreTheme, String> {
    StoreTheme findByStoreIdAndStatus(String storeId, String status);
}
