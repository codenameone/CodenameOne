package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.PayoutAccount;

/// Where each payee is paid, keyed by the payee.
@Repository(entity = PayoutAccount.class, key = String.class)
public interface PayoutAccountRepository extends CrudRepository<PayoutAccount, String> {
    /// Makes the rest of the transaction wait its turn behind any other that
    /// holds the same payee's payout account.
    ///
    /// @return 1, or 0 for a payee who has not said where to be paid
    @Modifying
    @Query("update PayoutAccount a set a.last4 = a.last4 where a.username = :payee")
    int hold(@Param("payee") String payee);

    int deleteByUsername(String username);
}
