package com.codenameone.examples.bazaar.dispute;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.DisputeApiServer;
import com.codenameone.examples.bazaar.api.DisputeDto;
import com.codenameone.examples.bazaar.api.DisputeEvidenceDto;
import java.util.List;

/// The server's half of `DisputeApi`.
@Component
public class DisputeEndpoint implements DisputeApiServer {
    private final Disputes disputes;

    public DisputeEndpoint(Disputes disputes) {
        this.disputes = disputes;
    }

    @Override
    public List<DisputeDto> disputes(String storeId) throws Exception {
        return disputes.list(Caller.name(), storeId);
    }

    @Override
    public DisputeDto dispute(String storeId, String disputeId) throws Exception {
        return disputes.detail(Caller.name(), storeId, disputeId);
    }

    @Override
    public List<DisputeEvidenceDto> disputeEvidence(String storeId, String disputeId) throws Exception {
        return disputes.evidence(Caller.name(), storeId, disputeId);
    }

    @Override
    public List<DisputeEvidenceDto> addDisputeEvidence(String storeId, String disputeId, DisputeEvidenceDto body) throws Exception {
        return disputes.addEvidence(Caller.name(), storeId, disputeId, body);
    }

    @Override
    public DisputeDto submitDispute(String storeId, String disputeId) throws Exception {
        return disputes.submit(Caller.name(), storeId, disputeId);
    }

    @Override
    public DisputeDto acceptDispute(String storeId, String disputeId) throws Exception {
        return disputes.accept(Caller.name(), storeId, disputeId);
    }
}
