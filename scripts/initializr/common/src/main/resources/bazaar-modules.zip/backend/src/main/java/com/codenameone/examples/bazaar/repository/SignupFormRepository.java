package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.SignupForm;

import java.util.List;

/// Reads and writes [SignupForm] rows.
@Repository(entity = SignupForm.class, key = String.class)
public interface SignupFormRepository extends CrudRepository<SignupForm, String> {
    List<SignupForm> findByStoreIdOrderByCreatedAtDesc(String storeId);
}
