package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ProductViewEvent;
import java.time.Instant;
import java.util.List;

/// Reads and writes [ProductViewEvent] rows.
@Repository(entity = ProductViewEvent.class, key = String.class)
public interface ProductViewEventRepository extends CrudRepository<ProductViewEvent, String> {

    /// The views of a store in `[from, to)`, counted in SQL.
    @Query("select count(v) from ProductViewEvent v where v.storeId = :storeId "
            + "and v.viewedAt >= :from and v.viewedAt < :to")
    Long countViews(@Param("storeId") String storeId, @Param("from") Instant from,
            @Param("to") Instant to);

    /// The distinct visitors of a store in `[from, to)`, counted in SQL.
    @Query("select count(distinct v.visitor) from ProductViewEvent v where v.storeId = :storeId "
            + "and v.viewedAt >= :from and v.viewedAt < :to")
    Long countVisitors(@Param("storeId") String storeId, @Param("from") Instant from,
            @Param("to") Instant to);

    /// A store's views from `since` on.
    List<ProductViewEvent> findByStoreIdAndViewedAtGreaterThanEqual(String storeId, Instant since);
}
