package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.SellingPlan;
import java.util.List;

/// Reads and writes [SellingPlan] rows.
@Repository(entity = SellingPlan.class, key = String.class)
public interface SellingPlanRepository extends CrudRepository<SellingPlan, String> {
    List<SellingPlan> findByStoreIdOrderByCreatedAtAsc(String storeId);

    List<SellingPlan> findByProductId(String productId);
}
