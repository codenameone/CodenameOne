package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.StoreUpsell;

/// Reads and writes [StoreUpsell] rows.
@Repository(entity = StoreUpsell.class, key = String.class)
public interface StoreUpsellRepository extends CrudRepository<StoreUpsell, String> {
}
