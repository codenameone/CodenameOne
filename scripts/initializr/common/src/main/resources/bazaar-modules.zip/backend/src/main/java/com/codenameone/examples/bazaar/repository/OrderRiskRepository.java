package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.OrderRisk;
import java.time.Instant;
import java.util.List;

/// Reads and writes [OrderRisk] rows.
@Repository(entity = OrderRisk.class, key = String.class)
public interface OrderRiskRepository extends CrudRepository<OrderRisk, String> {
    List<OrderRisk> findByStoreIdOrderByCreatedAtDesc(String storeId);
    OrderRisk findByOrderId(String orderId);
    /// Moves a review from `from` to `to` only while it is still at `from`.
    @Modifying
    @Query("update OrderRisk r set r.status = :to, r.reviewedBy = :who, r.updatedAt = :at where r.id = :id and r.status = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to,
            @Param("who") String who, @Param("at") Instant at);
}
