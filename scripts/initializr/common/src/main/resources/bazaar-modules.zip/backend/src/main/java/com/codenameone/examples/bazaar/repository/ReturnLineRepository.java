package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ReturnLine;
import java.util.List;

/// Reads and writes [ReturnLine] rows.
@Repository(entity = ReturnLine.class, key = String.class)
public interface ReturnLineRepository extends CrudRepository<ReturnLine, String> {
    List<ReturnLine> findByReturnId(String returnId);
}
