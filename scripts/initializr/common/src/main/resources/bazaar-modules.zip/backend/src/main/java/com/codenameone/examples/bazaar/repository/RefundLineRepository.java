package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.RefundLine;
import java.util.List;

/// Reads and writes [RefundLine] rows.
@Repository(entity = RefundLine.class, key = String.class)
public interface RefundLineRepository extends CrudRepository<RefundLine, String> {
    List<RefundLine> findByRefundId(String refundId);
}
