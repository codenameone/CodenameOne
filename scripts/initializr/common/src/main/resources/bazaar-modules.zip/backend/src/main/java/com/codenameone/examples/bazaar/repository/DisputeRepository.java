package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Dispute;
import java.time.Instant;
import java.util.List;

/// Reads and writes [Dispute] rows.
@Repository(entity = Dispute.class, key = String.class)
public interface DisputeRepository extends CrudRepository<Dispute, String> {
    List<Dispute> findByStoreIdOrderByCreatedAtDesc(String storeId);
    Dispute findByEventId(String eventId);
    List<Dispute> findByOrderId(String orderId);
    /// Moves a dispute from `from` to `to` only while it is still at `from`.
    @Modifying
    @Query("update Dispute d set d.status = :to, d.updatedAt = :at where d.id = :id and d.status = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to,
            @Param("at") Instant at);
}
