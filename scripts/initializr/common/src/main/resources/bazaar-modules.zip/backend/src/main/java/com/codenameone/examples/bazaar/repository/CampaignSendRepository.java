package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CampaignSend;

import java.time.Instant;
import java.util.List;

/// Reads and writes [CampaignSend] rows.
@Repository(entity = CampaignSend.class, key = String.class)
public interface CampaignSendRepository extends CrudRepository<CampaignSend, String> {
    CampaignSend findByToken(String token);

    List<CampaignSend> findByCampaignId(String campaignId);

    List<CampaignSend> findByCampaignIdAndStatus(String campaignId, String status);

    CampaignSend findByCampaignIdAndCustomerId(String campaignId, String customerId);

    List<CampaignSend> findByStoreIdAndCustomerIdAndSentAtGreaterThanEqual(String storeId, String customerId, Instant since);

    long countByCampaignId(String campaignId);

    @Modifying
    @Query("update CampaignSend s set s.status = :to, s.sentAt = :at where s.id = :id and s.status = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to, @Param("at") Instant at);

    @Modifying
    @Query("update CampaignSend s set s.openedAt = :at where s.id = :id and s.openedAt = :never")
    int open(@Param("id") String id, @Param("at") Instant at, @Param("never") Instant never);

    @Modifying
    @Query("update CampaignSend s set s.clickedAt = :at where s.id = :id and s.clickedAt = :never")
    int click(@Param("id") String id, @Param("at") Instant at, @Param("never") Instant never);

    @Modifying
    @Query("update CampaignSend s set s.orderId = :orderId, s.revenueCents = :cents where s.id = :id "
            + "and s.orderId = ''")
    int attribute(@Param("id") String id, @Param("orderId") String orderId, @Param("cents") long cents);
}
