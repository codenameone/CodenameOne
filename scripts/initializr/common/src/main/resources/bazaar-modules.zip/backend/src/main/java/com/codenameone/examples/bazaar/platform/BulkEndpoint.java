package com.codenameone.examples.bazaar.platform;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.BulkApiServer;
import com.codenameone.examples.bazaar.api.BulkJobDto;

import java.util.List;

/// The server's half of `BulkApi`; [BulkJobs] checks the caller.
@Component
public class BulkEndpoint implements BulkApiServer {
    private final BulkJobs jobs;

    public BulkEndpoint(BulkJobs jobs) {
        this.jobs = jobs;
    }

    @Override
    public List<BulkJobDto> list(String storeId) throws Exception {
        return jobs.list(Caller.name(), storeId);
    }

    @Override
    public BulkJobDto start(String storeId, BulkJobDto job) throws Exception {
        return jobs.startAsStaff(Caller.name(), storeId, job);
    }

    @Override
    public BulkJobDto job(String storeId, String jobId) throws Exception {
        return jobs.job(Caller.name(), storeId, jobId);
    }
}
