package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.UrlRedirect;
import java.util.List;

/// Reads and writes [UrlRedirect] rows.
@Repository(entity = UrlRedirect.class, key = String.class)
public interface UrlRedirectRepository extends CrudRepository<UrlRedirect, String> {
    List<UrlRedirect> findByStoreIdOrderByFromPathAsc(String storeId);
    UrlRedirect findByStoreIdAndFromPath(String storeId, String fromPath);
}
