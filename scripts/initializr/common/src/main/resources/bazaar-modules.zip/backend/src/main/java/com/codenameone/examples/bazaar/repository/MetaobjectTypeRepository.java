package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MetaobjectType;
import java.util.List;

/// Reads and writes [MetaobjectType] rows.
@Repository(entity = MetaobjectType.class, key = String.class)
public interface MetaobjectTypeRepository extends CrudRepository<MetaobjectType, String> {
    List<MetaobjectType> findByStoreIdOrderByNameAsc(String storeId);
    MetaobjectType findByStoreIdAndHandle(String storeId, String handle);
}
