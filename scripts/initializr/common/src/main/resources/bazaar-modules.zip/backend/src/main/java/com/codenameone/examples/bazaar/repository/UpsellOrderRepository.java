package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.UpsellOrder;

/// Reads and writes [UpsellOrder] rows.
@Repository(entity = UpsellOrder.class, key = String.class)
public interface UpsellOrderRepository extends CrudRepository<UpsellOrder, String> {
}
