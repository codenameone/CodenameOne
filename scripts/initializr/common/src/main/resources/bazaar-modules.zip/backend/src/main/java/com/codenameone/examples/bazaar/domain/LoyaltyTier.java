package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A level of a loyalty programme, reached by spend or points in the last twelve months.
@Entity
public class LoyaltyTier {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(80)")
    private String name = "";

    @Column(nullable = false)
    private long threshold;

    @Column(nullable = false)
    private int memberBps;

    @Column(nullable = false)
    private boolean freeShipping;

    @Column(nullable = false)
    private int earlyAccessHours;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String colour = "";

    @Column(nullable = false)
    private int position;

    @Column(nullable = false, type = "VARCHAR(32)")
    private String discountId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String shippingDiscountId = "";

    public LoyaltyTier() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getThreshold() {
        return threshold;
    }

    public void setThreshold(long threshold) {
        this.threshold = threshold;
    }

    public int getMemberBps() {
        return memberBps;
    }

    public void setMemberBps(int memberBps) {
        this.memberBps = memberBps;
    }

    public boolean isFreeShipping() {
        return freeShipping;
    }

    public void setFreeShipping(boolean freeShipping) {
        this.freeShipping = freeShipping;
    }

    public int getEarlyAccessHours() {
        return earlyAccessHours;
    }

    public void setEarlyAccessHours(int earlyAccessHours) {
        this.earlyAccessHours = earlyAccessHours;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getDiscountId() {
        return discountId;
    }

    public void setDiscountId(String discountId) {
        this.discountId = discountId;
    }

    public String getShippingDiscountId() {
        return shippingDiscountId;
    }

    public void setShippingDiscountId(String shippingDiscountId) {
        this.shippingDiscountId = shippingDiscountId;
    }
}
