package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Supplier;
import java.util.List;

/// Reads and writes [Supplier] rows.
@Repository(entity = Supplier.class, key = String.class)
public interface SupplierRepository extends CrudRepository<Supplier, String> {
    List<Supplier> findByStoreIdOrderByNameAsc(String storeId);
}
