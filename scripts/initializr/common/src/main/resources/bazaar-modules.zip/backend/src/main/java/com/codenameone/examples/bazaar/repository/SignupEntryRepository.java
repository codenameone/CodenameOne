package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.SignupEntry;

import java.util.List;

/// Reads and writes [SignupEntry] rows.
@Repository(entity = SignupEntry.class, key = String.class)
public interface SignupEntryRepository extends CrudRepository<SignupEntry, String> {
    SignupEntry findByConfirmToken(String confirmToken);

    List<SignupEntry> findByFormIdOrderByCreatedAtDesc(String formId);

    List<SignupEntry> findByFormIdAndEmail(String formId, String email);

    long countByFormId(String formId);
}
