package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.PosPolicy;
import java.util.List;

/// Reads and writes [PosPolicy] rows.
@Repository(entity = PosPolicy.class, key = String.class)
public interface PosPolicyRepository extends CrudRepository<PosPolicy, String> {
    PosPolicy findByStoreId(String storeId);
}
