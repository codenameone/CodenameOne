package com.codenameone.examples.bazaar;

/// The roles an account can hold. Every account is a customer; working for a
/// store and administering are granted on top of that, and the
/// app offers a mode for each role the account holds.
public final class Roles {
    public static final String CUSTOMER = "CUSTOMER";
    public static final String ADMIN = "ADMIN";
    /// Works for a store on the service. Which store, and as what (owner,
    /// manager, cashier), is the store's staff list, not the role.
    public static final String MERCHANT = "MERCHANT";

    private Roles() {
    }
}
