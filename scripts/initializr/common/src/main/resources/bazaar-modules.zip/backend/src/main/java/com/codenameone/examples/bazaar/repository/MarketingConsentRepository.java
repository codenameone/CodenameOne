package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MarketingConsent;

import java.util.List;

/// Reads and writes [MarketingConsent] rows.
@Repository(entity = MarketingConsent.class, key = String.class)
public interface MarketingConsentRepository extends CrudRepository<MarketingConsent, String> {
    MarketingConsent findByStoreIdAndAddressAndChannel(String storeId, String address, String channel);

    List<MarketingConsent> findByStoreIdAndStatus(String storeId, String status);
}
