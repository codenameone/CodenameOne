package com.codenameone.examples.bazaar.account;

import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.Transactional;
import com.codename1.appkit.server.Text;
import com.codenameone.examples.bazaar.api.PreferencesDto;
import com.codenameone.examples.bazaar.domain.Preference;
import com.codenameone.examples.bazaar.domain.Profile;
import com.codenameone.examples.bazaar.pay.Payments;
import com.codenameone.examples.bazaar.repository.PreferenceRepository;
import com.codenameone.examples.bazaar.repository.ProfileRepository;

import java.io.IOException;

/// How one person wants the app: language, theme, units, what they are told
/// about, and what an order is paid with unless they say otherwise.
///
/// Kept on the server so that they follow the account from one phone to the
/// next. Two of them live elsewhere, because something else reads them: the
/// language is in the profile, where the admin sees it, and the default way to
/// pay is the mark on the saved card itself, so that removing a card cannot
/// leave a preference pointing at it.
@Component
public class Preferences {
    private static final String[] LANGUAGES = {"en", "es", "fr", "de", "he"};
    private static final String[] THEMES = {"system", "light", "dark"};
    private static final String[] UNITS = {"km", "mi"};

    private final ProfileRepository profiles;
    private final PreferenceRepository preferences;
    private final Payments payments;

    public Preferences(ProfileRepository profiles, PreferenceRepository preferences,
            Payments payments) {
        this.profiles = profiles;
        this.preferences = preferences;
        this.payments = payments;
    }

    @Transactional(readOnly = true)
    public PreferencesDto get(String username) throws IOException {
        Profile profile = profiles.findById(username);
        if (profile == null) {
            throw new ResponseStatusException(404, "No such account");
        }
        Preference row = preferences.findById(username);
        String language = profile.getLanguage();
        String method = payments.defaultMethod(username);
        if (row == null) {
            // What someone who never opened the settings gets. The theme is
            // empty, not "system": the device keeps the look it already has
            // (a Dark chosen there before signing in), as it keeps its language.
            return new PreferencesDto(language, "", UNITS[0], true, true, false, method);
        }
        return new PreferencesDto(language, row.getTheme(), row.getUnits(), row.isNotifyOrders(),
                row.isNotifyReceipts(), row.isNotifyPromotions(), method);
    }

    /// Saves all of them. Each is checked against the values it can take: these
    /// are words the server later acts on, not text to show back. One
    /// transaction, so a value that is refused leaves none of the others saved.
    @Transactional
    public PreferencesDto save(String username, PreferencesDto wanted) throws IOException {
        if (wanted == null) {
            throw new ResponseStatusException(400, "Nothing to save");
        }
        // First, before anything is read: two saves sent together for an
        // account with no row of settings yet would each find none and each
        // insert one, and the second insert fails on the key. The profile is
        // there from registration, so held, one save waits and finds the
        // other's row.
        profiles.hold(username);
        String theme = Text.oneOf(wanted.theme(), THEMES, THEMES[0], "the theme");
        String units = Text.oneOf(wanted.units(), UNITS, UNITS[0], "the units");
        String language = Text.oneOf(wanted.language(), LANGUAGES, LANGUAGES[0], "the language");
        String method = wanted.defaultPaymentMethodId() == null ? ""
                : wanted.defaultPaymentMethodId().trim();
        if (method.length() > 0 && !method.equals(payments.defaultMethod(username))) {
            // Answers 404 for a card that is not this user's, before anything
            // else is saved.
            payments.makeDefault(username, method);
        }
        // Read after the card was marked, not before: marking one may be a
        // statement over every card of the account, and what was read before
        // such a statement is no longer the session's to write.
        Profile profile = profiles.findById(username);
        if (profile == null) {
            throw new ResponseStatusException(404, "No such account");
        }
        profile.setLanguage(language);
        Preference row = preferences.findById(username);
        boolean unsaved = row == null;
        if (unsaved) {
            row = new Preference();
            row.setUsername(username);
        }
        row.setTheme(theme);
        row.setUnits(units);
        row.setNotifyOrders(wanted.notifyOrderUpdates());
        row.setNotifyReceipts(wanted.notifyReceipts());
        row.setNotifyPromotions(wanted.notifyPromotions());
        if (unsaved) {
            preferences.insert(row);
        }
        return get(username);
    }
}
