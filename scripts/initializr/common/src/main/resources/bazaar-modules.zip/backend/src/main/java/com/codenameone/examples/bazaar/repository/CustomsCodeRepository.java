package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CustomsCode;
import java.util.List;

/// Reads and writes [CustomsCode] rows.
@Repository(entity = CustomsCode.class, key = String.class)
public interface CustomsCodeRepository extends CrudRepository<CustomsCode, String> {
    List<CustomsCode> findByStoreId(String storeId);
    CustomsCode findByProductId(String productId);
    List<CustomsCode> findByProductIdIn(List<String> productIds);
}
