package com.codenameone.examples.bazaar.carrier;

import com.codenameone.examples.bazaar.api.RateQuoteDto;

import java.io.IOException;
import java.util.List;

/// The carrier a server gets when the one it was told to use cannot be set
/// up: every call fails with an `IOException` naming what to fix, as an outage
/// of the carrier would, and the problem is logged at start-up.
///
/// [EasyPostCarrier] without its key or webhook secret is one of these, so a
/// half-configured account never buys labels; see
/// [com.codenameone.examples.bazaar.Services#carrierProvider].
public class MisconfiguredCarrier implements CarrierProvider {
    private final String provider;
    private final String problem;

    public MisconfiguredCarrier(String provider, String problem) {
        this.provider = provider;
        this.problem = problem;
        System.err.println("[config] " + problem);
    }

    @Override
    public String name() {
        return provider;
    }

    @Override
    public List<RateQuoteDto> rates(Parcel parcel, Place from, Place to) throws IOException {
        throw fail();
    }

    @Override
    public Label buyLabel(Parcel parcel, Place from, Place to, String service, String reference)
            throws IOException {
        throw fail();
    }

    @Override
    public List<Scan> track(String trackingNumber, long shippedAt, long now, Place from, Place to)
            throws IOException {
        throw fail();
    }

    private IOException fail() {
        System.err.println("[config] " + problem);
        return new IOException("Shipping labels are unavailable: " + problem);
    }
}
