package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ProductPhoto;
import java.util.List;

/// Reads and writes [ProductPhoto] rows.
@Repository(entity = ProductPhoto.class, key = String.class)
public interface ProductPhotoRepository extends CrudRepository<ProductPhoto, String> {
    List<ProductPhoto> findByProductIdOrderByPositionAsc(String productId);

    int deleteByProductId(String productId);

    List<ProductPhoto> findByPhotoId(String photoId);
}
