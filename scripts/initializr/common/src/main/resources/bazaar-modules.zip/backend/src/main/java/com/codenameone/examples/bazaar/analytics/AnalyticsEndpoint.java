package com.codenameone.examples.bazaar.analytics;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.AnalyticsApiServer;
import com.codenameone.examples.bazaar.api.AnalyticsDto;
import com.codenameone.examples.bazaar.api.FunnelStepDto;
import com.codenameone.examples.bazaar.api.InsightsDto;

import java.util.List;

/// The server's half of `AnalyticsApi`; [Analytics] checks the caller.
@Component
public class AnalyticsEndpoint implements AnalyticsApiServer {
    private final Analytics analytics;

    public AnalyticsEndpoint(Analytics analytics) {
        this.analytics = analytics;
    }

    @Override
    public AnalyticsDto dashboard(String storeId, String from, String to) throws Exception {
        return analytics.dashboard(Caller.name(), storeId, millis(from), millis(to));
    }

    @Override
    public List<FunnelStepDto> funnel(String storeId, String from, String to) throws Exception {
        return analytics.funnel(Caller.name(), storeId, millis(from), millis(to));
    }

    @Override
    public InsightsDto insights(String storeId, String from, String to) throws Exception {
        return analytics.insights(Caller.name(), storeId, millis(from), millis(to));
    }

    static long millis(String text) {
        if (text == null || text.trim().length() == 0) {
            return 0;
        }
        try {
            return Math.max(0, Long.parseLong(text.trim()));
        } catch (NumberFormatException bad) {
            throw new ResponseStatusException(400, "A time is milliseconds since 1970");
        }
    }
}
