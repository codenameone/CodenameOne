package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TransferLine;
import java.util.List;

/// Reads and writes [TransferLine] rows.
@Repository(entity = TransferLine.class, key = String.class)
public interface TransferLineRepository extends CrudRepository<TransferLine, String> {
    List<TransferLine> findByTransferId(String transferId);
}
