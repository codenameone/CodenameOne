package com.codenameone.examples.bazaar.channel;

import com.codenameone.examples.bazaar.ops.Amounts;

/// Decimal money strings (`"12.3"`, `"12.34"`, `"1250"` for yen) to minor
/// units of their currency and back, without floating point: marketplaces
/// answer prices as decimal strings. The decimals are the currency's own
/// ([Amounts#digits]).
public final class Cents {
    private Cents() {
    }

    /// Minor units of a decimal string in `currency`; decimals past the
    /// currency's own are cut. 0 when it is not a number or would not fit.
    static long parse(Object value, String currency) {
        return Amounts.parse(value == null ? "" : String.valueOf(value), currency);
    }

    /// `1234, "USD"` as `"12.34"`, `1234, "JPY"` as `"1234"`.
    public static String format(long minor, String currency) {
        return Amounts.plain(minor, currency);
    }
}
