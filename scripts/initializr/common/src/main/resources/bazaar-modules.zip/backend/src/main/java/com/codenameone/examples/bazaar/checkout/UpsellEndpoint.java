package com.codenameone.examples.bazaar.checkout;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.BuyNowDto;
import com.codenameone.examples.bazaar.api.OrderDto;
import com.codenameone.examples.bazaar.api.UpsellApiServer;
import com.codenameone.examples.bazaar.api.UpsellDto;

/// The server's half of `UpsellApi`.
@Component
public class UpsellEndpoint implements UpsellApiServer {
    private final Upsells upsells;

    public UpsellEndpoint(Upsells upsells) {
        this.upsells = upsells;
    }

    @Override
    public UpsellDto upsell(String storeId) throws Exception {
        return upsells.get(Caller.name(), storeId);
    }

    @Override
    public UpsellDto setUpsell(String storeId, UpsellDto upsell) throws Exception {
        return upsells.set(Caller.name(), storeId, upsell);
    }

    @Override
    public UpsellDto offer(String storeId, String orderId) throws Exception {
        UpsellDto o = upsells.offer(Caller.name(), storeId, orderId);
        return o == null ? new UpsellDto("", "", 0, 0) : o;
    }

    @Override
    public OrderDto accept(String storeId, String orderId) throws Exception {
        return upsells.accept(Caller.name(), storeId, orderId);
    }

    @Override
    public OrderDto buyNow(String storeId, BuyNowDto buy) throws Exception {
        return upsells.buyNow(Caller.name(), storeId, buy);
    }
}
