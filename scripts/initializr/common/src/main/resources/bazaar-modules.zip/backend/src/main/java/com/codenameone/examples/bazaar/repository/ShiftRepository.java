package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Shift;
import java.util.List;

/// Reads and writes [Shift] rows.
@Repository(entity = Shift.class, key = String.class)
public interface ShiftRepository extends CrudRepository<Shift, String> {
    List<Shift> findByRegisterIdOrderByOpenedAtDesc(String registerId);

    List<Shift> findByStoreIdOrderByOpenedAtDesc(String storeId);

    /// Adds to a shift's running totals in one statement, so a sale and a
    /// cash move landing at once both count. `drawer` is what the cash
    /// expected in the drawer moves by.
    @Modifying(clearAutomatically = true)
    @Query("update Shift s set s.cashSalesCents = s.cashSalesCents + :cash, "
            + "s.cardSalesCents = s.cardSalesCents + :card, "
            + "s.otherSalesCents = s.otherSalesCents + :other, "
            + "s.cashMovesCents = s.cashMovesCents + :moves, "
            + "s.expectedCents = s.expectedCents + :drawer, "
            + "s.salesCount = s.salesCount + :sales where s.id = :id")
    int addTotals(@Param("id") String id, @Param("cash") long cash, @Param("card") long card,
            @Param("other") long other, @Param("moves") long moves, @Param("drawer") long drawer,
            @Param("sales") int sales);

    /// Closes an open shift in one statement, writing only the count, note and
    /// status: a sale's addTotals landing meanwhile is kept, and of two
    /// closes only one finds the shift still open. Answers the rows changed.
    @Modifying(clearAutomatically = true)
    @Query("update Shift s set s.countedCents = :counted, s.note = :note, "
            + "s.status = :closed, s.closedAt = :at where s.id = :id and s.status = :open")
    int close(@Param("id") String id, @Param("counted") long counted, @Param("note") String note,
            @Param("closed") String closed, @Param("at") java.time.Instant at,
            @Param("open") String open);
}
