package com.codenameone.examples.bazaar.admin;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.PreAuthorize;
import com.codenameone.examples.bazaar.api.PlatformApiServer;
import com.codenameone.examples.bazaar.api.PlatformStatsDto;
import com.codenameone.examples.bazaar.api.StoreStatsDto;
import com.codenameone.examples.bazaar.api.StoreStatusDto;

/// The server's half of `PlatformApi`; admins only, as all of `/api/admin`.
@Component
@PreAuthorize("hasRole('ADMIN')")
public class PlatformEndpoint implements PlatformApiServer {
    private final Platform platform;

    public PlatformEndpoint(Platform platform) {
        this.platform = platform;
    }

    @Override
    public PlatformStatsDto stats() throws Exception {
        return platform.stats();
    }

    @Override
    public StoreStatsDto setStatus(String storeId, StoreStatusDto body) throws Exception {
        return platform.setStatus(Caller.name(), storeId, body);
    }
}
