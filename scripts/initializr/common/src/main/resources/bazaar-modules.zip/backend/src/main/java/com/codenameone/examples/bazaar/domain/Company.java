package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A business customer: its VAT id, payment terms and price list.
@Entity
public class Company {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(120)")
    private String name = "";

    @Column(nullable = false, type = "VARCHAR(20)")
    private String vatId = "";

    @Column(nullable = false)
    private int termsDays;

    @Column(nullable = false, type = "VARCHAR(32)")
    private String priceListId = "";

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    /// The last VIES outcome for the VAT id: format, verified, invalid or unverified.
    @Column(nullable = false, type = "VARCHAR(16)")
    private String vatStatus = "";

    /// The trader VIES named, or empty.
    @Column(nullable = false, type = "VARCHAR(200)")
    private String vatName = "";

    /// The consultation reference VIES gave, or empty.
    @Column(nullable = false, type = "VARCHAR(64)")
    private String vatReference = "";

    /// When VIES was asked, in epoch milliseconds; 0 for never.
    @Column(nullable = false)
    private long vatCheckedAt;

    public Company() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVatId() {
        return vatId;
    }

    public void setVatId(String vatId) {
        this.vatId = vatId;
    }

    public int getTermsDays() {
        return termsDays;
    }

    public void setTermsDays(int termsDays) {
        this.termsDays = termsDays;
    }

    public String getPriceListId() {
        return priceListId;
    }

    public void setPriceListId(String priceListId) {
        this.priceListId = priceListId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public String getVatStatus() {
        return vatStatus;
    }

    public void setVatStatus(String vatStatus) {
        this.vatStatus = vatStatus;
    }

    public String getVatName() {
        return vatName;
    }

    public void setVatName(String vatName) {
        this.vatName = vatName;
    }

    public String getVatReference() {
        return vatReference;
    }

    public void setVatReference(String vatReference) {
        this.vatReference = vatReference;
    }

    public long getVatCheckedAt() {
        return vatCheckedAt;
    }

    public void setVatCheckedAt(long vatCheckedAt) {
        this.vatCheckedAt = vatCheckedAt;
    }
}
