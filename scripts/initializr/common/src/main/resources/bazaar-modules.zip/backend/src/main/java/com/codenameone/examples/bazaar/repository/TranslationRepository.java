package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Translation;
import java.util.List;

/// Reads and writes [Translation] rows.
@Repository(entity = Translation.class, key = String.class)
public interface TranslationRepository extends CrudRepository<Translation, String> {
    List<Translation> findByStoreIdAndKindAndRefId(String storeId, String kind, String refId);
    List<Translation> findByStoreIdAndLocale(String storeId, String locale);
    List<Translation> findByStoreIdOrderByLocaleAsc(String storeId);
    Translation findByStoreIdAndKindAndRefIdAndLocaleAndField(String storeId, String kind, String refId,
            String locale, String field);
}
