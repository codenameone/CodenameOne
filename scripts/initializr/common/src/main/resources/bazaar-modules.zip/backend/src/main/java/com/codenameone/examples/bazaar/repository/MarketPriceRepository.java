package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MarketPrice;
import java.util.List;

/// Reads and writes [MarketPrice] rows.
@Repository(entity = MarketPrice.class, key = String.class)
public interface MarketPriceRepository extends CrudRepository<MarketPrice, String> {
    List<MarketPrice> findByMarketId(String marketId);
    MarketPrice findByMarketIdAndVariantId(String marketId, String variantId);
    int deleteByMarketId(String marketId);
}
