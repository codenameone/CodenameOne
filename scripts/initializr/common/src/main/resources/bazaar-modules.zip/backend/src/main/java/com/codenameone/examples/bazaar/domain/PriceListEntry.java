package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A variant's fixed price and quantity rules on a price list.
@Entity
public class PriceListEntry {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String priceListId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String variantId = "";

    @Column(nullable = false)
    private long fixedCents;

    @Column(nullable = false)
    private int minQty;

    @Column(nullable = false)
    private int maxQty;

    @Column(nullable = false)
    private int stepQty;

    public PriceListEntry() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getPriceListId() {
        return priceListId;
    }

    public void setPriceListId(String priceListId) {
        this.priceListId = priceListId;
    }

    public String getVariantId() {
        return variantId;
    }

    public void setVariantId(String variantId) {
        this.variantId = variantId;
    }

    public long getFixedCents() {
        return fixedCents;
    }

    public void setFixedCents(long fixedCents) {
        this.fixedCents = fixedCents;
    }

    public int getMinQty() {
        return minQty;
    }

    public void setMinQty(int minQty) {
        this.minQty = minQty;
    }

    public int getMaxQty() {
        return maxQty;
    }

    public void setMaxQty(int maxQty) {
        this.maxQty = maxQty;
    }

    public int getStepQty() {
        return stepQty;
    }

    public void setStepQty(int stepQty) {
        this.stepQty = stepQty;
    }
}
