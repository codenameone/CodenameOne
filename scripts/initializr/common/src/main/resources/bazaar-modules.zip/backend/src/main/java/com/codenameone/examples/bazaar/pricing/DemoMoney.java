package com.codenameone.examples.bazaar.pricing;

import com.codenameone.examples.bazaar.market.FixedExchangeRates;
import com.codenameone.examples.bazaar.ops.Amounts;

/// The demo's seed amounts, written once in US cents, in a store's own
/// currency: a store selling in yen gets yen prices, shipping rates and
/// thresholds of the same size, not 7500 yen for "$75". Converted at the
/// fixed demo table ([FixedExchangeRates]), half to even.
public final class DemoMoney {
    private DemoMoney() {
    }

    /// `usdCents` in minor units of `currency`; unchanged for US dollars and
    /// for a currency the demo table does not have.
    public static long local(long usdCents, String currency) {
        long rate = new FixedExchangeRates().rateMicros("USD", currency);
        if (rate <= 0 || "USD".equalsIgnoreCase(currency == null ? "" : currency.trim())) {
            return usdCents;
        }
        return Amounts.convert(usdCents, "USD", currency, rate);
    }
}
