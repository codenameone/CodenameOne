package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.StoreFollow;
import java.util.List;

/// Reads and writes [StoreFollow] rows.
@Repository(entity = StoreFollow.class, key = String.class)
public interface StoreFollowRepository extends CrudRepository<StoreFollow, String> {
    List<StoreFollow> findByUsernameOrderByCreatedAtDesc(String username);

    StoreFollow findByUsernameAndStoreId(String username, String storeId);
}
