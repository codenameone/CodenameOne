package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.StockTransfer;
import java.util.List;

/// Reads and writes [StockTransfer] rows.
@Repository(entity = StockTransfer.class, key = String.class)
public interface StockTransferRepository extends CrudRepository<StockTransfer, String> {
    List<StockTransfer> findByStoreIdOrderByCreatedAtDesc(String storeId);
}
