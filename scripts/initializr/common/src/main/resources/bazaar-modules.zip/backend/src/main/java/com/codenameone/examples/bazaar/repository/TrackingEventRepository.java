package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TrackingEvent;
import java.util.List;

/// Reads and writes [TrackingEvent] rows.
@Repository(entity = TrackingEvent.class, key = String.class)
public interface TrackingEventRepository extends CrudRepository<TrackingEvent, String> {
    List<TrackingEvent> findByFulfillmentIdOrderByCreatedAtAsc(String fulfillmentId);
}
