package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.NetTerm;
import java.util.List;

/// Reads and writes [NetTerm] rows.
@Repository(entity = NetTerm.class, key = String.class)
public interface NetTermRepository extends CrudRepository<NetTerm, String> {
    List<NetTerm> findByStoreIdOrderByDueAtAsc(String storeId);
}
