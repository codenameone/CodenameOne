package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.SaleClaim;

import java.util.List;

/// Reads and writes [SaleClaim] rows.
@Repository(entity = SaleClaim.class, key = String.class)
public interface SaleClaimRepository extends CrudRepository<SaleClaim, String> {
    List<SaleClaim> findByOrderId(String orderId);

    @Modifying
    @Query("update SaleClaim c set c.released = true where c.id = :id and c.released = false")
    int release(@Param("id") String id);
}
