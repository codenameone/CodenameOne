package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CheckoutFailure;
import java.time.Instant;

/// Reads and writes [CheckoutFailure] rows.
@Repository(entity = CheckoutFailure.class, key = String.class)
public interface CheckoutFailureRepository extends CrudRepository<CheckoutFailure, String> {
    long countByStoreIdAndUsernameAndCreatedAtGreaterThanEqual(String storeId, String username,
            Instant since);
}
