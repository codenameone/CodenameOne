package com.codenameone.examples.bazaar.journey;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.JourneyApiServer;
import com.codenameone.examples.bazaar.api.JourneyDto;
import com.codenameone.examples.bazaar.api.JourneyNodeStatDto;
import com.codenameone.examples.bazaar.api.NodeTypeDto;

import java.util.List;

/// The server's half of `JourneyApi`.
@Component
public class JourneyEndpoint implements JourneyApiServer {
    private final Journeys journeys;

    public JourneyEndpoint(Journeys journeys) {
        this.journeys = journeys;
    }

    @Override
    public List<NodeTypeDto> catalog(String storeId) throws Exception {
        return journeys.catalog(Caller.name(), storeId);
    }

    @Override
    public List<JourneyDto> list(String storeId) throws Exception {
        return journeys.list(Caller.name(), storeId);
    }

    @Override
    public JourneyDto get(String storeId, String journeyId) throws Exception {
        return journeys.get(Caller.name(), storeId, journeyId);
    }

    @Override
    public JourneyDto create(String storeId, JourneyDto body) throws Exception {
        return journeys.save(Caller.name(), storeId, null, body);
    }

    @Override
    public JourneyDto save(String storeId, String journeyId, JourneyDto body) throws Exception {
        return journeys.save(Caller.name(), storeId, journeyId, body);
    }

    @Override
    public List<JourneyNodeStatDto> stats(String storeId, String journeyId) throws Exception {
        return journeys.stats(Caller.name(), storeId, journeyId);
    }
}
