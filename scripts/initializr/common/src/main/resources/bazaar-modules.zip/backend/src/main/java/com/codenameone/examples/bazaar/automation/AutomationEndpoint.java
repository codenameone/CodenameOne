package com.codenameone.examples.bazaar.automation;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.AuditDto;
import com.codenameone.examples.bazaar.api.AutomationApiServer;
import com.codenameone.examples.bazaar.api.AutomationDto;
import com.codenameone.examples.bazaar.api.NodeTypeDto;
import com.codenameone.examples.bazaar.api.ValidationDto;

import java.util.List;

/// The server's half of `AutomationApi`; [Automations] checks the caller.
@Component
public class AutomationEndpoint implements AutomationApiServer {
    private final Automations automations;

    public AutomationEndpoint(Automations automations) {
        this.automations = automations;
    }

    @Override
    public List<NodeTypeDto> catalog(String storeId) throws Exception {
        return automations.catalog(Caller.name(), storeId);
    }

    @Override
    public List<AutomationDto> list(String storeId) throws Exception {
        return automations.list(Caller.name(), storeId);
    }

    @Override
    public AutomationDto get(String storeId, String automationId) throws Exception {
        return automations.get(Caller.name(), storeId, automationId);
    }

    @Override
    public AutomationDto create(String storeId, AutomationDto automation) throws Exception {
        return automations.create(Caller.name(), storeId, automation);
    }

    @Override
    public AutomationDto save(String storeId, String automationId, AutomationDto automation)
            throws Exception {
        return automations.save(Caller.name(), storeId, automationId, automation);
    }

    @Override
    public List<AutomationDto> remove(String storeId, String automationId) throws Exception {
        return automations.remove(Caller.name(), storeId, automationId);
    }

    @Override
    public ValidationDto validate(String storeId, AutomationDto automation) throws Exception {
        return automations.validate(Caller.name(), storeId, automation);
    }

    @Override
    public List<AuditDto> activity(String storeId, String automationId) throws Exception {
        return automations.activity(Caller.name(), storeId, automationId);
    }
}
