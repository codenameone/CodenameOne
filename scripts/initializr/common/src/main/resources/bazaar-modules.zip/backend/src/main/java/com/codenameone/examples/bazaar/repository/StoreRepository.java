package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Store;
import java.util.List;

/// Reads and writes [Store] rows.
@Repository(entity = Store.class, key = String.class)
public interface StoreRepository extends CrudRepository<Store, String> {
    Store findByHandle(String handle);

    Store findByCustomDomain(String customDomain);

    List<Store> findByStatusOrderByNameAsc(String status);

    List<Store> findByStatusNotOrderByNameAsc(String status);

    List<Store> findByOwnerUsernameOrderByNameAsc(String ownerUsername);
}
