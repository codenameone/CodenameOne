package com.codenameone.examples.bazaar.giftcard;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.GiftCardApiServer;
import com.codenameone.examples.bazaar.api.GiftCardBalanceDto;
import com.codenameone.examples.bazaar.api.GiftCardDto;

import java.util.List;

/// The server's half of `GiftCardApi`.
@Component
public class GiftCardEndpoint implements GiftCardApiServer {
    private final GiftCards cards;

    public GiftCardEndpoint(GiftCards cards) {
        this.cards = cards;
    }

    @Override
    public List<GiftCardDto> list(String storeId) throws Exception {
        return cards.list(Caller.name(), storeId);
    }

    @Override
    public GiftCardDto issue(String storeId, GiftCardDto body) throws Exception {
        return cards.issue(Caller.name(), storeId, body);
    }

    @Override
    public GiftCardDto disable(String storeId, String cardId) throws Exception {
        return cards.disable(Caller.name(), storeId, cardId);
    }

    @Override
    public GiftCardBalanceDto balance(String code) throws Exception {
        return cards.balance(code);
    }
}
