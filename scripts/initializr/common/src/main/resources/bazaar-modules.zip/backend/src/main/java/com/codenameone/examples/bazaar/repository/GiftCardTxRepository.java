package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.GiftCardTx;
import java.util.List;

/// Reads and writes [GiftCardTx] rows.
@Repository(entity = GiftCardTx.class, key = String.class)
public interface GiftCardTxRepository extends CrudRepository<GiftCardTx, String> {
    List<GiftCardTx> findByGiftCardIdOrderByCreatedAtAsc(String giftCardId);

    List<GiftCardTx> findByOrderId(String orderId);
}
