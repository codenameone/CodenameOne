package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Company;
import java.util.List;

/// Reads and writes [Company] rows.
@Repository(entity = Company.class, key = String.class)
public interface CompanyRepository extends CrudRepository<Company, String> {
    List<Company> findByStoreIdOrderByCreatedAtAsc(String storeId);
}
