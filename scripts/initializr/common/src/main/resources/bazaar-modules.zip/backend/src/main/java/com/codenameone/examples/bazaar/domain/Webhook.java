package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// An address told, by a signed POST, when something happens in a store.
@Entity
public class Webhook {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String topic = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String url = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String secret = "";

    @Column(nullable = false)
    private boolean active;

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    /// The app installation that subscribed this hook, or empty for one the
    /// store's staff made. An app's hooks are signed with the app's key and
    /// are neither listed to nor changed by staff.
    @Column(nullable = false, type = "VARCHAR(32)")
    private String appInstallationId = "";

    public Webhook() {
    }

    public String getAppInstallationId() {
        return appInstallationId;
    }

    public void setAppInstallationId(String appInstallationId) {
        this.appInstallationId = appInstallationId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
