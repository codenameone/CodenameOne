package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.LoyaltyProgram;

import java.util.List;

/// Reads and writes [LoyaltyProgram] rows.
@Repository(entity = LoyaltyProgram.class, key = String.class)
public interface LoyaltyProgramRepository extends CrudRepository<LoyaltyProgram, String> {
    LoyaltyProgram findByStoreId(String storeId);

    List<LoyaltyProgram> findByActive(boolean active);
}
