package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Journey;

import java.util.List;

/// Reads and writes [Journey] rows.
@Repository(entity = Journey.class, key = String.class)
public interface JourneyRepository extends CrudRepository<Journey, String> {
    List<Journey> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<Journey> findByStatus(String status);
}
