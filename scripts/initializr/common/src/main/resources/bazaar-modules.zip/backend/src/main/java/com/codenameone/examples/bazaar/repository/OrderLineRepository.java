package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.OrderLine;
import java.util.List;

/// Reads and writes [OrderLine] rows.
@Repository(entity = OrderLine.class, key = String.class)
public interface OrderLineRepository extends CrudRepository<OrderLine, String> {
    List<OrderLine> findByOrderId(String orderId);

    List<OrderLine> findByOrderIdIn(List<String> orderIds);

    void deleteByOrderId(String orderId);
}
