package com.codenameone.examples.bazaar.pos;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.ApprovalDto;
import com.codenameone.examples.bazaar.api.ApprovalRequestDto;
import com.codenameone.examples.bazaar.api.CommissionDto;
import com.codenameone.examples.bazaar.api.ParkedCartDto;
import com.codenameone.examples.bazaar.api.PosGridDto;
import com.codenameone.examples.bazaar.api.PosPolicyDto;
import com.codenameone.examples.bazaar.api.PosToolsApiServer;
import com.codenameone.examples.bazaar.api.StaffRateDto;
import java.util.List;

/// The server's half of `PosToolsApi`.
@Component
public class PosToolsEndpoint implements PosToolsApiServer {
    private final PosTools tools;

    public PosToolsEndpoint(PosTools tools) {
        this.tools = tools;
    }

    @Override
    public PosPolicyDto policy(String storeId) throws Exception {
        return tools.policy(Caller.name(), storeId);
    }

    @Override
    public PosPolicyDto savePolicy(String storeId, PosPolicyDto body) throws Exception {
        return tools.savePolicy(Caller.name(), storeId, body);
    }

    @Override
    public List<StaffRateDto> staffRates(String storeId) throws Exception {
        return tools.staffRates(Caller.name(), storeId);
    }

    @Override
    public StaffRateDto saveStaffRate(String storeId, StaffRateDto body) throws Exception {
        return tools.saveStaffRate(Caller.name(), storeId, body);
    }

    @Override
    public List<CommissionDto> commissions(String storeId, String from, String to)
            throws Exception {
        return tools.commissions(Caller.name(), storeId, from, to);
    }

    @Override
    public ApprovalDto approve(String storeId, String registerId, ApprovalRequestDto body)
            throws Exception {
        return tools.approve(Caller.name(), storeId, registerId, body);
    }

    @Override
    public List<ParkedCartDto> parked(String storeId, String registerId) throws Exception {
        return tools.parked(Caller.name(), storeId, registerId);
    }

    @Override
    public ParkedCartDto park(String storeId, String registerId, ParkedCartDto body)
            throws Exception {
        return tools.park(Caller.name(), storeId, registerId, body);
    }

    @Override
    public ParkedCartDto resume(String storeId, String registerId, String parkedId)
            throws Exception {
        return tools.resume(Caller.name(), storeId, registerId, parkedId);
    }

    @Override
    public ParkedCartDto discard(String storeId, String registerId, String parkedId)
            throws Exception {
        return tools.discard(Caller.name(), storeId, registerId, parkedId);
    }

    @Override
    public PosGridDto grid(String storeId, String locationId) throws Exception {
        return tools.grid(Caller.name(), storeId, locationId);
    }

    @Override
    public PosGridDto saveGrid(String storeId, String locationId, PosGridDto body)
            throws Exception {
        return tools.saveGrid(Caller.name(), storeId, locationId, body);
    }
}
