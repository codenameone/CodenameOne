package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.DisputeEvidence;
import java.util.List;

/// Reads and writes [DisputeEvidence] rows.
@Repository(entity = DisputeEvidence.class, key = String.class)
public interface DisputeEvidenceRepository extends CrudRepository<DisputeEvidence, String> {
    List<DisputeEvidence> findByDisputeIdOrderByCreatedAtAsc(String disputeId);
}
