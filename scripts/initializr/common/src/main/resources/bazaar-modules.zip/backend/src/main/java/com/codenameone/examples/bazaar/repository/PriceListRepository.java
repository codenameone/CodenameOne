package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.PriceList;
import java.util.List;

/// Reads and writes [PriceList] rows.
@Repository(entity = PriceList.class, key = String.class)
public interface PriceListRepository extends CrudRepository<PriceList, String> {
    List<PriceList> findByStoreIdOrderByCreatedAtAsc(String storeId);
}
