package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.GridTile;
import java.util.List;

/// Reads and writes [GridTile] rows.
@Repository(entity = GridTile.class, key = String.class)
public interface GridTileRepository extends CrudRepository<GridTile, String> {
    List<GridTile> findByStoreIdAndLocationIdOrderByPositionAsc(String storeId, String locationId);

    int deleteByStoreIdAndLocationId(String storeId, String locationId);
}
