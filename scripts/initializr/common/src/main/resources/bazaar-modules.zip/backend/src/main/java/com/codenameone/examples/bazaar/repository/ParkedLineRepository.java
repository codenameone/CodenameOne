package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.ParkedLine;
import java.util.List;

/// Reads and writes [ParkedLine] rows.
@Repository(entity = ParkedLine.class, key = String.class)
public interface ParkedLineRepository extends CrudRepository<ParkedLine, String> {
    List<ParkedLine> findByParkedIdOrderByPositionAsc(String parkedId);
}
