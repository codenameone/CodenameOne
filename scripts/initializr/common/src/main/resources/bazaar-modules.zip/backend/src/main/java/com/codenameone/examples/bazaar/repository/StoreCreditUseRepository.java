package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.StoreCreditUse;
import java.time.Instant;
import java.util.List;

/// Reads and writes [StoreCreditUse] rows.
@Repository(entity = StoreCreditUse.class, key = String.class)
public interface StoreCreditUseRepository extends CrudRepository<StoreCreditUse, String> {

    List<StoreCreditUse> findByOrderId(String orderId);

    @Modifying(clearAutomatically = true)
    @Query("update StoreCreditUse u set u.customerId = :to where u.customerId = :from")
    int moveAll(@Param("from") String from, @Param("to") String to);
}
