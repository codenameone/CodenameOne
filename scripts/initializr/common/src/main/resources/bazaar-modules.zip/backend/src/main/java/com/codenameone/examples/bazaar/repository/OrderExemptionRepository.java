package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.OrderExemption;
import java.util.List;

/// Reads and writes [OrderExemption] rows.
@Repository(entity = OrderExemption.class, key = String.class)
public interface OrderExemptionRepository extends CrudRepository<OrderExemption, String> {
    List<OrderExemption> findByStoreId(String storeId);
    OrderExemption findByOrderId(String orderId);
}
