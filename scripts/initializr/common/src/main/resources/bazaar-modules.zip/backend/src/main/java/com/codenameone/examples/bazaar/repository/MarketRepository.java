package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Market;
import java.util.List;

/// Reads and writes [Market] rows.
@Repository(entity = Market.class, key = String.class)
public interface MarketRepository extends CrudRepository<Market, String> {
    List<Market> findByStoreIdOrderByPositionAsc(String storeId);
    List<Market> findByFxSource(String fxSource);
    Market findByStoreIdAndCode(String storeId, String code);
}
