package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MetafieldValue;
import java.util.List;

/// Reads and writes [MetafieldValue] rows.
@Repository(entity = MetafieldValue.class, key = String.class)
public interface MetafieldValueRepository extends CrudRepository<MetafieldValue, String> {
    List<MetafieldValue> findByStoreIdAndOwnerId(String storeId, String ownerId);
    MetafieldValue findByDefIdAndOwnerId(String defId, String ownerId);
    List<MetafieldValue> findByDefId(String defId);
}
