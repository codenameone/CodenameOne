package com.codenameone.examples.bazaar.channel;

import com.codenameone.examples.bazaar.marketing.Tokens;
import java.io.IOException;

/// `sha256=<hex>` HMAC signatures over a raw notification body, compared in
/// constant time. An empty secret verifies nothing.
final class SignedBodies {
    private SignedBodies() {
    }

    static boolean verify(String secret, byte[] body, String signature) {
        if (secret == null || secret.length() == 0 || body == null || signature == null
                || !signature.startsWith("sha256=")) {
            return false;
        }
        try {
            return Tokens.verify(secret, new String(body, "UTF-8"), signature.substring(7));
        } catch (IOException e) {
            return false;
        }
    }
}
