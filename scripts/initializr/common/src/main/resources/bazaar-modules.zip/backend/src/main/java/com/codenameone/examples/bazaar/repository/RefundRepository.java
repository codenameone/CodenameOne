package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Refund;
import java.util.List;

/// Reads and writes [Refund] rows.
@Repository(entity = Refund.class, key = String.class)
public interface RefundRepository extends CrudRepository<Refund, String> {
    List<Refund> findByOrderId(String orderId);

    List<Refund> findByOrderIdIn(List<String> orderIds);
}
