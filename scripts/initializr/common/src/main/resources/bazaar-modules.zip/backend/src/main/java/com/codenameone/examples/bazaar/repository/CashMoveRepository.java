package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CashMove;
import java.util.List;

/// Reads and writes [CashMove] rows.
@Repository(entity = CashMove.class, key = String.class)
public interface CashMoveRepository extends CrudRepository<CashMove, String> {
    List<CashMove> findByShiftIdOrderByCreatedAtAsc(String shiftId);
}
