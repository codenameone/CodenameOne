package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ProductTrial;
import java.util.List;

/// Reads and writes [ProductTrial] rows.
@Repository(entity = ProductTrial.class, key = String.class)
public interface ProductTrialRepository extends CrudRepository<ProductTrial, String> {
    List<ProductTrial> findByStoreId(String storeId);
}
