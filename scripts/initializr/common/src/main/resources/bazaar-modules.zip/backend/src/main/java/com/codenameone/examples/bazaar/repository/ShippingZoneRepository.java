package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ShippingZone;
import java.util.List;

/// Reads and writes [ShippingZone] rows.
@Repository(entity = ShippingZone.class, key = String.class)
public interface ShippingZoneRepository extends CrudRepository<ShippingZone, String> {
    List<ShippingZone> findByStoreIdOrderByPositionAsc(String storeId);
}
