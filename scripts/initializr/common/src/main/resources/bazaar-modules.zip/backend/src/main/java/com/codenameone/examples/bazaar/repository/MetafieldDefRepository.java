package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.MetafieldDef;
import java.util.List;

/// Reads and writes [MetafieldDef] rows.
@Repository(entity = MetafieldDef.class, key = String.class)
public interface MetafieldDefRepository extends CrudRepository<MetafieldDef, String> {
    List<MetafieldDef> findByStoreIdOrderByPositionAsc(String storeId);
    List<MetafieldDef> findByStoreIdAndOwnerKindOrderByPositionAsc(String storeId, String ownerKind);
    MetafieldDef findByStoreIdAndOwnerKindAndFieldKey(String storeId, String ownerKind, String fieldKey);
}
