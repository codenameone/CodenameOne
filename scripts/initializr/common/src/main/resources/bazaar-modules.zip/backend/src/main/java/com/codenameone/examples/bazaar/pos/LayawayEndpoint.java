package com.codenameone.examples.bazaar.pos;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.LayawayApiServer;
import com.codenameone.examples.bazaar.api.LayawayCancelDto;
import com.codenameone.examples.bazaar.api.LayawayDto;
import com.codenameone.examples.bazaar.api.LayawayRequestDto;
import com.codenameone.examples.bazaar.api.PosTenderDto;
import java.util.List;

/// The server's half of `LayawayApi`.
@Component
public class LayawayEndpoint implements LayawayApiServer {
    private final Layaways layaways;

    public LayawayEndpoint(Layaways layaways) {
        this.layaways = layaways;
    }

    @Override
    public LayawayDto create(String storeId, String registerId, LayawayRequestDto body)
            throws Exception {
        return layaways.create(Caller.name(), storeId, registerId, body);
    }

    @Override
    public List<LayawayDto> layaways(String storeId) throws Exception {
        return layaways.layaways(Caller.name(), storeId);
    }

    @Override
    public LayawayDto layaway(String storeId, String layawayId) throws Exception {
        return layaways.layaway(Caller.name(), storeId, layawayId);
    }

    @Override
    public LayawayDto pay(String storeId, String layawayId, PosTenderDto body) throws Exception {
        return layaways.pay(Caller.name(), storeId, layawayId, body);
    }

    @Override
    public LayawayDto cancel(String storeId, String layawayId, LayawayCancelDto body)
            throws Exception {
        return layaways.cancel(Caller.name(), storeId, layawayId, body);
    }
}
