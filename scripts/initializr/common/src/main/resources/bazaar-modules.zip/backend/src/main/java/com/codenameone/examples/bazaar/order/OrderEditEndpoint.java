package com.codenameone.examples.bazaar.order;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.OrderEditApiServer;
import com.codenameone.examples.bazaar.api.OrderEditDto;
import com.codenameone.examples.bazaar.api.OrderEditEntryDto;
import com.codenameone.examples.bazaar.api.OrderEditResultDto;
import java.util.List;

/// The server's half of `OrderEditApi`.
@Component
public class OrderEditEndpoint implements OrderEditApiServer {
    private final OrderEdits edits;

    public OrderEditEndpoint(OrderEdits edits) {
        this.edits = edits;
    }

    @Override
    public OrderEditResultDto edit(String storeId, String orderId, OrderEditDto body)
            throws Exception {
        return edits.edit(Caller.name(), storeId, orderId, body);
    }

    @Override
    public List<OrderEditEntryDto> edits(String storeId, String orderId) throws Exception {
        return edits.edits(Caller.name(), storeId, orderId);
    }
}
