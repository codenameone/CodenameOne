package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.PurchaseLine;
import java.util.List;

/// Reads and writes [PurchaseLine] rows.
@Repository(entity = PurchaseLine.class, key = String.class)
public interface PurchaseLineRepository extends CrudRepository<PurchaseLine, String> {
    List<PurchaseLine> findByPurchaseOrderId(String purchaseOrderId);

    List<PurchaseLine> findByVariantId(String variantId);
}
