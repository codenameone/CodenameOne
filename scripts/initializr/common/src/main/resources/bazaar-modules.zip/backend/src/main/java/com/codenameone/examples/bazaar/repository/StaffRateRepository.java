package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.Repository;
import com.codename1.orm.repository.CrudRepository;
import com.codenameone.examples.bazaar.domain.StaffRate;
import java.util.List;

/// Reads and writes [StaffRate] rows.
@Repository(entity = StaffRate.class, key = String.class)
public interface StaffRateRepository extends CrudRepository<StaffRate, String> {
    List<StaffRate> findByStoreId(String storeId);

    StaffRate findByStoreIdAndUsername(String storeId, String username);
}
