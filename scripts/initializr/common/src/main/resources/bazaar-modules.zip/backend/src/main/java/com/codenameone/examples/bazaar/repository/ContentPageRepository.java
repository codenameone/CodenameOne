package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ContentPage;
import java.util.List;

/// Reads and writes [ContentPage] rows.
@Repository(entity = ContentPage.class, key = String.class)
public interface ContentPageRepository extends CrudRepository<ContentPage, String> {
    List<ContentPage> findByStoreIdOrderByTitleAsc(String storeId);
    ContentPage findByStoreIdAndKindAndHandle(String storeId, String kind, String handle);
}
