package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CartLine;
import java.util.List;

/// Reads and writes [CartLine] rows.
@Repository(entity = CartLine.class, key = String.class)
public interface CartLineRepository extends CrudRepository<CartLine, String> {
    List<CartLine> findByCartId(String cartId);

    int deleteByCartId(String cartId);
}
