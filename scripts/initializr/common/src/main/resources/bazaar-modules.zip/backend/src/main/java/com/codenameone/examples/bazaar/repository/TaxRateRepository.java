package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TaxRate;
import java.util.List;

/// Reads and writes [TaxRate] rows.
@Repository(entity = TaxRate.class, key = String.class)
public interface TaxRateRepository extends CrudRepository<TaxRate, String> {
    List<TaxRate> findByStoreId(String storeId);
}
