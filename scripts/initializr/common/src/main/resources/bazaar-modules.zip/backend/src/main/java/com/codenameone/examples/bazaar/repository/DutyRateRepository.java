package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.DutyRate;
import java.util.List;

/// Reads and writes [DutyRate] rows.
@Repository(entity = DutyRate.class, key = String.class)
public interface DutyRateRepository extends CrudRepository<DutyRate, String> {
    List<DutyRate> findByStoreIdOrderByCountryAsc(String storeId);
    List<DutyRate> findByStoreIdAndCountry(String storeId, String country);
}
