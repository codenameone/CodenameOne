package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ProductOption;
import java.util.List;

/// Reads and writes [ProductOption] rows.
@Repository(entity = ProductOption.class, key = String.class)
public interface ProductOptionRepository extends CrudRepository<ProductOption, String> {
    List<ProductOption> findByProductIdOrderByPositionAsc(String productId);

    int deleteByProductId(String productId);
}
