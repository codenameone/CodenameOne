package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TaxExemption;
import java.util.List;

/// Reads and writes [TaxExemption] rows.
@Repository(entity = TaxExemption.class, key = String.class)
public interface TaxExemptionRepository extends CrudRepository<TaxExemption, String> {
    List<TaxExemption> findByStoreIdOrderByCreatedAtDesc(String storeId);
    List<TaxExemption> findByStoreIdAndUsername(String storeId, String username);
}
