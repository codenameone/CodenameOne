package com.codenameone.examples.bazaar.dispute;

import com.codename1.backend.HttpServer;
import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Controller;
import com.codename1.backend.annotations.PostMapping;

/// The payment processor's dispute events: `POST /api/payments/webhooks/disputes`
/// with the body signed in `X-Bazaar-Signature` ([Disputes#webhook]). Open to
/// anyone -- the signature is the authentication -- and rate limited by
/// address in `SecurityConfig`.
@Controller
public class DisputeWebhook {
    public static final String PATH = "/api/payments/webhooks/disputes";

    private final Disputes disputes;

    public DisputeWebhook(Disputes disputes) {
        this.disputes = disputes;
    }

    @PostMapping(PATH)
    public HttpServer.Response receive(HttpServer.Request request) throws Exception {
        try {
            disputes.webhook(request.getBodyBytes(), request.getHeader("X-Bazaar-Signature"));
            return HttpServer.Response.text(200, "ok");
        } catch (ResponseStatusException e) {
            return HttpServer.Response.text(e.getStatus(), e.getReason() == null ? "refused"
                    : e.getReason());
        }
    }
}
