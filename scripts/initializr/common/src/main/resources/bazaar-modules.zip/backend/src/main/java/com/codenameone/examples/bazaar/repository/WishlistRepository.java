package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Wishlist;
import java.util.List;

/// Reads and writes [Wishlist] rows.
@Repository(entity = Wishlist.class, key = String.class)
public interface WishlistRepository extends CrudRepository<Wishlist, String> {
    List<Wishlist> findByUsernameOrderByCreatedAtDesc(String username);

    Wishlist findByUsernameAndProductId(String username, String productId);
}
