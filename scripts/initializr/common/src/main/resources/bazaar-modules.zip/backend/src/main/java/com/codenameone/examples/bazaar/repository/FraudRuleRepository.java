package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.FraudRule;
import java.util.List;

/// Reads and writes [FraudRule] rows.
@Repository(entity = FraudRule.class, key = String.class)
public interface FraudRuleRepository extends CrudRepository<FraudRule, String> {
    List<FraudRule> findByStoreIdOrderByCreatedAtAsc(String storeId);
}
