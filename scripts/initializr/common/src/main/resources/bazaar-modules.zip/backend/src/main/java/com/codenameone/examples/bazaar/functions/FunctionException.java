package com.codenameone.examples.bazaar.functions;

/// A program that did not compile or verify, or a run that failed: out of
/// fuel, too much output, arithmetic out of range, a remote that did not
/// answer in time. The checkout keeps its own behaviour for that function.
public class FunctionException extends Exception {
    public FunctionException(String message) {
        super(message);
    }
}
