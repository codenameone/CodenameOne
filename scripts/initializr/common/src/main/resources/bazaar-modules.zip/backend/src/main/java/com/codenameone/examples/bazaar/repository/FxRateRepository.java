package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.FxRate;
import java.util.List;

/// Reads and writes [FxRate] rows.
@Repository(entity = FxRate.class, key = String.class)
public interface FxRateRepository extends CrudRepository<FxRate, String> {
    List<FxRate> findByStoreIdOrderByCurrencyAsc(String storeId);
    FxRate findByStoreIdAndCurrency(String storeId, String currency);
}
