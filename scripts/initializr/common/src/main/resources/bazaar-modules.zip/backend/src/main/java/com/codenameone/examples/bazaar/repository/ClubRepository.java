package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Club;

import java.util.List;

/// Reads and writes [Club] rows.
@Repository(entity = Club.class, key = String.class)
public interface ClubRepository extends CrudRepository<Club, String> {
    List<Club> findByStoreIdOrderByCreatedAtAsc(String storeId);
}
