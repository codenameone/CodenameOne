package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.ReturnRequest;
import java.util.List;

/// Reads and writes [ReturnRequest] rows.
@Repository(entity = ReturnRequest.class, key = String.class)
public interface ReturnRequestRepository extends CrudRepository<ReturnRequest, String> {
    List<ReturnRequest> findByOrderId(String orderId);

    List<ReturnRequest> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<ReturnRequest> findByUsernameOrderByCreatedAtDesc(String username);

    /// Moves a return on only if nobody moved it first; answers the rows changed.
    @Modifying
    @Query("update ReturnRequest r set r.status = :to where r.id = :id and r.status = :from")
    int claimStatus(@Param("id") String id, @Param("from") String from, @Param("to") String to);
}
