package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Subscription;
import java.time.Instant;
import java.util.List;

/// Reads and writes [Subscription] rows.
@Repository(entity = Subscription.class, key = String.class)
public interface SubscriptionRepository extends CrudRepository<Subscription, String> {
    List<Subscription> findByStoreIdAndUsername(String storeId, String username);

    List<Subscription> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<Subscription> findByStatusAndNextAttemptAtLessThanEqual(String status, Instant now);

    @Query("select s from Subscription s where s.storeId = :storeId and s.status = :status and s.dueAt >= :from and s.dueAt < :to order by s.dueAt asc")
    List<Subscription> due(@Param("storeId") String storeId, @Param("status") String status,
            @Param("from") Instant from, @Param("to") Instant to);

    /// Takes a renewal attempt: moves the attempt time to `lease` only while it is
    /// still `at`, so two job runs cannot both charge one renewal.
    @Modifying
    @Query("update Subscription s set s.nextAttemptAt = :lease where s.id = :id and s.nextAttemptAt = :at and s.status = :status")
    int claim(@Param("id") String id, @Param("at") Instant at, @Param("lease") Instant lease,
            @Param("status") String status);

    /// Moves every row of one customer to another (a merge).
    @com.codename1.orm.repository.Modifying(clearAutomatically = true)
    @com.codename1.orm.repository.Query("update Subscription x set x.customerId = :to where x.customerId = :from")
    int moveCustomer(@com.codename1.orm.repository.Param("from") String from,
            @com.codename1.orm.repository.Param("to") String to);
}
