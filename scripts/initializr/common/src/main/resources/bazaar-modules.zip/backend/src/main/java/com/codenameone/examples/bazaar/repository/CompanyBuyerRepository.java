package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CompanyBuyer;
import java.util.List;

/// Reads and writes [CompanyBuyer] rows.
@Repository(entity = CompanyBuyer.class, key = String.class)
public interface CompanyBuyerRepository extends CrudRepository<CompanyBuyer, String> {
    List<CompanyBuyer> findByCompanyId(String companyId);

    List<CompanyBuyer> findByStoreIdAndUsername(String storeId, String username);

    List<CompanyBuyer> findByUsername(String username);
}
