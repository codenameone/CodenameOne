package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CollectionProduct;
import java.util.List;

/// Reads and writes [CollectionProduct] rows.
@Repository(entity = CollectionProduct.class, key = String.class)
public interface CollectionProductRepository extends CrudRepository<CollectionProduct, String> {
    List<CollectionProduct> findByCollectionIdOrderByPositionAsc(String collectionId);

    List<CollectionProduct> findByProductId(String productId);

    int deleteByCollectionId(String collectionId);

    int deleteByProductId(String productId);
}
