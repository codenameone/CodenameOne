package com.codenameone.examples.bazaar.platform;

import com.codename1.appkit.server.Caller;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.bazaar.api.AppApiServer;
import com.codenameone.examples.bazaar.api.AppAuthorizeDto;
import com.codenameone.examples.bazaar.api.AppConsentDto;
import com.codenameone.examples.bazaar.api.AppDto;
import com.codenameone.examples.bazaar.api.AppInstallationDto;
import com.codenameone.examples.bazaar.api.AppRedirectDto;

import java.util.List;

/// The server's half of `AppApi`; [Apps] checks the caller.
@Component
public class AppEndpoint implements AppApiServer {
    private final Apps apps;

    public AppEndpoint(Apps apps) {
        this.apps = apps;
    }

    @Override
    public List<AppDto> mine() throws Exception {
        return apps.mine(Caller.name());
    }

    @Override
    public AppDto register(AppDto app) throws Exception {
        return apps.register(Caller.name(), app);
    }

    @Override
    public AppDto update(String appId, AppDto app) throws Exception {
        return apps.update(Caller.name(), appId, app);
    }

    @Override
    public List<AppInstallationDto> installed(String storeId) throws Exception {
        return apps.installed(Caller.name(), storeId);
    }

    @Override
    public AppConsentDto consent(String storeId, AppAuthorizeDto request) throws Exception {
        return apps.consent(Caller.name(), storeId, request);
    }

    @Override
    public AppRedirectDto authorize(String storeId, AppAuthorizeDto request) throws Exception {
        return apps.authorize(Caller.name(), storeId, request);
    }

    @Override
    public List<AppInstallationDto> uninstall(String storeId, String installationId)
            throws Exception {
        return apps.uninstall(Caller.name(), storeId, installationId);
    }
}
