package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CampaignLink;

import java.util.List;

/// Reads and writes [CampaignLink] rows.
@Repository(entity = CampaignLink.class, key = String.class)
public interface CampaignLinkRepository extends CrudRepository<CampaignLink, String> {
    List<CampaignLink> findByCampaignIdOrderByPositionAsc(String campaignId);

    CampaignLink findByCampaignIdAndPosition(String campaignId, int position);
}
