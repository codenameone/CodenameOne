package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.OrderEvent;
import java.util.List;

/// Reads and writes [OrderEvent] rows.
@Repository(entity = OrderEvent.class, key = String.class)
public interface OrderEventRepository extends CrudRepository<OrderEvent, String> {
    List<OrderEvent> findByOrderIdOrderByCreatedAtAsc(String orderId);

    void deleteByOrderId(String orderId);
}
