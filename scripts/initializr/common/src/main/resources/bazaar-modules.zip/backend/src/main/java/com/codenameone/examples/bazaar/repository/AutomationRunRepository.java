package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.AutomationRun;
import java.util.List;

/// Reads and writes [AutomationRun] rows.
@Repository(entity = AutomationRun.class, key = String.class)
public interface AutomationRunRepository extends CrudRepository<AutomationRun, String> {
    List<AutomationRun> findByStatusOrderByResumeAtAsc(String status);

    List<AutomationRun> findByAutomationId(String automationId);
}
