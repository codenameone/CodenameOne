package com.codenameone.examples.bazaar.channel;

import com.codename1.backend.HttpServer;
import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Controller;
import com.codename1.backend.annotations.PostMapping;

/// A marketplace's order notification:
/// `POST /api/channels/notifications?channel={id}`, the raw body signed in
/// [MarketplaceConnector#SIGNATURE_HEADER]. Open to anyone -- the signature
/// is the authentication -- and rate limited by address in `SecurityConfig`.
/// An unknown channel and a bad signature get the same answer.
@Controller
public class ChannelWebhook {
    public static final String PATH = "/api/channels/notifications";

    private final ChannelSync sync;

    public ChannelWebhook(ChannelSync sync) {
        this.sync = sync;
    }

    @PostMapping(PATH)
    public HttpServer.Response receive(HttpServer.Request request) throws Exception {
        String channel;
        try {
            channel = request.param("channel");
        } catch (RuntimeException malformed) {
            channel = null;
        }
        try {
            sync.notification(channel, request.getBodyBytes(),
                    request.getHeader(MarketplaceConnector.SIGNATURE_HEADER),
                    System.currentTimeMillis());
            return HttpServer.Response.text(200, "ok");
        } catch (ResponseStatusException e) {
            return HttpServer.Response.text(e.getStatus(), e.getReason() == null ? "refused"
                    : e.getReason());
        }
    }
}
