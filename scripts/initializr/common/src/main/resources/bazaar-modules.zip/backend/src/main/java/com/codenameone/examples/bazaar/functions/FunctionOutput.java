package com.codenameone.examples.bazaar.functions;

/// The operations a function emitted, in order: an emit index into its
/// target and up to three arguments, longs and strings in parallel arrays.
/// Sized once, at the cap; emitting past the cap is an error.
public final class FunctionOutput {
    public static final int MAX_ARGS = 3;
    /// The most operations one run may emit.
    public static final int DEFAULT_CAP = 64;

    private final int cap;
    private int count;
    private final int[] ops;
    private final long[] numbers;
    private final String[] texts;

    public FunctionOutput() {
        this(DEFAULT_CAP);
    }

    public FunctionOutput(int cap) {
        this.cap = cap;
        ops = new int[cap];
        numbers = new long[cap * MAX_ARGS];
        texts = new String[cap * MAX_ARGS];
    }

    /// Starts operation `op`; answers its slot, whose arguments are then set.
    int add(int op) throws FunctionException {
        if (count >= cap) {
            throw new FunctionException("The function emitted more than " + cap + " operations");
        }
        ops[count] = op;
        return count++;
    }

    void number(int slot, int arg, long value) {
        numbers[slot * MAX_ARGS + arg] = value;
    }

    void text(int slot, int arg, String value) {
        texts[slot * MAX_ARGS + arg] = value;
    }

    public int size() {
        return count;
    }

    public int op(int index) {
        return ops[index];
    }

    public long number(int index, int arg) {
        return numbers[index * MAX_ARGS + arg];
    }

    public String text(int index, int arg) {
        return texts[index * MAX_ARGS + arg];
    }

    /// Forgets every operation, keeping the arrays.
    public void clear() {
        count = 0;
    }
}
