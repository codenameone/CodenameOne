package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Payout;

import java.util.List;

/// The payouts made to payees.
@Repository(entity = Payout.class, key = String.class)
public interface PayoutRepository extends CrudRepository<Payout, String> {
    /// The last hundred payouts made to a payee, newest first.
    List<Payout> findTop100ByPayeeOrderByCreatedAtDescIdAsc(String payee);

    /// Everything ever paid out to a payee. A sum over no rows is nothing at
    /// all to a database, hence the zero to fall back on.
    @Query("select coalesce(sum(p.amountCents), 0) from Payout p where p.payee = :payee")
    Long paidOut(@Param("payee") String payee);
}
