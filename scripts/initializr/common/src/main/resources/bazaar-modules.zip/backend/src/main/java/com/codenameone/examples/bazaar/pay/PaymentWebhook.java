package com.codenameone.examples.bazaar.pay;

import com.codename1.backend.HttpServer;
import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Controller;
import com.codename1.backend.annotations.PostMapping;

/// The processor's payment events: `POST /api/payments/webhooks/payments`
/// with the body signed in `X-Bazaar-Signature` ([PaymentEvents#webhook]).
/// Open to anyone -- the signature is the authentication, and the outcome is
/// asked of the processor anyway -- and rate limited by address in
/// `SecurityConfig`.
@Controller
public class PaymentWebhook {
    private final PaymentEvents events;

    public PaymentWebhook(PaymentEvents events) {
        this.events = events;
    }

    @PostMapping(PaymentEvents.PATH)
    public HttpServer.Response receive(HttpServer.Request request) throws Exception {
        try {
            events.webhook(request.getBodyBytes(), request.getHeader("X-Bazaar-Signature"));
            return HttpServer.Response.text(200, "ok");
        } catch (ResponseStatusException e) {
            return HttpServer.Response.text(e.getStatus(), e.getReason() == null ? "refused"
                    : e.getReason());
        }
    }
}
