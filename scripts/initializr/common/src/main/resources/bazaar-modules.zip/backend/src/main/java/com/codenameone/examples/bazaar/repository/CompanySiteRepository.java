package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.CompanySite;
import java.util.List;

/// Reads and writes [CompanySite] rows.
@Repository(entity = CompanySite.class, key = String.class)
public interface CompanySiteRepository extends CrudRepository<CompanySite, String> {
    List<CompanySite> findByCompanyId(String companyId);
}
