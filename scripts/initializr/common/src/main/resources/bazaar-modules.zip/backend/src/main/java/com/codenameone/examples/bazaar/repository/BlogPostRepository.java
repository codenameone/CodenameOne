package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.BlogPost;
import java.util.List;

/// Reads and writes [BlogPost] rows.
@Repository(entity = BlogPost.class, key = String.class)
public interface BlogPostRepository extends CrudRepository<BlogPost, String> {
    List<BlogPost> findByStoreIdOrderByPublishedAtDesc(String storeId);
    BlogPost findByStoreIdAndHandle(String storeId, String handle);
}
