package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.LoyaltyLedger;

import java.time.Instant;
import java.util.List;

/// Reads and writes [LoyaltyLedger] rows.
@Repository(entity = LoyaltyLedger.class, key = String.class)
public interface LoyaltyLedgerRepository extends CrudRepository<LoyaltyLedger, String> {
    List<LoyaltyLedger> findByMemberIdOrderByCreatedAtDesc(String memberId);

    LoyaltyLedger findByStoreIdAndRef(String storeId, String ref);

    List<LoyaltyLedger> findByStoreIdAndOrderId(String storeId, String orderId);

    List<LoyaltyLedger> findByMemberIdAndCreatedAtGreaterThanEqual(String memberId, Instant since);
}
