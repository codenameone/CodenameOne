package com.codenameone.examples.bazaar.market;

/// Where the platform's exchange rates come from, for adding sales made in
/// different currencies into one figure ([ReportingRates]).
///
/// A rate is how many units of `to` one unit of `from` buys, in millionths:
/// US dollars to yen at 150 is 150000000. Units are major units; the
/// difference in decimals between the two currencies is the converter's
/// business ([com.codenameone.examples.bazaar.ops.Amounts#convert]).
///
/// [FixedExchangeRates] is the demo table, and the default;
/// [EcbExchangeRates] reads the European Central Bank's daily reference rates.
public interface ExchangeRates {
    /// Units of `to` per unit of `from`, in millionths; 1000000 for the same
    /// currency and 0 when either is unknown to this provider.
    long rateMicros(String from, String to);

    /// A short name for where the rates come from, such as `fixed` or `ecb`.
    String source();
}
