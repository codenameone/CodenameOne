package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// An import duty rate into a country for HS codes starting with a prefix (empty prefix: every code).
@Entity
public class DutyRate {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String storeId = "";

    @Column(nullable = false, type = "VARCHAR(2)")
    private String country = "";

    @Column(nullable = false, type = "VARCHAR(12)")
    private String hsPrefix = "";

    @Column(nullable = false)
    private int rateBps;

    public DutyRate() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHsPrefix() {
        return hsPrefix;
    }

    public void setHsPrefix(String hsPrefix) {
        this.hsPrefix = hsPrefix;
    }

    public int getRateBps() {
        return rateBps;
    }

    public void setRateBps(int rateBps) {
        this.rateBps = rateBps;
    }
}
