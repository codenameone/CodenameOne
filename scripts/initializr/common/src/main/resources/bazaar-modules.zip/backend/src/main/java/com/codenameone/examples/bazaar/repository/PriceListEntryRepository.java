package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.PriceListEntry;
import java.util.List;

/// Reads and writes [PriceListEntry] rows.
@Repository(entity = PriceListEntry.class, key = String.class)
public interface PriceListEntryRepository extends CrudRepository<PriceListEntry, String> {
    List<PriceListEntry> findByPriceListId(String priceListId);
}
