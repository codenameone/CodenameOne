package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.WebhookDelivery;
import java.util.List;

/// Reads and writes [WebhookDelivery] rows.
@Repository(entity = WebhookDelivery.class, key = String.class)
public interface WebhookDeliveryRepository extends CrudRepository<WebhookDelivery, String> {
    List<WebhookDelivery> findByWebhookIdOrderByCreatedAtDesc(String webhookId);

    List<WebhookDelivery> findByStatusOrderByNextAttemptAtAsc(String status);
}
