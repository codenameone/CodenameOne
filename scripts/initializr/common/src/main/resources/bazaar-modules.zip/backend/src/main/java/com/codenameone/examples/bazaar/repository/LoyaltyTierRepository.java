package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.LoyaltyTier;

import java.util.List;

/// Reads and writes [LoyaltyTier] rows.
@Repository(entity = LoyaltyTier.class, key = String.class)
public interface LoyaltyTierRepository extends CrudRepository<LoyaltyTier, String> {
    List<LoyaltyTier> findByStoreIdOrderByPositionAsc(String storeId);
}
