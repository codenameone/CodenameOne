package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.SaleItem;

import java.util.List;

/// Reads and writes [SaleItem] rows.
@Repository(entity = SaleItem.class, key = String.class)
public interface SaleItemRepository extends CrudRepository<SaleItem, String> {
    List<SaleItem> findBySaleId(String saleId);

    List<SaleItem> findByVariantIdIn(List<String> variantIds);

    List<SaleItem> findByVariantId(String variantId);

    @Modifying
    @Query("update SaleItem i set i.state = :to where i.id = :id and i.state = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to);
}
