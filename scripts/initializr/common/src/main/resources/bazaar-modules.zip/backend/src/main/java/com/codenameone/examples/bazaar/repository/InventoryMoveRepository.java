package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.PageRequest;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.InventoryMove;
import java.util.List;

/// Reads and writes [InventoryMove] rows.
@Repository(entity = InventoryMove.class, key = String.class)
public interface InventoryMoveRepository extends CrudRepository<InventoryMove, String> {
    List<InventoryMove> findByVariantIdOrderByCreatedAtDesc(String variantId);

    List<InventoryMove> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<InventoryMove> findByStoreIdOrderByCreatedAtDesc(String storeId, PageRequest page);

    List<InventoryMove> findByVariantIdAndLocationId(String variantId, String locationId);

    List<InventoryMove> findByStoreId(String storeId);

    boolean existsByLocationId(String locationId);
}
