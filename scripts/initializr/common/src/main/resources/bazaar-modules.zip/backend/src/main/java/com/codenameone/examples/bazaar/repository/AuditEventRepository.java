package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.AuditEvent;
import java.util.List;

/// Reads and writes [AuditEvent] rows.
@Repository(entity = AuditEvent.class, key = String.class)
public interface AuditEventRepository extends CrudRepository<AuditEvent, String> {
    List<AuditEvent> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<AuditEvent> findByStoreIdAndSubjectOrderByCreatedAtDesc(String storeId, String subject);
}
