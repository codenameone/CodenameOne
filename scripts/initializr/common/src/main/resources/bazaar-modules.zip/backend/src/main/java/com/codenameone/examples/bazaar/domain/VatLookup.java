package com.codenameone.examples.bazaar.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A cached VIES answer for one VAT number (the id): `verified` or `invalid`,
/// the trader's name, the consultation reference when VIES gave one, and when
/// it was asked. An outage is never cached.
@Entity
public class VatLookup {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(20)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String status = "";

    @Column(nullable = false, type = "VARCHAR(200)")
    private String name = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String reference = "";

    @Column(nullable = false)
    private long checkedAt;

    public VatLookup() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public long getCheckedAt() {
        return checkedAt;
    }

    public void setCheckedAt(long checkedAt) {
        this.checkedAt = checkedAt;
    }
}
