package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.DataRequest;
import java.time.Instant;
import java.util.List;

/// Reads and writes [DataRequest] rows.
@Repository(entity = DataRequest.class, key = String.class)
public interface DataRequestRepository extends CrudRepository<DataRequest, String> {

    List<DataRequest> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<DataRequest> findByUsernameOrderByCreatedAtDesc(String username);

    List<DataRequest> findByCustomerId(String customerId);

    DataRequest findByStoreIdAndUsernameAndKindAndStatus(String storeId, String username,
            String kind, String status);

    /// Moves every row of one customer to another (a merge).
    @com.codename1.orm.repository.Modifying(clearAutomatically = true)
    @com.codename1.orm.repository.Query("update DataRequest x set x.customerId = :to where x.customerId = :from")
    int moveCustomer(@com.codename1.orm.repository.Param("from") String from,
            @com.codename1.orm.repository.Param("to") String to);
}
