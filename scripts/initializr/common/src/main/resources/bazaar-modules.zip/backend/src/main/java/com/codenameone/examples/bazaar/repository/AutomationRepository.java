package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.Automation;
import java.util.List;

/// Reads and writes [Automation] rows.
@Repository(entity = Automation.class, key = String.class)
public interface AutomationRepository extends CrudRepository<Automation, String> {
    List<Automation> findByStoreIdOrderByNameAsc(String storeId);

    List<Automation> findByStoreIdAndTriggerKind(String storeId, String triggerKind);
}
