package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.StockAlert;

import java.util.List;

/// Reads and writes [StockAlert] rows.
@Repository(entity = StockAlert.class, key = String.class)
public interface StockAlertRepository extends CrudRepository<StockAlert, String> {
    List<StockAlert> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<StockAlert> findByVariantIdAndStatus(String variantId, String status);

    List<StockAlert> findByStatus(String status);

    List<StockAlert> findByVariantIdAndEmailAndChannel(String variantId, String email, String channel);

    @Modifying
    @Query("update StockAlert a set a.status = :to where a.id = :id and a.status = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to);

    @Modifying
    @Query("update StockAlert a set a.status = 'READY' where a.variantId = :variantId "
            + "and a.status = 'WAITING'")
    int ready(@Param("variantId") String variantId);
    /// A shopper's own alerts, newest first (index `stock_alert_username_created_at`).
    List<StockAlert> findByUsernameOrderByCreatedAtDesc(String username);
}
