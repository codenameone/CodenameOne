package com.codenameone.examples.bazaar.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bazaar.domain.TradeQuote;
import java.time.Instant;
import java.util.List;

/// Reads and writes [TradeQuote] rows.
@Repository(entity = TradeQuote.class, key = String.class)
public interface TradeQuoteRepository extends CrudRepository<TradeQuote, String> {
    List<TradeQuote> findByStoreIdOrderByCreatedAtDesc(String storeId);

    List<TradeQuote> findByCompanyIdOrderByCreatedAtDesc(String companyId);

    /// Moves a quote from `from` to `to` only while it is still at `from`.
    @Modifying
    @Query("update TradeQuote q set q.status = :to, q.updatedAt = :at where q.id = :id and q.status = :from")
    int move(@Param("id") String id, @Param("from") String from, @Param("to") String to,
            @Param("at") Instant at);
}
