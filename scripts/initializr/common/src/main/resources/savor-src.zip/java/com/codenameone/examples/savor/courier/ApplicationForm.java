package com.codenameone.examples.savor.courier;

import com.codename1.components.SpanLabel;
import com.codename1.l10n.ParseException;
import com.codename1.l10n.SimpleDateFormat;
import com.codename1.ui.Button;
import com.codename1.ui.CN;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.spinner.Picker;
import com.codename1.util.Base64;
import com.codenameone.examples.savor.Telemetry;
import com.codenameone.examples.savor.api.DocumentDto;
import com.codenameone.examples.savor.api.DocumentUploadDto;
import com.codenameone.examples.savor.api.CourierApplicationDto;
import com.codenameone.examples.savor.api.UserDto;
import com.codenameone.examples.savor.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.savor.net.Session;
import com.codename1.appkit.Chart;
import com.codenameone.examples.savor.ui.Lang;
import com.codenameone.examples.savor.ui.Photos;
import com.codenameone.examples.savor.ui.Ui;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/// The application to deliver, a step at a time: you, your licence, your vehicle,
/// your documents, and a last look before it is handed in.
///
/// Each step is saved as it is left, so an application can be put down half
/// way and picked up on another day or another phone. The server keeps the
/// draft and decides what "complete" means: handing in an application that is
/// missing something comes back with what, in words, and that is shown as it
/// is rather than worked out again here.
public final class ApplicationForm {
    /// The documents asked for, in the order the server lists them.
    public static final String[] KINDS = {"photo_id", "licence", "selfie",
        "vehicle_registration", "insurance"};
    private static final String[] KIND_NAMES = {"Photo ID", "Driving licence", "A photo of you",
        "Vehicle registration", "Insurance"};
    private static final String[] KIND_HINTS = {"A passport or an identity card",
        "The side with your photo on it", "Your face, in good light, no sunglasses",
        "The paper that says the vehicle is yours", "The page with the policy's dates on it"};
    private static final char[] KIND_ICONS = {FontImage.MATERIAL_BADGE,
        FontImage.MATERIAL_CREDIT_CARD, FontImage.MATERIAL_FACE,
        FontImage.MATERIAL_DESCRIPTION, FontImage.MATERIAL_VERIFIED_USER};
    private static final String[] STEPS = {"About you", "Your licence", "Your vehicle",
        "Your documents", "Review and submit"};
    private static final String ISO = "yyyy-MM-dd";

    private final Form form = Ui.form("Deliver with Savor", "Application");
    private final Runnable done;
    private final Container body = Ui.page();
    private final Label stepLabel = Ui.plain("", "SvStepLabel");
    private final Label stepTitle = Ui.label("", "SvTitle");
    private final Container progress = new Container(new BorderLayout());
    private final SpanLabel error = Ui.text("", "SvError");
    private final Button next = Ui.primary("Continue", "next", e -> forward());
    private final Button back = Ui.link("Back", "backStep", e -> backward());
    /// The pictures taken on this visit, to show beside their documents.
    private final Map<String, Image> thumbs = new HashMap<String, Image>();
    private CourierApplicationDto application;
    private int step;
    /// Reads what the step on screen has in its fields into [#application].
    private Runnable collect = () -> { };

    private ApplicationForm(CourierApplicationDto application, Runnable done) {
        this.application = application;
        this.done = done;
        Ui.back(form, () -> done.run());
        UserDto user = Session.user();
        if (application.legalName() == null || application.legalName().length() == 0) {
            this.application = filled(user.displayName(), application.dateOfBirth(),
                    application.licenceNumber(), application.licenceExpiry());
        }
        stepLabel.setName("step");
        error.setName("error");
        Container head = new Container(BoxLayout.y());
        head.setUIID("SvPage");
        head.add(stepLabel).add(stepTitle).add(progress);
        Container foot = new Container(BoxLayout.y());
        foot.setUIID("SvFooter");
        foot.setSafeArea(true);
        foot.add(error).add(next).add(back);
        form.add(BorderLayout.NORTH, head);
        form.add(BorderLayout.CENTER, body);
        form.add(BorderLayout.SOUTH, foot);
    }

    /// @param done run when the user leaves, with the application handed in or
    ///     not; it shows the screen to go back to
    public static void show(Form previous, CourierApplicationDto application, Runnable done) {
        ApplicationForm wizard = new ApplicationForm(application, done);
        wizard.display();
        wizard.form.show();
    }

    // -------------------------------------------------------------- the steps

    private void display() {
        stepLabel.setText(Lang.tr("Step {0} of {1}", String.valueOf(step + 1),
                String.valueOf(STEPS.length)));
        stepTitle.setText(STEPS[step]);
        progress.removeAll();
        progress.add(BorderLayout.CENTER, new Chart.Meter("Sv", (step + 1) / (double) STEPS.length));
        body.removeAll();
        // A new step starts at its top, wherever the last one was left.
        body.scrollRectToVisible(0, 0, 1, 1, body);
        error.setText("");
        collect = () -> { };
        if (step == 0) {
            you();
        } else if (step == 1) {
            licence();
        } else if (step == 2) {
            vehicle();
        } else if (step == 3) {
            documents();
        } else {
            review();
        }
        next.setText(step == STEPS.length - 1 ? "Submit application" : "Continue");
        next.setName(step == STEPS.length - 1 ? "submitApplication" : "next");
        back.setHidden(step == 0);
        Ui.refresh(form);
    }

    private void you() {
        body.add(Ui.text("As it is written on your licence. Customers see only your first name.",
                "SvMuted"));
        final TextField name = Ui.field(body, "Legal name", "legalName", "");
        name.setText(application.legalName());
        final Picker born = date(body, "Date of birth", "dateOfBirth", application.dateOfBirth());
        collect = () -> application = filled(name.getText().trim(), iso(born),
                application.licenceNumber(), application.licenceExpiry());
    }

    private void licence() {
        body.add(Ui.text("The number is on the front of the card.", "SvMuted"));
        final TextField number = Ui.field(body, "Licence number", "licenceNumber", "");
        number.setText(application.licenceNumber());
        final Picker expiry = date(body, "Expires", "licenceExpiry", application.licenceExpiry());
        collect = () -> application = filled(application.legalName(),
                application.dateOfBirth(), number.getText().trim(), iso(expiry));
    }

    private void vehicle() {
        Container pair = new Container(new GridLayout(1, 2));
        Container left = side("SvPairLeft");
        Container right = side("SvPairRight");
        final TextField make = Ui.field(left, "Make", "vehicleMake", "Vespa");
        final TextField model = Ui.field(right, "Model", "vehicleModel", "Primavera");
        pair.add(left).add(right);
        body.add(pair);
        Container second = new Container(new GridLayout(1, 2));
        left = side("SvPairLeft");
        right = side("SvPairRight");
        final TextField year = Ui.field(left, "Year", "vehicleYear", "2021", TextArea.NUMERIC);
        final TextField colour = Ui.field(right, "Colour", "vehicleColor", "Blue");
        second.add(left).add(right);
        body.add(second);
        Container third = new Container(new GridLayout(1, 2));
        left = side("SvPairLeft");
        right = side("SvPairRight");
        final TextField plate = Ui.field(left, "Licence plate", "vehiclePlate", "7ABC123");
        third.add(left).add(right);
        body.add(third);
        make.setText(application.vehicleMake());
        model.setText(application.vehicleModel());
        year.setText(application.vehicleYear() > 0
                ? String.valueOf(application.vehicleYear()) : "");
        colour.setText(application.vehicleColor());
        plate.setText(application.vehiclePlate());
        collect = () -> {
            CourierApplicationDto a = application;
            application = new CourierApplicationDto(a.username(), a.name(), a.status(),
                    a.legalName(), a.dateOfBirth(), a.licenceNumber(), a.licenceExpiry(),
                    make.getText().trim(), model.getText().trim(), number(year.getText()),
                    colour.getText().trim(), plate.getText().trim(), a.documents(), a.rejectionReason(),
                    a.submittedAt(), a.reviewedAt(), a.reviewedBy());
        };
    }

    /// The application as it stands, with the applicant's and the licence's
    /// details as given.
    private CourierApplicationDto filled(String legalName, String dateOfBirth,
            String licenceNumber, String licenceExpiry) {
        CourierApplicationDto a = application;
        return new CourierApplicationDto(a.username(), a.name(), a.status(), legalName,
                dateOfBirth, licenceNumber, licenceExpiry, a.vehicleMake(), a.vehicleModel(),
                a.vehicleYear(), a.vehicleColor(), a.vehiclePlate(), a.documents(),
                a.rejectionReason(), a.submittedAt(), a.reviewedAt(), a.reviewedBy());
    }

    private void documents() {
        body.add(Ui.text("Photograph each one flat, with all four corners in the picture.",
                "SvMuted"));
        for (int iter = 0; iter < KINDS.length; iter++) {
            body.add(document(iter));
        }
    }

    /// One document: what it is, whether we have it, and the two ways to give
    /// it to us.
    private Container document(final int index) {
        final String kind = KINDS[index];
        String status = status(kind);
        boolean have = !"missing".equals(status);
        Container box = new Container(BoxLayout.y());
        box.setUIID("SvOption");
        Label picture = new Label("", "SvThumb");
        Image thumb = thumbs.get(kind);
        if (thumb != null) {
            int side = CN.convertToPixels(9f);
            picture.setIcon(thumb.fill(side, side));
        } else {
            Ui.icon(picture, KIND_ICONS[index], 4f);
        }
        Label state = Ui.badge(have ? "rejected".equals(status) ? "Rejected"
                : "accepted".equals(status) ? "Accepted" : "Added" : "Needed",
                have ? "rejected".equals(status) ? "SvBadgeBad" : "SvBadgeGood" : "SvBadgeWarn");
        state.setName("status-" + kind);
        // The state stands over the name and not beside it: the name is long
        // in some languages and has to keep the whole line.
        state.getAllStyles().setMargin(0, 0, 0, 0);
        Container lines = new Container(BoxLayout.y());
        lines.add(FlowLayout.encloseIn(state));
        lines.add(Ui.label(KIND_NAMES[index], "SvRowTitle"));
        lines.add(Ui.text(KIND_HINTS[index], "SvRowDetail"));
        Container top = new Container(new BorderLayout());
        top.add(BorderLayout.WEST, FlowLayout.encloseCenterMiddle(picture));
        top.add(BorderLayout.CENTER, lines);
        box.add(top);
        Container ways = new Container(new GridLayout(1, 2));
        Button camera = Ui.link(have ? "Retake" : "Camera", "camera-" + kind,
                e -> Photos.camera((jpeg, taken) -> upload(kind, jpeg, taken)));
        Ui.icon(camera, FontImage.MATERIAL_PHOTO_CAMERA, 3f);
        Button gallery = Ui.link("Gallery", "gallery-" + kind,
                e -> Photos.gallery((jpeg, taken) -> upload(kind, jpeg, taken)));
        Ui.icon(gallery, FontImage.MATERIAL_PHOTO_LIBRARY, 3f);
        ways.add(camera).add(gallery);
        box.add(ways);
        return box;
    }

    private void upload(final String kind, byte[] jpeg, final Image picture) {
        DocumentUploadDto document = new DocumentUploadDto(kind, "image/jpeg",
                Base64.encodeNoNewline(jpeg));
        Api.onboarding().upload(document, Net.to(saved -> {
            application = saved;
            thumbs.put(kind, picture);
            if (step == 3) {
                display();
            }
        }, this::failed));
    }

    private void review() {
        body.add(Ui.text("Have a last look. You can change anything until it is handed in.",
                "SvMuted"));
        Ui.section(body, "You");
        body.add(Ui.fact("Legal name", application.legalName()));
        body.add(Ui.fact("Date of birth", application.dateOfBirth()));
        body.add(Ui.fact("Licence", application.licenceNumber()));
        body.add(Ui.fact("Licence expires", application.licenceExpiry()));
        Ui.section(body, "Your vehicle");
        body.add(Ui.fact("Vehicle", ApplyForm.car(application)));
        body.add(Ui.fact("Licence plate", application.vehiclePlate()));
        Ui.section(body, "Documents");
        int have = KINDS.length - ApplyForm.missing(application);
        Container documents = Ui.fact("Photos added", have + " / " + KINDS.length);
        documents.getComponentAt(1).setName("documentsAdded");
        body.add(documents);
        body.add(Ui.text("By submitting you confirm that all of this is true and that the "
                + "documents are your own.", "SvMuted"));
    }

    // ----------------------------------------------------------- moving along

    private void forward() {
        collect.run();
        // What the step asks for, asked for here: the server would take a
        // half-empty draft, and say what is missing only at the very end.
        if (incomplete()) {
            error.setText(Lang.tr("Fill in everything on this step to continue."));
            Ui.refresh(form);
            return;
        }
        next.setEnabled(false);
        error.setText("");
        if (step == STEPS.length - 1) {
            Api.onboarding().submit(Net.to(submitted -> {
                Telemetry.applicationSubmitted();
                next.setEnabled(true);
                Ui.say("Application sent. We will be in touch.");
                done.run();
            }, this::failed));
            return;
        }
        if (step == 3) {
            // Nothing typed on this step: each picture was sent as it was taken.
            next.setEnabled(true);
            step++;
            display();
            return;
        }
        Api.onboarding().save(application, Net.to(saved -> {
            application = saved;
            next.setEnabled(true);
            step++;
            display();
        }, this::failed));
    }

    private boolean incomplete() {
        if (step == 0) {
            return empty(application.legalName()) || empty(application.dateOfBirth());
        }
        if (step == 1) {
            return empty(application.licenceNumber()) || empty(application.licenceExpiry());
        }
        if (step == 2) {
            return empty(application.vehicleMake()) || empty(application.vehicleModel())
                    || empty(application.vehicleColor()) || empty(application.vehiclePlate())
                    || application.vehicleYear() <= 0;
        }
        return false;
    }

    private static boolean empty(String text) {
        return text == null || text.length() == 0;
    }

    private void backward() {
        collect.run();
        if (step > 0) {
            step--;
            display();
        }
    }

    private void failed(int status, String message) {
        next.setEnabled(true);
        // The server's own sentence: what is missing, or what is wrong with it.
        error.setText(Lang.tr(message));
        Ui.refresh(form);
    }

    private String status(String kind) {
        for (int iter = 0; application.documents() != null && iter < application.documents().size();
                iter++) {
            DocumentDto document = application.documents().get(iter);
            if (kind.equals(document.kind())) {
                return document.status();
            }
        }
        return "missing";
    }

    private static Container side(String uiid) {
        Container side = new Container(BoxLayout.y());
        side.setUIID(uiid);
        return side;
    }

    /// A field for a date, which opens the platform's own way of choosing one.
    private static Picker date(Container to, String caption, String name, String value) {
        Picker picker = new Picker();
        picker.setType(Display.PICKER_TYPE_DATE);
        picker.setUIID("SvField");
        picker.setName(name);
        picker.setFormatter(new SimpleDateFormat("d MMM yyyy"));
        if (value != null && value.length() > 0) {
            try {
                picker.setDate(new SimpleDateFormat(ISO).parse(value));
            } catch (ParseException unreadable) {
                // Left on today: the server would not have stored such a date.
                picker.setDate(new Date());
            }
        }
        to.add(Ui.label(caption, "SvLabel")).add(picker);
        return picker;
    }

    private static String iso(Picker picker) {
        Date date = picker.getDate();
        return date == null ? "" : new SimpleDateFormat(ISO).format(date);
    }

    private static int number(String text) {
        String trimmed = text == null ? "" : text.trim();
        if (trimmed.length() == 0 || trimmed.length() > 6) {
            return 0;
        }
        for (int iter = 0; iter < trimmed.length(); iter++) {
            if (trimmed.charAt(iter) < '0' || trimmed.charAt(iter) > '9') {
                return 0;
            }
        }
        return Integer.parseInt(trimmed);
    }
}
