package com.codenameone.examples.savor.admin;

import com.codename1.components.ScaleImageLabel;
import com.codename1.io.Log;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.util.Base64;
import com.codenameone.examples.savor.Telemetry;
import com.codenameone.examples.savor.api.DocumentContentDto;
import com.codenameone.examples.savor.api.DocumentDto;
import com.codenameone.examples.savor.api.CourierApplicationDto;
import com.codenameone.examples.savor.api.ReasonDto;
import com.codenameone.examples.savor.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.savor.ui.Lang;
import com.codenameone.examples.savor.ui.Ui;
import java.util.List;

/// The people who asked to drive, and the decision about each.
///
/// An application is approved or sent back with a reason. Approving is what
/// makes the account a courier; nothing else in the app or on the server does.
/// The documents are pictures only an admin and the applicant can fetch, one
/// at a time, when they are opened.
public final class ApplicationsForm {
    private static final String[] KINDS = {"photo_id", "licence", "selfie",
        "vehicle_registration", "insurance"};
    private static final String[] KIND_NAMES = {"Photo ID", "Driving licence", "A photo of you",
        "Vehicle registration", "Insurance"};

    private final Panes panes;
    private final Container list = Ui.list("applications");
    private String status = "pending";

    private ApplicationsForm(Panes panes) {
        this.panes = panes;
        Container top = new Container(BoxLayout.y());
        top.setUIID("SvPage");
        top.add(Ui.choice("status", new String[] {"Waiting", "Approved", "Sent back"},
                new String[] {"pending", "approved", "rejected"}, status, value -> {
                    status = value;
                    load();
                }));
        Ui.pull(list, this::load);
        panes.list("Applications", "Applications", Panes.listed(top, list), this::load);
    }

    static void show(Form previous) {
        show(Panes.phone(previous));
    }

    static void show(Panes panes) {
        new ApplicationsForm(panes);
    }

    private void load() {
        final String asked = status;
        Api.admin().applications(asked, Net.to(found -> {
            if (asked.equals(status)) {
                fill(found);
            }
        }, Ui.failed(list, this::load)));
    }

    private void fill(List<CourierApplicationDto> found) {
        list.removeAll();
        if (found == null || found.isEmpty()) {
            list.add(Ui.empty(FontImage.MATERIAL_INBOX, "Nothing here",
                    "pending".equals(status) ? "Every application has had its answer." : null));
        }
        for (int iter = 0; found != null && iter < found.size(); iter++) {
            final CourierApplicationDto application = found.get(iter);
            Container row = Ui.row((char) 0, application.name(), car(application),
                    Ui.badge(word(application.status()), badge(application.status())));
            row.add(BorderLayout.WEST, FlowLayout.encloseCenterMiddle(
                    Ui.avatar(application.name())));
            final Container picked = row;
            list.add(Ui.tap(row, "application-" + application.username(), e -> {
                panes.picked(picked);
                review(application.username());
            }));
        }
        panes.refresh();
    }

    /// One application in full, fetched fresh: it may have been answered by
    /// another admin since the list was drawn.
    private void review(final String username) {
        Api.admin().application(username, Net.to(application -> show(application), Ui::fail));
    }

    private void show(final CourierApplicationDto application) {
        Container page = Ui.page();
        Label state = Ui.badge(word(application.status()), badge(application.status()));
        state.setName("applicationStatus");
        page.add(Ui.person(application.name(), application.username(), state));
        if ("rejected".equals(application.status())) {
            page.add(Ui.text(application.rejectionReason(), "SvNotice"));
        }

        Ui.section(page, "Applicant");
        page.add(Ui.fact("Legal name", application.legalName()));
        page.add(Ui.fact("Date of birth", application.dateOfBirth()));
        page.add(Ui.fact("Licence", application.licenceNumber()));
        page.add(Ui.fact("Licence expires", application.licenceExpiry()));
        if (application.submittedAt() > 0) {
            page.add(Ui.fact("Submitted", Ui.when(application.submittedAt())));
        }
        if (application.reviewedAt() > 0) {
            page.add(Ui.fact("Reviewed", Ui.when(application.reviewedAt())));
            page.add(Ui.fact("Reviewed by", application.reviewedBy()));
        }

        Ui.section(page, "Vehicle");
        page.add(Ui.fact("Vehicle", car(application)));
        page.add(Ui.fact("Licence plate", application.vehiclePlate()));

        Ui.section(page, "Documents");
        for (int iter = 0; iter < KINDS.length; iter++) {
            final String kind = KINDS[iter];
            final String title = KIND_NAMES[iter];
            String had = status(application, kind);
            boolean missing = "missing".equals(had);
            Container row = Ui.row(FontImage.MATERIAL_IMAGE, title,
                    missing ? "Not provided" : "Tap to open", Ui.badge(
                            missing ? "Missing" : "Provided",
                            missing ? "SvBadgeBad" : "SvBadgeGood"));
            if (missing) {
                page.add(row);
            } else {
                page.add(Ui.tap(row, "document-" + kind,
                        e -> picture(application.username(), kind, title)));
            }
        }

        if ("pending".equals(application.status())) {
            page.add(Ui.primary("Approve", "approve", e -> Api.admin().approve(
                    application.username(), Net.to(approved -> {
                        Telemetry.applicationReviewed(true);
                        Ui.say(Lang.tr("{0} can now deliver", application.name()));
                        panes.home();
                    }, Ui::fail))));
            page.add(Ui.danger("Send back", "reject", e -> panes.reason("Send back",
                    Lang.tr("{0} sees what you write, and can apply again once it is put "
                            + "right.", application.name()), "Send back", why -> {
                        ReasonDto reason = new ReasonDto(why);
                        Api.admin().reject(application.username(), reason, Net.to(rejected -> {
                            Telemetry.applicationReviewed(false);
                            panes.home();
                        }, Ui::fail));
                    })));
        }
        panes.detail(application.name(), "ApplicationReview", page);
    }

    /// A document, as large as the screen allows.
    private void picture(String username, String kind, String title) {
        final Container stage = new Container(new BorderLayout());
        stage.setUIID("SvPicture");
        panes.over(title, "Document", stage);
        Api.admin().document(username, kind, Net.to(content -> {
            Image image = decode(content);
            if (image == null) {
                stage.add(BorderLayout.CENTER, Ui.empty(FontImage.MATERIAL_BROKEN_IMAGE,
                        "This picture could not be opened", null));
            } else {
                ScaleImageLabel shown = new ScaleImageLabel(image);
                shown.setUIID("SvPicture");
                shown.setBackgroundType(Style.BACKGROUND_IMAGE_SCALED_FIT);
                shown.setName("picture");
                stage.add(BorderLayout.CENTER, shown);
            }
            panes.refresh();
        }, Ui::fail));
    }

    private static Image decode(DocumentContentDto content) {
        if (content == null || content.dataBase64() == null || content.dataBase64().length() == 0) {
            return null;
        }
        try {
            byte[] data = Base64.decode(content.dataBase64().getBytes("UTF-8"));
            return data == null ? null : Image.createImage(data, 0, data.length);
        } catch (java.io.UnsupportedEncodingException impossible) {
            Log.e(impossible);
            return null;
        } catch (RuntimeException unreadable) {
            // Not a picture after all; the screen says so.
            Log.e(unreadable);
            Telemetry.error(unreadable);
            return null;
        }
    }

    private static String status(CourierApplicationDto application, String kind) {
        for (int iter = 0; application.documents() != null && iter < application.documents().size();
                iter++) {
            DocumentDto document = application.documents().get(iter);
            if (kind.equals(document.kind())) {
                return document.status();
            }
        }
        return "missing";
    }

    private static String car(CourierApplicationDto application) {
        StringBuilder car = new StringBuilder();
        String[] words = {application.vehicleColor(), application.vehicleMake(),
            application.vehicleModel(),
            application.vehicleYear() > 0 ? String.valueOf(application.vehicleYear()) : ""};
        for (int iter = 0; iter < words.length; iter++) {
            if (words[iter] != null && words[iter].length() > 0) {
                car.append(car.length() > 0 ? " " : "").append(words[iter]);
            }
        }
        return car.toString();
    }

    static String word(String status) {
        return "pending".equals(status) ? "Waiting" : "approved".equals(status) ? "Approved"
                : "rejected".equals(status) ? "Sent back" : "Draft";
    }

    static String badge(String status) {
        return "pending".equals(status) ? "SvBadgeWarn" : "approved".equals(status)
                ? "SvBadgeGood" : "rejected".equals(status) ? "SvBadgeBad" : "SvBadge";
    }
}
