package com.codenameone.examples.savor.net;

import com.codename1.io.rest.RestClients;
import com.codenameone.examples.savor.api.AccountApi;
import com.codenameone.examples.savor.api.AdminApi;
import com.codenameone.examples.savor.api.CatalogApi;
import com.codenameone.examples.savor.api.CourierApi;
import com.codenameone.examples.savor.api.OnboardingApi;
import com.codenameone.examples.savor.api.GeoApi;
import com.codenameone.examples.savor.api.MerchantApi;
import com.codenameone.examples.savor.api.OrderApi;
import com.codenameone.examples.savor.api.PaymentApi;

/// The server, as the app calls it.
///
/// Each of these is an implementation the build generated from an interface in
/// the `shared` module. The server implements the other half of the same
/// interface, so a path or a field that changes on one side stops the other
/// from compiling.
public final class Api {
    private static AccountApi account;
    private static CatalogApi catalog;
    private static OrderApi orders;
    private static MerchantApi merchant;
    private static CourierApi courier;
    private static GeoApi geo;
    private static AdminApi admin;
    private static PaymentApi payments;
    private static OnboardingApi onboarding;

    private Api() {
    }

    static void connect(String baseUrl) {
        account = RestClients.create(AccountApi.class, baseUrl);
        catalog = RestClients.create(CatalogApi.class, baseUrl);
        orders = RestClients.create(OrderApi.class, baseUrl);
        merchant = RestClients.create(MerchantApi.class, baseUrl);
        courier = RestClients.create(CourierApi.class, baseUrl);
        geo = RestClients.create(GeoApi.class, baseUrl);
        admin = RestClients.create(AdminApi.class, baseUrl);
        payments = RestClients.create(PaymentApi.class, baseUrl);
        onboarding = RestClients.create(OnboardingApi.class, baseUrl);
    }

    public static AccountApi account() {
        return account;
    }

    /// Restaurants and their menus, and applying to open one.
    public static CatalogApi catalog() {
        return catalog;
    }

    /// The customer's orders, favourites and addresses.
    public static OrderApi orders() {
        return orders;
    }

    /// The restaurant the caller is on the staff of.
    public static MerchantApi merchant() {
        return merchant;
    }

    public static CourierApi courier() {
        return courier;
    }

    public static GeoApi geo() {
        return geo;
    }

    public static AdminApi admin() {
        return admin;
    }

    public static PaymentApi payments() {
        return payments;
    }

    /// Applying to deliver, which is open to everyone; [#courier] is for those
    /// whose application was approved.
    public static OnboardingApi onboarding() {
        return onboarding;
    }
}
