package com.codenameone.examples.savor.merchant;

import com.codename1.components.Switch;
import com.codename1.ui.CN;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.util.UITimer;
import com.codenameone.examples.savor.api.OrderDto;
import com.codenameone.examples.savor.api.OrderState;
import com.codenameone.examples.savor.api.RestaurantDto;
import com.codenameone.examples.savor.live.LiveChannel;
import com.codenameone.examples.savor.net.Api;
import com.codenameone.examples.savor.net.Net;
import com.codenameone.examples.savor.ui.Lang;
import com.codenameone.examples.savor.ui.Layouts;
import com.codenameone.examples.savor.ui.Menu;
import com.codenameone.examples.savor.ui.Nav;
import com.codenameone.examples.savor.ui.Ui;

import java.util.List;

/// The restaurant's side of the app: the orders coming in, the menu they are
/// ordered from, and whether the kitchen is taking any.
///
/// Which restaurant is the server's to say. An account is a merchant because it
/// is on a restaurant's staff, and every call this screen makes is answered for
/// that restaurant alone.
///
/// On a tablet or a desktop the queue stays down the left and the order picked
/// in it fills the rest; on a phone the order opens over the queue.
public class MerchantForm extends LiveChannel.Adapter implements Nav.Home {
    private static final Net.Failed QUIET = (status, message) -> { };
    /// How often the queue is read while the live channel is down.
    private static final int POLL_MILLIS = 8000;
    private static final float QUEUE_MM = 92f;

    private final Form form = Ui.home("Restaurant");
    private final Menu menu = new Menu(form, Nav.MERCHANT);
    private final Container body = new Container(new BorderLayout());
    private final Label title = Ui.label("Your restaurant", "SvHeading");
    private final Label status = Ui.label("Taking orders", "SvMutedSmall");
    private final Switch open = new Switch();
    private RestaurantDto restaurant;
    private Container queue;
    private Container detail;
    private String picked;
    private int waiting = -1;
    private String place = "orders";

    public MerchantForm() {
        menu.item(FontImage.MATERIAL_RECEIPT_LONG, "Orders", "home", () -> go("orders"));
        menu.item(FontImage.MATERIAL_RESTAURANT_MENU, "Menu", "menu-editor", () -> go("menu"));
        menu.item(FontImage.MATERIAL_INSIGHTS, "Sales", "sales", () -> go("sales"));
        menu.item(FontImage.MATERIAL_STOREFRONT, "Store details", "store",
                () -> StoreForm.show(form, restaurant, saved -> shown(saved)));
        Container bar = new Container(new BorderLayout());
        bar.setUIID("SvHomeBar");
        bar.add(BorderLayout.WEST, FlowLayout.encloseCenterMiddle(menu.flatButton()));
        // The name over whether it is taking orders, so that a long name and
        // the switch share a phone's width without running into each other.
        Container named = new Container(BoxLayout.y());
        named.add(title).add(status);
        bar.add(BorderLayout.CENTER, BorderLayout.centerAbsolute(named));
        open.setName("accepting");
        open.addActionListener(e -> pause(!open.isValue()));
        bar.add(BorderLayout.EAST, FlowLayout.encloseRightMiddle(open));
        Container screen = new Container(new BorderLayout());
        screen.setUIID("SvForm");
        screen.setSafeArea(true);
        screen.add(BorderLayout.NORTH, bar);
        screen.add(BorderLayout.CENTER, body);
        form.add(screen);
        menu.install();
        form.addShowListener(e -> {
            LiveChannel.listen(this);
            reload();
        });
        Layouts.onChange(form, () -> go(place));
        UITimer.timer(POLL_MILLIS, true, form, () -> {
            if (!LiveChannel.connected() && "orders".equals(place)) {
                loadQueue();
            }
        });
    }

    @Override
    public Form form() {
        return form;
    }

    @Override
    public void start() {
        go("orders");
    }

    private void reload() {
        Api.merchant().restaurant(Net.to(this::shown, QUIET));
        if ("orders".equals(place)) {
            loadQueue();
        }
    }

    private void shown(RestaurantDto found) {
        restaurant = found;
        title.setText(found.name());
        open.setValue(!found.paused());
        status.setText(Lang.tr(found.paused() ? "Paused" : "Taking orders"));
        form.revalidateLater();
    }

    private void pause(final boolean paused) {
        Api.merchant().pause(paused, Net.to(saved -> {
            shown(saved);
            Ui.say(paused ? "New orders are paused" : "Taking orders again");
        }, (status, message) -> {
            // Back to what it was: the switch says whether orders are taken.
            open.setValue(paused);
            Ui.fail(status, message);
        }));
    }

    private void go(String where) {
        place = where;
        body.removeAll();
        queue = null;
        detail = null;
        if ("menu".equals(where)) {
            body.add(BorderLayout.CENTER, new MenuEditor(form).page());
        } else if ("sales".equals(where)) {
            body.add(BorderLayout.CENTER, SalesPage.page());
        } else {
            queue = Ui.list("queue");
            Ui.pull(queue, this::loadQueue);
            if (Layouts.wide()) {
                Container left = new Container(new BorderLayout()) {
                    @Override
                    protected com.codename1.ui.geom.Dimension calcPreferredSize() {
                        return new com.codename1.ui.geom.Dimension(CN.convertToPixels(QUEUE_MM),
                                super.calcPreferredSize().getHeight());
                    }
                };
                left.setUIID("SvQueuePane");
                left.add(BorderLayout.CENTER, queue);
                detail = new Container(new BorderLayout());
                detail.setUIID("SvDetailPane");
                detail.add(BorderLayout.CENTER, Ui.empty(FontImage.MATERIAL_RECEIPT_LONG,
                        Lang.tr("Pick an order"), null));
                body.add(BorderLayout.WEST, left);
                body.add(BorderLayout.CENTER, detail);
            } else {
                body.add(BorderLayout.CENTER, queue);
            }
            loadQueue();
        }
        form.revalidate();
    }

    private void loadQueue() {
        final Container into = queue;
        if (into == null) {
            return;
        }
        Api.merchant().orders(Net.to(found -> fill(into, found),
                Ui.failed(into, this::loadQueue)));
    }

    private void fill(Container into, List<OrderDto> found) {
        int placed = 0;
        into.removeAll();
        if (found.isEmpty()) {
            into.add(Ui.empty(FontImage.MATERIAL_STOREFRONT, Lang.tr("No orders right now"),
                    Lang.tr("New orders appear here as customers place them.")));
        }
        OrderDto again = null;
        for (final OrderDto order : found) {
            if (order.state() == OrderState.PLACED) {
                placed++;
            }
            if (order.id().equals(picked)) {
                again = order;
            }
            into.add(row(order));
        }
        // A new order is the one thing on this screen worth interrupting
        // the kitchen for.
        if (waiting >= 0 && placed > waiting) {
            Display.getInstance().vibrate(400);
            Ui.say("New order");
        }
        waiting = placed;
        Ui.relayout(into);
        if (detail != null) {
            if (again != null) {
                open(again);
            } else if (picked != null) {
                picked = null;
                detail.removeAll();
                detail.add(BorderLayout.CENTER, Ui.empty(FontImage.MATERIAL_RECEIPT_LONG,
                        Lang.tr("Pick an order"), null));
                Ui.relayout(detail);
            }
        }
    }

    private Component row(final OrderDto order) {
        Container row = new Container(new BorderLayout());
        row.setUIID(order.id().equals(picked) ? "SvQueueRowPicked" : "SvQueueRow");
        Container words = new Container(BoxLayout.y());
        words.add(Ui.plain(order.customerName(), "SvRowTitle"));
        words.add(Ui.plain(Orders.summary(order), "SvMutedSmall"));
        words.add(Ui.plain("#" + Orders.shortId(order.id()) + Ui.DOT + Ui.when(order.placedAt()),
                "SvMutedSmall"));
        row.add(BorderLayout.CENTER, words);
        row.add(BorderLayout.EAST, Ui.badge(Orders.state(order.state()),
                Orders.badge(order.state())));
        return Ui.tap(row, "queue-" + order.id(), e -> {
            picked = order.id();
            if (detail == null) {
                OrderPane.show(form, order, this::loadQueue);
            } else {
                open(order);
                // Read again, which also marks the picked row.
                loadQueue();
            }
        });
    }

    private void open(OrderDto order) {
        detail.removeAll();
        detail.add(BorderLayout.CENTER, OrderPane.page(order, changed -> loadQueue()));
        Ui.relayout(detail);
    }

    @Override
    public void orderChanged(String id, String state) {
        if (CN.getCurrentForm() == form && "orders".equals(place)) {
            loadQueue();
        }
    }
}
