package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Kudos;

import java.util.List;

@Repository(entity = Kudos.class, key = String.class)
public interface KudosRepository extends CrudRepository<Kudos, String> {
    List<Kudos> findByWorkoutIdIn(List<String> workoutIds);

    boolean existsByFromAccountAndWorkoutId(String fromAccount, String workoutId);

    int deleteByFromAccount(String account);

    int deleteByToAccount(String account);
}
