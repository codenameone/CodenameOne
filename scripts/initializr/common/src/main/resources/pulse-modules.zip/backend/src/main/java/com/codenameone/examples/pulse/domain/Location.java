package com.codenameone.examples.pulse.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A site. Opening hours are minutes after midnight in the site's own zone.
@Entity
public class Location {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(120)")
    private String name = "";

    @Column(nullable = false, type = "VARCHAR(255)")
    private String address = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String timeZone = "";

    @Column(nullable = false)
    private int opensMinute;

    @Column(nullable = false)
    private int closesMinute;

    public Location() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public int getOpensMinute() {
        return opensMinute;
    }

    public void setOpensMinute(int opensMinute) {
        this.opensMinute = opensMinute;
    }

    public int getClosesMinute() {
        return closesMinute;
    }

    public void setClosesMinute(int closesMinute) {
        this.closesMinute = closesMinute;
    }
}
