package com.codenameone.examples.pulse.desk;

import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.PreAuthorize;
import com.codenameone.examples.pulse.Caller;
import com.codenameone.examples.pulse.api.CheckInRequestDto;
import com.codenameone.examples.pulse.api.CheckInResultDto;
import com.codenameone.examples.pulse.api.DeskApiServer;
import com.codenameone.examples.pulse.api.DeskDayDto;
import com.codenameone.examples.pulse.api.MemberSummaryDto;
import com.codenameone.examples.pulse.api.WalkInDto;

import java.util.List;

/// The server's half of `DeskApi`, for the front desk, the door kiosk and
/// the owner. Guarded by path in the filter chain and by role here.
@Component
@PreAuthorize("hasAnyRole('DESK', 'OWNER')")
public class DeskEndpoint implements DeskApiServer {
    private final Desk desk;

    public DeskEndpoint(Desk desk) {
        this.desk = desk;
    }

    @Override
    public CheckInResultDto checkIn(CheckInRequestDto request) throws Exception {
        return desk.checkIn(Caller.name(), request);
    }

    @Override
    public List<MemberSummaryDto> find(String q) throws Exception {
        Caller.name();
        return desk.find(q);
    }

    @Override
    public WalkInDto walkIn(WalkInDto walkIn) throws Exception {
        return desk.walkIn(Caller.name(), walkIn);
    }

    @Override
    public DeskDayDto today(String location) throws Exception {
        return desk.today(Caller.name(), location);
    }
}
