package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Workout;

import java.time.Instant;
import java.util.List;

@Repository(entity = Workout.class, key = String.class)
public interface WorkoutRepository extends CrudRepository<Workout, String> {
    List<Workout> findByAccountOrderByStartedAtDesc(String account);
    List<Workout> findBySessionIdIn(List<String> sessionIds);

    List<Workout> findByAccountAndStartedAtGreaterThanEqual(String account, Instant since);

    List<Workout> findByAccountInAndSharedTrueAndStartedAtGreaterThanEqualOrderByStartedAtDesc(
            List<String> accounts, Instant since);

    boolean existsByAccountAndStartedAt(String account, Instant startedAt);

    int deleteByAccount(String account);
}
