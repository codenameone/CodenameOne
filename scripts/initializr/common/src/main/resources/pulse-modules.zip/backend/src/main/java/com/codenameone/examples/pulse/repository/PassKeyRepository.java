package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.PassKey;

import java.util.List;

@Repository(entity = PassKey.class, key = String.class)
public interface PassKeyRepository extends CrudRepository<PassKey, String> {
    PassKey findFirstByNfcId(String nfcId);

    List<PassKey> findByMemberIdIn(List<String> memberIds);

    int deleteByMemberIdIn(List<String> memberIds);
}
