package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Staff;

import java.util.List;

@Repository(entity = Staff.class, key = String.class)
public interface StaffRepository extends CrudRepository<Staff, String> {
    List<Staff> findByActiveTrueOrderByUsernameAsc();

    @Query("select s from Staff s order by s.username asc")
    List<Staff> findAllByOrderByUsernameAsc();
}
