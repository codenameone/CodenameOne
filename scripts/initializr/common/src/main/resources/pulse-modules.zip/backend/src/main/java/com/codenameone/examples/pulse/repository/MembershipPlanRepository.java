package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.MembershipPlan;

import java.util.List;

@Repository(entity = MembershipPlan.class, key = String.class)
public interface MembershipPlanRepository extends CrudRepository<MembershipPlan, String> {
    @Query("select p from MembershipPlan p order by p.priceCents asc")
    List<MembershipPlan> findAllByOrderByPriceCentsAsc();

    List<MembershipPlan> findByActiveTrueOrderByPriceCentsAsc();
}
