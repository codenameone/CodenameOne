package com.codenameone.examples.pulse.owner;

import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.PreAuthorize;
import com.codenameone.examples.pulse.Caller;
import com.codenameone.examples.pulse.api.CampaignDto;
import com.codenameone.examples.pulse.api.ClassTypeDto;
import com.codenameone.examples.pulse.api.InvoiceDto;
import com.codenameone.examples.pulse.api.NewSessionDto;
import com.codenameone.examples.pulse.api.OwnerApiServer;
import com.codenameone.examples.pulse.api.OwnerDashboardDto;
import com.codenameone.examples.pulse.api.PlanDto;
import com.codenameone.examples.pulse.api.ReasonDto;
import com.codenameone.examples.pulse.api.RoomDto;
import com.codenameone.examples.pulse.api.SessionDto;
import com.codenameone.examples.pulse.api.ShiftDto;
import com.codenameone.examples.pulse.api.StaffDto;
import com.codenameone.examples.pulse.billing.Billing;

import java.util.List;

/// The server's half of `OwnerApi`.
@Component
@PreAuthorize("hasRole('OWNER')")
public class OwnerEndpoint implements OwnerApiServer {
    private final Owner owner;
    private final Billing billing;

    public OwnerEndpoint(Owner owner, Billing billing) {
        this.owner = owner;
        this.billing = billing;
    }

    @Override
    public OwnerDashboardDto dashboard() throws Exception {
        return owner.dashboard();
    }

    @Override
    public List<PlanDto> plans() throws Exception {
        return billing.plans(true);
    }

    @Override
    public PlanDto savePlan(PlanDto body) throws Exception {
        return owner.savePlan(body);
    }

    @Override
    public ClassTypeDto saveClassType(ClassTypeDto body) throws Exception {
        return owner.saveClassType(body);
    }

    @Override
    public List<RoomDto> rooms() throws Exception {
        return owner.rooms();
    }

    @Override
    public List<SessionDto> schedule(NewSessionDto body) throws Exception {
        return owner.schedule(body);
    }

    @Override
    public SessionDto cancelClass(String id, ReasonDto body) throws Exception {
        return owner.cancelClass(id, body == null ? "" : body.reason());
    }

    @Override
    public SessionDto substitute(String id, String trainer) throws Exception {
        return owner.substitute(id, trainer);
    }

    @Override
    public List<StaffDto> staff() throws Exception {
        return owner.staff();
    }

    @Override
    public StaffDto saveStaff(StaffDto body) throws Exception {
        return owner.saveStaff(Caller.name(), body);
    }

    @Override
    public List<ShiftDto> shifts(String location) throws Exception {
        return owner.shifts(location);
    }

    @Override
    public ShiftDto addShift(ShiftDto body) throws Exception {
        return owner.addShift(body);
    }

    @Override
    public List<CampaignDto> campaigns() throws Exception {
        return owner.campaigns();
    }

    @Override
    public CampaignDto send(CampaignDto body) throws Exception {
        return owner.send(Caller.name(), body);
    }

    @Override
    public List<InvoiceDto> invoices(String status) throws Exception {
        return billing.all(status);
    }

    @Override
    public InvoiceDto voidInvoice(String id, ReasonDto body) throws Exception {
        return billing.voidInvoice(id, body == null ? "" : body.reason());
    }
}
