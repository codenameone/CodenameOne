package com.codenameone.examples.pulse.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// How one person wants the app and their deliveries, when they have said.
@Entity
public class Preference {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false, type = "VARCHAR(8)")
    private String theme = "";

    @Column(nullable = false, type = "VARCHAR(4)")
    private String units = "";

    @Column(nullable = false)
    private boolean notifyReceipts;

    @Column(nullable = false)
    private boolean notifyPromotions;

    @Column(nullable = false)
    private boolean notifyClasses;

    @Column(nullable = false)
    private int quietFrom;

    @Column(nullable = false)
    private int quietTo;

    public Preference() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public boolean isNotifyReceipts() {
        return notifyReceipts;
    }

    public void setNotifyReceipts(boolean notifyReceipts) {
        this.notifyReceipts = notifyReceipts;
    }

    public boolean isNotifyPromotions() {
        return notifyPromotions;
    }

    public void setNotifyPromotions(boolean notifyPromotions) {
        this.notifyPromotions = notifyPromotions;
    }

    public boolean isNotifyClasses() {
        return notifyClasses;
    }

    public void setNotifyClasses(boolean notifyClasses) {
        this.notifyClasses = notifyClasses;
    }

    public int getQuietFrom() {
        return quietFrom;
    }

    public void setQuietFrom(int quietFrom) {
        this.quietFrom = quietFrom;
    }

    public int getQuietTo() {
        return quietTo;
    }

    public void setQuietTo(int quietTo) {
        this.quietTo = quietTo;
    }
}
