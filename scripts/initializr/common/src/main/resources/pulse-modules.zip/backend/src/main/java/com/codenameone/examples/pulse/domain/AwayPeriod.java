package com.codenameone.examples.pulse.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;
import java.time.LocalDate;

/// A member saying they will not be in: travelling, injured. No nudge reaches
/// them meanwhile, and with `freeze_billing` their membership is frozen for
/// the days it covers.
@Entity
public class AwayPeriod {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String account = "";

    @Column(nullable = false)
    private LocalDate startsOn = LocalDate.of(1970, 1, 1);

    @Column(nullable = false)
    private LocalDate endsOn = LocalDate.of(1970, 1, 1);

    @Column(nullable = false, type = "VARCHAR(16)")
    private String reason = "";

    @Column(nullable = false)
    private boolean freezeBilling;

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    public AwayPeriod() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public LocalDate getStartsOn() {
        return startsOn;
    }

    public void setStartsOn(LocalDate startsOn) {
        this.startsOn = startsOn;
    }

    public LocalDate getEndsOn() {
        return endsOn;
    }

    public void setEndsOn(LocalDate endsOn) {
        this.endsOn = endsOn;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public boolean isFreezeBilling() {
        return freezeBilling;
    }

    public void setFreezeBilling(boolean freezeBilling) {
        this.freezeBilling = freezeBilling;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
