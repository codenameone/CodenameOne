package com.codenameone.examples.pulse.studio;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.pulse.Caller;
import com.codenameone.examples.pulse.api.HouseholdApiServer;
import com.codenameone.examples.pulse.api.MemberDto;
import com.codenameone.examples.pulse.api.NewMemberDto;
import com.codenameone.examples.pulse.api.PassDto;

import java.util.List;

/// The server's half of `HouseholdApi`: always the caller's own household.
@Component
public class HouseholdEndpoint implements HouseholdApiServer {
    private final Household household;

    public HouseholdEndpoint(Household household) {
        this.household = household;
    }

    @Override
    public List<MemberDto> members() throws Exception {
        return household.list(Caller.name());
    }

    @Override
    public MemberDto addChild(NewMemberDto child) throws Exception {
        return household.addChild(Caller.name(), child);
    }

    @Override
    public MemberDto signWaiver(String id) throws Exception {
        return household.signWaiver(Caller.name(), id);
    }

    @Override
    public PassDto pass(String id) throws Exception {
        return household.pass(Caller.name(), id);
    }

    @Override
    public PassDto rotatePass(String id) throws Exception {
        return household.rotate(Caller.name(), id);
    }
}
