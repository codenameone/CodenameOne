package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.PhoneCode;

/// The code an account was texted to prove its phone number. An account has at
/// most one.
@Repository(entity = PhoneCode.class, key = String.class)
public interface PhoneCodeRepository extends CrudRepository<PhoneCode, String> {
    /// Takes one of the guesses an account's code allows. The database does
    /// the sum and applies the limit in the same statement, so of any number
    /// of guesses sent at once only as many as are left are let through;
    /// nothing is read and written back.
    ///
    /// The guess is taken of the code whose hash is `codeHash`, and of no
    /// other: a new code sent between reading the hash and taking the guess
    /// has another hash, and the update changes nothing.
    ///
    /// The code before it, when one is kept, is guessed at by the same guess,
    /// so its count goes up too; its own limit is applied by the caller.
    ///
    /// Empties the session, so the code is read again after it with the guess
    /// counted.
    ///
    /// @return 1 for a guess taken, 0 when none is left or there is no code
    @Modifying(clearAutomatically = true)
    @Query("update PhoneCode c set c.attempts = c.attempts + 1, "
            + "c.previousAttempts = c.previousAttempts + 1 "
            + "where c.username = :username and c.codeHash = :hash and c.attempts < :most")
    int takeGuess(@Param("username") String username, @Param("hash") String codeHash,
            @Param("most") int most);

    int deleteByUsername(String username);
}
