package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.ClassType;

import java.util.List;

@Repository(entity = ClassType.class, key = String.class)
public interface ClassTypeRepository extends CrudRepository<ClassType, String> {
    @Query("select t from ClassType t order by t.name asc")
    List<ClassType> findAllByOrderByNameAsc();
}
