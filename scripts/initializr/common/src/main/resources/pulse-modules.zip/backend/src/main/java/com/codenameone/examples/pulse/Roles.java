package com.codenameone.examples.pulse;

/// The roles an account can hold. Every account is a member; teaching, working
/// the front desk and running the studio are granted on top of that, and the
/// app offers a mode for each role the account holds.
public final class Roles {
    public static final String MEMBER = "MEMBER";
    /// Teaches classes: sees their rosters, marks attendance, swaps shifts.
    public static final String TRAINER = "TRAINER";
    /// Works the front desk and the door kiosk: checks people in, takes walk-ins.
    public static final String DESK = "DESK";
    /// Runs the studio: plans, timetable, staff, campaigns, accounts, numbers.
    public static final String OWNER = "OWNER";

    private Roles() {
    }
}
