package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Campaign;

import java.util.List;

@Repository(entity = Campaign.class, key = String.class)
public interface CampaignRepository extends CrudRepository<Campaign, String> {
    @Query("select c from Campaign c order by c.createdAt desc")
    List<Campaign> findAllByOrderByCreatedAtDesc();

    @Modifying
    @Query("update Campaign c set c.opened = c.opened + 1 where c.id = :id")
    int countOpen(@Param("id") String id);

    @Modifying
    @Query("update Campaign c set c.booked = c.booked + 1 where c.id = :id")
    int countBooking(@Param("id") String id);
}
