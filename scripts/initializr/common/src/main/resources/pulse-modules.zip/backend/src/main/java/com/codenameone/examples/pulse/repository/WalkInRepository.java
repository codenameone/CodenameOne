package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.WalkIn;

import java.time.Instant;
import java.util.List;

@Repository(entity = WalkIn.class, key = String.class)
public interface WalkInRepository extends CrudRepository<WalkIn, String> {
    List<WalkIn> findByLocationIdAndAtGreaterThanEqualOrderByAtDesc(String locationId,
            Instant since);

    List<WalkIn> findByAtGreaterThanEqual(Instant since);
}
