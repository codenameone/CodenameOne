package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Nudge;

import java.time.Instant;
import java.util.List;

@Repository(entity = Nudge.class, key = String.class)
public interface NudgeRepository extends CrudRepository<Nudge, String> {
    List<Nudge> findByAccountOrderBySentAtDesc(String account);

    Nudge findFirstByIdAndAccount(String id, String account);

    boolean existsByAccountAndSessionIdAndKind(String account, String sessionId, String kind);

    boolean existsByAccountAndKindAndSentAtGreaterThan(String account, String kind, Instant since);

    /// The newest nudge about a class an account was sent and has not booked
    /// from yet, to credit a booking to.
    Nudge findFirstByAccountAndSessionIdAndBookedAtOrderBySentAtDesc(String account,
            String sessionId, Instant notBooked);

    int deleteByAccount(String account);
}
