package com.codenameone.examples.pulse.push;

import com.codename1.backend.push.PushNotification;
import com.codename1.backend.push.PushTarget;

import java.util.List;

/// Prints each notification on the server's console instead of sending it.
///
/// For development only: [com.codenameone.examples.pulse.Services] hands it
/// out on a development profile alone.
public class ConsolePushSender implements PushSender {
    @Override
    public void send(List<PushTarget> targets, PushNotification message, Runnable delivered) {
        if (targets == null || targets.isEmpty()) {
            return;
        }
        System.out.println("[push] to " + targets.size() + " device(s): "
                + message.toJson());
        // Printed is as delivered as this sender gets.
        if (delivered != null) {
            delivered.run();
        }
    }
}
