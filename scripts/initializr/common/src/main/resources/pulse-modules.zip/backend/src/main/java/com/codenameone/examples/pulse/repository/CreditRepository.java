package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Credit;

import java.util.List;

@Repository(entity = Credit.class, key = String.class)
public interface CreditRepository extends CrudRepository<Credit, String> {
    List<Credit> findByAccountAndInvoiceIdOrderByCreatedAtAsc(String account, String invoiceId);

    boolean existsByAccountAndReason(String account, String reason);

    int deleteByAccount(String account);
}
