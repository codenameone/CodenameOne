package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.AwayPeriod;

import java.time.LocalDate;
import java.util.List;

@Repository(entity = AwayPeriod.class, key = String.class)
public interface AwayPeriodRepository extends CrudRepository<AwayPeriod, String> {
    List<AwayPeriod> findByAccountAndEndsOnGreaterThanEqualOrderByStartsOnAsc(String account,
            LocalDate from);

    AwayPeriod findFirstByIdAndAccount(String id, String account);

    /// Whether an account is away on a day.
    boolean existsByAccountAndStartsOnLessThanEqualAndEndsOnGreaterThanEqual(String account,
            LocalDate day, LocalDate sameDay);

    List<AwayPeriod> findByStartsOnLessThanEqualAndEndsOnGreaterThanEqual(LocalDate day,
            LocalDate sameDay);

    int deleteByAccount(String account);
}
