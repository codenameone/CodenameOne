package com.codenameone.examples.pulse.social;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.pulse.api.FeedItemDto;
import com.codenameone.examples.pulse.api.FriendDto;
import com.codenameone.examples.pulse.api.FriendRequestDto;
import com.codenameone.examples.pulse.api.InviteDto;
import com.codenameone.examples.pulse.api.NudgeDto;
import com.codenameone.examples.pulse.api.SocialApiServer;

import java.util.List;

/// The server's half of `SocialApi`.
@Component
public class SocialEndpoint implements SocialApiServer {
    private final Social social;

    public SocialEndpoint(Social social) {
        this.social = social;
    }

    @Override
    public List<FriendDto> friends() throws Exception {
        return social.friends(Caller.name());
    }

    @Override
    public FriendDto request(FriendRequestDto body) throws Exception {
        return social.request(Caller.name(), body == null ? null : body.email());
    }

    @Override
    public FriendDto accept(String account) throws Exception {
        return social.accept(Caller.name(), account);
    }

    @Override
    public FriendDto remove(String account) throws Exception {
        return social.remove(Caller.name(), account);
    }

    @Override
    public List<FeedItemDto> feed() throws Exception {
        return social.feed(Caller.name());
    }

    @Override
    public FeedItemDto kudos(String id) throws Exception {
        return social.kudos(Caller.name(), id);
    }

    @Override
    public NudgeDto invite(InviteDto body) throws Exception {
        return social.invite(Caller.name(), body);
    }
}
