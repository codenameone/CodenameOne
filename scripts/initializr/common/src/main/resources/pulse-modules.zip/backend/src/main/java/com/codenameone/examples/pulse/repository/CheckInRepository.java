package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.CheckIn;

import java.time.Instant;
import java.util.List;

@Repository(entity = CheckIn.class, key = String.class)
public interface CheckInRepository extends CrudRepository<CheckIn, String> {
    long countByMemberIdAndAtGreaterThanEqual(String memberId, Instant since);

    long countByAccount(String account);

    long countByAccountAndAtGreaterThanEqual(String account, Instant since);

    long countByLocationIdAndAtGreaterThanEqual(String locationId, Instant since);

    long countByAtGreaterThanEqual(Instant since);
    List<CheckIn> findByAtGreaterThanEqual(Instant since);
    List<CheckIn> findByMemberIdAndAtGreaterThanEqualOrderByAtAsc(String memberId, Instant since);
    /// When each member, not account, last came in: a child and their parent
    /// share an account.
    @Query("select c.memberId, max(c.at) from CheckIn c group by c.memberId")
    List<Object[]> lastVisitsByMember();

    List<CheckIn> findByAccountAndAtGreaterThanEqualOrderByAtAsc(String account, Instant since);

    List<CheckIn> findByLocationIdAndAtGreaterThanEqualOrderByAtDesc(String locationId,
            Instant since);

    /// When each account last came in.
    @Query("select c.account, max(c.at) from CheckIn c group by c.account")
    List<Object[]> lastVisits();

    @Query("select max(c.at) from CheckIn c where c.account = :account")
    Instant lastVisit(@Param("account") String account);

    int deleteByAccount(String account);
}
