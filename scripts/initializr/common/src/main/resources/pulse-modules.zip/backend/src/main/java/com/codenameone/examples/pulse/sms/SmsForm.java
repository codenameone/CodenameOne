package com.codenameone.examples.pulse.sms;

import java.io.IOException;
import java.net.URLEncoder;

/// Builds an `application/x-www-form-urlencoded` body, which is what all three
/// providers' send calls take.
final class SmsForm {
    private SmsForm() {
    }

    /// Names and values in turn, each escaped as UTF-8.
    static byte[] of(String... pairs) throws IOException {
        StringBuilder out = new StringBuilder();
        for (int iter = 0; iter + 1 < pairs.length; iter += 2) {
            if (out.length() > 0) {
                out.append('&');
            }
            out.append(URLEncoder.encode(pairs[iter], "UTF-8")).append('=')
                    .append(URLEncoder.encode(pairs[iter + 1], "UTF-8"));
        }
        return out.toString().getBytes("UTF-8");
    }
}
