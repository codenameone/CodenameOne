package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Location;

import java.util.List;

@Repository(entity = Location.class, key = String.class)
public interface LocationRepository extends CrudRepository<Location, String> {
    @Query("select l from Location l order by l.name asc")
    List<Location> findAllByOrderByNameAsc();
}
