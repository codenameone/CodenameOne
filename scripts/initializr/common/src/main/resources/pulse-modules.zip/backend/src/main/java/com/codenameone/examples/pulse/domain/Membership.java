package com.codenameone.examples.pulse.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A member's plan. `current_period_end` is when the next invoice is raised;
/// a freeze moves it on by the frozen days.
@Entity
public class Membership {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String memberId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String account = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String planId = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String state = "";

    @Column(nullable = false)
    private Instant startedAt = Instant.EPOCH;

    @Column(nullable = false)
    private Instant currentPeriodEnd = Instant.EPOCH;

    @Column(nullable = false)
    private int creditsLeft;

    @Column(nullable = false)
    private Instant frozenFrom = Instant.EPOCH;

    @Column(nullable = false)
    private Instant frozenUntil = Instant.EPOCH;

    @Column(nullable = false)
    private boolean cancelAtPeriodEnd;

    @Column(nullable = false)
    private Instant updatedAt = Instant.EPOCH;

    public Membership() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public Instant getCurrentPeriodEnd() {
        return currentPeriodEnd;
    }

    public void setCurrentPeriodEnd(Instant currentPeriodEnd) {
        this.currentPeriodEnd = currentPeriodEnd;
    }

    public int getCreditsLeft() {
        return creditsLeft;
    }

    public void setCreditsLeft(int creditsLeft) {
        this.creditsLeft = creditsLeft;
    }

    public Instant getFrozenFrom() {
        return frozenFrom;
    }

    public void setFrozenFrom(Instant frozenFrom) {
        this.frozenFrom = frozenFrom;
    }

    public Instant getFrozenUntil() {
        return frozenUntil;
    }

    public void setFrozenUntil(Instant frozenUntil) {
        this.frozenUntil = frozenUntil;
    }

    public boolean isCancelAtPeriodEnd() {
        return cancelAtPeriodEnd;
    }

    public void setCancelAtPeriodEnd(boolean cancelAtPeriodEnd) {
        this.cancelAtPeriodEnd = cancelAtPeriodEnd;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }
}
