package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Room;

import java.util.List;

@Repository(entity = Room.class, key = String.class)
public interface RoomRepository extends CrudRepository<Room, String> {
    @Query("select r from Room r order by r.locationId asc, r.name asc")
    List<Room> findAllByOrderByLocationIdAscNameAsc();
}
