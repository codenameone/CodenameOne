package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Friend;

import java.util.List;

/// Friendships, one row per direction: `account` asked `friend`, or accepted
/// them. Two rows, both ACCEPTED, are a friendship.
@Repository(entity = Friend.class, key = String.class)
public interface FriendRepository extends CrudRepository<Friend, String> {
    List<Friend> findByAccount(String account);

    List<Friend> findByFriend(String friend);

    List<Friend> findByAccountAndState(String account, String state);

    int deleteByAccount(String account);

    int deleteByFriend(String friend);
}
