package com.codenameone.examples.pulse.engagement;

import com.codenameone.examples.pulse.domain.Workout;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PointsTest {
    private static Workout workout(int minutes, int avgHr, String source, String zones) {
        Workout row = new Workout();
        row.setMinutes(minutes);
        row.setAvgHr(avgHr);
        row.setSource(source);
        row.setZones(zones);
        return row;
    }

    @Test
    void aStrapIsWorthMoreThanAnEstimateAndAnEstimateMoreThanNothing() {
        List<Workout> none = new ArrayList<Workout>();
        assertEquals(10 * 3 + 5 * 2, Points.score(3, 2, none));
        int bare = Points.score(0, 0, Arrays.asList(workout(45, 0, "HEALTH", "0,0,0,0,0")));
        int phone = Points.score(0, 0, Arrays.asList(workout(45, 130, "HEALTH", "5,5,5,5,0")));
        int strap = Points.score(0, 0, Arrays.asList(workout(45, 130, Points.STRAP, "5,5,5,5,0")));
        assertEquals(9, bare);
        assertEquals(bare + Points.HEART_RATE, phone);
        assertEquals(phone + Points.WORN_SENSOR, strap);
    }

    @Test
    void levelsClimbAndStopAtTheTop() {
        assertEquals(1, Points.level(0));
        assertEquals(2, Points.level(100));
        assertEquals(100, Points.floor(2));
        assertEquals(250, Points.next(2));
        int top = Points.level(1000000);
        assertEquals(Points.LEVELS.length, top);
        assertEquals(Points.floor(top), Points.next(top));
    }

    @Test
    void badgesComeFromTheRecord() {
        List<String> earned = Points.badges(12, 4,
                Arrays.asList(workout(600, 150, Points.WATCH, "1,2,3,4,6")));
        assertEquals(Arrays.asList("FIRST_CLASS", "TEN_CLASSES", "STREAK_4", "HEART_TRACKED",
                "STRAPPED_IN", "ZONE_5", "TEN_HOURS"), earned);
        assertTrue(Points.badges(0, 0, new ArrayList<Workout>()).isEmpty());
        assertEquals(0, Engagement.zoneMinutes(null, 5));
        assertEquals(6, Engagement.zoneMinutes("1,2,3,4,6", 5));
        assertEquals(0, Engagement.zoneMinutes("1,2", 5));
    }
}
