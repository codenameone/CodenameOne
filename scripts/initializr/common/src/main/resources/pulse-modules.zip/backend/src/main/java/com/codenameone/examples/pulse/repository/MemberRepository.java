package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.Member;

import java.util.List;

@Repository(entity = Member.class, key = String.class)
public interface MemberRepository extends CrudRepository<Member, String> {
    List<Member> findByAccountOrderByCreatedAtAsc(String account);

    Member findFirstByIdAndAccount(String id, String account);

    Member findFirstByAccountAndRelation(String account, String relation);

    List<Member> findByIdIn(List<String> ids);

    long countByAccount(String account);

    /// Members whose name, or whose account's e-mail, contains `text`.
    @Query("select m from Member m where m.name like :text or m.account like :text"
            + " order by m.name asc")
    List<Member> search(@Param("text") String text);

    int deleteByAccount(String account);
}
