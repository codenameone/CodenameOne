package com.codenameone.examples.pulse.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.pulse.domain.UsedPassCode;

import java.time.Instant;

@Repository(entity = UsedPassCode.class, key = String.class)
public interface UsedPassCodeRepository extends CrudRepository<UsedPassCode, String> {
    int deleteByExpiresAtLessThan(Instant now);
}
