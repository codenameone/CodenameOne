package com.codenameone.examples.pulse.trainer;

import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.PreAuthorize;
import com.codenameone.examples.pulse.Caller;
import com.codenameone.examples.pulse.Roles;
import com.codenameone.examples.pulse.api.AttendanceDto;
import com.codenameone.examples.pulse.api.RosterEntryDto;
import com.codenameone.examples.pulse.api.SessionDto;
import com.codenameone.examples.pulse.api.ShiftDto;
import com.codenameone.examples.pulse.api.TrainerStatsDto;
import com.codenameone.examples.pulse.api.TrainerApiServer;

import java.util.List;

/// The server's half of `TrainerApi`. An owner may read any class's roster
/// and take its attendance; a trainer only their own.
@Component
@PreAuthorize("hasAnyRole('TRAINER', 'OWNER')")
public class TrainerEndpoint implements TrainerApiServer {
    private final Trainers trainers;

    public TrainerEndpoint(Trainers trainers) {
        this.trainers = trainers;
    }

    @Override
    public List<SessionDto> classes() throws Exception {
        return trainers.classes(Caller.name());
    }

    @Override
    public List<RosterEntryDto> roster(String id) throws Exception {
        return trainers.roster(Caller.name(), Caller.hasRole(Roles.OWNER), id);
    }

    @Override
    public RosterEntryDto attendance(String id, AttendanceDto mark) throws Exception {
        return trainers.attendance(Caller.name(), Caller.hasRole(Roles.OWNER), id, mark);
    }

    @Override
    public TrainerStatsDto stats() throws Exception {
        return trainers.stats(Caller.name());
    }

    @Override
    public List<ShiftDto> shifts() throws Exception {
        return trainers.shifts(Caller.name());
    }

    @Override
    public ShiftDto offer(String id) throws Exception {
        return trainers.offer(Caller.name(), id);
    }

    @Override
    public ShiftDto take(String id) throws Exception {
        return trainers.take(Caller.name(), id);
    }
}
