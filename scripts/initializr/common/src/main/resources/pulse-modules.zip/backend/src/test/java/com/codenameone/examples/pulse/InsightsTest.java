package com.codenameone.examples.pulse;

import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Autowired;
import com.codename1.backend.test.BackendTest;
import com.codenameone.examples.pulse.account.DemoAccounts;
import com.codenameone.examples.pulse.api.InsightsDto;
import com.codenameone.examples.pulse.api.MemberDetailDto;
import com.codenameone.examples.pulse.api.OwnerMemberDto;
import com.codenameone.examples.pulse.api.TrainerStatsDto;
import com.codenameone.examples.pulse.api.TypeFillDto;
import com.codenameone.examples.pulse.owner.Insights;
import com.codenameone.examples.pulse.owner.Owner;
import com.codenameone.examples.pulse.trainer.Trainers;
import java.util.List;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/// The owner's insights and member list, and a trainer's own numbers, over
/// the demo studio the tests start with.
@BackendTest
class InsightsTest {
    @Autowired
    private Insights insights;
    @Autowired
    private Trainers trainers;
    @Autowired
    private Owner owner;

    @Test
    void insightsHaveTheShapeTheAppDraws() throws Exception {
        InsightsDto dto = insights.insights();
        assertTrue(dto.firstHour() < dto.lastHour());
        assertEquals(7 * (dto.lastHour() - dto.firstHour()), dto.busyHours().size());
        assertEquals(12, dto.weeks().size());
        int visits = 0;
        for (int iter = 0; iter < dto.busyHours().size(); iter++) {
            assertTrue(dto.busyHours().get(iter).intValue() >= 0);
            visits += dto.busyHours().get(iter).intValue();
        }
        assertTrue(visits > 0, "the demo studio has visits");
        for (int iter = 1; iter < dto.weeks().size(); iter++) {
            assertTrue(dto.weeks().get(iter).weekOf().compareTo(
                    dto.weeks().get(iter - 1).weekOf()) > 0, "oldest first");
        }
        assertFalse(dto.classes().isEmpty());
        for (int iter = 0; iter < dto.classes().size(); iter++) {
            TypeFillDto type = dto.classes().get(iter);
            assertPercent(type.fillPercent());
            assertPercent(type.noShowPercent());
        }
        assertFalse(dto.plans().isEmpty());
        assertFalse(dto.coaches().isEmpty());
        for (int iter = 0; iter < dto.coaches().size(); iter++) {
            assertPercent(dto.coaches().get(iter).fillPercent());
            assertPercent(dto.coaches().get(iter).showPercent());
        }
        assertPercent(dto.retention90());
        assertPercent(dto.noShowPercent());
        assertTrue(dto.revenuePerMemberCents() > 0);
    }

    @Test
    void theFiltersFindThePeopleTheyName() throws Exception {
        assertTrue(has(insights.members("PAST_DUE"), DemoAccounts.FLAGGED_MEMBER));
        assertFalse(has(insights.members("PAST_DUE"), DemoAccounts.MEMBER));
        assertTrue(has(insights.members("AT_RISK"), DemoAccounts.LAPSED_MEMBER));
        List<OwnerMemberDto> running = insights.members("");
        assertTrue(has(running, DemoAccounts.MEMBER));
        assertTrue(has(running, DemoAccounts.FLAGGED_MEMBER));
        for (int iter = 1; iter < running.size(); iter++) {
            assertTrue(running.get(iter - 1).name().compareToIgnoreCase(
                    running.get(iter).name()) <= 0, "by name");
        }
        List<OwnerMemberDto> cancelled = insights.members("CANCELLED");
        for (int iter = 0; iter < cancelled.size(); iter++) {
            assertEquals("CANCELLED", cancelled.get(iter).state());
        }
    }

    @Test
    void aMembersDetailTellsTheirStory() throws Exception {
        OwnerMemberDto riley = null;
        List<OwnerMemberDto> running = insights.members("");
        for (int iter = 0; iter < running.size(); iter++) {
            if (DemoAccounts.MEMBER.equals(running.get(iter).account())
                    && "Riley Park".equals(running.get(iter).name())) {
                riley = running.get(iter);
            }
        }
        assertNotNull(riley);
        MemberDetailDto detail = insights.member(riley.id());
        assertEquals(riley.id(), detail.member().id());
        assertEquals(12, detail.visitsByWeek().size());
        assertFalse(detail.invoices().isEmpty());
        assertTrue(detail.lifetimeCents() > 0);
        for (int iter = 1; iter < detail.favourites().size(); iter++) {
            assertTrue(detail.favourites().get(iter - 1).count()
                    >= detail.favourites().get(iter).count());
        }
        ResponseStatusException missing = assertThrows(ResponseStatusException.class,
                () -> insights.member("no-such-membership"));
        assertEquals(404, missing.getStatus());
    }

    @Test
    void aTrainerSeesTheirOwnMonth() throws Exception {
        TrainerStatsDto tess = trainers.stats(DemoAccounts.TRAINER);
        assertTrue(tess.classes() > 0, "Tess has taught");
        assertEquals(8, tess.attendeesByWeek().size());
        assertPercent(tess.fillPercent());
        assertPercent(tess.showPercent());
        assertTrue(tess.points() > 0, "Tess has points");
        assertTrue(tess.points() >= tess.levelFloor() && tess.points() < tess.nextLevel());
        assertTrue(tess.rank() >= 1 && tess.rank() <= tess.leaderboard().size());
        for (int iter = 1; iter < tess.leaderboard().size(); iter++) {
            assertTrue(tess.leaderboard().get(iter - 1).count()
                    >= tess.leaderboard().get(iter).count(), "leaderboard is ranked");
        }
        TrainerStatsDto nobody = trainers.stats("nobody@myappname.example");
        assertEquals(0, nobody.classes());
        assertEquals(0, nobody.rank());
        assertEquals(0, nobody.points());
        assertTrue(nobody.badges().isEmpty());
        assertEquals(8, nobody.attendeesByWeek().size());
    }

    @Test
    void anOwnerSeesEveryLocationsShiftsWithNoLocation() throws Exception {
        int all = owner.shifts("").size();
        assertTrue(all > 0, "the demo studio has shifts");
        assertTrue(all >= owner.shifts("loc-downtown").size());
        ResponseStatusException missing = assertThrows(ResponseStatusException.class,
                () -> owner.shifts("no-such-location"));
        assertEquals(404, missing.getStatus());
    }

    private static boolean has(List<OwnerMemberDto> list, String account) {
        for (int iter = 0; iter < list.size(); iter++) {
            if (account.equals(list.get(iter).account())) {
                return true;
            }
        }
        return false;
    }

    private static void assertPercent(int value) {
        assertTrue(value >= 0 && value <= 100, value + " is not a percent");
    }
}
