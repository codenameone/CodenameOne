package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One class on the timetable, with how full it is and, for the caller, which of their
/// household hold a place in it (`booked`) or are queued for one (`waitlisted`): member
/// ids.
@Mapped
public record SessionDto(
        String id,
        String classTypeId,
        String name,
        String category,
        int intensity,
        int minAge,
        int maxAge,
        String color,
        String locationId,
        String locationName,
        String roomName,
        String trainer,
        String trainerName,
        long startsAt,
        long endsAt,
        int capacity,
        int booked,
        int waitlisted,
        String state,
        String note,
        List<String> mine,
        List<String> queued,
        int friendsGoing) {
}
