package com.codenameone.examples.pulse.api;

import java.util.List;

import com.codename1.annotations.Mapped;

/// One account in full, for the owner deciding what to do about it.
///
/// @param household The people the account books for, itself first.
/// @param visits Check-ins of the household, ever.
/// @param noShows Places booked and not taken, ever.
/// @param spent Cents paid, ever.
@Mapped
public record UserDetailDto(
        UserDto user,
        List<MemberDto> household,
        int visits,
        int noShows,
        long spent,
        List<ModerationEventDto> events) {
}
