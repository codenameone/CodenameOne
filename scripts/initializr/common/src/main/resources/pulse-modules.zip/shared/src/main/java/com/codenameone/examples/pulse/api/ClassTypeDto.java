package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A kind of class. `minAge`/`maxAge` are inclusive years; 0 and 120 mean no bound.
@Mapped
public record ClassTypeDto(
        String id,
        String name,
        String description,
        String category,
        int intensity,
        int minAge,
        int maxAge,
        int capacity,
        int minutes,
        String color,
        boolean active) {
}
