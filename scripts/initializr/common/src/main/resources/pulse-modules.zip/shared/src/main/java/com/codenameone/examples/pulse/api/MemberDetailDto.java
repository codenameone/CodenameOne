package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// Everything the owner sees about one member.
///
/// @param visitsByWeek check-ins a week for the last twelve weeks, oldest first.
/// @param favourites the kinds of class they come to most, most first.
/// @param streakWeeks weeks in a row, up to this one, with at least one visit.
@Mapped
public record MemberDetailDto(OwnerMemberDto member, List<Integer> visitsByWeek,
        List<NameCountDto> favourites, int streakWeeks, long lifetimeCents,
        List<InvoiceDto> invoices) {
}
