package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Asks for a place in a class for one member of the caller's household. `invitedBy` is the
/// account whose invitation this answers, or empty.
@Mapped
public record BookRequestDto(
        String sessionId,
        String memberId,
        String invitedBy) {
}
