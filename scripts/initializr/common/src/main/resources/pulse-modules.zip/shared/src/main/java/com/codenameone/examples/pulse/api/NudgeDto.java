package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A message the studio sent. `kind` is FILL_CLASS, WE_MISS_YOU, WAITLIST, INVITE, REFERRAL
/// or CAMPAIGN.
@Mapped
public record NudgeDto(
        String id,
        String kind,
        String sessionId,
        String title,
        String body,
        long sentAt,
        long openedAt) {
}
