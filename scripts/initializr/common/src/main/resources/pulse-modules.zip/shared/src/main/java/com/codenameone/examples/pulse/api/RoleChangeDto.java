package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// The staff roles an owner gives an account, or takes away. Every account is
/// a member whatever is set here.
@Mapped
public record RoleChangeDto(boolean trainer, boolean desk, boolean owner) {
}
