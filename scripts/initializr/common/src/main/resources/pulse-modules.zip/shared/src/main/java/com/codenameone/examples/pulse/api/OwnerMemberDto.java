package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A member as the owner's member list shows them.
///
/// @param state the membership's state: ACTIVE, FROZEN, PAST_DUE or CANCELLED.
/// @param atRisk not in for two weeks and not away.
@Mapped
public record OwnerMemberDto(String id, String account, String name, String planName,
        String state, long joinedAt, long lastVisit, int visits30, boolean atRisk,
        boolean away) {
}
