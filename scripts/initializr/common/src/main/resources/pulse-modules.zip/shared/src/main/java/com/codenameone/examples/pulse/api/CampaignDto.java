package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A campaign an owner sent and how it did. `kind` is FILL_CLASS, WIN_BACK or ANNOUNCE.
@Mapped
public record CampaignDto(
        String id,
        String name,
        String kind,
        String sessionId,
        String title,
        String body,
        long createdAt,
        int sent,
        int opened,
        int booked) {
}
