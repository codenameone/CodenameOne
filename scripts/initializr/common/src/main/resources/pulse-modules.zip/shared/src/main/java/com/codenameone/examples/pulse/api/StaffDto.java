package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Someone who works here.
@Mapped
public record StaffDto(
        String username,
        String name,
        String title,
        String bio,
        String locationId,
        long certifiedUntil,
        List<String> roles,
        int classesThisWeek) {
}
