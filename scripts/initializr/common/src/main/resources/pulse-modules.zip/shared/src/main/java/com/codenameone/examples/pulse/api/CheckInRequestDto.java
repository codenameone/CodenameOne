package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// What the door read: a pass `code` shown on a phone or watch, an `nfcId` tapped, or a
/// `memberId` the desk picked by hand. `locationId` is the door's site.
@Mapped
public record CheckInRequestDto(
        String code,
        String nfcId,
        String memberId,
        String locationId) {
}
