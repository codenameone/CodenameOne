package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A block of work. `state` is ASSIGNED, SWAP_REQUESTED or OPEN.
@Mapped
public record ShiftDto(
        String id,
        String locationId,
        String staff,
        String staffName,
        String duty,
        long startsAt,
        long endsAt,
        String state) {
}
