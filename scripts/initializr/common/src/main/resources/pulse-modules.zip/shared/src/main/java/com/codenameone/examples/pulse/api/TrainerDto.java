package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A trainer as members see one.
@Mapped
public record TrainerDto(
        String username,
        String name,
        String title,
        String bio,
        String locationId) {
}
