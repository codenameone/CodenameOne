package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A place in a class, or in the queue for one. `position` is 1-based while WAITLISTED and
/// 0 otherwise.
@Mapped
public record BookingDto(
        String id,
        String sessionId,
        String memberId,
        String memberName,
        String state,
        int position,
        long createdAt,
        long checkedInAt,
        SessionDto session) {
}
