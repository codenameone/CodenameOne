package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The owner's numbers. Money is in cents; `utilisation` is percent of places booked over
/// the last 30 days.
@Mapped
public record OwnerDashboardDto(
        int activeMembers,
        int newMembers30,
        int churned30,
        long mrrCents,
        long revenue30Cents,
        int utilisation,
        int checkIns7,
        int pastDue,
        int atRisk,
        List<DayAmountDto> revenueByDay,
        List<NameCountDto> popularClasses,
        List<SessionDto> underfilled) {
}
