package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Pauses a membership between two dates, yyyy-MM-dd, both inclusive.
@Mapped
public record FreezeDto(
        String from,
        String until) {
}
