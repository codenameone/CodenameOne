package com.codenameone.examples.pulse.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Training with friends. Nothing is shown to anyone who is not a friend, and a
/// workout reaches the feed only when its owner shared it.
@RestClient
public interface SocialApi {
    @GET("/api/social/friends")
    void friends(OnComplete<Response<List<FriendDto>>> callback);

    /// Asks a member, by e-mail, to be friends. Answers the same whether or not
    /// the address has an account, so the call cannot be used to find out.
    @POST("/api/social/friends")
    void request(@Body FriendRequestDto request, OnComplete<Response<FriendDto>> callback);

    @POST("/api/social/friends/{account}/accept")
    void accept(@Path("account") String account, OnComplete<Response<FriendDto>> callback);

    @POST("/api/social/friends/{account}/remove")
    void remove(@Path("account") String account, OnComplete<Response<FriendDto>> callback);

    @GET("/api/social/feed")
    void feed(OnComplete<Response<List<FeedItemDto>>> callback);

    @POST("/api/social/workouts/{id}/kudos")
    void kudos(@Path("id") String id, OnComplete<Response<FeedItemDto>> callback);

    /// Invites a friend to a class; they are sent a push they can book from.
    @POST("/api/social/invite")
    void invite(@Body InviteDto invite, OnComplete<Response<NudgeDto>> callback);
}
