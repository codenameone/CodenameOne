package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// What opening an account takes. The password travels once, in the body of a
/// request over TLS, and the server keeps only its hash.
///
/// @param birthDate `yyyy-MM-dd`: the account holder is a member too, and some classes
///     and plans have an age band.
/// @param referredBy The e-mail of the member who sent them, or empty. Both are credited
///     once the new account pays its first invoice.
@Mapped
public record RegisterDto(
        String email,
        String password,
        String displayName,
        String phone,
        String birthDate,
        String referredBy) {
}
