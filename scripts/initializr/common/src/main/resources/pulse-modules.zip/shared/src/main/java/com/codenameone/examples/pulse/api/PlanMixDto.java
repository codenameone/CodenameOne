package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// The members on one plan, and what they bring in a month.
@Mapped
public record PlanMixDto(String name, String kind, int members, long monthlyCents) {
}
