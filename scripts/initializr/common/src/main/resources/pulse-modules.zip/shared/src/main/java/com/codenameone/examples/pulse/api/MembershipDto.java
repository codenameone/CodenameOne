package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A member's plan and where it stands. `state` is ACTIVE, FROZEN, PAST_DUE or CANCELLED.
@Mapped
public record MembershipDto(
        String id,
        String memberId,
        String memberName,
        String planId,
        String planName,
        String kind,
        String state,
        long startedAt,
        long currentPeriodEnd,
        int creditsLeft,
        long frozenFrom,
        long frozenUntil,
        boolean cancelAtPeriodEnd) {
}
