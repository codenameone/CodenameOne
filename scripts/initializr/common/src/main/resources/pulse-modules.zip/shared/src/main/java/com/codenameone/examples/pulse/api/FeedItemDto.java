package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Something a friend did. `kind` is WORKOUT or BOOKED.
@Mapped
public record FeedItemDto(
        String id,
        String kind,
        String account,
        String name,
        String title,
        long at,
        int minutes,
        int avgHr,
        int calories,
        int kudos,
        boolean kudoed,
        String sessionId) {
}
