package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;
import java.util.List;

/// A trainer's own numbers over the last four weeks.
///
/// @param regulars members who came to three or more of their classes.
/// @param attendeesByWeek people who came, a week at a time for eight weeks,
///     oldest first.
/// @param topClasses their kinds of class by attendance, most first.
@Mapped
public record TrainerStatsDto(int classes, int attendees, int fillPercent, int showPercent,
        int regulars, int kudos, List<Integer> attendeesByWeek, List<NameCountDto> topClasses) {
}
