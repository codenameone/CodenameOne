package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Invites a friend to a class.
@Mapped
public record InviteDto(
        String sessionId,
        String friend) {
}
