package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// One week of the studio's membership.
///
/// @param weekOf the Monday that starts the week, `yyyy-MM-dd`.
/// @param active memberships running at the end of the week.
/// @param joined memberships started in the week.
/// @param left memberships cancelled in the week.
/// @param visits check-ins in the week.
@Mapped
public record WeekPointDto(String weekOf, int active, int joined, int left, int visits) {
}
