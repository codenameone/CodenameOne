package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The desk's view of today at one site.
@Mapped
public record DeskDayDto(
        int checkIns,
        int walkIns,
        long walkInCents,
        List<SessionDto> upcoming,
        List<CheckInResultDto> recent) {
}
