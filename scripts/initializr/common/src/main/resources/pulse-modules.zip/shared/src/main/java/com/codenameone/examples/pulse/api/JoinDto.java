package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Starts a plan for a member of the household, paid with `methodId` (empty for the default
/// card).
@Mapped
public record JoinDto(
        String memberId,
        String planId,
        String methodId) {
}
