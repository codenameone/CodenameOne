package com.codenameone.examples.pulse.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// The front desk and the door kiosk: for accounts with the DESK role.
@RestClient
public interface DeskApi {
    /// Admits a member, or says why not. A refusal is an answer, not an error:
    /// the kiosk shows it, and the desk can still let them in by hand.
    @POST("/api/desk/checkin")
    void checkIn(@Body CheckInRequestDto request, OnComplete<Response<CheckInResultDto>> callback);

    /// Members whose name or e-mail contains `q`, at most 25.
    @GET("/api/desk/members")
    void find(@Query("q") String q, OnComplete<Response<List<MemberSummaryDto>>> callback);

    @POST("/api/desk/walkins")
    void walkIn(@Body WalkInDto walkIn, OnComplete<Response<WalkInDto>> callback);

    @GET("/api/desk/today")
    void today(@Query("location") String location, OnComplete<Response<DeskDayDto>> callback);
}
