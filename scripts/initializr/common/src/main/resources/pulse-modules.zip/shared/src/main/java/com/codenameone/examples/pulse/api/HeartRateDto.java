package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A live heart rate reading from a member in a class.
@Mapped
public record HeartRateDto(
        String sessionId,
        int bpm) {
}
