package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Something that can be bought. `kind` is MONTHLY, ANNUAL, CLASS_PACK or DROP_IN.
@Mapped
public record PlanDto(
        String id,
        String name,
        String description,
        String kind,
        long priceCents,
        String currency,
        int periodMonths,
        int classCredits,
        int minAge,
        int maxAge,
        boolean offPeakOnly,
        boolean active) {
}
