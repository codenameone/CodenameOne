package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A child added to the caller's household. `birthDate` is yyyy-MM-dd.
@Mapped
public record NewMemberDto(
        String name,
        String birthDate,
        String medicalNote) {
}
