package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Another account the caller trains with. `state` is PENDING_OUT, PENDING_IN or FRIENDS.
@Mapped
public record FriendDto(
        String account,
        String name,
        String state,
        long lastVisit,
        int weekStreak) {
}
