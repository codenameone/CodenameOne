package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// One person on a trainer's class list. `state` is BOOKED, CHECKED_IN, NO_SHOW or
/// WAITLISTED; `heartRate` is the last live reading, 0 for none.
@Mapped
public record RosterEntryDto(
        String bookingId,
        String memberId,
        String name,
        int age,
        String state,
        int position,
        boolean firstVisit,
        String medicalNote,
        int heartRate,
        int zone) {
}
