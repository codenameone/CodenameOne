package com.codenameone.examples.pulse.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// A trainer's classes, rosters and shifts: for accounts with the TRAINER role.
@RestClient
public interface TrainerApi {
    /// The trainer's classes for the next 14 days.
    @GET("/api/trainer/classes")
    void classes(OnComplete<Response<List<SessionDto>>> callback);

    /// Who is coming, with the live heart rate of anyone sharing one.
    @GET("/api/trainer/classes/{id}/roster")
    void roster(@Path("id") String id, OnComplete<Response<List<RosterEntryDto>>> callback);

    @POST("/api/trainer/classes/{id}/attendance")
    void attendance(@Path("id") String id, @Body AttendanceDto mark,
            OnComplete<Response<RosterEntryDto>> callback);

    /// The trainer's own shifts, and open ones at their site anyone may take.
    /// The signed-in trainer's last four weeks: classes, attendance, regulars
    /// and kudos.
    @GET("/api/trainer/stats")
    void stats(OnComplete<Response<TrainerStatsDto>> callback);

    @GET("/api/trainer/shifts")
    void shifts(OnComplete<Response<List<ShiftDto>>> callback);

    /// Offers one of the trainer's shifts to the others.
    @POST("/api/trainer/shifts/{id}/swap")
    void offer(@Path("id") String id, OnComplete<Response<ShiftDto>> callback);

    /// Takes a shift another trainer offered.
    @POST("/api/trainer/shifts/{id}/take")
    void take(@Path("id") String id, OnComplete<Response<ShiftDto>> callback);
}
