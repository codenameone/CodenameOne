package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Puts a class on the timetable, once or every week for `weeks` weeks.
@Mapped
public record NewSessionDto(
        String classTypeId,
        String roomId,
        String trainer,
        long startsAt,
        int capacity,
        int weeks) {
}
