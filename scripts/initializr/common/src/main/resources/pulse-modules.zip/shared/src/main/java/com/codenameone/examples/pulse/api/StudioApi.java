package com.codenameone.examples.pulse.api;

import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// The studio as anyone signed in sees it: its sites, its classes and its
/// trainers.
@RestClient
public interface StudioApi {
    @GET("/api/studio/locations")
    void locations(OnComplete<Response<List<LocationDto>>> callback);

    @GET("/api/studio/types")
    void classTypes(OnComplete<Response<List<ClassTypeDto>>> callback);

    @GET("/api/studio/trainers")
    void trainers(OnComplete<Response<List<TrainerDto>>> callback);

    /// The timetable at a site from `from` (epoch millis) for `days` days, at
    /// most 14, cancelled classes included so a member sees what changed.
    @GET("/api/studio/classes")
    void classes(@Query("location") String location, @Query("from") long from,
            @Query("days") int days, OnComplete<Response<List<SessionDto>>> callback);

    @GET("/api/studio/classes/{id}")
    void session(@Path("id") String id, OnComplete<Response<SessionDto>> callback);
}
