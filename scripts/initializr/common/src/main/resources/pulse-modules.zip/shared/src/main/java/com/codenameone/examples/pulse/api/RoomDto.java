package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A room at a site.
@Mapped
public record RoomDto(
        String id,
        String locationId,
        String name,
        int capacity) {
}
