package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Asks someone, by e-mail, to train together.
@Mapped
public record FriendRequestDto(
        String email) {
}
