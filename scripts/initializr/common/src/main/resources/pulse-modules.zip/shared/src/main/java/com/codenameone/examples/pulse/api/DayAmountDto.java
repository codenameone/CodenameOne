package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// One day of takings: what was charged, and in how many payments.
///
/// @param date `yyyy-MM-dd`, in UTC.
@Mapped
public record DayAmountDto(String date, long amount, int count) {
}
