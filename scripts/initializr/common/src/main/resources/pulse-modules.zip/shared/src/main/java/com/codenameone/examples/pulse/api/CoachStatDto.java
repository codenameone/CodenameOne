package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// One trainer's last four weeks.
///
/// @param fillPercent places booked of places offered in their classes.
/// @param showPercent of those booked, the percent who came.
/// @param kudos kudos members gave for workouts in their classes.
@Mapped
public record CoachStatDto(String account, String name, int classes, int attendees,
        int fillPercent, int showPercent, int kudos) {
}
