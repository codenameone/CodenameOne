package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A bill. `status` is OPEN, PAID, FAILED or VOID; a FAILED one is tried again at
/// `nextAttemptAt` until the ladder runs out.
@Mapped
public record InvoiceDto(
        String id,
        String memberName,
        String description,
        long amountCents,
        long creditCents,
        String currency,
        String status,
        long periodStart,
        long periodEnd,
        int attempts,
        long nextAttemptAt,
        String methodLabel,
        String failure,
        long createdAt,
        long paidAt) {
}
