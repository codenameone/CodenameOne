package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// What a member's pass is made from. The app derives a fresh code from `secret` every
/// `periodSeconds` with no network; `nfcId` is what a tap at the door sends.
@Mapped
public record PassDto(
        String memberId,
        String memberName,
        String secret,
        String nfcId,
        int periodSeconds,
        int digits) {
}
