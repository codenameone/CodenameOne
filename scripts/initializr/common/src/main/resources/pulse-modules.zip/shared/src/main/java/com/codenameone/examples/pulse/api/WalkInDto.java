package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Someone at the desk without a membership. `kind` is GUEST, DAY_PASS or TRIAL; `paidBy`
/// is cash, card or none.
@Mapped
public record WalkInDto(
        String id,
        String locationId,
        String name,
        String email,
        String phone,
        String kind,
        long amountCents,
        String paidBy,
        long at) {
}
