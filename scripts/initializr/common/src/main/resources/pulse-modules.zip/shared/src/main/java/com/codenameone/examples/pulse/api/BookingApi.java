package com.codenameone.examples.pulse.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Places in classes for the caller's household.
///
/// A class with room gives a place at once; a full one puts the member on its
/// waitlist, and a place given up is handed to the first in the queue, who is
/// told by push. Cancelling inside the class's cut-off counts as a late
/// cancellation and, on a class pack, spends the credit.
@RestClient
public interface BookingApi {
    /// The household's places and queue entries from now on, soonest first.
    @GET("/api/bookings")
    void upcoming(OnComplete<Response<List<BookingDto>>> callback);

    /// The household's classes that have happened, newest first.
    @GET("/api/bookings/history")
    void history(OnComplete<Response<List<BookingDto>>> callback);

    /// Answers 403 for a member who is not the caller's, 409 when the member
    /// is outside the class's age band or already holds a place, and 402 when
    /// no membership covers the class.
    @POST("/api/bookings")
    void book(@Body BookRequestDto request, OnComplete<Response<BookingDto>> callback);

    @POST("/api/bookings/{id}/cancel")
    void cancel(@Path("id") String id, OnComplete<Response<BookingDto>> callback);
}
