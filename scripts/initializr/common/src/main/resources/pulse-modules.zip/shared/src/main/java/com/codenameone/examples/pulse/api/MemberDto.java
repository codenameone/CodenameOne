package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A person in the caller's household. `relation` is SELF or CHILD; `age` is in whole years
/// today.
@Mapped
public record MemberDto(
        String id,
        String name,
        String birthDate,
        int age,
        String relation,
        boolean waiverSigned,
        String medicalNote,
        String membershipState,
        String planName) {
}
