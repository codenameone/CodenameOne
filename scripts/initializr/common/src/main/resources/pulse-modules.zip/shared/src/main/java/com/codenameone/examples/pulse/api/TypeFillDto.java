package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// How well one kind of class fills, over the last four weeks.
///
/// @param fillPercent places booked of places offered.
/// @param noShowPercent bookings nobody turned up for.
@Mapped
public record TypeFillDto(String name, String color, int classes, int fillPercent,
        int noShowPercent) {
}
