package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Why an owner did something: cancelled a class, voided an invoice,
/// suspended an account.
@Mapped
public record ReasonDto(String reason) {
}
