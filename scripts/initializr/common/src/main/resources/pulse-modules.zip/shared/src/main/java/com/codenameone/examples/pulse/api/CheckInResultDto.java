package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Whether the door opens, and why not. `reason` is a key the app translates: ok, unknown,
/// replayed, expired, no-membership, past-due, frozen, age, waiver, no-credits.
@Mapped
public record CheckInResultDto(
        boolean admitted,
        String reason,
        String memberId,
        String memberName,
        int age,
        String planName,
        String membershipState,
        String sessionName,
        long sessionStartsAt,
        int visitsThisMonth) {
}
