package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A member saying they will not be in, between two dates, yyyy-MM-dd, inclusive. `reason`
/// is TRAVEL, INJURY or OTHER.
@Mapped
public record AwayDto(
        String id,
        String startsOn,
        String endsOn,
        String reason,
        boolean freezeBilling) {
}
