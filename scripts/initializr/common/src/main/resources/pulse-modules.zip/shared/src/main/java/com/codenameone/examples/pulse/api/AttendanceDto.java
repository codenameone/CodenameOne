package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A trainer marking someone in, or as a no-show.
@Mapped
public record AttendanceDto(
        String bookingId,
        boolean present) {
}
