package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A site: where it is, and when it is open, in minutes after midnight local time.
@Mapped
public record LocationDto(
        String id,
        String name,
        String address,
        String timeZone,
        int opensMinute,
        int closesMinute) {
}
