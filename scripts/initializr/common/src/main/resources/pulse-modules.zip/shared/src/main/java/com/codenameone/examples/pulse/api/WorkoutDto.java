package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A workout the phone's health store or the watch recorded. `zones` is minutes in each of
/// the five heart rate zones.
@Mapped
public record WorkoutDto(
        String id,
        String sessionId,
        String activity,
        long startedAt,
        int minutes,
        int avgHr,
        int maxHr,
        int calories,
        List<Integer> zones,
        String source,
        boolean shared) {
}
