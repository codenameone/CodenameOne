package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// Pays an invoice now, with `methodId` or the default card when empty.
@Mapped
public record PayInvoiceDto(
        String methodId) {
}
