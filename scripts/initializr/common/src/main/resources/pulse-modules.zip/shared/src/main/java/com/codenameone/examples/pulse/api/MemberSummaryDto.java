package com.codenameone.examples.pulse.api;

import com.codename1.annotations.Mapped;

/// A member as the desk finds one.
@Mapped
public record MemberSummaryDto(
        String id,
        String account,
        String name,
        int age,
        String relation,
        String membershipState,
        String planName,
        long lastVisit) {
}
