package com.codenameone.examples.papercut.play;

/// A pencil stroke in flight.
public final class Shot {
    public float x;
    public float y;
    public float vx;
    public float vy;
    public float angle;
    public boolean dead;
}
