package com.codenameone.examples.papercut.play;

/// A drop of ink a creature leaves when it is cut up. Fly through it and the
/// multiplier goes up by one; leave it and it soaks into the page.
public final class Drop {
    public static final float LIFE = 7;
    public float x;
    public float y;
    public float vx;
    public float vy;
    public float life = LIFE;
    public boolean dead;
}
