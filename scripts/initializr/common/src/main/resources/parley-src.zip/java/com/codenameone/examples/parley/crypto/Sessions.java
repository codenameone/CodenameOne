package com.codenameone.examples.parley.crypto;

import com.codename1.security.CryptoException;
import com.codename1.security.Hash;
import com.codenameone.examples.parley.api.PreKeyBundleDto;

import java.util.HashMap;
import java.util.Map;

/// The [Ratchet] sessions this device holds, one per device it talks to,
/// plus the one before it.
///
/// Two devices that start a session with each other at the same moment each
/// end up with two; the one kept as "previous" opens whatever the other side
/// sent on the session it started, and whichever answers first wins. The same
/// happens when a contact reinstalls: their new device's first message starts
/// a new session, and messages still in flight on the old one still open.
public final class Sessions {
    private static final Map<String, Ratchet> cache = new HashMap<String, Ratchet>();

    private Sessions() {
    }

    public static void clear() {
        cache.clear();
    }

    public static boolean has(String username, String device) {
        return current(username, device) != null;
    }

    /// Starts a session from a prekey bundle, replacing any there was.
    public static void start(PreKeyBundleDto bundle) {
        Ratchet session = Ratchet.initiate(bundle);
        keep(bundle.username(), bundle.deviceId(), session, current(bundle.username(),
                bundle.deviceId()));
    }

    /// Encrypts for one device, in the conversation `context`; answers header
    /// and ciphertext.
    public static String[] encrypt(String username, String device, byte[] plaintext,
            String context) {
        Ratchet session = current(username, device);
        if (session == null) {
            throw new CryptoException("No session with " + username + "/" + device);
        }
        String[] out = session.encrypt(plaintext, context);
        try {
            Vault.put(name("s", username, device), session.toMap());
        } catch (Vault.WriteFailed unsaved) {
            // The cached session moved on and the stored one did not: drop
            // the cache, so the next use starts from what is on disk.
            cache.remove(name("s", username, device));
            throw unsaved;
        }
        return out;
    }

    /// Told the plaintext of a message after it opens and before the session
    /// state that opening moved on is saved. Once that state is saved the
    /// message key is gone for good, so this is the caller's one chance to
    /// make the plaintext durable: a crash after the save and before the
    /// message is stored would otherwise lose it, the server's retry no longer
    /// opening.
    public interface Journal {
        void opened(byte[] plaintext);
    }

    /// Decrypts a message from one device, trying the current session, the
    /// previous one, and a new one when the header starts one.
    ///
    /// #### Throws
    ///
    /// - `CryptoException`: when none of them opens it, or its header names a
    ///   conversation other than `context`
    public static byte[] decrypt(String username, String device, String headerText,
            byte[] ciphertext, String context, Journal journal) {
        Map<String, Object> header = Codec.parse(headerText);
        if (header == null) {
            throw new CryptoException("That message has no header");
        }
        // Checked before anything is opened: the header is authenticated, so
        // a message the server moved to another chat fails here, and fails
        // without spending its key, so it still opens where it belongs.
        Object named = header.get("c");
        if (!(named instanceof String) || !named.equals(context)) {
            throw new CryptoException("That message belongs to another conversation");
        }
        Ratchet current = current(username, device);
        Ratchet previous = load(name("p", username, device));
        boolean fresh = Ratchet.starts(header) && (current == null
                || !Ratchet.ephemeral(header).equals(current.startedBy()))
                && (previous == null || !Ratchet.ephemeral(header).equals(previous.startedBy()));
        CryptoException last = null;
        if (!fresh) {
            if (current != null) {
                try {
                    Ratchet trial = current.copy();
                    byte[] plain = trial.decrypt(header, headerText, ciphertext);
                    journal.opened(plain);
                    keep(username, device, trial, null);
                    return plain;
                } catch (CryptoException failed) {
                    last = failed;
                }
            }
            if (previous != null) {
                try {
                    Ratchet trial = previous.copy();
                    byte[] plain = trial.decrypt(header, headerText, ciphertext);
                    journal.opened(plain);
                    Vault.put(name("p", username, device), trial.toMap());
                    return plain;
                } catch (CryptoException failed) {
                    last = failed;
                }
            }
        }
        if (Ratchet.starts(header)) {
            Ratchet started = Ratchet.respond(header);
            byte[] plain = started.decrypt(header, headerText, ciphertext);
            journal.opened(plain);
            keep(username, device, started, current);
            // Only now, with the message authenticated and the session it
            // opened saved, is the one-time prekey it named spent. Before
            // that, a tampered first message or a crash would have burned it
            // and every honest retry would name a key that is gone.
            Identity.consumePreKey(Ratchet.oneTimePreKey(header));
            return plain;
        }
        throw last != null ? last : new CryptoException("No session with " + username + "/" + device);
    }

    /// The identity key of the device a session is with, for safety numbers.
    public static byte[] identity(String username, String device) {
        Ratchet session = current(username, device);
        return session == null ? null : session.theirIdentity();
    }

    public static void forget(String username, String device) {
        cache.remove(name("s", username, device));
        Vault.remove(name("s", username, device));
        Vault.remove(name("p", username, device));
    }

    private static Ratchet current(String username, String device) {
        String name = name("s", username, device);
        Ratchet out = cache.get(name);
        if (out == null) {
            out = load(name);
            if (out != null) {
                cache.put(name, out);
            }
        }
        return out;
    }

    private static void keep(String username, String device, Ratchet now, Ratchet before) {
        String name = name("s", username, device);
        Vault.put(name, now.toMap());
        cache.put(name, now);
        if (before != null) {
            Vault.put(name("p", username, device), before.toMap());
        }
    }

    private static Ratchet load(String name) {
        Map<String, Object> stored = Vault.get(name);
        return stored == null ? null : Ratchet.fromMap(stored);
    }

    /// Storage names say nothing about whom they are for.
    private static String name(String kind, String username, String device) {
        String hash = Codec.b64(Hash.sha256(Codec.utf8(username + "/" + device)));
        return kind + "-" + hash.substring(0, 22).replace('/', '_').replace('+', '-');
    }
}
