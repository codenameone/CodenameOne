package com.codenameone.examples.parley.ui;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.parley.Telemetry;
import com.codenameone.examples.parley.api.ContactDto;
import com.codenameone.examples.parley.net.Api;
import com.codename1.appkit.Net;

import java.util.List;

/// The people this account blocked. A blocked person's messages are dropped
/// by the server without telling them, their calls do not ring, and they no
/// longer see last seen or the profile photo.
public final class BlockedForm {
    private BlockedForm() {
    }

    public static void show(final Form previous) {
        final Form form = Ui.form("Blocked", "Blocked");
        Ui.back(form, previous);
        Container page = Ui.page();
        final Container list = Ui.list("blocked");
        page.add(list);
        form.add(BorderLayout.CENTER, page);
        form.show();
        load(form, list);
    }

    private static void load(final Form form, final Container list) {
        Api.contacts().blocked(Net.to((List<ContactDto> blocked) -> {
            list.removeAll();
            if (blocked.isEmpty()) {
                list.add(Ui.empty(FontImage.MATERIAL_BLOCK, "Nobody is blocked",
                        "Block someone from their chat's info screen."));
            }
            for (final ContactDto each : blocked) {
                list.add(Ui.person(each.displayName(), each.username(),
                        Ui.link("Unblock", "unblock-" + each.username(), e ->
                                Api.contacts().unblock(each.username(), Net.to(gone -> {
                                    Telemetry.blocked(false);
                                    load(form, list);
                                }, Ui::fail)))));
            }
            Ui.refresh(form);
        }, Ui.failed(list, () -> load(form, list))));
    }
}
