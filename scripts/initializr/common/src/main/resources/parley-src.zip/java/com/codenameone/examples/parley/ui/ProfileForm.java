package com.codenameone.examples.parley.ui;

import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.parley.api.ProfileDto;
import com.codenameone.examples.parley.api.UserDto;
import com.codenameone.examples.parley.net.Account;
import com.codenameone.examples.parley.net.Api;
import com.codename1.appkit.Net;
import com.codenameone.examples.parley.net.Session;
import java.util.List;

/// Who the user is to the people they talk to: a name and a line about them.
public final class ProfileForm {
    private ProfileForm() {
    }

    /// @param saved where to go once the profile is saved: a screen that shows
    ///     the name is built again there
    public static void show(final Form previous, final Runnable saved) {
        final Form form = Ui.form("Profile", "Profile");
        Ui.back(form, previous);
        UserDto user = Session.user();
        ProfileDto profile = Account.profile();
        Container page = Ui.page();

        Ui.section(page, "About you");
        final TextField name = Ui.field(page, "Name", "name", "What your contacts will see");
        name.setText(profile == null ? user.displayName() : profile.name());
        final TextField about = Ui.field(page, "About", "about", "Available");
        about.setText(profile == null ? (user.about() == null ? "" : user.about())
                : (profile.about() == null ? "" : profile.about()));

        final SpanLabel error = Ui.text("", "PlError");
        error.setName("error");
        final Button save = Ui.primary("Save", "submit", null);
        save.addActionListener(e -> {
            save.setEnabled(false);
            error.setText("");
            Account.saveProfile(name.getText().trim(), about.getText().trim(), saved,
                    (status, message) -> {
                        save.setEnabled(true);
                        error.setText(message);
                        Ui.refresh(form);
                    });
        });
        page.add(error).add(save);
        page.add(Ui.text("Your name and photo are seen by the people you talk to. Who sees "
                + "your photo and when you were last online is up to you, in Privacy.",
                "PlMuted"));
        form.add(BorderLayout.CENTER, page);
        form.show();
    }
}
