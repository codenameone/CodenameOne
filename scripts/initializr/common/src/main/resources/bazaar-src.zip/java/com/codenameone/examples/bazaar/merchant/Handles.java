package com.codenameone.examples.bazaar.merchant;

/// URL handles made from titles: ASCII letters and digits, folded to lower
/// case by hand (never `toLowerCase()`, which is locale sensitive), every run
/// of anything else one dash.
public final class Handles {
    private Handles() {
    }

    public static String of(String title) {
        StringBuilder b = new StringBuilder();
        boolean dash = false;
        for (int iter = 0; title != null && iter < title.length(); iter++) {
            char c = title.charAt(iter);
            if (c >= 'A' && c <= 'Z') {
                c = (char) (c + ('a' - 'A'));
            }
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                if (dash && b.length() > 0) {
                    b.append('-');
                }
                dash = false;
                b.append(c);
            } else {
                dash = true;
            }
        }
        return b.length() == 0 ? "item" : b.toString();
    }
}
