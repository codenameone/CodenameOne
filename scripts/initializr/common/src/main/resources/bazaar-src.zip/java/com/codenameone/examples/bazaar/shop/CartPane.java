package com.codenameone.examples.bazaar.shop;

import com.codename1.appkit.Net;
import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.CN;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Label;
import com.codename1.ui.SwipeableContainer;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codenameone.examples.bazaar.api.CartDto;
import com.codenameone.examples.bazaar.api.CartLineChangeDto;
import com.codenameone.examples.bazaar.api.CartLineDto;
import com.codenameone.examples.bazaar.api.CodeDto;
import com.codenameone.examples.bazaar.net.Api;
import com.codenameone.examples.bazaar.ui.Lang;
import com.codenameone.examples.bazaar.ui.Layouts;
import com.codenameone.examples.bazaar.ui.ProductArt;
import com.codenameone.examples.bazaar.ui.RowMenus;
import com.codenameone.examples.bazaar.ui.Sections;
import com.codenameone.examples.bazaar.ui.SignInGate;
import com.codenameone.examples.bazaar.ui.Ui;
import java.util.List;

/// The cart of the current store: its lines (swipe one away, or change how
/// many), a discount code and a gift card, and the summary as the server
/// priced it. Lines on the left and the summary on the right on a wide
/// screen.
final class CartPane extends ShopPane {
    private final boolean wide = Layouts.split();
    private boolean busy;

    CartPane() {
        super(new BorderLayout());
        setName("shop-cart");
        add(BorderLayout.CENTER, new com.codenameone.examples.bazaar.ui.Shimmer(5, "SvSkeleton"));
        reload();
    }

    @Override
    void reload() {
        if (ShopState.store() == null && ShopState.cartStoreId().length() == 0) {
            draw();
            return;
        }
        ShopState.loadShownCart(this::draw);
    }

    @Override
    void cartChanged() {
        draw();
    }

    private void draw() {
        removeAll();
        CartDto cart = ShopState.cart();
        if (ShopState.store() == null || cart == null || cart.lines() == null
                || cart.lines().isEmpty()) {
            Container page = Ui.page();
            page.add(Ui.empty(FontImage.MATERIAL_SHOPPING_CART, "Your cart is empty",
                    "Things you add to your cart show up here."));
            page.add(FlowLayout.encloseCenter(Ui.primary("Start shopping", "start-shopping",
                    e -> ShopSections.show(Sections.HOME))));
            add(BorderLayout.CENTER, page);
            Ui.relayout(this);
            return;
        }
        Container lines = new Container(BoxLayout.y());
        lines.setName("cart-lines");
        if (cart.problems() != null) {
            for (String problem : cart.problems()) {
                lines.add(Ui.callout(FontImage.MATERIAL_WARNING, "Check your cart", problem));
            }
        }
        for (CartLineDto line : cart.lines()) {
            lines.add(line(line));
        }
        Container summary = summary(cart);
        if (wide) {
            Container split = new Container(new GridLayout(1, 2));
            Container left = Ui.page();
            left.add(Ui.label(Lang.tr("Cart ({0})", String.valueOf(ShopState.units())), "SvTitle"));
            left.add(lines);
            Container right = Ui.page();
            right.add(summary);
            split.add(left).add(right);
            add(BorderLayout.CENTER, split);
        } else {
            Container page = Ui.page();
            // Every store has a cart of its own: say whose this is.
            page.add(Ui.label(Lang.tr("Cart ({0})", String.valueOf(ShopState.units())), "SvTitle"));
            Label from = Ui.plain(Lang.tr("From {0}", ShopState.store().name()), "SvMuted");
            from.setName("cart-store");
            page.add(from);
            page.add(lines);
            page.add(summary);
            Ui.pull(page, this::reload);
            add(BorderLayout.CENTER, page);
        }
        Ui.relayout(this);
    }

    private Component line(final CartLineDto line) {
        Container row = new Container(new BorderLayout());
        row.setUIID("SvCartLine");
        int side = CN.convertToPixels(16);
        Label art = ProductArt.label(line.productId(), line.title(), line.title(),
                line.photoId(), side, side, "ShopThumb");
        row.add(BorderLayout.WEST, art);
        Container words = new Container(BoxLayout.y());
        words.add(Ui.plain(line.title(), "SvRowTitle"));
        if (line.variantTitle() != null && line.variantTitle().length() > 0
                && !"Default".equalsIgnoreCase(line.variantTitle())) {
            words.add(Ui.plain(line.variantTitle(), "SvRowDetail"));
        }
        if (!line.available()) {
            words.add(Ui.plain(line.availableQty() > 0
                    ? Lang.tr("Only {0} left", String.valueOf(line.availableQty()))
                    : Lang.tr("Sold out"), "ShopStockOut"));
        } else if (line.backordered()) {
            // More than the shelf holds, of a variant that keeps selling.
            // Wraps rather than cut short: the line's words share the row
            // with the price.
            SpanLabel waits = Ui.text(Lang.tr("Ships when back in stock"), "ShopStockLow");
            waits.setName("line-backordered-" + line.id());
            words.add(waits);
        }
        Container stepper = new Container(BoxLayout.x());
        stepper.setUIID("ShopStepper");
        Button less = new Button("", "ShopStepButton");
        less.setName("line-less-" + line.id());
        less.setAccessibilityText(Lang.tr(line.quantity() <= 1 ? "Remove" : "Decrease quantity"));
        FontImage.setMaterialIcon(less, line.quantity() <= 1 ? FontImage.MATERIAL_DELETE
                : FontImage.MATERIAL_REMOVE, 2.8f);
        Button more = new Button("", "ShopStepButton");
        more.setName("line-more-" + line.id());
        more.setAccessibilityText(Lang.tr("Increase quantity"));
        FontImage.setMaterialIcon(more, FontImage.MATERIAL_ADD, 2.8f);
        less.addActionListener(e -> change(line, line.quantity() - 1));
        more.addActionListener(e -> change(line, line.quantity() + 1));
        stepper.add(less).add(new Label(String.valueOf(line.quantity()), "ShopStepValue")).add(more);
        words.add(FlowLayout.encloseIn(stepper));
        row.add(BorderLayout.CENTER, words);
        Container prices = new Container(BoxLayout.y());
        // A quantity change rolls the line's price to its new amount.
        prices.add(ShopFx.rolling("line-" + line.id(), line.priceCents() * line.quantity(),
                "SvRowValue", ShopState::money));
        if (line.discountCents() > 0) {
            prices.add(Ui.plain(ShopState.money(-line.discountCents()), "SvDiscount"));
        }
        row.add(BorderLayout.EAST, prices);
        RowMenus.attach(row, new Command[] {
            Command.create(Lang.tr("Remove"), null, e -> remove(line))
        });
        if (CN.isDesktop()) {
            // A desktop has no swipe: the menu above, and a delete key on the
            // stepper.
            return row;
        }
        Button delete = Ui.danger("Remove", "line-remove-" + line.id(), e -> remove(line));
        FontImage.setMaterialIcon(delete, FontImage.MATERIAL_DELETE, 3.2f);
        SwipeableContainer swipe = new SwipeableContainer(null, delete, row);
        swipe.setName("line-" + line.id());
        return swipe;
    }

    /// Bumped by every cart write; only the newest one's answer is applied,
    /// so a slow change cannot bring back a line a later remove took out.
    private int sent;

    private void change(CartLineDto line, int quantity) {
        if (quantity <= 0) {
            remove(line);
            return;
        }
        if (busy || ShopState.store() == null) {
            return;
        }
        busy = true;
        ShopUi.tap();
        final int t = ++sent;
        Api.cart().update(ShopState.store().id(), line.id(), ShopState.token(),
                new CartLineChangeDto(line.variantId(), quantity), Net.to(cart -> {
                    busy = false;
                    if (t == sent) {
                        ShopState.setCart(cart);
                    }
                }, (status, message) -> {
                    busy = false;
                    Ui.fail(status, message);
                }));
    }

    private void remove(CartLineDto line) {
        if (ShopState.store() == null) {
            return;
        }
        ShopUi.tap();
        final int t = ++sent;
        Api.cart().remove(ShopState.store().id(), line.id(), ShopState.token(),
                Net.to(cart -> {
                    if (t == sent) {
                        ShopState.setCart(cart);
                    }
                }, Ui::fail));
    }

    private Container summary(final CartDto cart) {
        Container box = new Container(BoxLayout.y());
        box.setUIID("ShopSummary");
        box.setName("cart-summary");
        codes(box, cart);
        credit(box, cart);
        // A card heading, not a page section: SvSection opens a new part of a
        // page with 5mm above it, which left a hole inside the card.
        box.add(Ui.label("Summary", "ShopCardTitle"));
        rows(box, cart);
        // Installed apps' storefront blocks placed under the total.
        if (ShopState.store() != null) {
            box.add(com.codenameone.examples.bazaar.ui.AppBlocks.storefront(
                    ShopState.store().handle(), "cart-below-total"));
        }
        box.add(Ui.primary("Checkout", "checkout", e -> checkout()));
        return box;
    }

    /// The checkout is the first place a guest is asked to sign in. The cart
    /// they filled is merged into the account's, and the checkout opens on it.
    static void checkout() {
        SignInGate.require(CN.getCurrentForm(), "Sign in to check out",
                "Your cart comes with you. Next time your address and card are already "
                + "filled in, so checking out takes a tap.",
                () -> ShopState.loadCart(() -> ShopState.syncIfNeeded(CheckoutForm::show)));
    }

    /// The summary lines of `cart`, as [Estimate] decides them.
    static void rows(Container box, CartDto cart) {
        List<Estimate.Row> rows = Estimate.rows(cart);
        for (Estimate.Row row : rows) {
            String caption = Lang.tr(row.caption);
            if (row.detail != null && row.detail.length() > 0) {
                caption += " (" + row.detail + ")";
            }
            String value = row.kind == Estimate.NOTE ? Lang.tr(row.note) : ShopState.money(row.cents);
            String uiid = row.kind == Estimate.TOTAL ? "SvTotal"
                    : row.kind == Estimate.SAVING ? "SvDiscount" : "SvFactValue";
            if (row.kind == Estimate.TOTAL) {
                Container fact = new com.codenameone.examples.bazaar.ui.FactRow(
                        Ui.label(caption, "SvFactLabel"), ShopFx.rolling("total", row.cents, uiid,
                        ShopState::money));
                fact.setUIID("SvFact");
                box.add(fact);
                continue;
            }
            box.add(Ui.fact(caption, value, uiid));
        }
    }

    private void codes(Container box, final CartDto cart) {
        final String storeId = cart.storeId();
        if (cart.discountCode() != null && cart.discountCode().length() > 0) {
            box.add(applied(Lang.tr("Code {0}", cart.discountCode()), "discount-remove",
                    () -> Api.cart().removeDiscount(storeId, ShopState.token(),
                            Net.to(ShopState::setCart, Ui::fail))));
        } else {
            box.add(codeField("Discount code", "discount", (code, done) ->
                    Api.cart().applyDiscount(storeId, ShopState.token(), new CodeDto(code),
                            Net.to(c -> {
                                done.run();
                                ShopState.setCart(c);
                                Ui.say("Discount applied");
                            }, (status, message) -> {
                                done.run();
                                Ui.fail(status, message);
                            }))));
        }
        if (cart.giftCardCode() != null && cart.giftCardCode().length() > 0) {
            box.add(applied(Lang.tr("Gift card {0}", cart.giftCardCode()), "giftcard-remove",
                    () -> Api.cart().removeGiftCard(storeId, ShopState.token(),
                            Net.to(ShopState::setCart, Ui::fail))));
        } else {
            box.add(codeField("Gift card", "giftcard", (code, done) ->
                    Api.cart().applyGiftCard(storeId, ShopState.token(), new CodeDto(code),
                            Net.to(c -> {
                                done.run();
                                ShopState.setCart(c);
                                Ui.say("Gift card applied");
                            }, (status, message) -> {
                                done.run();
                                Ui.fail(status, message);
                            }))));
        }
    }

    /// The store credit switch, shown when the signed-in shopper holds credit
    /// at this store.
    private void credit(Container box, final CartDto cart) {
        if (cart.creditAvailableCents() <= 0) {
            return;
        }
        final String storeId = cart.storeId();
        final boolean on = cart.useStoreCredit();
        String text = Lang.tr("Store credit available: {0}",
                ShopState.money(cart.creditAvailableCents()));
        box.add(Ui.text(text, "SvMuted"));
        box.add(Ui.secondary(on ? "Don't use store credit" : "Use store credit",
                "store-credit", e -> {
                    if (on) {
                        Api.cart().stopStoreCredit(storeId, ShopState.token(),
                                Net.to(ShopState::setCart, Ui::fail));
                    } else {
                        Api.cart().useStoreCredit(storeId, ShopState.token(),
                                Net.to(ShopState::setCart, Ui::fail));
                    }
                }));
    }

    private interface Apply {
        void apply(String code, Runnable done);
    }

    private static Container codeField(String caption, String name, final Apply apply) {
        Container row = new Container(new BorderLayout());
        row.setUIID("ShopCodeRow");
        final TextField field = new TextField("", Lang.tr(caption), 16, TextField.ANY);
        field.setUIID("SvField");
        field.getHintLabel().setUIID("SvFieldHint");
        field.setName(name + "-code");
        final Button go = Ui.secondary("Apply", name + "-apply", null);
        go.setUIID("SvFieldButton");
        Runnable submit = () -> {
            String code = field.getText().trim();
            if (code.length() == 0) {
                return;
            }
            go.setEnabled(false);
            apply.apply(code, () -> go.setEnabled(true));
        };
        go.addActionListener(e -> submit.run());
        // Enter applies it.
        field.setDoneListener(e -> submit.run());
        row.add(BorderLayout.CENTER, field);
        row.add(BorderLayout.EAST, go);
        return row;
    }

    private static Container applied(String text, String name, final Runnable remove) {
        Container row = new Container(new BorderLayout());
        row.setUIID("ShopCodeRow");
        Label chip = Ui.chip(text, FontImage.MATERIAL_LOCAL_OFFER);
        row.add(BorderLayout.CENTER, FlowLayout.encloseIn(chip));
        Button x = new Button("", "ShopIconButton");
        x.setName(name);
        FontImage.setMaterialIcon(x, FontImage.MATERIAL_CLOSE, 3f);
        x.addActionListener(e -> remove.run());
        row.add(BorderLayout.EAST, x);
        return row;
    }
}
