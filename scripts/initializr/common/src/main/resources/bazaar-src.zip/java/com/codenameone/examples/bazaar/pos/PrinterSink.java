package com.codenameone.examples.bazaar.pos;

/// Where receipt printer bytes go: a socket to the printer's raw port in the
/// app ([SocketPrinter]), memory in a test.
public interface PrinterSink {
    /// Told once how the job went; on the EDT for the app's sink.
    interface Done {
        /// @param error null when every byte was written, else what went wrong
        void done(String error);
    }

    void send(byte[] job, Done done);
}
