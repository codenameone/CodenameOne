package com.codenameone.examples.bazaar.shop;

/// Which predictive-search answer may still be shown. Every request takes a
/// ticket; an answer is shown only while its ticket is the newest, so a slow
/// answer for "mu" never replaces the one for "mug" that came back first.
/// Clearing the field (or searching) invalidates every ticket out. EDT only.
final class SuggestGate {
    /// The fewest characters worth asking about.
    static final int MIN_CHARS = 2;

    private int newest;

    /// True when `text` is long enough to ask about.
    static boolean worthAsking(String text) {
        return text != null && text.trim().length() >= MIN_CHARS;
    }

    /// A ticket for a request about to go out.
    int issue() {
        return ++newest;
    }

    /// Drops every answer still on its way.
    void invalidate() {
        newest++;
    }

    /// True when the answer for `ticket` is the one to show.
    boolean current(int ticket) {
        return ticket == newest;
    }
}
