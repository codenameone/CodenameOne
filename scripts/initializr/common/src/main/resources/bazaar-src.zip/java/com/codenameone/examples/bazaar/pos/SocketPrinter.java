package com.codenameone.examples.bazaar.pos;

import com.codename1.io.Socket;
import com.codename1.io.SocketConnection;
import com.codename1.io.Util;
import com.codename1.ui.CN;
import java.io.InputStream;
import java.io.OutputStream;

/// Sends a job to a network receipt printer's raw port over a Codename One
/// socket: connect, write every byte, close. The printer prints what it is
/// sent; there is nothing to read back.
public final class SocketPrinter implements PrinterSink {
    private final PrinterAddress address;

    public SocketPrinter(PrinterAddress address) {
        this.address = address;
    }

    @Override
    public void send(final byte[] job, final Done done) {
        if (!Socket.isSupported()) {
            done.done("Sockets are not available on this device");
            return;
        }
        Socket.connect(address.host, address.port, new SocketConnection(5000) {
            @Override
            public void connectionError(int errorCode, final String message) {
                CN.callSerially(() -> done.done(message == null || message.length() == 0
                        ? "The printer did not answer" : message));
            }

            @Override
            public void connectionEstablished(InputStream is, OutputStream os) {
                String error = null;
                try {
                    os.write(job);
                    os.flush();
                } catch (java.io.IOException failed) {
                    error = failed.getMessage() == null ? "The printer closed the connection"
                            : failed.getMessage();
                } finally {
                    Util.cleanup(os);
                    Util.cleanup(is);
                }
                final String result = error;
                CN.callSerially(() -> done.done(result));
            }
        });
    }
}
