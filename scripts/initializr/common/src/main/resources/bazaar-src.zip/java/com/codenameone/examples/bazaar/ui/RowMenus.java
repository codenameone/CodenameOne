package com.codenameone.examples.bazaar.ui;

import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.ContextMenu;
import java.util.function.Supplier;

/// The right-click menu of a row: a secondary click, a stylus barrel button
/// or a long press opens the platform's context menu with the row's commands.
///
/// The commands are asked for when the menu opens, so a row whose state
/// changed offers what is true now:
///
/// ```java
/// RowMenus.attach(row, () -> new Command[] {
///     Command.create("Open in new window", null, e -> Windows.open(...)),
///     Command.create("Archive", null, e -> archive(product))});
/// ```
public final class RowMenus {
    private RowMenus() {
    }

    public static void attach(final Component row, final Supplier<Command[]> commands) {
        row.addContextMenuListener(e -> {
            Command[] items = commands.get();
            if (items != null && items.length > 0) {
                ContextMenu.show(row, e.getX(), e.getY(), items);
                e.consume();
            }
        });
    }

    /// A menu that is always the same.
    public static void attach(Component row, final Command... commands) {
        attach(row, () -> commands);
    }
}
