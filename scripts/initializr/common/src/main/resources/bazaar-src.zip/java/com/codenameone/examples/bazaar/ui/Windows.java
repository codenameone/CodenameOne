package com.codenameone.examples.bazaar.ui;

import com.codename1.ui.CN;
import com.codename1.ui.Component;
import com.codename1.ui.Desktop;
import com.codename1.ui.Window;
import com.codename1.ui.layouts.BorderLayout;

/// A second native window, where the platform has a windowing system: an
/// order opened beside the list, the customer-facing display of a register.
///
/// Elsewhere -- a phone, a tablet, a browser -- there is no second window, and
/// the caller shows the same content another way (a form, a sheet).
public final class Windows {
    private Windows() {
    }

    /// Whether [#open] can open a window here.
    public static boolean supported() {
        return Desktop.isSupported();
    }

    /// Opens `content` in a window of its own, `widthMm` by `heightMm`.
    ///
    /// @return the window, or null where windows are not supported
    public static Window open(String title, Component content, float widthMm, float heightMm) {
        if (!supported()) {
            return null;
        }
        Window window = new Window(Lang.tr(title), new BorderLayout());
        window.getContentPane().setUIID("SvForm");
        window.add(BorderLayout.CENTER, content);
        window.setWindowSize(CN.convertToPixels(widthMm), CN.convertToPixels(heightMm));
        Layouts.dress(window.getContentPane());
        window.show();
        return window;
    }
}
