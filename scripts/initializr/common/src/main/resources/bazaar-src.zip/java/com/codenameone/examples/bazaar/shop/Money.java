package com.codenameone.examples.bazaar.shop;

/// Money as the shopper reads it. Pure: no display, no bundle, so the rules
/// are tested on their own.
///
/// Amounts are whole cents (minor units). Dollars are written `$12.40`; any
/// other currency as the amount followed by its code, `12.40 EUR`. A negative
/// amount -- a discount, a gift card -- keeps its sign even under one unit,
/// which plain integer division would lose (`-50 / 100` is `0`).
public final class Money {
    private Money() {
    }

    /// `cents` in `currency`, or in `fallback` when the amount carries none.
    public static String format(long cents, String currency, String fallback) {
        String code = currency == null || currency.length() == 0 ? fallback : currency;
        boolean negative = cents < 0;
        long abs = negative ? -cents : cents;
        long whole = abs / 100;
        long part = abs % 100;
        String amount = grouped(whole) + "." + (part < 10 ? "0" : "") + part;
        String sign = negative ? "-" : "";
        if (code == null || code.length() == 0 || "USD".equalsIgnoreCase(code)) {
            return sign + "$" + amount;
        }
        return sign + amount + " " + code;
    }

    /// `cents` in whole dollars, rounded down, for a figure that has to fit
    /// in a ring: `$877`, `$1,250`.
    public static String whole(long cents) {
        return (cents < 0 ? "-$" : "$") + grouped(Math.abs(cents) / 100);
    }

    /// `whole` with a comma between each group of three digits: `4,952`.
    static String grouped(long whole) {
        String digits = String.valueOf(whole);
        StringBuilder out = new StringBuilder();
        for (int iter = 0; iter < digits.length(); iter++) {
            if (iter > 0 && (digits.length() - iter) % 3 == 0) {
                out.append(',');
            }
            out.append(digits.charAt(iter));
        }
        return out.toString();
    }

    /// A price that depends on the variant: `$10.00 - $14.00`, or one price
    /// when every variant costs the same.
    public static String range(long min, long max, String currency, String fallback) {
        if (max <= min) {
            return format(min, currency, fallback);
        }
        return format(min, currency, fallback) + " - " + format(max, currency, fallback);
    }

    /// How much cheaper than `compareAt` the price is, in whole percent; 0
    /// when it is not a sale. Guarded: a zero compare-at price divides
    /// nothing.
    public static int percentOff(long price, long compareAt) {
        if (compareAt <= 0 || price >= compareAt || price < 0) {
            return 0;
        }
        return (int) ((compareAt - price) * 100 / compareAt);
    }

    /// `cents` as a price filter shows it back for editing: `12`, or `12.50`
    /// when there are cents, so what `parse` reads is what was typed.
    public static String typed(long cents) {
        // Sign first, then the magnitude: -1250 is "-12.50", never "-12.-50".
        String sign = cents < 0 ? "-" : "";
        long a = Math.abs(cents);
        long whole = a / 100;
        long part = a % 100;
        if (part == 0) {
            return sign + whole;
        }
        return sign + whole + "." + (part < 10 ? "0" : "") + part;
    }

    /// Dollars as typed into a price filter (`12`, `12.5`, `12.50`) to cents;
    /// -1 for anything that is not an amount.
    public static long parse(String text) {
        if (text == null) {
            return -1;
        }
        String t = text.trim();
        if (t.startsWith("$")) {
            t = t.substring(1).trim();
        }
        if (t.length() == 0) {
            return -1;
        }
        long whole = 0;
        long part = 0;
        int partDigits = 0;
        boolean dot = false;
        for (int iter = 0; iter < t.length(); iter++) {
            char c = t.charAt(iter);
            if (c == '.' && !dot) {
                dot = true;
            } else if (c >= '0' && c <= '9') {
                if (dot) {
                    if (partDigits < 2) {
                        part = part * 10 + (c - '0');
                        partDigits++;
                    }
                } else {
                    whole = whole * 10 + (c - '0');
                    if (whole > 100000000L) {
                        return -1;
                    }
                }
            } else {
                return -1;
            }
        }
        if (partDigits == 1) {
            part *= 10;
        }
        return whole * 100 + part;
    }
}
