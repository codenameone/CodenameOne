package com.codenameone.examples.bazaar.merchant;

import com.codenameone.examples.bazaar.api.CheckoutSettingsDto;
import java.util.ArrayList;
import java.util.List;

/// The checkout settings' payment method switches: turning one type on or off
/// in the store's [CheckoutSettingsDto] while keeping its tips and fields as
/// they are. The server still refuses a type it does not know.
final class CheckoutMethods {
    private CheckoutMethods() {
    }

    /// Whether `settings` offers `type`.
    static boolean on(CheckoutSettingsDto settings, String type) {
        return settings != null && settings.methods() != null
                && settings.methods().contains(type);
    }

    /// `settings` with `type` switched to `wanted`, in the order the types
    /// were switched on; everything else is kept.
    static CheckoutSettingsDto switched(CheckoutSettingsDto settings, String type,
            boolean wanted) {
        List<String> methods = new ArrayList<String>();
        if (settings != null && settings.methods() != null) {
            for (int iter = 0; iter < settings.methods().size(); iter++) {
                String m = settings.methods().get(iter);
                if (!m.equals(type) && !methods.contains(m)) {
                    methods.add(m);
                }
            }
        }
        if (wanted) {
            methods.add(type);
        }
        if (settings == null) {
            return new CheckoutSettingsDto(methods, false, null, null);
        }
        return new CheckoutSettingsDto(methods, settings.tipsEnabled(), settings.tips(),
                settings.fields());
    }
}
