package com.codenameone.examples.bazaar.shop;

/// Which payment labels a shopper reads in their own language. The server
/// stores the label a payment was taken with: a generic one ("Card", "SEPA
/// Direct Debit") is a Bundle key and is translated; a brand, a wallet or a
/// card's "Visa 4242" is a name and is shown as it is.
///
/// Plain on purpose, so the rule is tested without loading the UI or Lang.
public final class PayLabels {
    /// The generic labels, each a key in every Bundle.
    static final String[] GENERIC = {"Card", "SEPA Direct Debit"};

    private PayLabels() {
    }

    /// Whether `label` is a generic label to look up in the Bundle.
    public static boolean translatable(String label) {
        for (int iter = 0; label != null && iter < GENERIC.length; iter++) {
            if (GENERIC[iter].equals(label)) {
                return true;
            }
        }
        return false;
    }
}
