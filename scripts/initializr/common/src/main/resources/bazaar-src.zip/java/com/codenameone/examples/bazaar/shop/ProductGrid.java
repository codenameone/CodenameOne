package com.codenameone.examples.bazaar.shop;

import com.codename1.appkit.Net;
import com.codename1.ui.CN;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.components.InfiniteProgress;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codenameone.examples.bazaar.api.ProductCardDto;
import com.codenameone.examples.bazaar.api.ProductPageDto;
import com.codenameone.examples.bazaar.api.StoreDto;
import com.codenameone.examples.bazaar.net.Api;
import com.codenameone.examples.bazaar.ui.Layouts;
import com.codenameone.examples.bazaar.ui.Ui;

/// A scrolling grid of products that fetches the next page as the end comes
/// into view, shows the outline of cards while the first page loads, and an
/// empty state when nothing matches. Two columns on a phone, as many as fit
/// on a wide screen.
///
/// Answers are numbered, and one that arrives after a newer question was
/// asked -- the words changed while it was on its way -- is dropped.
final class ProductGrid {
    private static final int PAGE = 24;
    private static final float CARD_MM = 40f;
    /// The navigation beside a section on a wide screen (`Shell`).
    private static final float NAV_MM = 56f;

    private final Container scroller = new Container(BoxLayout.y());
    private final Container grid;
    private final Container footer = new Container(new FlowLayout(Component.CENTER));
    private final int columns;
    private final int cardWidth;
    private final SearchQuery query;
    private int page;
    private boolean more;
    private boolean loading;
    private int asked;
    private int count;

    /// @param query what to show; read afresh on every [#reload]
    /// @param sideWidth what sits beside the grid inside its section, in pixels
    ProductGrid(Component header, SearchQuery query, int sideWidth) {
        this.query = query;
        int width = Math.max(1, room() - sideWidth);
        columns = columns(width);
        cardWidth = width / columns - CN.convertToPixels(3);
        grid = new Container(new GridLayout(1, columns));
        grid.setUIID("ShopGrid");
        grid.setName("product-grid");
        scroller.setUIID("ShopScroller");
        scroller.setScrollableY(true);
        scroller.setScrollVisible(false);
        if (header != null) {
            scroller.add(header);
        }
        scroller.add(grid);
        scroller.add(footer);
        scroller.addScrollListener((x, y, oldX, oldY) -> {
            if (more && !loading && y + scroller.getHeight() * 2 > scroller.getScrollDimension()
                    .getHeight()) {
                next();
            }
        });
        Ui.pull(scroller, this::reload);
    }

    /// The width a shopper's section has for its content: the screen, less
    /// the navigation and no wider than [Layouts#wideColumn()] on a wide one
    /// (`ShopPane` stops there).
    static int room() {
        if (!Layouts.wide()) {
            return CN.getDisplayWidth();
        }
        return Math.min(CN.getDisplayWidth() - CN.convertToPixels(NAV_MM), Layouts.wideColumn());
    }

    /// How many cards a grid `width` pixels wide shows across: two on a phone.
    static int columns(int width) {
        return Math.max(2, Layouts.columns(width, CARD_MM, 6));
    }

    Container component() {
        return scroller;
    }

    int count() {
        return count;
    }

    /// Starts again from the first page.
    void reload() {
        page = 0;
        more = false;
        count = 0;
        grid.removeAll();
        grid.setLayout(new GridLayout(2, columns));
        for (int iter = 0; iter < columns * 2; iter++) {
            grid.add(ProductCard.placeholder(cardWidth));
        }
        footer.removeAll();
        fetch(true);
    }

    private void next() {
        page++;
        footer.removeAll();
        footer.add(new InfiniteProgress());
        footer.revalidate();
        fetch(false);
    }

    private void fetch(final boolean first) {
        StoreDto store = ShopState.store();
        loading = true;
        final int ticket = ++asked;
        if (!ShopState.inStore() || store == null) {
            // Not inside a store: the search runs over every store, one page.
            String sort = query.sortParam();
            Api.discover().feed(query.words(), "rating".equals(sort) ? "popular"
                    : "newest".equals(sort) ? "newest" : null, String.valueOf(PAGE),
                    Net.to(answer -> {
                        if (ticket != asked) {
                            return;
                        }
                        loading = false;
                        show(new ProductPageDto(answer.items(), answer.items() == null ? 0
                                : answer.items().size(), 0, PAGE), first);
                    }, (status, message) -> {
                        if (ticket == asked) {
                            loading = false;
                            failed(first, status, message);
                        }
                    }));
            return;
        }
        Api.catalog().products(store.handle(), query.words(), query.collection, query.tag,
                query.type, query.vendor, query.minParam(), query.maxParam(), query.sortParam(),
                String.valueOf(page), String.valueOf(PAGE), query.categoryParam(), Net.to(answer -> {
                    if (ticket != asked) {
                        return;
                    }
                    loading = false;
                    show(answer, first);
                }, (status, message) -> {
                    if (ticket != asked) {
                        return;
                    }
                    loading = false;
                    failed(first, status, message);
                }));
    }

    private void failed(boolean first, int status, String message) {
        if (first) {
            grid.removeAll();
            footer.removeAll();
            footer.add(Ui.empty(FontImage.MATERIAL_CLOUD_OFF, message, null));
            footer.add(Ui.link("Try again", "retry", e -> reload()));
            Ui.relayout(scroller);
        }
        Ui.fail(status, message);
    }

    private void show(ProductPageDto answer, boolean first) {
        if (first) {
            grid.removeAll();
        }
        footer.removeAll();
        int added = answer.items() == null ? 0 : answer.items().size();
        for (int iter = 0; iter < added; iter++) {
            ProductCardDto p = answer.items().get(iter);
            grid.add(ProductCard.create(p, cardWidth));
        }
        count += added;
        // Whole rows only: a grid layout with too few rows squeezes the cards.
        int rows = Math.max(1, (count + columns - 1) / columns);
        grid.setLayout(new GridLayout(rows, columns));
        more = count < answer.total() && added > 0;
        if (count == 0) {
            footer.add(Ui.empty(FontImage.MATERIAL_SEARCH_OFF, "Nothing matches",
                    "Try other words, or fewer filters."));
        }
        Ui.relayout(scroller);
    }
}
