package com.codenameone.examples.bazaar.merchant;

import com.codename1.appkit.Net;
import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.bazaar.net.Api;
import com.codenameone.examples.bazaar.ui.Lang;
import com.codenameone.examples.bazaar.ui.Ui;

/// The store's B2B companies: name, VAT number, payment terms and the price
/// list each one buys at.
final class CompaniesPane extends MerchantPane {
    CompaniesPane() {
        super("Companies", "merchant-companies");
    }

    @Override
    void load() {
        clearTools();
        tool(FontImage.MATERIAL_REFRESH, "Refresh", "companies-refresh", this::load);
        Api.trade().companies(MerchantState.storeId(), Net.to(list -> {
            Container page = new Container(new BorderLayout());
            Rows<com.codenameone.examples.bazaar.api.CompanyDto> rows =
                    new Rows<com.codenameone.examples.bazaar.api.CompanyDto>()
                    .col(Lang.tr("Company"), c -> c.name())
                    .col(Lang.tr("VAT number"), c -> c.vatId() == null ? "" : c.vatId())
                    .col(Lang.tr("Terms (days)"), c -> String.valueOf(c.termsDays()))
                    .col(Lang.tr("Price list"), c -> c.priceListId() == null ? Lang.tr("Retail")
                            : c.priceListId());
            rows.set(list);
            if (list.isEmpty()) {
                page.add(BorderLayout.CENTER, Ui.empty(FontImage.MATERIAL_BUSINESS,
                        "No companies yet", "A buyer's company appears once it is set up."));
            } else {
                page.add(BorderLayout.CENTER, MUi.grid(rows, "companies-grid"));
            }
            root(page);
        }, Ui::fail));
    }
}
