package com.codenameone.examples.bazaar.merchant;

import com.codenameone.examples.bazaar.ops.UnitPricing;

/// The variant editor's input checks, kept apart from its UI so a plain unit
/// test can load them without a display. A problem is returned as its
/// Bundle key, the English text; the editor translates it.
final class VariantChecks {
    private VariantChecks() {
    }

    /// Why a variant's customs and unit pricing cannot be saved, or null.
    /// `hsCode` and `country` are what [Customs] made of the fields.
    static String unitProblem(String hsCode, String country, long quantity, String unitName,
            int reference, String referenceName) {
        if (hsCode == null) {
            return ("An HS code has 6 to 10 digits");
        }
        if (country == null) {
            return ("Enter a two-letter country code, such as US or DE");
        }
        if (quantity < 0) {
            return ("Enter the measure as a number, such as 250 or 1.5");
        }
        if (quantity == 0 && unitName.length() == 0) {
            return null;
        }
        if (quantity == 0 || !UnitPricing.isUnit(unitName) || !UnitPricing.isUnit(referenceName)
                || !UnitPricing.compatible(unitName, referenceName)
                || reference < 1 || reference > UnitPricing.MAX_REFERENCE) {
            return ("Enter a measure, a unit and a price-per unit of the same kind");
        }
        return null;
    }
}
