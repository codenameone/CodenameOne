package com.codenameone.examples.reel.ui;

import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.reel.Telemetry;
import com.codenameone.examples.reel.api.SignupDto;
import com.codenameone.examples.reel.net.Api;
import com.codenameone.examples.reel.net.Net;
import com.codenameone.examples.reel.net.Session;

/// Creates an account and signs in with it.
///
/// Everyone who registers can watch what is free and pick a plan. Creating,
/// moderating and administering are roles an admin grants from the admin
/// screens; nobody registers into them.
public final class RegisterForm {
    private RegisterForm() {
    }

    public static void show(Form previous) {
        final Form form = Ui.form("Create an account", "Register");
        Ui.back(form, previous);
        Container page = Ui.page();
        final TextField name = Ui.field(page, "Name", "name", "Your name");
        final TextField email = Ui.field(page, "E-mail", "email", "you@example.com", TextArea.EMAILADDR);
        final TextField password = Ui.field(page, "Password", "password", "At least 8 characters",
                TextArea.PASSWORD);

        final SpanLabel error = Ui.text("", "SvError");
        error.setName("error");
        final Button create = Ui.primary("Create account", "submit", null);
        create.addActionListener(e -> {
            final SignupDto request = new SignupDto(email.getText().trim(), password.getText(),
                    name.getText().trim());
            final Net.Failed failed = (status, message) -> {
                create.setEnabled(true);
                error.setText(message);
                Ui.refresh(form);
            };
            create.setEnabled(false);
            error.setText("");
            // The server checks every field and says what is wrong with the
            // first that fails, so nothing is validated twice.
            Api.account().signup(request, Net.to(user -> Session.signIn(request.email(),
                    request.password(), () -> {
                        Telemetry.registered();
                        Nav.enter();
                    }, failed), failed));
        });
        page.add(error).add(create);
        form.add(BorderLayout.CENTER, page);
        form.show();
    }
}
