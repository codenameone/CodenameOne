package com.codenameone.examples.reel.ui;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codenameone.examples.reel.AppConfig;

/// What a signed-out user sees.
public final class WelcomeForm {
    private WelcomeForm() {
    }

    public static void show() {
        final Form form = Ui.form("", "Welcome");
        form.getToolbar().hideToolbar();

        Container hero = new Container(BoxLayout.y());
        hero.setUIID("SvHero");
        hero.setSafeArea(true);
        Label icon = new Label("", "SvHeroIcon");
        Ui.icon(icon, FontImage.MATERIAL_MOVIE, 10f);
        hero.add(icon);
        hero.add(Ui.label("Reel", "SvHeroTitle"));
        hero.add(Ui.text("Films, series and courses, on every screen you own.", "SvHeroText"));

        Container actions = Ui.page();
        actions.setScrollableY(false);
        actions.add(Ui.primary("Sign in", "signIn", e -> SignInForm.show(form)));
        actions.add(Ui.secondary("Create an account", "register", e -> RegisterForm.show(form)));
        if (AppConfig.serverSwitchable()) {
            actions.add(Ui.link("Server address", "server", e -> ServerForm.show(form)));
        }

        form.add(BorderLayout.CENTER, hero);
        form.add(BorderLayout.SOUTH, actions);
        form.show();
    }
}
