package com.codenameone.examples.fieldline.ui;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codenameone.examples.fieldline.AppConfig;

/// What a signed-out user sees.
public final class WelcomeForm {
    private WelcomeForm() {
    }

    private static Container feature(char glyph, String text) {
        Container row = new Container(new BorderLayout(), "WlHeroFeature");
        Label icon = new Label("", "WlHeroFeatureIcon");
        Ui.icon(icon, glyph, 3.6f);
        row.add(BorderLayout.WEST, icon);
        row.add(BorderLayout.CENTER, Ui.text(text, "WlHeroText"));
        return row;
    }

    public static void show() {
        final Form form = Ui.form("", "Welcome");
        form.getToolbar().hideToolbar();

        Container hero = new Container(BoxLayout.y());
        hero.setUIID("WlHero");
        hero.setSafeArea(true);
        Label icon = new Label("", "WlHeroIcon");
        Ui.icon(icon, FontImage.MATERIAL_HANDYMAN, 10f);
        hero.add(icon);
        hero.add(Ui.label("Fieldline", "WlHeroTitle"));
        hero.add(Ui.text("The day planned around your crew, the job done right on site.", "WlHeroText"));
        // What the app does, as Slate and Pulse say it: the hero was a logo
        // and one line over an empty field of color.
        hero.add(feature(FontImage.MATERIAL_ROUTE, "Your route, planned around skills, hours and travel"));
        hero.add(feature(FontImage.MATERIAL_FACT_CHECK, "Checklists and photos the assistant can diagnose"));
        hero.add(feature(FontImage.MATERIAL_VERIFIED, "Customer sign-off sealed so the report can be verified"));

        Container actions = Ui.page();
        actions.setScrollableY(false);
        actions.add(Ui.primary("Sign in", "signIn", e -> SignInForm.show(form)));
        actions.add(Ui.secondary("Create an account", "register", e -> RegisterForm.show(form)));
        if (AppConfig.serverSwitchable()) {
            actions.add(Ui.link("Server address", "server", e -> ServerForm.show(form)));
        }

        form.add(BorderLayout.CENTER, hero);
        form.add(BorderLayout.SOUTH, actions);
        form.show();
    }
}
