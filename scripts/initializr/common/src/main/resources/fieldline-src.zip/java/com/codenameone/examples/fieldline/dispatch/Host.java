package com.codenameone.examples.fieldline.dispatch;

import com.codename1.ui.Component;
import com.codename1.ui.Form;

/// Where a page of the back office shows what was picked from its list.
///
/// The pages are written once. In the console the list stays in view and the
/// detail is shown beside it; on a phone each is a screen of its own, reached
/// from the list and left with the back arrow.
interface Host {
    /// Shows `content` as what was picked, in place of whatever was.
    void detail(String title, String name, Component content);

    /// Marks `row` as the one that is open, where the list stays in view.
    void picked(Component row);

    /// Back to the list alone, which is fetched again.
    void reload();

    /// The screen all of this is on.
    Form form();
}
