package com.codenameone.examples.wayline.ui;

import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.wayline.Telemetry;
import com.codenameone.examples.wayline.net.Session;

/// E-mail and password. The form is the app's own; what happens when it is
/// submitted is in [Session#signIn].
public final class SignInForm {
    private SignInForm() {
    }

    public static void show(Form previous) {
        final Form form = Ui.form("Sign in", "SignIn");
        Ui.back(form, previous);
        Container page = Ui.page();
        final TextField email = Ui.field(page, "E-mail", "email", "you@example.com",
                TextArea.EMAILADDR);
        final TextField password = Ui.field(page, "Password", "password", "",
                TextArea.PASSWORD);
        final SpanLabel error = Ui.text("", "WlError");
        error.setName("error");
        final Button signIn = Ui.primary("Sign in", "submit", null);
        signIn.addActionListener(e -> {
            if (email.getText().trim().length() == 0 || password.getText().length() == 0) {
                error.setText("Enter your e-mail and password.");
                Ui.refresh(form);
                return;
            }
            signIn.setEnabled(false);
            error.setText("");
            Session.signIn(email.getText().trim(), password.getText(), () -> {
                Telemetry.signedIn();
                Nav.enter();
            }, (status, message) -> {
                        signIn.setEnabled(true);
                        error.setText(message);
                        Ui.refresh(form);
                    });
        });
        page.add(error).add(signIn);
        form.add(BorderLayout.CENTER, page);
        form.show();
    }
}
