package com.codenameone.examples.wayline.ui;

import com.codename1.ui.Container;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;

/// What a signed-out user sees.
public final class WelcomeForm {
    private WelcomeForm() {
    }

    public static void show() {
        final Form form = Ui.form("", "Welcome");
        form.getToolbar().hideToolbar();

        Container hero = new Container(BoxLayout.y());
        hero.setUIID("WlHero");
        hero.setSafeArea(true);
        Label icon = new Label("", "WlHeroIcon");
        Ui.icon(icon, FontImage.MATERIAL_NEAR_ME, 10f);
        hero.add(icon);
        hero.add(Ui.label("Wayline", "WlHeroTitle"));
        hero.add(Ui.text("A ride when you need one, and a fair way to drive.", "WlHeroText"));

        Container actions = Ui.page();
        actions.setScrollableY(false);
        actions.add(Ui.primary("Sign in", "signIn", e -> SignInForm.show(form)));
        actions.add(Ui.secondary("Create an account", "register", e -> RegisterForm.show(form)));
        actions.add(Ui.link("Server address", "server", e -> ServerForm.show(form)));

        form.add(BorderLayout.CENTER, hero);
        form.add(BorderLayout.SOUTH, actions);
        form.show();
    }
}
