package com.codenameone.examples.wayline.ui;

import com.codename1.ui.CN;
import com.codename1.ui.plaf.UIManager;
import com.codenameone.examples.wayline.Prefs;

/// Light or dark.
///
/// `theme.css` has both: every rule has its dark twin in the block at the end
/// of the file. Which of the two a component gets is decided when its style is
/// resolved, so a screen built after [#apply()] is in the new look and one
/// already built is not -- the caller rebuilds what is on screen.
public final class Look {
    private Look() {
    }

    /// Makes the look the one chosen in Settings: light, dark, or whichever
    /// the device is in.
    public static void apply() {
        String theme = Prefs.theme();
        CN.setDarkMode(Prefs.THEME_DARK.equals(theme) ? Boolean.TRUE
                : Prefs.THEME_LIGHT.equals(theme) ? Boolean.FALSE : null);
        if (CN.isDesktop()) {
            // On a desktop the platform's theme takes the colours and the font
            // the user chose for the whole machine -- the accent among them.
            // It reaches only what that theme styles, which is what the admin
            // console wears; see Layouts.
            UIManager.getInstance().setUseNativeColors(true);
            UIManager.getInstance().setUseNativeFonts(true);
        }
        UIManager.getInstance().refreshTheme();
    }

    /// Whether the app is drawn dark right now. A platform that cannot say is
    /// taken to be light.
    public static boolean dark() {
        Boolean dark = CN.isDarkMode();
        return dark != null && dark.booleanValue();
    }
}
