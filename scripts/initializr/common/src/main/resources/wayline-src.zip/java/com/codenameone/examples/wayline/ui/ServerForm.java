package com.codenameone.examples.wayline.ui;

import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BorderLayout;
import com.codenameone.examples.wayline.net.Session;

/// Where the server is. A released app has one answer and no use for this
/// screen; while you are developing, it is how a phone is pointed at the server
/// running on your computer -- `http://` and the computer's address on the
/// network, since `localhost` on a phone is the phone.
public final class ServerForm {
    private ServerForm() {
    }

    public static void show(Form previous) {
        Form form = Ui.form("Server address", "Server");
        Ui.back(form, previous);
        Container page = Ui.page();
        page.add(Ui.text("The address of the Wayline server this app talks to. "
                + "Changing it signs you out.", "WlText"));
        final TextField url = Ui.field(page, "Address", "url", "http://192.168.1.20:8080",
                TextArea.URL);
        url.setText(Session.serverUrl());
        page.add(Ui.primary("Save", "submit", e -> Nav.changeServer(url.getText())));
        form.add(BorderLayout.CENTER, page);
        form.show();
    }
}
