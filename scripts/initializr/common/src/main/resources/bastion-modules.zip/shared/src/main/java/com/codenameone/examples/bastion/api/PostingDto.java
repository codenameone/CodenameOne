package com.codenameone.examples.bastion.api;

import com.codename1.annotations.Mapped;

/// One line of an account's history: `amount` in (positive) or out (negative).
@Mapped
public record PostingDto(String id, String entryId, String asset, long amount, long createdAt) {
}
