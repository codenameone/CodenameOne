package com.codenameone.examples.bastion.api;

import com.codename1.annotations.Mapped;

/// Ledger activity on the UTC day starting at `day` in one asset: entries
/// posted and their total debits.
@Mapped
public record VolumeDayDto(
        long day,
        String asset,
        int entries,
        long volume) {
}
