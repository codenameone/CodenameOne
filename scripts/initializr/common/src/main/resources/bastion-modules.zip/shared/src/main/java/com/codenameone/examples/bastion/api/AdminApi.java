package com.codenameone.examples.bastion.api;

import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

/// What only an admin may ask: whether the records still hold.
@RestClient
public interface AdminApi {
    /// Walks the audit chain from its first link.
    @GET("/api/admin/audit/verify")
    void verifyAudit(OnComplete<Response<VerificationDto>> callback);

    /// Checks every entry sums to zero in each asset and every balance is the
    /// sum of its postings.
    @GET("/api/admin/ledger/verify")
    void verifyLedger(OnComplete<Response<VerificationDto>> callback);
}
