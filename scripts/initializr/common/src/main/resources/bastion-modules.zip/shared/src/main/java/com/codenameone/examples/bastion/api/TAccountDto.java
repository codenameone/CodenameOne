package com.codenameone.examples.bastion.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One account as a T: its debits on the left, credits on the right, between
/// the balance brought forward at `from` and the balance carried at `to`
/// (both on the normal side).
@Mapped
public record TAccountDto(
        String accountId,
        String code,
        String name,
        String accountClass,
        String normalBalance,
        String asset,
        long from,
        long to,
        long openingBalance,
        List<LedgerLineDto> debits,
        List<LedgerLineDto> credits,
        long totalDebits,
        long totalCredits,
        long closingBalance) {
}
