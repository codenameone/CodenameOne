package com.codenameone.examples.bastion.api;

import com.codename1.annotations.Mapped;

/// A six-digit code from the user's authenticator app.
@Mapped
public record TotpCodeDto(String code) {
}
