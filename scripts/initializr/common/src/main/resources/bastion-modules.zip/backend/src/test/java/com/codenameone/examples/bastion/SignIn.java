package com.codenameone.examples.bastion;

import com.codename1.backend.Json;
import com.codename1.backend.security.oauth2.core.OAuth2Parameters;
import com.codename1.backend.test.MockMvc;
import com.codename1.backend.test.MockRequestBuilder;
import com.codename1.backend.test.MockResponse;

import java.util.Map;

import static com.codename1.backend.test.MockMvcRequestBuilders.get;
import static com.codename1.backend.test.MockMvcRequestBuilders.post;

/// Signing in the way the app does: the password form, a code when the
/// account asks for one, then the authorization-code flow with PKCE.
final class SignIn {
    private static final String VERIFIER = "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk";
    private static final String CHALLENGE = "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM";
    static final String HOST = "myappname.test:8080";

    private SignIn() {
    }

    static MockRequestBuilder formPost(String path, String... pairs) {
        StringBuilder body = new StringBuilder();
        for (int i = 0; i < pairs.length; i += 2) {
            if (body.length() > 0) {
                body.append('&');
            }
            body.append(OAuth2Parameters.encode(pairs[i])).append('=')
                    .append(OAuth2Parameters.encode(pairs[i + 1]));
        }
        return post(path).contentType("application/x-www-form-urlencoded").content(body.toString())
                .header("Host", HOST);
    }

    static MockResponse password(MockMvc mvc, String username, String password) throws Exception {
        return mvc.perform(formPost("/login", "username", username, "password", password))
                .andReturn().getResponse();
    }

    static String session(MockMvc mvc, String username, String password) throws Exception {
        MockResponse answer = password(mvc, username, password);
        return answer.getStatus() == 200 ? answer.getCookie("CN1SESSION") : null;
    }

    /// The authorization code a signed-in session gets, or null when the
    /// session is not signed in.
    static String code(MockMvc mvc, String session) throws Exception {
        String location = mvc.perform(get("/oauth2/authorize?response_type=code&client_id="
                        + SecurityConfig.CLIENT_ID + "&redirect_uri="
                        + OAuth2Parameters.encode(SecurityConfig.LOOPBACK_REDIRECT)
                        + "&scope=openid%20profile&state=s-1&nonce=n-1&code_challenge=" + CHALLENGE
                        + "&code_challenge_method=S256")
                        .header("Host", HOST).cookie("CN1SESSION", session))
                .andReturn().getResponse().getRedirectedUrl();
        if (location == null || !location.startsWith(SecurityConfig.LOOPBACK_REDIRECT)
                || location.indexOf("code=") < 0) {
            return null;
        }
        int at = location.indexOf("code=") + 5;
        int end = location.indexOf('&', at);
        return location.substring(at, end < 0 ? location.length() : end);
    }

    static Map exchange(MockMvc mvc, String session) throws Exception {
        String code = code(mvc, session);
        if (code == null) {
            throw new IllegalStateException("no authorization code");
        }
        String body = mvc.perform(formPost("/oauth2/token",
                        "grant_type", "authorization_code",
                        "code", code,
                        "redirect_uri", SecurityConfig.LOOPBACK_REDIRECT,
                        "code_verifier", VERIFIER,
                        "client_id", SecurityConfig.CLIENT_ID))
                .andReturn().getResponse().getContentAsString();
        return Json.parseObject(body);
    }

    static Map tokens(MockMvc mvc, String username, String password) throws Exception {
        String session = session(mvc, username, password);
        if (session == null) {
            throw new IllegalStateException("could not sign in as " + username);
        }
        return exchange(mvc, session);
    }

    static String token(MockMvc mvc, String username, String password) throws Exception {
        Object token = tokens(mvc, username, password).get("access_token");
        if (!(token instanceof String)) {
            throw new IllegalStateException("no access token for " + username);
        }
        return (String) token;
    }

    /// Opens an account through the API and answers its username.
    static String register(MockMvc mvc, String username, String password) throws Exception {
        int status = mvc.perform(post("/api/account/register").header("Host", HOST)
                        .contentType("application/json")
                        .content("{\"email\":\"" + username + "\",\"password\":\"" + password
                                + "\",\"displayName\":\"Test Person\"}"))
                .andReturn().getResponse().getStatus();
        if (status != 200) {
            throw new IllegalStateException("register answered " + status);
        }
        return username;
    }
}
