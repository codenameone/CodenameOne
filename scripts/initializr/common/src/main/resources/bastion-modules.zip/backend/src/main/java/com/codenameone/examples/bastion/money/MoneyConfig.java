package com.codenameone.examples.bastion.money;

import com.codename1.backend.annotations.Bean;
import com.codename1.backend.annotations.Configuration;

/// The pieces of money movement a deployment replaces.
@Configuration
public class MoneyConfig {
    /// The device integrity check. Simulated: see [IntegrityVerifier] for what
    /// a production one calls, and why this sample cannot.
    @Bean
    public IntegrityVerifier integrityVerifier() {
        return new SimulatedIntegrityVerifier();
    }
}
