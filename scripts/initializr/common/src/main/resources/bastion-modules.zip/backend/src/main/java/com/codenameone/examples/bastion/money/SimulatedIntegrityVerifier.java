package com.codenameone.examples.bastion.money;

/// Takes the device's word for it, which is exactly what a real verifier
/// must never do: a rooted phone reports whatever its owner -- or the malware
/// on it -- likes.
///
/// It exists so the rest of the policy can be built and tested before the app
/// is signed by the build daemon and a real verdict can be had. One rule it
/// keeps from the real thing: no token, no attestation. A device that sent
/// nothing to check is never counted as attested, whatever it claims.
public class SimulatedIntegrityVerifier implements IntegrityVerifier {
    @Override
    public Verdict verify(String platform, String token, boolean reportedRooted,
            boolean reportedAttested) {
        boolean hasToken = token != null && token.length() > 0;
        return new Verdict(reportedAttested && hasToken && !reportedRooted, reportedRooted);
    }
}
