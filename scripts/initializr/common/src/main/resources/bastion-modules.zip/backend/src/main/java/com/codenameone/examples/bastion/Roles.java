package com.codenameone.examples.bastion;

/// The roles an account can hold. Every account opened through the app is a
/// customer; ADMIN is given only by configuration ([account.DemoAccounts]) and
/// never by any request, so no bug in an endpoint can hand it out.
public final class Roles {
    public static final String CUSTOMER = "CUSTOMER";
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
