package com.codenameone.examples.bastion.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// Wrong passwords counted against one account, for the lockout in
/// [com.codenameone.examples.bastion.account.SignInGuard]. Kept in the
/// database and not in memory so that every instance of the server counts the
/// same attempts: spreading guesses over instances buys an attacker nothing.
@Entity
public class LoginFailure {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String username = "";

    @Column(nullable = false)
    private int failures;

    @Column(nullable = false)
    private long firstAt;

    @Column(nullable = false)
    private long lockedUntil;

    public LoginFailure() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getFailures() {
        return failures;
    }

    public void setFailures(int failures) {
        this.failures = failures;
    }

    public long getFirstAt() {
        return firstAt;
    }

    public void setFirstAt(long firstAt) {
        this.firstAt = firstAt;
    }

    public long getLockedUntil() {
        return lockedUntil;
    }

    public void setLockedUntil(long lockedUntil) {
        this.lockedUntil = lockedUntil;
    }
}
