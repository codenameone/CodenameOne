package com.codenameone.examples.bastion.chain;

import java.io.ByteArrayOutputStream;
import java.util.List;

/// Ethereum's Recursive Length Prefix encoding, the byte form every
/// transaction is signed and broadcast in. Only encoding: a node's answers
/// arrive as JSON, so nothing here ever parses RLP from outside.
///
/// An item is a byte string or a list of items. Integers are byte strings
/// too, big-endian with no leading zero bytes (zero is the empty string), and
/// [#quantity] is the only way a number should get in: a stray leading zero
/// makes a transaction every node refuses.
public final class Rlp {
    private Rlp() {
    }

    /// One byte string.
    public static byte[] string(byte[] value) {
        if (value.length == 1 && (value[0] & 0xff) < 0x80) {
            return new byte[] {value[0]};
        }
        return concat(prefix(0x80, value.length), value);
    }

    /// A list of already encoded items.
    public static byte[] list(List<byte[]> encodedItems) {
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        for (byte[] item : encodedItems) {
            body.write(item, 0, item.length);
        }
        byte[] payload = body.toByteArray();
        return concat(prefix(0xc0, payload.length), payload);
    }

    /// A non-negative integer.
    public static byte[] quantity(long value) {
        if (value < 0) {
            throw new IllegalArgumentException("negative quantity");
        }
        return string(Wei.trim(Wei.ofLong(value)));
    }

    /// An unsigned big-endian integer, leading zeros stripped.
    public static byte[] quantity(byte[] unsigned) {
        return string(Wei.trim(unsigned));
    }

    private static byte[] prefix(int offset, int length) {
        if (length < 56) {
            return new byte[] {(byte) (offset + length)};
        }
        byte[] len = Wei.trim(Wei.ofLong(length));
        byte[] out = new byte[1 + len.length];
        out[0] = (byte) (offset + 55 + len.length);
        System.arraycopy(len, 0, out, 1, len.length);
        return out;
    }

    static byte[] concat(byte[] a, byte[] b) {
        byte[] out = new byte[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }
}
