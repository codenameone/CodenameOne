package com.codenameone.examples.bastion.chain;

/// [ChainSigner] from a BIP-32 seed held in memory. Each key is derived when
/// it is needed and wiped after the one signature it makes, so a heap dump
/// between signatures holds the seed and nothing more -- which is the reason
/// a product moves the seed itself into a key service.
public final class SeedSigner implements ChainSigner {
    /// The hot wallet: account 1, so it never collides with a deposit index.
    private static final long HOT_ACCOUNT = 1;

    private final byte[] seed;
    private final String hot;

    public SeedSigner(byte[] seed) {
        this.seed = seed;
        this.hot = hotKey().address();
    }

    private Bip32 hotKey() {
        return Bip32.master(seed).child(44 + Bip32.HARDENED).child(60 + Bip32.HARDENED)
                .child(HOT_ACCOUNT + Bip32.HARDENED).child(0).child(0);
    }

    @Override
    public String hotAddress() {
        return hot;
    }

    @Override
    public String depositAddress(long index) {
        return Bip32.ethereum(seed, index).address();
    }

    @Override
    public byte[] signWithHot(byte[] hash32) {
        return signWith(hotKey().privateKey(), hash32);
    }

    @Override
    public byte[] signWithDeposit(long index, byte[] hash32) {
        return signWith(Bip32.ethereum(seed, index).privateKey(), hash32);
    }

    private static byte[] signWith(byte[] key, byte[] hash32) {
        try {
            return EthKeys.sign(key, hash32);
        } finally {
            for (int iter = 0; iter < key.length; iter++) {
                key[iter] = 0;
            }
        }
    }
}
