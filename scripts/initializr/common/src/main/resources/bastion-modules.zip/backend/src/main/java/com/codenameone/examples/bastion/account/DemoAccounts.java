package com.codenameone.examples.bastion.account;

import com.codename1.backend.Config;
import com.codename1.backend.annotations.Component;
import com.codename1.backend.annotations.PostConstruct;
import com.codename1.backend.annotations.Value;
import com.codenameone.examples.bastion.domain.LedgerAccount;
import com.codenameone.examples.bastion.ledger.AccountKinds;
import com.codenameone.examples.bastion.ledger.Leg;
import com.codenameone.examples.bastion.ledger.Ledger;

import java.io.IOException;
import java.util.Arrays;

/// The accounts a server starts with.
///
/// Outside a development profile: one administrator, from
/// `myappname.admin.email` and `myappname.admin.password`, and only when both are
/// set -- in the environment, never in a file that is committed. No request
/// can make an administrator, so this is the only way one comes to exist.
///
/// On a development profile (`dev`, and `test` for the tests): demo customers
/// with money in their checking accounts, and an admin, all with
/// [#PASSWORD]. Those passwords are in this file for anyone to read, which is
/// why they exist nowhere else.
@Component
public class DemoAccounts {
    public static final String CUSTOMER = "customer@myappname.example";
    public static final String SECOND_CUSTOMER = "customer2@myappname.example";
    public static final String ADMIN = "admin@myappname.example";
    public static final String PASSWORD = "myappname-demo-password";

    private final Accounts accounts;
    private final Ledger ledger;
    private final Config config;
    private final String adminEmail;
    private final String adminPassword;

    public DemoAccounts(Accounts accounts, Ledger ledger, Config config,
            @Value("${myappname.admin.email:}") String adminEmail,
            @Value("${myappname.admin.password:}") String adminPassword) {
        this.accounts = accounts;
        this.ledger = ledger;
        this.config = config;
        this.adminEmail = adminEmail;
        this.adminPassword = adminPassword;
    }

    @PostConstruct
    public void seed() throws IOException {
        if (adminEmail.length() > 0 && adminPassword.length() > 0) {
            String username = Accounts.email(adminEmail);
            // The same policy as anyone's: a weak admin password fails the
            // start-up rather than guarding the audit log.
            Passwords.check(username, adminPassword);
            admin(username, adminPassword);
        }
        if (!config.isDevelopmentProfile()) {
            return;
        }
        admin(ADMIN, PASSWORD);
        customer(CUSTOMER, "Riley Customer", 250000);
        customer(SECOND_CUSTOMER, "Robin Customer", 120000);
    }

    private void admin(String username, String password) throws IOException {
        if (accounts.exists(username)) {
            return;
        }
        try {
            accounts.create(username, password, "Administrator", true,
                    System.currentTimeMillis());
        } catch (IOException | RuntimeException failed) {
            // Two servers started together against a new database both find
            // no admin and both make one; the second insert fails on the name.
            // create() is one transaction, so the loser left nothing behind.
            if (!accounts.exists(username)) {
                throw failed;
            }
        }
    }

    private void customer(String username, String name, long cents) throws IOException {
        if (accounts.exists(username)) {
            return;
        }
        accounts.create(username, PASSWORD, name, false, System.currentTimeMillis());
        LedgerAccount checking = ledger.open(username, Accounts.FIRST_ASSET,
                AccountKinds.CHECKING, "Checking");
        // Money comes from the bank's cash account, as a deposit at a branch
        // would: the books balance from the first entry. The key makes a
        // second seeding of the same account a no-op.
        LedgerAccount cash = ledger.system(Accounts.FIRST_ASSET, AccountKinds.SYS_CASH);
        ledger.post("seed-" + username, "DEPOSIT", AccountKinds.BANK, "Opening deposit",
                Arrays.asList(new Leg(cash.getId(), -cents), new Leg(checking.getId(), cents)));
    }
}
