package com.codenameone.examples.bastion.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bastion.domain.LoginFailure;

@Repository(entity = LoginFailure.class, key = String.class)
public interface LoginFailureRepository extends CrudRepository<LoginFailure, String> {
}
