package com.codenameone.examples.bastion.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bastion.domain.CryptoAddress;

import java.util.List;

@Repository(entity = CryptoAddress.class, key = String.class)
public interface CryptoAddressRepository extends CrudRepository<CryptoAddress, String> {
    List<CryptoAddress> findByOwnerOrderByCreatedAtAsc(String owner);
}
