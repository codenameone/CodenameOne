package com.codenameone.examples.bastion.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// An address outside the bank that a customer may withdraw a crypto asset to.
/// Usable only from `usableAt`: the cooling-off that gives the customer a day
/// to notice an address they did not add.
@Entity
public class CryptoAddress {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String owner = "";

    @Column(nullable = false, type = "VARCHAR(12)")
    private String asset = "";

    @Column(nullable = false, type = "VARCHAR(100)")
    private String address = "";

    @Column(nullable = false, type = "VARCHAR(80)")
    private String label = "";

    @Column(nullable = false)
    private long usableAt;

    @Column(nullable = false)
    private boolean removed;

    @Column(nullable = false)
    private long createdAt;

    public CryptoAddress() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAsset() {
        return asset;
    }

    public void setAsset(String asset) {
        this.asset = asset;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public long getUsableAt() {
        return usableAt;
    }

    public void setUsableAt(long usableAt) {
        this.usableAt = usableAt;
    }

    public boolean isRemoved() {
        return removed;
    }

    public void setRemoved(boolean removed) {
        this.removed = removed;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}
