package com.codenameone.examples.bastion.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.bastion.domain.Trade;

import java.util.List;

@Repository(entity = Trade.class, key = String.class)
public interface TradeRepository extends CrudRepository<Trade, String> {
    @Query("select t from Trade t where t.buyer = :who or t.seller = :who "
            + "order by t.createdAt desc")
    List<Trade> of(@Param("who") String who);
}
