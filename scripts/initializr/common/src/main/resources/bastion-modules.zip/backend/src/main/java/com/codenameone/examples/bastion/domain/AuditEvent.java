package com.codenameone.examples.bastion.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One row of the hash-chained audit log.
@Entity
public class AuditEvent {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private long seq;

    @Column(nullable = false)
    private long at;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String actor = "";

    @Column(nullable = false, type = "VARCHAR(40)")
    private String action = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String subject = "";

    @Column(nullable = false, type = "VARCHAR(500)")
    private String detail = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String address = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String prevHash = "";

    @Column(nullable = false, type = "VARCHAR(64)")
    private String hash = "";

    public AuditEvent() {
    }

    public long getSeq() {
        return seq;
    }

    public void setSeq(long seq) {
        this.seq = seq;
    }

    public long getAt() {
        return at;
    }

    public void setAt(long at) {
        this.at = at;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrevHash() {
        return prevHash;
    }

    public void setPrevHash(String prevHash) {
        this.prevHash = prevHash;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }
}
