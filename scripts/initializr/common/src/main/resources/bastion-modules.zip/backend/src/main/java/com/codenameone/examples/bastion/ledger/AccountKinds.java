package com.codenameone.examples.bastion.ledger;

/// What an account is for. The `SYS_` kinds belong to the bank, are owned by
/// [#BANK], and are the only ones allowed below zero.
public final class AccountKinds {
    /// The owner of every account the bank keeps for itself. Not a valid
    /// username, so no customer can ever be it.
    public static final String BANK = "@bank";

    public static final String CHECKING = "CHECKING";
    public static final String SAVINGS = "SAVINGS";
    /// A customer's balance in a crypto asset.
    public static final String WALLET = "WALLET";
    /// Funds a customer has committed to an open order and can no longer
    /// spend; see the exchange.
    public static final String HOLD = "HOLD";

    /// The world outside the ledger: money deposited comes out of it, money
    /// withdrawn goes into it.
    public static final String SYS_CASH = "SYS_CASH";
    public static final String SYS_FEES = "SYS_FEES";
    /// The blockchain, simulated: coins withdrawn to an outside address go
    /// here, as fiat withdrawn goes to SYS_CASH.
    public static final String SYS_CHAIN = "SYS_CHAIN";

    private AccountKinds() {
    }

    public static boolean isSystem(String kind) {
        return kind != null && kind.startsWith("SYS_");
    }

    public static boolean isCustomer(String kind) {
        return CHECKING.equals(kind) || SAVINGS.equals(kind) || WALLET.equals(kind)
                || HOLD.equals(kind);
    }
}
