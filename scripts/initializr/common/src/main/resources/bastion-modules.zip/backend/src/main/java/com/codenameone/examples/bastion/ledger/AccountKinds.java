package com.codenameone.examples.bastion.ledger;

/// What an account is for. The `SYS_` kinds belong to the bank, are owned by
/// [#BANK], and are the only ones allowed below zero.
public final class AccountKinds {
    /// The owner of every account the bank keeps for itself. Not a valid
    /// username, so no customer can ever be it.
    public static final String BANK = "@bank";

    public static final String CHECKING = "CHECKING";
    public static final String SAVINGS = "SAVINGS";
    /// A customer's balance in a crypto asset.
    public static final String WALLET = "WALLET";
    /// Funds a customer has committed to an open order and can no longer
    /// spend; see the exchange.
    public static final String HOLD = "HOLD";

    /// The world outside the ledger: money deposited comes out of it, money
    /// withdrawn goes into it.
    public static final String SYS_CASH = "SYS_CASH";
    public static final String SYS_FEES = "SYS_FEES";
    /// The blockchain, simulated: coins withdrawn to an outside address go
    /// here, as fiat withdrawn goes to SYS_CASH.
    public static final String SYS_CHAIN = "SYS_CHAIN";
    /// Coins taken from a customer for a withdrawal whose transaction is not
    /// final yet: confirmed, they move on to SYS_CHAIN; failed, back to the
    /// customer. Never anything else, so its balance is the coins in flight.
    public static final String SYS_CHAIN_TRANSIT = "SYS_CHAIN_TRANSIT";
    /// What the bank pays the network to move coins (gas): withdrawals and
    /// the sweeps that gather deposits into the hot wallet.
    public static final String SYS_NETWORK_FEES = "SYS_NETWORK_FEES";
    /// The bank's own capital: what its owners paid in.
    public static final String SYS_EQUITY = "SYS_EQUITY";
    /// Profit kept from closed periods; period close moves revenue and
    /// expense here.
    public static final String SYS_RETAINED = "SYS_RETAINED";
    /// Interest the bank pays on savings.
    public static final String SYS_INTEREST = "SYS_INTEREST";
    /// Goodwill credits and corrections an administrator posts.
    public static final String SYS_ADJUST = "SYS_ADJUST";

    private AccountKinds() {
    }

    public static boolean isSystem(String kind) {
        return kind != null && kind.startsWith("SYS_");
    }

    public static boolean isCustomer(String kind) {
        return CHECKING.equals(kind) || SAVINGS.equals(kind) || WALLET.equals(kind)
                || HOLD.equals(kind);
    }
}
