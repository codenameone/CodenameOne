package com.codenameone.examples.bastion.domain;

import java.time.Instant;
import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// Coins crossing between the bank and a blockchain, in either direction.
///
/// A withdrawal (`OUT`) moves through QUEUED (the ledger has taken the coins
/// from the customer into the in-flight account), SIGNED (a transaction with
/// a fixed nonce exists and `raw` holds it, so a crash re-broadcasts the same
/// bytes rather than signing a second spend), BROADCAST, and then CONFIRMED
/// or FAILED, each final state posting once to the ledger. A deposit (`IN`)
/// is written only when it is already deep enough to credit, CONFIRMED from
/// birth; `(txHash, logIndex)` is unique, so a rescan cannot credit it twice.
@Entity
public class ChainTransfer {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    /// `IN` or `OUT`.
    @Column(nullable = false, type = "VARCHAR(3)")
    private String direction = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String owner = "";

    @Column(nullable = false, type = "VARCHAR(12)")
    private String asset = "";

    /// The outside address: where an OUT pays, or the deposit address an IN arrived at.
    @Column(nullable = false, type = "VARCHAR(42)")
    private String address = "";

    /// Ledger units (gwei for ETH).
    @Column(nullable = false)
    private long amount;

    @Column(nullable = false, type = "VARCHAR(12)")
    private String status = "";

    /// Empty until signed.
    @Column(nullable = false, type = "VARCHAR(66)")
    private String txHash = "";

    /// 0 for a plain value transfer; reserved for token transfers, which arrive as logs.
    @Column(nullable = false)
    private int logIndex;

    /// The hot wallet nonce an OUT was signed with, or -1.
    @Column(nullable = false)
    private long nonce;

    /// The signed transaction, hex, so a re-broadcast is the same bytes.
    @Column(nullable = false, type = "VARCHAR(4000)")
    private String raw = "";

    @Column(nullable = false)
    private long blockNumber;

    @Column(nullable = false, type = "VARCHAR(66)")
    private String blockHash = "";

    /// Network fee paid, ledger units, rounded up.
    @Column(nullable = false)
    private long fee;

    /// The CryptoAddress an OUT pays, or the DepositAddress an IN reached.
    @Column(nullable = false, type = "VARCHAR(32)")
    private String reference = "";

    /// Why it failed, for the customer and the back office.
    @Column(nullable = false, type = "VARCHAR(200)")
    private String detail = "";

    @Column(nullable = false)
    private Instant broadcastAt = Instant.EPOCH;

    @Column(nullable = false)
    private Instant createdAt = Instant.EPOCH;

    @Column(nullable = false)
    private Instant updatedAt = Instant.EPOCH;

    public ChainTransfer() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAsset() {
        return asset;
    }

    public void setAsset(String asset) {
        this.asset = asset;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTxHash() {
        return txHash;
    }

    public void setTxHash(String txHash) {
        this.txHash = txHash;
    }

    public int getLogIndex() {
        return logIndex;
    }

    public void setLogIndex(int logIndex) {
        this.logIndex = logIndex;
    }

    public long getNonce() {
        return nonce;
    }

    public void setNonce(long nonce) {
        this.nonce = nonce;
    }

    public String getRaw() {
        return raw;
    }

    public void setRaw(String raw) {
        this.raw = raw;
    }

    public long getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(long blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getBlockHash() {
        return blockHash;
    }

    public void setBlockHash(String blockHash) {
        this.blockHash = blockHash;
    }

    public long getFee() {
        return fee;
    }

    public void setFee(long fee) {
        this.fee = fee;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Instant getBroadcastAt() {
        return broadcastAt;
    }

    public void setBroadcastAt(Instant broadcastAt) {
        this.broadcastAt = broadcastAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }
}
