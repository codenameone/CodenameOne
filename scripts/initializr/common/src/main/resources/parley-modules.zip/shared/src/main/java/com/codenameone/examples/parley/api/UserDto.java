package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Who is signed in, as the app needs to know it: enough to greet them, to
/// decide whether to offer the admin console, and to tell whether they still
/// owe a phone verification.
///
/// @param username The sign-in name, the e-mail address the account was opened with.
/// @param displayName The name other people see.
/// @param phone The phone number, as entered.
/// @param phoneVerified The phone number was confirmed with a code.
/// @param admin Granted: the account may run the service.
/// @param suspended An admin blocked the account.
/// @param flagged An admin marked the account for attention.
/// @param flagReason Why it was flagged, or empty.
/// @param language The language the account asked for, or empty for the device's.
/// @param about The one-line status shown under the name.
/// @param hasPhoto A profile photo was uploaded.
@Mapped
public record UserDto(
        String username,
        String displayName,
        String phone,
        boolean phoneVerified,
        boolean admin,
        boolean suspended,
        boolean flagged,
        String flagReason,
        String language,
        String about,
        boolean hasPhoto) {
}
