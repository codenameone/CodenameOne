package com.codenameone.examples.parley.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

/// Sending and receiving envelopes. The live channel pushes new envelopes as
/// they arrive; these calls are the fallback and the catch-up after a device
/// has been offline.
@RestClient
public interface MessageApi {
    @POST("/api/messages")
    void send(@Body OutgoingDto message, OnComplete<Response<SendResultDto>> callback);

    @GET("/api/messages/{device}")
    void sync(@Path("device") String device, @Query("limit") int limit,
            OnComplete<Response<SyncDto>> callback);

    @POST("/api/messages/{device}/ack")
    void ack(@Path("device") String device, @Body AckDto ack,
            OnComplete<Response<KeyCountDto>> callback);
}
