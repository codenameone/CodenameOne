package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The admin dashboard's charts.
///
/// @param days One entry per day, oldest first.
/// @param byHour Envelopes per hour of the day, UTC, 24 entries.
/// @param byKind Conversations per kind.
/// @param byPlatform Devices per platform.
/// @param flaggedUsers Accounts flagged for attention.
/// @param openReports Reports nobody has handled.
@Mapped
public record StatsSeriesDto(
        List<DayStatsDto> days,
        List<Integer> byHour,
        List<NameCountDto> byKind,
        List<NameCountDto> byPlatform,
        int flaggedUsers,
        int openReports) {
}
