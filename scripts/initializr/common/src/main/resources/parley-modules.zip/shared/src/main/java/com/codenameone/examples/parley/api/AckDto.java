package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// Envelopes the device has stored, which the server may now delete.
///
/// @param ids Envelope ids.
@Mapped
public record AckDto(
        List<String> ids) {
}
