package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// One device of one account.
///
/// @param username The account.
/// @param deviceId The device.
@Mapped
public record DeviceAddressDto(
        String username,
        String deviceId) {
}
