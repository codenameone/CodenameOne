package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// The roles an admin grants.
///
/// @param admin May run the service.
@Mapped
public record RoleChangeDto(
        boolean admin) {
}
