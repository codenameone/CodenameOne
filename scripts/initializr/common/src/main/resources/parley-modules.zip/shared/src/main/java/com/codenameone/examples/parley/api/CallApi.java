package com.codenameone.examples.parley.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Voice and video calls. The server rings the other side and relays call
/// setup; the media itself flows directly between the devices, or through
/// the TURN server when they cannot reach each other.
@RestClient
public interface CallApi {
    @POST("/api/calls")
    void start(@Body CallStartDto call, OnComplete<Response<CallDto>> callback);

    @POST("/api/calls/{id}/signal")
    void signal(@Path("id") String id, @Body CallSignalDto signal,
            OnComplete<Response<CallDto>> callback);

    @GET("/api/calls")
    void history(OnComplete<Response<List<CallDto>>> callback);

    @GET("/api/calls/ice")
    void iceServers(OnComplete<Response<IceConfigDto>> callback);
}
