package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Where an uploaded attachment can be fetched.
///
/// @param id The blob id.
/// @param size Its size in bytes.
@Mapped
public record MediaRefDto(
        String id,
        int size) {
}
