package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// One encrypted copy of a message, for one device.
///
/// @param username The recipient account.
/// @param deviceId The recipient device.
/// @param header The ratchet header, base64; opaque to the server.
/// @param ciphertext The encrypted payload, base64; opaque to the server.
@Mapped
public record EnvelopeCopyDto(
        String username,
        String deviceId,
        String header,
        String ciphertext) {
}
