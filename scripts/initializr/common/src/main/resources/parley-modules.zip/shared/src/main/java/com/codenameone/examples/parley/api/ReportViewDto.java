package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// An abuse report as the admins see it.
///
/// @param id The report id.
/// @param reporter Who reported.
/// @param subject Who was reported.
/// @param conversationId The conversation, or empty.
/// @param reason Why.
/// @param evidence What the reporter shared.
/// @param createdAt When.
/// @param status OPEN, DISMISSED or ACTIONED.
@Mapped
public record ReportViewDto(
        String id,
        String reporter,
        String subject,
        String conversationId,
        String reason,
        String evidence,
        long createdAt,
        String status) {
}
