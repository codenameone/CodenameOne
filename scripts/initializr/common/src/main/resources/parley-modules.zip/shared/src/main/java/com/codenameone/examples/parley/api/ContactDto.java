package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Another account as this one is allowed to see it.
///
/// @param username The account.
/// @param displayName Its name.
/// @param about Its status line.
/// @param hasPhoto A photo is visible to the caller.
/// @param lastSeenAt When it was last online, 0 when hidden, -1 when online now.
/// @param blocked The caller blocked it.
@Mapped
public record ContactDto(
        String username,
        String displayName,
        String about,
        boolean hasPhoto,
        long lastSeenAt,
        boolean blocked) {
}
