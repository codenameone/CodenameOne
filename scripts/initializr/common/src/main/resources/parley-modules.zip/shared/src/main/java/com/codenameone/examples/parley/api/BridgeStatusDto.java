package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Which bridges the server has credentials for.
///
/// @param telegram The Telegram bot is configured.
/// @param whatsapp The WhatsApp Cloud API is configured.
/// @param telegramBot The bot's username, for the link instructions.
@Mapped
public record BridgeStatusDto(
        boolean telegram,
        boolean whatsapp,
        String telegramBot) {
}
