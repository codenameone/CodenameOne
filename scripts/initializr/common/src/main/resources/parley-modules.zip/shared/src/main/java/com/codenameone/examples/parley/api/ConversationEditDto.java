package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// The settings of a conversation its admins change.
///
/// @param title The name.
/// @param about The description.
/// @param disappearingSeconds The timer, 0 for off.
/// @param adminsOnly Only admins may post.
@Mapped
public record ConversationEditDto(
        String title,
        String about,
        int disappearingSeconds,
        boolean adminsOnly) {
}
