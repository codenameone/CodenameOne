package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// One device of an account. Every device has its own keys and its own
/// encrypted sessions; a message is encrypted once per device that receives it.
///
/// @param id The device id, unique within the account.
/// @param name The name the user gave it, or the model.
/// @param platform ios, android, web, desktop or simulator.
/// @param createdAt When it was linked.
/// @param lastSeenAt When it last connected.
@Mapped
public record DeviceDto(
        String id,
        String name,
        String platform,
        long createdAt,
        long lastSeenAt) {
}
