package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What the admin console shows about one account.
///
/// @param user The account.
/// @param devices Its registered devices.
/// @param conversations The conversations it is a member of.
/// @param messagesSent Envelopes it sent.
/// @param reportsAgainst Reports naming it.
/// @param events What the admins did to it, newest first.
@Mapped
public record UserDetailDto(
        UserDto user,
        int devices,
        int conversations,
        int messagesSent,
        int reportsAgainst,
        List<ModerationEventDto> events) {
}
