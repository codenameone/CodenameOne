package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A slice of a chart: a name and how many.
@Mapped
public record NameCountDto(String name, int count) {
}
