package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// An encrypted attachment. The key that opens it travels inside the message,
/// so the server stores bytes it cannot read.
///
/// @param contentType Always application/octet-stream for encrypted media.
/// @param data The encrypted bytes, base64.
@Mapped
public record MediaUploadDto(
        String contentType,
        String data) {
}
