package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A one-time prekey: a P-256 public key used for at most one session setup.
///
/// @param id The key's id within its device.
/// @param publicKey The public key, base64 SubjectPublicKeyInfo.
@Mapped
public record PreKeyDto(
        int id,
        String publicKey) {
}
