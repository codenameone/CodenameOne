package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// How many one-time prekeys the server still holds for this device.
///
/// @param remaining Unused one-time prekeys.
@Mapped
public record KeyCountDto(
        int remaining) {
}
