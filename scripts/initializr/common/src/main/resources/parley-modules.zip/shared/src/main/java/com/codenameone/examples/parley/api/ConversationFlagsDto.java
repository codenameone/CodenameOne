package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// The caller's own view of a conversation.
///
/// @param muted Muted.
/// @param archived Archived.
/// @param pinned Pinned.
@Mapped
public record ConversationFlagsDto(
        boolean muted,
        boolean archived,
        boolean pinned) {
}
