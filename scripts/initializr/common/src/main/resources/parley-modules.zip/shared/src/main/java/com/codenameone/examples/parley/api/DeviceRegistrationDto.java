package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What a device publishes when it is linked to an account.
///
/// @param name The device's name.
/// @param platform ios, android, web, desktop or simulator.
/// @param identityKey The device's identity public key, base64 SubjectPublicKeyInfo. It both agrees keys and signs the signed prekey.
/// @param signedPreKey The signed prekey.
/// @param oneTimePreKeys A batch of one-time prekeys.
@Mapped
public record DeviceRegistrationDto(
        String name,
        String platform,
        String identityKey,
        SignedPreKeyDto signedPreKey,
        List<PreKeyDto> oneTimePreKeys) {
}
