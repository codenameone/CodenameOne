package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// The numbers the admin dashboard leads with. Message counts only: the
/// server never sees what a message says.
///
/// @param users Accounts.
/// @param devices Registered devices.
/// @param conversations Conversations of every kind.
/// @param groups Group conversations.
/// @param messagesToday Envelopes accepted since midnight UTC.
/// @param callsToday Calls started since midnight UTC.
/// @param openReports Abuse reports nobody has handled yet.
/// @param bridges Conversations linked to Telegram or WhatsApp.
@Mapped
public record AdminStatsDto(
        int users,
        int devices,
        int conversations,
        int groups,
        int messagesToday,
        int callsToday,
        int openReports,
        int bridges) {
}
