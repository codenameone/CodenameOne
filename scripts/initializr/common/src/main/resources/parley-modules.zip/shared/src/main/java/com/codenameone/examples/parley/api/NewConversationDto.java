package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A conversation to create.
///
/// @param kind DIRECT, GROUP or CHANNEL.
/// @param title The group's name; ignored for DIRECT.
/// @param members The usernames to add besides the caller.
@Mapped
public record NewConversationDto(
        String kind,
        String title,
        List<String> members) {
}
