package com.codenameone.examples.parley.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.DELETE;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.PUT;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.Query;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Finding other people, and the privacy controls between accounts: blocking
/// and reporting.
@RestClient
public interface ContactApi {
    @GET("/api/contacts/search")
    void search(@Query("q") String query, OnComplete<Response<List<ContactDto>>> callback);

    @GET("/api/contacts/{username}")
    void contact(@Path("username") String username, OnComplete<Response<ContactDto>> callback);

    @GET("/api/blocks")
    void blocked(OnComplete<Response<List<ContactDto>>> callback);

    @PUT("/api/blocks/{username}")
    void block(@Path("username") String username, OnComplete<Response<ContactDto>> callback);

    @DELETE("/api/blocks/{username}")
    void unblock(@Path("username") String username, OnComplete<Response<ContactDto>> callback);

    @POST("/api/reports")
    void report(@Body ReportDto report, OnComplete<Response<ReportViewDto>> callback);
}
