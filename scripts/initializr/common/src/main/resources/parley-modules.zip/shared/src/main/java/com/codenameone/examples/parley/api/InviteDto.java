package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A link that lets whoever holds it join a group.
///
/// @param code The code the link carries.
/// @param conversationId The group.
/// @param title The group's name, so a preview can show it before joining.
/// @param members How many members it has.
/// @param expiresAt When the link stops working, 0 for never.
@Mapped
public record InviteDto(
        String code,
        String conversationId,
        String title,
        int members,
        long expiresAt) {
}
