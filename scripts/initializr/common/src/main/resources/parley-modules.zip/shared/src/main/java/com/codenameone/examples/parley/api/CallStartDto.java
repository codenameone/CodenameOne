package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A call to place.
///
/// @param conversationId The direct conversation to call in.
/// @param video A video call.
@Mapped
public record CallStartDto(
        String conversationId,
        boolean video) {
}
