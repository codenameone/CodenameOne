package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A page of envelopes waiting for this device.
///
/// @param envelopes Oldest first.
/// @param more More are waiting.
@Mapped
public record SyncDto(
        List<EnvelopeDto> envelopes,
        boolean more) {
}
