package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// One day of the dashboard's chart.
///
/// @param date The day, yyyy-MM-dd in UTC.
/// @param messages Envelopes accepted.
/// @param calls Calls started.
/// @param newUsers Accounts opened.
/// @param activeUsers Accounts that sent something.
@Mapped
public record DayStatsDto(
        String date,
        int messages,
        int calls,
        int newUsers,
        int activeUsers) {
}
