package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// One STUN or TURN server.
///
/// @param urls The server's URLs.
/// @param username The TURN username, empty for STUN.
/// @param credential The TURN password, empty for STUN.
@Mapped
public record IceServerDto(
        List<String> urls,
        String username,
        String credential) {
}
