package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// The parts of an account its owner edits.
///
/// @param name The display name.
/// @param about The one-line status.
@Mapped
public record ProfileDto(
        String name,
        String about) {
}
