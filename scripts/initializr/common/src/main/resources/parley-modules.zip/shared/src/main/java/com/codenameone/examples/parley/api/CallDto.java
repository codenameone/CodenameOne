package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A call, live or in history.
///
/// @param id The call id.
/// @param conversationId The conversation.
/// @param caller Who called.
/// @param callee Who was called.
/// @param video A video call.
/// @param state RINGING, ACCEPTED, ENDED, MISSED, DECLINED or BUSY.
/// @param startedAt When it was placed.
/// @param answeredAt When it was answered, 0 if it never was.
/// @param endedAt When it ended, 0 while live.
/// @param uuid The call's UUID, which both ends report to the system call screen.
@Mapped
public record CallDto(
        String id,
        String conversationId,
        String caller,
        String callee,
        boolean video,
        String state,
        long startedAt,
        long answeredAt,
        long endedAt,
        String uuid) {
}
