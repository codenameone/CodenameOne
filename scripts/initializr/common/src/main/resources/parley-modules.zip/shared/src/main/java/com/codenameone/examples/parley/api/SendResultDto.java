package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// What the server did with an outgoing message.
///
/// @param messageId The server's id for it.
/// @param sentAt The server's timestamp, which every copy carries.
/// @param missing Devices of members the sender has no copy for; fetch their keys and retry.
/// @param stale Copies addressed to devices that no longer exist.
@Mapped
public record SendResultDto(
        String messageId,
        long sentAt,
        List<DeviceAddressDto> missing,
        List<DeviceAddressDto> stale) {
}
