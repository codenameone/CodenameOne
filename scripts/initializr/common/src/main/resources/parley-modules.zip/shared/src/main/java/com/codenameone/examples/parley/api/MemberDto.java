package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A member of a conversation.
///
/// @param username The account.
/// @param displayName Its name.
/// @param role OWNER, ADMIN or MEMBER.
@Mapped
public record MemberDto(
        String username,
        String displayName,
        String role) {
}
