package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Everything a sender needs to start an encrypted session with one device
/// without that device being online.
///
/// @param username The account.
/// @param deviceId The device.
/// @param identityKey The device's identity key, base64 SubjectPublicKeyInfo.
/// @param signedPreKey The signed prekey.
/// @param oneTimePreKey A one-time prekey, or null when they ran out.
@Mapped
public record PreKeyBundleDto(
        String username,
        String deviceId,
        String identityKey,
        SignedPreKeyDto signedPreKey,
        PreKeyDto oneTimePreKey) {
}
