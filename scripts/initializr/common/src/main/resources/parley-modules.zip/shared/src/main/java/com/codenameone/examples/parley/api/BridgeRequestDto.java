package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A conversation to link.
///
/// @param conversationId The Parley conversation.
/// @param network TELEGRAM or WHATSAPP.
/// @param externalChat The chat id or phone number on the other network.
/// @param label What to call the link.
@Mapped
public record BridgeRequestDto(
        String conversationId,
        String network,
        String externalChat,
        String label) {
}
