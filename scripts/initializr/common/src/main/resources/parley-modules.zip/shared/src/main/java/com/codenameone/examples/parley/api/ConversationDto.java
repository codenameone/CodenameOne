package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A chat: a direct conversation between two accounts, a group, or a channel
/// only its admins post to.
///
/// @param id The conversation id.
/// @param kind DIRECT, GROUP or CHANNEL.
/// @param title The group's name; for a direct chat, the other person's.
/// @param about The group's description.
/// @param members Its members.
/// @param myRole The caller's role.
/// @param muted The caller muted it.
/// @param archived The caller archived it.
/// @param pinned The caller pinned it.
/// @param disappearingSeconds The disappearing-message timer, 0 for off.
/// @param adminsOnly Only admins may post.
/// @param bridge TELEGRAM or WHATSAPP when it is bridged, else empty.
/// @param lastActivityAt When the last message arrived.
/// @param hasPhoto A group photo was set.
@Mapped
public record ConversationDto(
        String id,
        String kind,
        String title,
        String about,
        List<MemberDto> members,
        String myRole,
        boolean muted,
        boolean archived,
        boolean pinned,
        int disappearingSeconds,
        boolean adminsOnly,
        String bridge,
        long lastActivityAt,
        boolean hasPhoto) {
}
