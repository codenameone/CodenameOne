package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// One step of call setup, relayed by the server between the two devices.
/// The SDP and candidates pass through; media never does.
///
/// @param callId The call.
/// @param type OFFER, ANSWER, CANDIDATE, ACCEPT, DECLINE, HANGUP or BUSY.
/// @param payload The SDP or the candidate, or empty.
/// @param fromDevice The sending device, filled in by the server.
@Mapped
public record CallSignalDto(
        String callId,
        String type,
        String payload,
        String fromDevice) {
}
