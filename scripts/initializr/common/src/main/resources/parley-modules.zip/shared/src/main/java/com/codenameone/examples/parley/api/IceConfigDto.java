package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// The ICE servers a call may use. TURN credentials are minted per request and
/// expire, so a leaked one is short-lived.
///
/// @param servers The servers.
/// @param ttlSeconds How long the credentials last.
@Mapped
public record IceConfigDto(
        List<IceServerDto> servers,
        int ttlSeconds) {
}
