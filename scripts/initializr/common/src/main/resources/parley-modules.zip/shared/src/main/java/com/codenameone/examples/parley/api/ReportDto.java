package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// An abuse report. The reporter chooses which decrypted messages to attach;
/// the server has no other way of seeing them.
///
/// @param username The account reported.
/// @param conversationId The conversation, or empty.
/// @param reason Why.
/// @param evidence The messages the reporter chose to share, or empty.
@Mapped
public record ReportDto(
        String username,
        String conversationId,
        String reason,
        String evidence) {
}
