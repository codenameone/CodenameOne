package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Marks an account for a closer look, or clears the mark.
@Mapped
public record FlagDto(boolean flagged, String reason) {
}
