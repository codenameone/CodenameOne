package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Blocks an account, or lifts the block.
///
/// @param reason Why, for the moderation record. May be empty.
@Mapped
public record SuspendDto(boolean suspended, String reason) {
}
