package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// The medium-term prekey, signed with the device's identity key so a sender
/// can tell the server did not substitute its own.
///
/// @param id The key's id within its device.
/// @param publicKey The public key, base64 SubjectPublicKeyInfo.
/// @param signature ECDSA P-256 (SHA-256, DER) over the encoded public key, by the identity key, base64.
@Mapped
public record SignedPreKeyDto(
        int id,
        String publicKey,
        String signature) {
}
