package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A conversation linked to a chat on another network.
///
/// @param id The link id.
/// @param conversationId The Parley conversation.
/// @param network TELEGRAM or WHATSAPP.
/// @param externalChat The chat id or phone number on the other network.
/// @param label What the link is called in the UI.
/// @param createdAt When it was linked.
@Mapped
public record BridgeLinkDto(
        String id,
        String conversationId,
        String network,
        String externalChat,
        String label,
        long createdAt) {
}
