package com.codenameone.examples.parley.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

/// Encrypted attachments: photos, videos, voice notes and files.
@RestClient
public interface MediaApi {
    @POST("/api/media")
    void upload(@Body MediaUploadDto media, OnComplete<Response<MediaRefDto>> callback);

    @GET("/api/media/{id}")
    void download(@Path("id") String id, OnComplete<Response<MediaDataDto>> callback);
}
