package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

import java.util.List;

/// A refill of one-time prekeys, and optionally a rotated signed prekey.
///
/// @param signedPreKey A new signed prekey, or null to keep the old one.
/// @param oneTimePreKeys New one-time prekeys.
@Mapped
public record PreKeyUploadDto(
        SignedPreKeyDto signedPreKey,
        List<PreKeyDto> oneTimePreKeys) {
}
