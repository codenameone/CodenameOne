package com.codenameone.examples.parley.api;

import com.codename1.annotations.rest.Body;
import com.codename1.annotations.rest.DELETE;
import com.codename1.annotations.rest.GET;
import com.codename1.annotations.rest.POST;
import com.codename1.annotations.rest.Path;
import com.codename1.annotations.rest.RestClient;
import com.codename1.io.rest.Response;
import com.codename1.util.OnComplete;

import java.util.List;

/// Links between Parley conversations and chats on Telegram or WhatsApp. A
/// bridged conversation is not end-to-end encrypted: the server has to read
/// a message to pass it on.
@RestClient
public interface BridgeApi {
    @GET("/api/bridges/status")
    void status(OnComplete<Response<BridgeStatusDto>> callback);

    @GET("/api/bridges")
    void list(OnComplete<Response<List<BridgeLinkDto>>> callback);

    @POST("/api/bridges")
    void link(@Body BridgeRequestDto request, OnComplete<Response<BridgeLinkDto>> callback);

    @DELETE("/api/bridges/{id}")
    void unlink(@Path("id") String id, OnComplete<Response<BridgeLinkDto>> callback);
}
