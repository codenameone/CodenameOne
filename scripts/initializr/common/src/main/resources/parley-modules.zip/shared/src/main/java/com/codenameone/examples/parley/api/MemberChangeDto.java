package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// Add a member or change one's role.
///
/// @param username The account.
/// @param role ADMIN or MEMBER.
@Mapped
public record MemberChangeDto(
        String username,
        String role) {
}
