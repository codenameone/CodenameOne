package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A profile or group photo, JPEG or PNG.
///
/// @param contentType The image type.
/// @param data The bytes, base64.
@Mapped
public record PhotoDto(
        String contentType,
        String data) {
}
