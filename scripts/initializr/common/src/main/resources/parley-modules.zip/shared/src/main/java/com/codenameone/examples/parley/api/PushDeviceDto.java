package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// A device that can be sent push notifications, as the app registers it.
///
/// `provider` is the push service the device's token belongs to -- `fcm`,
/// `apns`, `huawei`, `wns` or `web` -- and `token` the token that service gave
/// the app. `platform` is the device's platform name, for the record only.
@Mapped
public record PushDeviceDto(String provider, String token, String platform) {
}
