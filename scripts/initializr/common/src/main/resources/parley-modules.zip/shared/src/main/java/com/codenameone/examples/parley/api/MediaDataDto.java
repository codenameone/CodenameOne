package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// An attachment's encrypted bytes.
///
/// @param id The blob id.
/// @param data The bytes, base64.
@Mapped
public record MediaDataDto(
        String id,
        String data) {
}
