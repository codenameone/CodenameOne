package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// One message as one device receives it.
///
/// @param id The envelope id, acknowledged to delete it.
/// @param messageId The message id, shared by every copy.
/// @param conversationId The conversation.
/// @param sender The sending account.
/// @param senderDevice The sending device.
/// @param kind MESSAGE, RECEIPT, TYPING, KEYS, SIGNAL or SYSTEM.
/// @param header The ratchet header, base64.
/// @param ciphertext The payload, base64; for SYSTEM and bridged messages, plain text.
/// @param sentAt The server's timestamp.
/// @param expiresAt When the disappearing timer deletes it, 0 for never.
@Mapped
public record EnvelopeDto(
        String id,
        String messageId,
        String conversationId,
        String sender,
        String senderDevice,
        String kind,
        String header,
        String ciphertext,
        long sentAt,
        long expiresAt) {
}
