package com.codenameone.examples.parley.api;

import com.codename1.annotations.Mapped;

/// What a new account is opened with.
///
/// @param email The e-mail address, which becomes the username.
/// @param password The password.
/// @param displayName The name other people see.
/// @param phone The phone number to verify.
@Mapped
public record RegisterDto(
        String email,
        String password,
        String displayName,
        String phone) {
}
