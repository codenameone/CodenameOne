package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// One encrypted copy of a message, waiting for one device to fetch it. It is
/// deleted when the device acknowledges it, or when its disappearing timer runs
/// out, whichever comes first.
@Entity
public class Envelope {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String messageId = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String conversationId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String sender = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String senderDevice = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String recipient = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String recipientDevice = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String kind = "";

    @Column(nullable = false, type = "VARCHAR(2048)")
    private String header = "";

    @Column(nullable = false)
    private byte[] payload = new byte[0];

    @Column(nullable = false)
    private long sentAt;

    @Column(nullable = false)
    private long expiresAt;

    public Envelope() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSenderDevice() {
        return senderDevice;
    }

    public void setSenderDevice(String senderDevice) {
        this.senderDevice = senderDevice;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getRecipientDevice() {
        return recipientDevice;
    }

    public void setRecipientDevice(String recipientDevice) {
        this.recipientDevice = recipientDevice;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public byte[] getPayload() {
        return payload;
    }

    public void setPayload(byte[] payload) {
        this.payload = payload;
    }

    public long getSentAt() {
        return sentAt;
    }

    public void setSentAt(long sentAt) {
        this.sentAt = sentAt;
    }

    public long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(long expiresAt) {
        this.expiresAt = expiresAt;
    }
}
