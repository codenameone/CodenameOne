package com.codenameone.examples.parley.chat;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.parley.api.MediaApiServer;
import com.codenameone.examples.parley.api.MediaDataDto;
import com.codenameone.examples.parley.api.MediaRefDto;
import com.codenameone.examples.parley.api.MediaUploadDto;

/// The server's half of `MediaApi`.
@Component
public class MediaEndpoint implements MediaApiServer {
    private final Media media;

    public MediaEndpoint(Media media) {
        this.media = media;
    }

    @Override
    public MediaRefDto upload(MediaUploadDto upload) throws Exception {
        return media.upload(Caller.name(), upload);
    }

    @Override
    public MediaDataDto download(String id) throws Exception {
        Caller.name();
        return media.download(id);
    }
}
