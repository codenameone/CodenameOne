package com.codenameone.examples.parley.bridge;

/// A network a Parley conversation can be linked to.
///
/// A bridge carries text both ways: what a Parley member writes goes out to
/// the linked chat, and what is written there comes in through the bridge's
/// webhook and is posted into the conversation. To do the first it has to
/// read the message, so a bridged conversation is not end-to-end encrypted:
/// its members' apps send it to the server in plain text, and every one of
/// them shows that it is.
public interface Bridge {
    /// The network's name, as [com.codenameone.examples.parley.api.BridgeLinkDto]
    /// carries it: `TELEGRAM` or `WHATSAPP`.
    String network();

    /// Whether the server has the credentials this bridge needs. One that is
    /// not configured cannot be linked to.
    boolean configured();

    /// Sends `text` to a chat on the network, as written by `senderName`.
    void send(String externalChat, String senderName, String text) throws Exception;
}
