package com.codenameone.examples.parley;

/// The roles an account can hold. Every account is a user; administering is
/// granted on top of that, and the app offers the admin console to an account
/// that holds it.
public final class Roles {
    /// Every account: it may chat, call and manage its own groups.
    public static final String USER = "USER";

    /// May run the service: the dashboard, accounts, reports and bridges.
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
