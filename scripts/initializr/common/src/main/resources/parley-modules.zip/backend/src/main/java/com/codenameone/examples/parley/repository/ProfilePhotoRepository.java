package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.ProfilePhoto;

/// Profile photos.
@Repository(entity = ProfilePhoto.class, key = String.class)
public interface ProfilePhotoRepository extends CrudRepository<ProfilePhoto, String> {

}
