package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.PushDevice;

import java.util.List;

/// The devices each account is sent notifications on.
@Repository(entity = PushDevice.class, key = String.class)
public interface PushDeviceRepository extends CrudRepository<PushDevice, String> {
    List<PushDevice> findByUsername(String username);

    int deleteByUsername(String username);

    int deleteByIdAndUsername(String id, String username);
}
