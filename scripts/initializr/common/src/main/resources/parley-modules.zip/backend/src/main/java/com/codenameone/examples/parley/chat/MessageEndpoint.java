package com.codenameone.examples.parley.chat;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.parley.Caller;
import com.codenameone.examples.parley.api.AckDto;
import com.codenameone.examples.parley.api.KeyCountDto;
import com.codenameone.examples.parley.api.MessageApiServer;
import com.codenameone.examples.parley.api.OutgoingDto;
import com.codenameone.examples.parley.api.SendResultDto;
import com.codenameone.examples.parley.api.SyncDto;

/// The server's half of `MessageApi`.
@Component
public class MessageEndpoint implements MessageApiServer {
    private final Messages messages;

    public MessageEndpoint(Messages messages) {
        this.messages = messages;
    }

    @Override
    public SendResultDto send(OutgoingDto message) throws Exception {
        return messages.send(Caller.name(), message);
    }

    @Override
    public SyncDto sync(String device, int limit) throws Exception {
        return messages.sync(Caller.name(), device, limit);
    }

    @Override
    public KeyCountDto ack(String device, AckDto ack) throws Exception {
        return messages.ack(Caller.name(), device, ack);
    }
}
