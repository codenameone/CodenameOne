package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A direct chat, a group or a channel.
@Entity
public class Conversation {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String kind = "";

    @Column(nullable = false, type = "VARCHAR(120)")
    private String title = "";

    @Column(nullable = false, type = "VARCHAR(255)")
    private String about = "";

    @Column(nullable = false)
    private int disappearingSeconds;

    @Column(nullable = false)
    private boolean adminsOnly;

    @Column(nullable = false)
    private boolean hasPhoto;

    @Column(nullable = false, type = "VARCHAR(190)")
    private String createdBy = "";

    @Column(nullable = false)
    private long createdAt;

    @Column(nullable = false)
    private long lastActivityAt;

    @Column(nullable = false, type = "VARCHAR(400)")
    private String directKey = "";

    public Conversation() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public int getDisappearingSeconds() {
        return disappearingSeconds;
    }

    public void setDisappearingSeconds(int disappearingSeconds) {
        this.disappearingSeconds = disappearingSeconds;
    }

    public boolean isAdminsOnly() {
        return adminsOnly;
    }

    public void setAdminsOnly(boolean adminsOnly) {
        this.adminsOnly = adminsOnly;
    }

    public boolean isHasPhoto() {
        return hasPhoto;
    }

    public void setHasPhoto(boolean hasPhoto) {
        this.hasPhoto = hasPhoto;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getLastActivityAt() {
        return lastActivityAt;
    }

    public void setLastActivityAt(long lastActivityAt) {
        this.lastActivityAt = lastActivityAt;
    }

    public String getDirectKey() {
        return directKey;
    }

    public void setDirectKey(String directKey) {
        this.directKey = directKey;
    }
}
