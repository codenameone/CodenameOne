package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.Envelope;

import java.util.List;

/// Envelopes waiting for their device.
@Repository(entity = Envelope.class, key = String.class)
public interface EnvelopeRepository extends CrudRepository<Envelope, String> {
    /// The oldest envelopes waiting for a device, a page at a time.
    List<Envelope> findTop100ByRecipientDeviceOrderBySentAtAscIdAsc(String recipientDevice);

    long countByRecipientDevice(String recipientDevice);

    Envelope findByIdAndRecipientDevice(String id, String recipientDevice);

    int deleteByIdAndRecipientDevice(String id, String recipientDevice);

    int deleteByRecipientDevice(String recipientDevice);

    int deleteByRecipient(String recipient);

    /// Removes what the disappearing timer has run out on.
    @Modifying
    @Query("delete from Envelope e where e.expiresAt > 0 and e.expiresAt <= :now")
    int expire(@Param("now") long now);

    /// Removes what nobody fetched for a month: the device is gone or lost.
    int deleteBySentAtLessThan(long before);
}
