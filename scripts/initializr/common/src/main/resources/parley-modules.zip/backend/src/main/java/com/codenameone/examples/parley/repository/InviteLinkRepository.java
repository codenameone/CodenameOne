package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.InviteLink;

import java.util.List;

/// Group invite links.
@Repository(entity = InviteLink.class, key = String.class)
public interface InviteLinkRepository extends CrudRepository<InviteLink, String> {
    List<InviteLink> findByConversationId(String conversationId);

    int deleteByConversationId(String conversationId);
}
