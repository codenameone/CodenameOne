package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.ConversationPhoto;

/// Group photos.
@Repository(entity = ConversationPhoto.class, key = String.class)
public interface ConversationPhotoRepository extends CrudRepository<ConversationPhoto, String> {

}
