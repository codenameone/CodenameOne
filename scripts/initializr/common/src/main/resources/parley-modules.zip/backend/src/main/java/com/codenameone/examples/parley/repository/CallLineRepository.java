package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.CallLine;

/// Who is on which call.
@Repository(entity = CallLine.class, key = String.class)
public interface CallLineRepository extends CrudRepository<CallLine, String> {
    int deleteByCallId(String callId);
}
