package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// What the caller sent before anyone answered: the offer and the caller's
/// first ICE candidates. A callee whose phone was asleep gets the ring by push
/// and connects afterwards, when those signals have long gone by on the live
/// channel, so they are kept here and replayed to the device that accepts.
@Entity
public class CallSetup {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false)
    private String offer = "";

    /// The candidates, one signal payload per line.
    @Column(nullable = false)
    private String candidates = "";

    public CallSetup() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOffer() {
        return offer;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }

    public String getCandidates() {
        return candidates;
    }

    public void setCandidates(String candidates) {
        this.candidates = candidates;
    }
}
