package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A voice or video call, from ringing to hang-up.
@Entity
public class CallRecord {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String conversationId = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String caller = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String callerDevice = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String callee = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String calleeDevice = "";

    @Column(nullable = false)
    private boolean video;

    @Column(nullable = false, type = "VARCHAR(16)")
    private String state = "";

    @Column(nullable = false)
    private long startedAt;

    @Column(nullable = false)
    private long answeredAt;

    @Column(nullable = false)
    private long endedAt;

    public CallRecord() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getCaller() {
        return caller;
    }

    public void setCaller(String caller) {
        this.caller = caller;
    }

    public String getCallerDevice() {
        return callerDevice;
    }

    public void setCallerDevice(String callerDevice) {
        this.callerDevice = callerDevice;
    }

    public String getCallee() {
        return callee;
    }

    public void setCallee(String callee) {
        this.callee = callee;
    }

    public String getCalleeDevice() {
        return calleeDevice;
    }

    public void setCalleeDevice(String calleeDevice) {
        this.calleeDevice = calleeDevice;
    }

    public boolean isVideo() {
        return video;
    }

    public void setVideo(boolean video) {
        this.video = video;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public long getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(long startedAt) {
        this.startedAt = startedAt;
    }

    public long getAnsweredAt() {
        return answeredAt;
    }

    public void setAnsweredAt(long answeredAt) {
        this.answeredAt = answeredAt;
    }

    public long getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(long endedAt) {
        this.endedAt = endedAt;
    }
}
