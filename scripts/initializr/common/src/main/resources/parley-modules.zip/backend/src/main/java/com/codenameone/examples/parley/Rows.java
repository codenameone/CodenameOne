package com.codenameone.examples.parley;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

/// Reading the rows a repository answers for a select of several values,
/// `select d.platform, count(d) ...`, which come back as `Object[]`.
///
/// What a column holds is checked and never cast blindly: a count is a `Long`
/// on one database and an `Integer` on another, and a name is read as text
/// whatever type the column came back as.
public final class Rows {
    private Rows() {
    }

    /// A column as a whole number; 0 for null or anything that is not a
    /// number.
    public static long number(Object value) {
        return value instanceof Number ? ((Number) value).longValue() : 0L;
    }

    /// A column as text; empty for null.
    public static String text(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    /// Rows of `{name, count}` as a map from the name to the count.
    public static Map<String, Long> counts(List<Object[]> rows) {
        Map<String, Long> out = new HashMap<String, Long>();
        for (int iter = 0; iter < rows.size(); iter++) {
            Object[] row = rows.get(iter);
            out.put(text(row[0]), Long.valueOf(number(row[1])));
        }
        return out;
    }

    /// A single number a repository answers, which is null for a sum or a
    /// maximum of no rows.
    public static long number(Long value) {
        return value == null ? 0L : value.longValue();
    }
}
