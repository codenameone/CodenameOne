package com.codenameone.examples.parley.contact;

import com.codename1.backend.annotations.Component;
import com.codename1.appkit.server.Caller;
import com.codenameone.examples.parley.api.ContactApiServer;
import com.codenameone.examples.parley.api.ContactDto;
import com.codenameone.examples.parley.api.ReportDto;
import com.codenameone.examples.parley.api.ReportViewDto;

import java.util.List;

/// The server's half of `ContactApi`.
@Component
public class ContactEndpoint implements ContactApiServer {
    private final Contacts contacts;

    public ContactEndpoint(Contacts contacts) {
        this.contacts = contacts;
    }

    @Override
    public List<ContactDto> search(String query) throws Exception {
        return contacts.search(Caller.name(), query);
    }

    @Override
    public ContactDto contact(String username) throws Exception {
        return contacts.contact(Caller.name(), username);
    }

    @Override
    public List<ContactDto> blocked() throws Exception {
        return contacts.blocked(Caller.name());
    }

    @Override
    public ContactDto block(String username) throws Exception {
        return contacts.block(Caller.name(), username);
    }

    @Override
    public ContactDto unblock(String username) throws Exception {
        return contacts.unblock(Caller.name(), username);
    }

    @Override
    public ReportViewDto report(ReportDto report) throws Exception {
        return contacts.report(Caller.name(), report);
    }
}
