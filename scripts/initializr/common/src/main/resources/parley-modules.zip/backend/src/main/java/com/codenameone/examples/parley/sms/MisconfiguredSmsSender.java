package com.codenameone.examples.parley.sms;

import java.io.IOException;

/// What the server sends with when the SMS settings are incomplete: every
/// message fails, and says why.
///
/// The problem is logged once when the server starts and again on every send,
/// naming the settings that are missing, so it is in front of whoever reads the
/// log at either moment. The failure is an `IOException` like any provider
/// outage, which the phone verification answers with 503: a server whose SMS
/// settings were forgotten verifies nobody, rather than everybody.
public class MisconfiguredSmsSender implements SmsSender {
    private final String problem;

    /// @param problem what is wrong, naming the settings to fix
    public MisconfiguredSmsSender(String problem) {
        this.problem = problem;
        System.err.println("[config] " + problem);
    }

    @Override
    public void send(String phone, String text) throws IOException {
        System.err.println("[config] a text message was not sent: " + problem);
        throw new IOException(problem);
    }

    /// True, because it stands in for a provider that would: the demo code a
    /// development server hands back is only for the console sender.
    @Override
    public boolean delivers() {
        return true;
    }
}
