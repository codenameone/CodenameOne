package com.codenameone.examples.parley.bridge;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.parley.Caller;
import com.codenameone.examples.parley.api.BridgeApiServer;
import com.codenameone.examples.parley.api.BridgeLinkDto;
import com.codenameone.examples.parley.api.BridgeRequestDto;
import com.codenameone.examples.parley.api.BridgeStatusDto;

import java.util.List;

/// The members' side of bridges: what can be linked, and linking it.
@Component
public class BridgeEndpoint implements BridgeApiServer {
    private final Bridges bridges;

    public BridgeEndpoint(Bridges bridges) {
        this.bridges = bridges;
    }

    @Override
    public BridgeStatusDto status() throws Exception {
        return bridges.status();
    }

    @Override
    public List<BridgeLinkDto> list() throws Exception {
        return bridges.list(Caller.name());
    }

    @Override
    public BridgeLinkDto link(BridgeRequestDto request) throws Exception {
        return bridges.link(Caller.name(), request);
    }

    @Override
    public BridgeLinkDto unlink(String id) throws Exception {
        return bridges.unlink(Caller.name(), id);
    }
}
