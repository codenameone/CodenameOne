package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.ContactBlock;

import java.util.List;

/// Who blocked whom.
@Repository(entity = ContactBlock.class, key = String.class)
public interface ContactBlockRepository extends CrudRepository<ContactBlock, String> {
    List<ContactBlock> findByBlocker(String blocker);

    int deleteByBlocker(String blocker);

    int deleteByBlocked(String blocked);
}
