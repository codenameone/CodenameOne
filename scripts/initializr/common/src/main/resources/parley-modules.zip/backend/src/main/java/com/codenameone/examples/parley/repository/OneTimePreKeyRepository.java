package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.OneTimePreKey;

/// One-time prekeys waiting to be handed out.
@Repository(entity = OneTimePreKey.class, key = String.class)
public interface OneTimePreKeyRepository extends CrudRepository<OneTimePreKey, String> {
    /// The device's oldest-uploaded key, the next to hand out.
    OneTimePreKey findFirstByDeviceIdOrderByKeyIdAsc(String deviceId);

    long countByDeviceId(String deviceId);

    int deleteByDeviceId(String deviceId);
}
