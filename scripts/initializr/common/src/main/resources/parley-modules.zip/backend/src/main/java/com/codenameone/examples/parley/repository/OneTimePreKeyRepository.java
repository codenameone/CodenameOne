package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Modifying;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.OneTimePreKey;

/// One-time prekeys waiting to be handed out.
@Repository(entity = OneTimePreKey.class, key = String.class)
public interface OneTimePreKeyRepository extends CrudRepository<OneTimePreKey, String> {
    /// The device's oldest-uploaded key, the next to hand out.
    OneTimePreKey findFirstByDeviceIdOrderByKeyIdAsc(String deviceId);

    long countByDeviceId(String deviceId);

    int deleteByDeviceId(String deviceId);

    /// Deletes one key, answering how many rows went: 0 means another
    /// request claimed it first.
    @Modifying
    @Query("delete from OneTimePreKey k where k.id = :id")
    int claim(@Param("id") String id);
}
