package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.MediaBlob;
import java.time.Instant;

/// Encrypted attachments.
@Repository(entity = MediaBlob.class, key = String.class)
public interface MediaBlobRepository extends CrudRepository<MediaBlob, String> {
    int deleteByOwner(String owner);

    int deleteByCreatedAtLessThan(Instant before);

    @Query("select coalesce(sum(m.size), 0) from MediaBlob m where m.owner = :owner and m.createdAt >= :since")
    Long storedSince(@Param("owner") String owner, @Param("since") Instant since);
}
