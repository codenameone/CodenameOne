package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.MediaBlob;

/// Encrypted attachments.
@Repository(entity = MediaBlob.class, key = String.class)
public interface MediaBlobRepository extends CrudRepository<MediaBlob, String> {
    int deleteByOwner(String owner);

    int deleteByCreatedAtLessThan(long before);
}
