package com.codenameone.examples.parley.call;

import com.codename1.backend.annotations.Component;
import com.codenameone.examples.parley.Caller;
import com.codenameone.examples.parley.api.CallApiServer;
import com.codenameone.examples.parley.api.CallDto;
import com.codenameone.examples.parley.api.CallSignalDto;
import com.codenameone.examples.parley.api.CallStartDto;
import com.codenameone.examples.parley.api.IceConfigDto;

import java.util.List;

@Component
public class CallEndpoint implements CallApiServer {
    private final Calls calls;

    public CallEndpoint(Calls calls) {
        this.calls = calls;
    }

    @Override
    public CallDto start(CallStartDto call) throws Exception {
        return calls.start(Caller.name(), call);
    }

    @Override
    public CallDto signal(String id, CallSignalDto signal) throws Exception {
        return calls.signal(Caller.name(), id, signal);
    }

    @Override
    public List<CallDto> history() throws Exception {
        return calls.history(Caller.name());
    }

    @Override
    public IceConfigDto iceServers() throws Exception {
        return calls.ice(Caller.name());
    }
}
