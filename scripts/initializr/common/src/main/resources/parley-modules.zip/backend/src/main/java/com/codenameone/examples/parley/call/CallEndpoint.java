package com.codenameone.examples.parley.call;

import com.codename1.backend.ResponseStatusException;
import com.codename1.backend.annotations.Component;
import com.codenameone.examples.parley.Caller;
import com.codenameone.examples.parley.api.CallApiServer;
import com.codenameone.examples.parley.api.CallDto;
import com.codenameone.examples.parley.api.CallSignalDto;
import com.codenameone.examples.parley.api.CallStartDto;
import com.codenameone.examples.parley.api.IceConfigDto;

import java.util.List;

@Component
public class CallEndpoint implements CallApiServer {
    private final Calls calls;

    public CallEndpoint(Calls calls) {
        this.calls = calls;
    }

    @Override
    public CallDto start(CallStartDto call) throws Exception {
        String username = Caller.name();
        CallDto started;
        try {
            started = calls.start(username, call, false);
        } catch (ResponseStatusException refused) {
            throw refused;
        } catch (RuntimeException lostTheLine) {
            // Another caller claimed the callee's line in the same moment;
            // the unique key on call_line rejected this commit. To the caller
            // that is a busy line, not a server error.
            return calls.start(username, call, true);
        }
        calls.ring(started);
        return started;
    }

    @Override
    public CallDto signal(String id, CallSignalDto signal) throws Exception {
        return calls.signal(Caller.name(), id, signal);
    }

    @Override
    public List<CallDto> history() throws Exception {
        return calls.history(Caller.name());
    }

    @Override
    public IceConfigDto iceServers() throws Exception {
        return calls.ice(Caller.name());
    }
}
