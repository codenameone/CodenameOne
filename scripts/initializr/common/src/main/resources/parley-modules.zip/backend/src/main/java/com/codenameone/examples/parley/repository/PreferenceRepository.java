package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.Preference;

/// An account's preferences, keyed by its name. An account that never saved any
/// has no row.
@Repository(entity = Preference.class, key = String.class)
public interface PreferenceRepository extends CrudRepository<Preference, String> {
    int deleteByUsername(String username);
}
