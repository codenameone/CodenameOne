package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// The call a person is on. The key is the username, so the database itself
/// refuses a second live call for anyone: two callers ringing the same callee
/// at once cannot both get through, whatever order their transactions run in.
@Entity
public class CallLine {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(190)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String callId = "";

    public CallLine() {
    }

    public CallLine(String username, String callId) {
        this.id = username;
        this.callId = callId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCallId() {
        return callId;
    }

    public void setCallId(String callId) {
        this.callId = callId;
    }
}
