package com.codenameone.examples.parley.bridge;

import com.codename1.backend.Crypto;

import java.nio.charset.StandardCharsets;

/// The comparisons the webhooks prove themselves with, all in constant time:
/// a comparison that stops at the first wrong byte tells whoever is guessing
/// how many they had right.
final class Signatures {
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private Signatures() {
    }

    /// Whether `given` is `expected`, with neither one's length or content
    /// leaking through the time taken.
    static boolean same(String expected, String given) {
        if (expected == null || expected.length() == 0 || given == null) {
            return false;
        }
        return Crypto.equalsConstantTime(expected.getBytes(StandardCharsets.UTF_8),
                given.getBytes(StandardCharsets.UTF_8));
    }

    /// `HMAC-SHA256(key, body)` as lower-case hex.
    static String hmacHex(String key, byte[] body) {
        byte[] mac = Crypto.hmacSha256(key.getBytes(StandardCharsets.UTF_8), body);
        char[] out = new char[mac.length * 2];
        for (int iter = 0; iter < mac.length; iter++) {
            out[iter * 2] = HEX[(mac[iter] >> 4) & 15];
            out[iter * 2 + 1] = HEX[mac[iter] & 15];
        }
        return new String(out);
    }
}
