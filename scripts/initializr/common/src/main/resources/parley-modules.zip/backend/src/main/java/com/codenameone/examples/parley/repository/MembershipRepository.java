package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.Membership;

import java.util.List;

/// Who is in which conversation.
@Repository(entity = Membership.class, key = String.class)
public interface MembershipRepository extends CrudRepository<Membership, String> {
    List<Membership> findByConversationId(String conversationId);

    List<Membership> findByUsername(String username);

    Membership findByConversationIdAndUsername(String conversationId, String username);

    long countByConversationId(String conversationId);

    long countByUsername(String username);

    long countByConversationIdAndRole(String conversationId, String role);

    int deleteByConversationId(String conversationId);

    int deleteByUsername(String username);

    List<Membership> findByConversationIdIn(List<String> conversationIds);
}
