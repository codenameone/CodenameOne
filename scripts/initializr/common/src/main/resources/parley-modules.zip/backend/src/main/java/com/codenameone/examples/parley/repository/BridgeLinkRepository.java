package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.BridgeLink;

import java.util.List;

/// Conversations linked to Telegram or WhatsApp.
@Repository(entity = BridgeLink.class, key = String.class)
public interface BridgeLinkRepository extends CrudRepository<BridgeLink, String> {
    List<BridgeLink> findByConversationId(String conversationId);

    BridgeLink findByNetworkAndExternalChat(String network, String externalChat);

    @Query("select b from BridgeLink b order by b.createdAt desc")
    List<BridgeLink> newestFirst();

    int deleteByConversationId(String conversationId);
}
