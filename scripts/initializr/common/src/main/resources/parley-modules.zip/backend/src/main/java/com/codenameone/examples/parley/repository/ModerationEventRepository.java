package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.ModerationEvent;

import java.util.List;

/// The record of what the admins did to each account.
@Repository(entity = ModerationEvent.class, key = String.class)
public interface ModerationEventRepository extends CrudRepository<ModerationEvent, String> {
    /// When the newest event of an account was written, or null when it has
    /// none.
    @Query("select max(e.createdAt) from ModerationEvent e where e.username = :username")
    Long newest(@Param("username") String username);

    /// An account's last hundred events, newest first.
    List<ModerationEvent> findTop100ByUsernameOrderByCreatedAtDescIdAsc(String username);

    int deleteByUsername(String username);
}
