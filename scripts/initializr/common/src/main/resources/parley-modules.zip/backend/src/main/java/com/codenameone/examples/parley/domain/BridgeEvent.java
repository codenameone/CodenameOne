package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A webhook event already posted, keyed by the network and its own id for
/// the event. Telegram and WhatsApp retry a delivery whose answer they did
/// not see; the key is what makes the retry a no-op.
@Entity
public class BridgeEvent {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String id = "";

    @Column(nullable = false)
    private long receivedAt;

    public BridgeEvent() {
    }

    public BridgeEvent(String id, long receivedAt) {
        this.id = id;
        this.receivedAt = receivedAt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(long receivedAt) {
        this.receivedAt = receivedAt;
    }
}
