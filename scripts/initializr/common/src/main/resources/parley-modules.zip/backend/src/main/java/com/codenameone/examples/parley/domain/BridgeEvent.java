package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;
import java.time.Instant;

/// A webhook event already posted, keyed by the network and its own id for
/// the event. Telegram and WhatsApp retry a delivery whose answer they did
/// not see; the key is what makes the retry a no-op.
@Entity
public class BridgeEvent {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(240)")
    private String id = "";

    @Column(nullable = false)
    private Instant receivedAt = Instant.EPOCH;

    public BridgeEvent() {
    }

    public BridgeEvent(String id, Instant receivedAt) {
        this.id = id;
        this.receivedAt = receivedAt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Instant getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(Instant receivedAt) {
        this.receivedAt = receivedAt;
    }
}
