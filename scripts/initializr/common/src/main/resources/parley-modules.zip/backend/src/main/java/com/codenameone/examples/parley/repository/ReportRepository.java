package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.Report;

import java.util.List;

/// Abuse reports.
@Repository(entity = Report.class, key = String.class)
public interface ReportRepository extends CrudRepository<Report, String> {
    List<Report> findByStatusOrderByCreatedAtDesc(String status);

    @Query("select r from Report r order by r.createdAt desc")
    List<Report> newestFirst();

    long countByStatus(String status);

    long countBySubject(String subject);

    int deleteByReporter(String reporter);
}
