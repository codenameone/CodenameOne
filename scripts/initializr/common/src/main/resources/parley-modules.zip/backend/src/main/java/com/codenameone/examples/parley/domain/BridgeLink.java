package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A Parley conversation linked to a chat on Telegram or WhatsApp.
@Entity
public class BridgeLink {
    @Id(autoIncrement = false)
    @Column(nullable = false, type = "VARCHAR(32)")
    private String id = "";

    @Column(nullable = false, type = "VARCHAR(32)")
    private String conversationId = "";

    @Column(nullable = false, type = "VARCHAR(16)")
    private String network = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String externalChat = "";

    @Column(nullable = false, type = "VARCHAR(120)")
    private String label = "";

    @Column(nullable = false, type = "VARCHAR(190)")
    private String createdBy = "";

    @Column(nullable = false)
    private long createdAt;

    public BridgeLink() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public String getExternalChat() {
        return externalChat;
    }

    public void setExternalChat(String externalChat) {
        this.externalChat = externalChat;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}
