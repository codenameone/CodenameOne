package com.codenameone.examples.parley.domain;

import com.codename1.annotations.Column;
import com.codename1.annotations.Entity;
import com.codename1.annotations.Id;

/// A code that lets whoever holds it join a group.
@Entity
public class InviteLink {
    @Id(autoIncrement = false)
    @Column(nullable = false)
    private String code = "";

    @Column(nullable = false)
    private String conversationId = "";

    @Column(nullable = false)
    private String createdBy = "";

    @Column(nullable = false)
    private long createdAt;

    @Column(nullable = false)
    private long expiresAt;

    public InviteLink() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(long expiresAt) {
        this.expiresAt = expiresAt;
    }
}
