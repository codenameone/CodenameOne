package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.CallSetup;

/// The setup of calls still ringing.
@Repository(entity = CallSetup.class, key = String.class)
public interface CallSetupRepository extends CrudRepository<CallSetup, String> {
}
