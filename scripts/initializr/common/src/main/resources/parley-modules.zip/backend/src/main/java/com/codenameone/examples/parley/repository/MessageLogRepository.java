package com.codenameone.examples.parley.repository;

import com.codename1.orm.repository.CrudRepository;
import com.codename1.orm.repository.Param;
import com.codename1.orm.repository.Query;
import com.codename1.orm.repository.Repository;
import com.codenameone.examples.parley.domain.MessageLog;

import java.time.Instant;
import java.util.List;

/// That messages were sent, never what they said.
@Repository(entity = MessageLog.class, key = String.class)
public interface MessageLogRepository extends CrudRepository<MessageLog, String> {
    long countBySentAtGreaterThanEqual(Instant since);

    long countBySender(String sender);

    @Query("select m.sentAt, m.sender from MessageLog m where m.sentAt >= :since and m.kind = 'MESSAGE'")
    List<Object[]> since(@Param("since") Instant since);

    int deleteBySender(String sender);

    int deleteBySentAtLessThan(Instant before);
}
