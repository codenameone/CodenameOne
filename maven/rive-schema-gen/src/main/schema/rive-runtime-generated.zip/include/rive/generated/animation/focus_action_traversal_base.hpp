#ifndef _RIVE_FOCUS_ACTION_TRAVERSAL_BASE_HPP_
#define _RIVE_FOCUS_ACTION_TRAVERSAL_BASE_HPP_
#include "rive/animation/focus_action.hpp"
#include "rive/core/field_types/core_uint_type.hpp"
namespace rive
{
class FocusActionTraversalBase : public FocusAction
{
protected:
  typedef FocusAction Super;

public:
  static const uint16_t typeKey = 672;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t traversalKindPropertyKey = 1011;

protected:
  uint32_t m_TraversalKind = 0;

public:
  inline uint32_t traversalKind() const { return m_TraversalKind; }
  void traversalKind(uint32_t value)
  {
    if (m_TraversalKind == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(traversalKindPropertyKey, &m_TraversalKind, &value);
    m_TraversalKind = value;
    notifyPropertyChanged(traversalKindPropertyKey);
  }

  Core* clone() const override;
  void copy(const FocusActionTraversalBase& object)
  {
    m_TraversalKind = object.m_TraversalKind;
    FocusAction::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case traversalKindPropertyKey:
        m_TraversalKind = CoreUintType::deserialize(reader);
        return true;
    }
    return FocusAction::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/focus_action_traversal_ext.inl"
#endif
};
} // namespace rive

#endif