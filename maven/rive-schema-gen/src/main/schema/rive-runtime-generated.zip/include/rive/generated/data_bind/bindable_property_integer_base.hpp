#ifndef _RIVE_BINDABLE_PROPERTY_INTEGER_BASE_HPP_
#define _RIVE_BINDABLE_PROPERTY_INTEGER_BASE_HPP_
#include "rive/core/field_types/core_uint_type.hpp"
#include "rive/data_bind/bindable_property.hpp"
namespace rive
{
class BindablePropertyIntegerBase : public BindableProperty
{
protected:
  typedef BindableProperty Super;

public:
  static const uint16_t typeKey = 567;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t propertyValuePropertyKey = 686;

protected:
  uint32_t m_PropertyValue = 0;

public:
  inline uint32_t propertyValue() const { return m_PropertyValue; }
  void propertyValue(uint32_t value)
  {
    if (m_PropertyValue == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(propertyValuePropertyKey, &m_PropertyValue, &value);
    m_PropertyValue = value;
    RIVE_EDITOR_CHANGED(propertyValueChanged());
    notifyPropertyChanged(propertyValuePropertyKey);
  }

  Core* clone() const override;
  void copy(const BindablePropertyIntegerBase& object)
  {
    m_PropertyValue = object.m_PropertyValue;
    BindableProperty::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case propertyValuePropertyKey:
        m_PropertyValue = CoreUintType::deserialize(reader);
        return true;
    }
    return BindableProperty::deserialize(propertyKey, reader);
  }

protected:
  virtual void propertyValueChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/data_bind/bindable_property_integer_ext.inl"
#endif
};
} // namespace rive

#endif