#ifndef _RIVE_STATE_MACHINE_FIRE_TRIGGER_BASE_HPP_
#define _RIVE_STATE_MACHINE_FIRE_TRIGGER_BASE_HPP_
#include "rive/animation/state_machine_fire_action.hpp"
#include "rive/core/field_types/core_bytes_type.hpp"
#include "rive/span.hpp"
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/editor_field_types.hpp"
#endif
namespace rive
{
class StateMachineFireTriggerBase : public StateMachineFireAction
{
protected:
  typedef StateMachineFireAction Super;

public:
  static const uint16_t typeKey = 614;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t viewModelPathIdsPropertyKey = 871;

public:
  virtual void decodeViewModelPathIds(Span<const uint8_t> value) = 0;
  virtual void copyViewModelPathIds(
      const StateMachineFireTriggerBase& object) = 0;

  Core* clone() const override;
  void copy(const StateMachineFireTriggerBase& object)
  {
    copyViewModelPathIds(object);
    RIVE_EDITOR_COPY(object);
    StateMachineFireAction::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case viewModelPathIdsPropertyKey:
        decodeViewModelPathIds(CoreBytesType::deserialize(reader));
        return true;
    }
    RIVE_EDITOR_DESERIALIZE(propertyKey, reader);
    return StateMachineFireAction::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/state_machine_fire_trigger_ext.inl"
#endif
};
} // namespace rive

#endif