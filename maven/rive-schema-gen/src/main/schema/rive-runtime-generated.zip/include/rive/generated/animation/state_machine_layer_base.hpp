#ifndef _RIVE_STATE_MACHINE_LAYER_BASE_HPP_
#define _RIVE_STATE_MACHINE_LAYER_BASE_HPP_
#include "rive/animation/state_machine_component.hpp"
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/editor_field_types.hpp"
#endif
namespace rive
{
class StateMachineLayerBase : public StateMachineComponent
{
protected:
  typedef StateMachineComponent Super;

public:
  static const uint16_t typeKey = 57;

  uint16_t coreType() const override { return typeKey; }

public:
  Core* clone() const override;
  void copy(const StateMachineLayerBase& object)
  {
    RIVE_EDITOR_COPY(object);
    StateMachineComponent::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    RIVE_EDITOR_DESERIALIZE(propertyKey, reader);
    return StateMachineComponent::deserialize(propertyKey, reader);
  }
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/state_machine_layer_ext.inl"
#endif
};
} // namespace rive

#endif