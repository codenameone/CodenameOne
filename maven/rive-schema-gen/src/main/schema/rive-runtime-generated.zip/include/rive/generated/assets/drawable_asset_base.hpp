#ifndef _RIVE_DRAWABLE_ASSET_BASE_HPP_
#define _RIVE_DRAWABLE_ASSET_BASE_HPP_
#include "rive/assets/file_asset.hpp"
#include "rive/core/field_types/core_double_type.hpp"
namespace rive
{
class DrawableAssetBase : public FileAsset
{
protected:
  typedef FileAsset Super;

public:
  static const uint16_t typeKey = 104;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t heightPropertyKey = 207;
  static const uint16_t widthPropertyKey = 208;

protected:
  float m_Height = 0.0f;
  float m_Width = 0.0f;

public:
  inline float height() const { return m_Height; }
  void height(float value)
  {
    if (m_Height == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(heightPropertyKey, &m_Height, &value);
    m_Height = value;
    RIVE_EDITOR_CHANGED(heightChanged());
    notifyPropertyChanged(heightPropertyKey);
  }

  inline float width() const { return m_Width; }
  void width(float value)
  {
    if (m_Width == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(widthPropertyKey, &m_Width, &value);
    m_Width = value;
    RIVE_EDITOR_CHANGED(widthChanged());
    notifyPropertyChanged(widthPropertyKey);
  }

  void copy(const DrawableAssetBase& object)
  {
    m_Height = object.m_Height;
    m_Width = object.m_Width;
    FileAsset::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case heightPropertyKey:
        m_Height = CoreDoubleType::deserialize(reader);
        return true;
      case widthPropertyKey:
        m_Width = CoreDoubleType::deserialize(reader);
        return true;
    }
    return FileAsset::deserialize(propertyKey, reader);
  }

protected:
  virtual void heightChanged() {}
  virtual void widthChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/assets/drawable_asset_ext.inl"
#endif
};
} // namespace rive

#endif