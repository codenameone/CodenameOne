#ifndef _RIVE_DATA_ENUM_VALUE_BASE_HPP_
#define _RIVE_DATA_ENUM_VALUE_BASE_HPP_
#include <string>
#include "rive/core.hpp"
#include "rive/core/field_types/core_string_type.hpp"
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/editor_field_types.hpp"
#endif
namespace rive
{
class DataEnumValueBase : public Core
{
protected:
  typedef Core Super;

public:
  static const uint16_t typeKey = 445;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t keyPropertyKey = 578;
  static const uint16_t valuePropertyKey = 579;

protected:
  std::string m_Key = "";
  std::string m_Value = "";

public:
  inline const std::string& key() const { return m_Key; }
  void key(std::string value)
  {
    if (m_Key == value)
    {
      return;
    }
    RIVE_EDITOR_STRING_CHANGING(keyPropertyKey, m_Key, value);
    m_Key = value;
    notifyPropertyChanged(keyPropertyKey);
  }

  inline const std::string& value() const { return m_Value; }
  void value(std::string value)
  {
    if (m_Value == value)
    {
      return;
    }
    RIVE_EDITOR_STRING_CHANGING(valuePropertyKey, m_Value, value);
    m_Value = value;
    RIVE_EDITOR_CHANGED(valueChanged());
    notifyPropertyChanged(valuePropertyKey);
  }

  Core* clone() const override;
  void copy(const DataEnumValueBase& object)
  {
    m_Key = object.m_Key;
    m_Value = object.m_Value;
    RIVE_EDITOR_COPY(object);
    RIVE_EDITOR_COPY_VALIDATED(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case keyPropertyKey:
        m_Key = CoreStringType::deserialize(reader);
        return true;
      case valuePropertyKey:
        m_Value = CoreStringType::deserialize(reader);
        return true;
    }
    RIVE_EDITOR_DESERIALIZE(propertyKey, reader);
    return false;
  }

protected:
  virtual void valueChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/viewmodel/data_enum_value_ext.inl"
#endif
};
} // namespace rive

#endif