#ifndef _RIVE_EXPORT_AUDIO_BASE_HPP_
#define _RIVE_EXPORT_AUDIO_BASE_HPP_
#include "rive/assets/file_asset.hpp"
#include "rive/core/field_types/core_double_type.hpp"
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/editor_field_types.hpp"
#endif
namespace rive
{
class ExportAudioBase : public FileAsset
{
protected:
  typedef FileAsset Super;

public:
  static const uint16_t typeKey = 422;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t volumePropertyKey = 530;

protected:
  float m_Volume = 1.0f;

public:
  inline float volume() const { return m_Volume; }
  void volume(float value)
  {
    if (m_Volume == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(volumePropertyKey, &m_Volume, &value);
    m_Volume = value;
    notifyPropertyChanged(volumePropertyKey);
  }

  void copy(const ExportAudioBase& object)
  {
    m_Volume = object.m_Volume;
    RIVE_EDITOR_COPY(object);
    FileAsset::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case volumePropertyKey:
        m_Volume = CoreDoubleType::deserialize(reader);
        return true;
    }
    RIVE_EDITOR_DESERIALIZE(propertyKey, reader);
    return FileAsset::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/assets/export_audio_ext.inl"
#endif
};
} // namespace rive

#endif