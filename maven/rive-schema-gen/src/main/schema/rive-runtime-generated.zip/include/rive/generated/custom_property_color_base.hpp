#ifndef _RIVE_CUSTOM_PROPERTY_COLOR_BASE_HPP_
#define _RIVE_CUSTOM_PROPERTY_COLOR_BASE_HPP_
#include "rive/core/field_types/core_color_type.hpp"
#include "rive/custom_property.hpp"
namespace rive
{
class CustomPropertyColorBase : public CustomProperty
{
protected:
  typedef CustomProperty Super;

public:
  static const uint16_t typeKey = 592;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t propertyValuePropertyKey = 836;

protected:
  int m_PropertyValue = 0xFF1D1D1D;

public:
  inline int propertyValue() const { return m_PropertyValue; }
  void propertyValue(int value)
  {
    if (m_PropertyValue == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(propertyValuePropertyKey, &m_PropertyValue, &value);
    m_PropertyValue = value;
    RIVE_EDITOR_CHANGED(propertyValueChanged());
    notifyPropertyChanged(propertyValuePropertyKey);
  }

  Core* clone() const override;
  void copy(const CustomPropertyColorBase& object)
  {
    m_PropertyValue = object.m_PropertyValue;
    CustomProperty::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case propertyValuePropertyKey:
        m_PropertyValue = CoreColorType::deserialize(reader);
        return true;
    }
    return CustomProperty::deserialize(propertyKey, reader);
  }

protected:
  virtual void propertyValueChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/custom_property_color_ext.inl"
#endif
};
} // namespace rive

#endif