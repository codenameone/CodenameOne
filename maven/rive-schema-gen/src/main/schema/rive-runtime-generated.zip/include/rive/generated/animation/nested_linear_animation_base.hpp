#ifndef _RIVE_NESTED_LINEAR_ANIMATION_BASE_HPP_
#define _RIVE_NESTED_LINEAR_ANIMATION_BASE_HPP_
#include "rive/core/field_types/core_double_type.hpp"
#include "rive/nested_animation.hpp"
namespace rive
{
class NestedLinearAnimationBase : public NestedAnimation
{
protected:
  typedef NestedAnimation Super;

public:
  static const uint16_t typeKey = 97;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t mixPropertyKey = 200;

protected:
  float m_Mix = 1.0f;

public:
  inline float mix() const { return m_Mix; }
  void mix(float value)
  {
    if (m_Mix == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(mixPropertyKey, &m_Mix, &value);
    m_Mix = value;
    notifyPropertyChanged(mixPropertyKey);
  }

  void copy(const NestedLinearAnimationBase& object)
  {
    m_Mix = object.m_Mix;
    NestedAnimation::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case mixPropertyKey:
        m_Mix = CoreDoubleType::deserialize(reader);
        return true;
    }
    return NestedAnimation::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/nested_linear_animation_ext.inl"
#endif
};
} // namespace rive

#endif