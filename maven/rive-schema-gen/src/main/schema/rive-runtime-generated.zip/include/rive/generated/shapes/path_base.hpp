#ifndef _RIVE_PATH_BASE_HPP_
#define _RIVE_PATH_BASE_HPP_
#include "rive/core/field_types/core_bool_type.hpp"
#include "rive/core/field_types/core_uint_type.hpp"
#include "rive/node.hpp"
namespace rive
{
class PathBase : public Node
{
protected:
  typedef Node Super;

public:
  static const uint16_t typeKey = 12;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t pathFlagsPropertyKey = 128;
  static const uint16_t isHolePropertyKey = 770;

protected:
  uint32_t m_PathFlags = 0;
  bool m_IsHole = false;

public:
  inline uint32_t pathFlags() const { return m_PathFlags; }
  void pathFlags(uint32_t value)
  {
    if (m_PathFlags == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(pathFlagsPropertyKey, &m_PathFlags, &value);
    m_PathFlags = value;
    notifyPropertyChanged(pathFlagsPropertyKey);
  }

  inline bool isHole() const { return m_IsHole; }
  void isHole(bool value)
  {
    if (m_IsHole == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(isHolePropertyKey, &m_IsHole, &value);
    m_IsHole = value;
    RIVE_EDITOR_CHANGED(isHoleChanged());
    notifyPropertyChanged(isHolePropertyKey);
  }

  void copy(const PathBase& object)
  {
    m_PathFlags = object.m_PathFlags;
    m_IsHole = object.m_IsHole;
    Node::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case pathFlagsPropertyKey:
        m_PathFlags = CoreUintType::deserialize(reader);
        return true;
      case isHolePropertyKey:
        m_IsHole = CoreBoolType::deserialize(reader);
        return true;
    }
    return Node::deserialize(propertyKey, reader);
  }

protected:
  virtual void isHoleChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/shapes/path_ext.inl"
#endif
};
} // namespace rive

#endif