#ifndef _RIVE_BLOB_ASSET_BASE_HPP_
#define _RIVE_BLOB_ASSET_BASE_HPP_
#include "rive/assets/file_asset.hpp"
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/editor_field_types.hpp"
#endif
namespace rive
{
class BlobAssetBase : public FileAsset
{
protected:
  typedef FileAsset Super;

public:
  static const uint16_t typeKey = 649;

  uint16_t coreType() const override { return typeKey; }

public:
  Core* clone() const override;
  void copy(const BlobAssetBase& object)
  {
    RIVE_EDITOR_COPY(object);
    FileAsset::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    RIVE_EDITOR_DESERIALIZE(propertyKey, reader);
    return FileAsset::deserialize(propertyKey, reader);
  }
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/assets/blob_asset_ext.inl"
#endif
};
} // namespace rive

#endif