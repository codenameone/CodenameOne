#ifndef _RIVE_TRANSITION_VALUE_COLOR_COMPARATOR_BASE_HPP_
#define _RIVE_TRANSITION_VALUE_COLOR_COMPARATOR_BASE_HPP_
#include "rive/animation/transition_value_comparator.hpp"
#include "rive/core/field_types/core_color_type.hpp"
namespace rive
{
class TransitionValueColorComparatorBase : public TransitionValueComparator
{
protected:
  typedef TransitionValueComparator Super;

public:
  static const uint16_t typeKey = 483;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t valuePropertyKey = 651;

protected:
  int m_Value = 0xFF1D1D1D;

public:
  inline int value() const { return m_Value; }
  void value(int value)
  {
    if (m_Value == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(valuePropertyKey, &m_Value, &value);
    m_Value = value;
    RIVE_EDITOR_CHANGED(valueChanged());
    notifyPropertyChanged(valuePropertyKey);
  }

  Core* clone() const override;
  void copy(const TransitionValueColorComparatorBase& object)
  {
    m_Value = object.m_Value;
    TransitionValueComparator::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case valuePropertyKey:
        m_Value = CoreColorType::deserialize(reader);
        return true;
    }
    return TransitionValueComparator::deserialize(propertyKey, reader);
  }

protected:
  virtual void valueChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/transition_value_color_comparator_ext.inl"
#endif
};
} // namespace rive

#endif