#ifndef _RIVE_TEXT_STYLE_BASE_HPP_
#define _RIVE_TEXT_STYLE_BASE_HPP_
#include "rive/core/field_types/core_double_type.hpp"
#include "rive/core/field_types/core_id_type.hpp"
#include "rive/core/id.hpp"
#include "rive/text/text_style_reference.hpp"
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/editor_field_types.hpp"
#endif
namespace rive
{
class TextStyleBase : public TextStyleReference
{
protected:
  typedef TextStyleReference Super;

public:
  static const uint16_t typeKey = 573;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t fontSizePropertyKey = 274;
  static const uint16_t lineHeightPropertyKey = 370;
  static const uint16_t letterSpacingPropertyKey = 390;
  static const uint16_t fontAssetIdPropertyKey = 279;

protected:
  float m_FontSize = 12.0f;
  float m_LineHeight = -1.0f;
  float m_LetterSpacing = 0.0f;
  Id m_FontAssetId = kEmptyId;

public:
  inline float fontSize() const { return m_FontSize; }
  void fontSize(float value)
  {
    if (m_FontSize == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(fontSizePropertyKey, &m_FontSize, &value);
    m_FontSize = value;
    RIVE_EDITOR_CHANGED(fontSizeChanged());
    notifyPropertyChanged(fontSizePropertyKey);
  }

  inline float lineHeight() const { return m_LineHeight; }
  void lineHeight(float value)
  {
    if (m_LineHeight == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(lineHeightPropertyKey, &m_LineHeight, &value);
    m_LineHeight = value;
    RIVE_EDITOR_CHANGED(lineHeightChanged());
    notifyPropertyChanged(lineHeightPropertyKey);
  }

  inline float letterSpacing() const { return m_LetterSpacing; }
  void letterSpacing(float value)
  {
    if (m_LetterSpacing == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(letterSpacingPropertyKey, &m_LetterSpacing, &value);
    m_LetterSpacing = value;
    RIVE_EDITOR_CHANGED(letterSpacingChanged());
    notifyPropertyChanged(letterSpacingPropertyKey);
  }

  inline Id fontAssetId() const { return m_FontAssetId; }
  void fontAssetId(Id value)
  {
    if (m_FontAssetId == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(fontAssetIdPropertyKey, &m_FontAssetId, &value);
    m_FontAssetId = value;
    RIVE_EDITOR_CHANGED(fontAssetIdChanged());
    notifyPropertyChanged(fontAssetIdPropertyKey);
  }

  Core* clone() const override;
  void copy(const TextStyleBase& object)
  {
    m_FontSize = object.m_FontSize;
    m_LineHeight = object.m_LineHeight;
    m_LetterSpacing = object.m_LetterSpacing;
    m_FontAssetId = object.m_FontAssetId;
    RIVE_EDITOR_COPY(object);
    TextStyleReference::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case fontSizePropertyKey:
        m_FontSize = CoreDoubleType::deserialize(reader);
        return true;
      case lineHeightPropertyKey:
        m_LineHeight = CoreDoubleType::deserialize(reader);
        return true;
      case letterSpacingPropertyKey:
        m_LetterSpacing = CoreDoubleType::deserialize(reader);
        return true;
      case fontAssetIdPropertyKey:
        m_FontAssetId = CoreIdType::runtimeDeserialize(reader);
        return true;
    }
    RIVE_EDITOR_DESERIALIZE(propertyKey, reader);
    return TextStyleReference::deserialize(propertyKey, reader);
  }

protected:
  virtual void fontSizeChanged() {}
  virtual void lineHeightChanged() {}
  virtual void letterSpacingChanged() {}
  virtual void fontAssetIdChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/text/text_style_ext.inl"
#endif
};
} // namespace rive

#endif