#ifndef _RIVE_TRANSITION_TRIGGER_CONDITION_BASE_HPP_
#define _RIVE_TRANSITION_TRIGGER_CONDITION_BASE_HPP_
#include "rive/animation/transition_input_condition.hpp"
namespace rive
{
class TransitionTriggerConditionBase : public TransitionInputCondition
{
protected:
  typedef TransitionInputCondition Super;

public:
  static const uint16_t typeKey = 68;

  uint16_t coreType() const override { return typeKey; }

  Core* clone() const override;
};
} // namespace rive

#endif