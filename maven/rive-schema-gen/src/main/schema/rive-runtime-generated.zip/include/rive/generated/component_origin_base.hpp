#ifndef _RIVE_COMPONENT_ORIGIN_BASE_HPP_
#define _RIVE_COMPONENT_ORIGIN_BASE_HPP_
#include "rive/component.hpp"
#include "rive/core/field_types/core_double_type.hpp"
namespace rive
{
class ComponentOriginBase : public Component
{
protected:
  typedef Component Super;

public:
  static const uint16_t typeKey = 1039;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t originXPropertyKey = 1040;
  static const uint16_t originYPropertyKey = 1041;

protected:
  float m_OriginX = 0.0f;
  float m_OriginY = 0.0f;

public:
  inline float originX() const { return m_OriginX; }
  void originX(float value)
  {
    if (m_OriginX == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(originXPropertyKey, &m_OriginX, &value);
    m_OriginX = value;
    RIVE_EDITOR_CHANGED(originXChanged());
    notifyPropertyChanged(originXPropertyKey);
  }

  inline float originY() const { return m_OriginY; }
  void originY(float value)
  {
    if (m_OriginY == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(originYPropertyKey, &m_OriginY, &value);
    m_OriginY = value;
    RIVE_EDITOR_CHANGED(originYChanged());
    notifyPropertyChanged(originYPropertyKey);
  }

  Core* clone() const override;
  void copy(const ComponentOriginBase& object)
  {
    m_OriginX = object.m_OriginX;
    m_OriginY = object.m_OriginY;
    Component::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case originXPropertyKey:
        m_OriginX = CoreDoubleType::deserialize(reader);
        return true;
      case originYPropertyKey:
        m_OriginY = CoreDoubleType::deserialize(reader);
        return true;
    }
    return Component::deserialize(propertyKey, reader);
  }

protected:
  virtual void originXChanged() {}
  virtual void originYChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/component_origin_ext.inl"
#endif
};
} // namespace rive

#endif