#ifndef _RIVE_CUSTOM_PROPERTY_TRIGGER_BASE_HPP_
#define _RIVE_CUSTOM_PROPERTY_TRIGGER_BASE_HPP_
#include "rive/core/field_types/core_callback_type.hpp"
#include "rive/core/field_types/core_uint_type.hpp"
#include "rive/custom_property.hpp"
namespace rive
{
class CustomPropertyTriggerBase : public CustomProperty
{
protected:
  typedef CustomProperty Super;

public:
  static const uint16_t typeKey = 613;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t firePropertyKey = 869;
  static const uint16_t propertyValuePropertyKey = 870;

protected:
  uint32_t m_PropertyValue = 0;

public:
  virtual void fire(const CallbackData& value) = 0;

  inline uint32_t propertyValue() const { return m_PropertyValue; }
  void propertyValue(uint32_t value)
  {
    if (m_PropertyValue == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(propertyValuePropertyKey, &m_PropertyValue, &value);
    m_PropertyValue = value;
    RIVE_EDITOR_CHANGED(propertyValueChanged());
    notifyPropertyChanged(propertyValuePropertyKey);
  }

  Core* clone() const override;
  void copy(const CustomPropertyTriggerBase& object)
  {
    m_PropertyValue = object.m_PropertyValue;
    CustomProperty::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case propertyValuePropertyKey:
        m_PropertyValue = CoreUintType::deserialize(reader);
        return true;
    }
    return CustomProperty::deserialize(propertyKey, reader);
  }

protected:
  virtual void propertyValueChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/custom_property_trigger_ext.inl"
#endif
};
} // namespace rive

#endif