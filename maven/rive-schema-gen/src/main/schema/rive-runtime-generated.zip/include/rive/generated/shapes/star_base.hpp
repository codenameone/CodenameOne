#ifndef _RIVE_STAR_BASE_HPP_
#define _RIVE_STAR_BASE_HPP_
#include "rive/core/field_types/core_double_type.hpp"
#include "rive/shapes/polygon.hpp"
namespace rive
{
class StarBase : public Polygon
{
protected:
  typedef Polygon Super;

public:
  static const uint16_t typeKey = 52;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t innerRadiusPropertyKey = 127;

protected:
  float m_InnerRadius = 0.5f;

public:
  inline float innerRadius() const { return m_InnerRadius; }
  void innerRadius(float value)
  {
    if (m_InnerRadius == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(innerRadiusPropertyKey, &m_InnerRadius, &value);
    m_InnerRadius = value;
    RIVE_EDITOR_CHANGED(innerRadiusChanged());
    notifyPropertyChanged(innerRadiusPropertyKey);
  }

  Core* clone() const override;
  void copy(const StarBase& object)
  {
    m_InnerRadius = object.m_InnerRadius;
    Polygon::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case innerRadiusPropertyKey:
        m_InnerRadius = CoreDoubleType::deserialize(reader);
        return true;
    }
    return Polygon::deserialize(propertyKey, reader);
  }

protected:
  virtual void innerRadiusChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/shapes/star_ext.inl"
#endif
};
} // namespace rive

#endif