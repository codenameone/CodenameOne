#ifndef _RIVE_BLEND_STATE_BASE_HPP_
#define _RIVE_BLEND_STATE_BASE_HPP_
#include "rive/animation/layer_state.hpp"
namespace rive
{
class BlendStateBase : public LayerState
{
protected:
  typedef LayerState Super;

public:
  static const uint16_t typeKey = 72;

  uint16_t coreType() const override { return typeKey; }
};
} // namespace rive

#endif