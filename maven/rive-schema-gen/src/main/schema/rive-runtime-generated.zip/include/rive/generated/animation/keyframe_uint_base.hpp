#ifndef _RIVE_KEY_FRAME_UINT_BASE_HPP_
#define _RIVE_KEY_FRAME_UINT_BASE_HPP_
#include "rive/animation/interpolating_keyframe.hpp"
#include "rive/core/field_types/core_uint_type.hpp"
namespace rive
{
class KeyFrameUintBase : public InterpolatingKeyFrame
{
protected:
  typedef InterpolatingKeyFrame Super;

public:
  static const uint16_t typeKey = 450;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t valuePropertyKey = 631;

protected:
  uint32_t m_Value = 0;

public:
  inline uint32_t value() const { return m_Value; }
  void value(uint32_t value)
  {
    if (m_Value == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(valuePropertyKey, &m_Value, &value);
    m_Value = value;
    RIVE_EDITOR_CHANGED(valueChanged());
    notifyPropertyChanged(valuePropertyKey);
  }

  Core* clone() const override;
  void copy(const KeyFrameUintBase& object)
  {
    m_Value = object.m_Value;
    InterpolatingKeyFrame::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case valuePropertyKey:
        m_Value = CoreUintType::deserialize(reader);
        return true;
    }
    return InterpolatingKeyFrame::deserialize(propertyKey, reader);
  }

protected:
  virtual void valueChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/keyframe_uint_ext.inl"
#endif
};
} // namespace rive

#endif