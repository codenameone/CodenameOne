#ifndef _RIVE_FILL_BASE_HPP_
#define _RIVE_FILL_BASE_HPP_
#include "rive/core/field_types/core_uint_type.hpp"
#include "rive/shapes/paint/shape_paint.hpp"
namespace rive
{
class FillBase : public ShapePaint
{
protected:
  typedef ShapePaint Super;

public:
  static const uint16_t typeKey = 20;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t fillRulePropertyKey = 40;

protected:
  uint8_t m_FillRule = 0;

public:
  inline uint8_t fillRule() const { return m_FillRule; }
  void fillRule(uint8_t value)
  {
    if (m_FillRule == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(fillRulePropertyKey, &m_FillRule, &value);
    m_FillRule = value;
    RIVE_EDITOR_CHANGED(fillRuleChanged());
    notifyPropertyChanged(fillRulePropertyKey);
  }

  Core* clone() const override;
  void copy(const FillBase& object)
  {
    m_FillRule = object.m_FillRule;
    ShapePaint::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case fillRulePropertyKey:
        m_FillRule = CoreUintType::deserialize(reader);
        return true;
    }
    return ShapePaint::deserialize(propertyKey, reader);
  }

protected:
  virtual void fillRuleChanged() {}
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/shapes/paint/fill_ext.inl"
#endif
};
} // namespace rive

#endif