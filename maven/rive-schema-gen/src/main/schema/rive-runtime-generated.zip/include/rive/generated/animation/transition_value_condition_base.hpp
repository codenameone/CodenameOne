#ifndef _RIVE_TRANSITION_VALUE_CONDITION_BASE_HPP_
#define _RIVE_TRANSITION_VALUE_CONDITION_BASE_HPP_
#include "rive/animation/transition_input_condition.hpp"
#include "rive/core/field_types/core_uint_type.hpp"
namespace rive
{
class TransitionValueConditionBase : public TransitionInputCondition
{
protected:
  typedef TransitionInputCondition Super;

public:
  static const uint16_t typeKey = 69;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t opValuePropertyKey = 156;

protected:
  uint8_t m_OpValue = 0;

public:
  inline uint8_t opValue() const { return m_OpValue; }
  void opValue(uint8_t value)
  {
    if (m_OpValue == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(opValuePropertyKey, &m_OpValue, &value);
    m_OpValue = value;
    notifyPropertyChanged(opValuePropertyKey);
  }

  void copy(const TransitionValueConditionBase& object)
  {
    m_OpValue = object.m_OpValue;
    TransitionInputCondition::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case opValuePropertyKey:
        m_OpValue = CoreUintType::deserialize(reader);
        return true;
    }
    return TransitionInputCondition::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/transition_value_condition_ext.inl"
#endif
};
} // namespace rive

#endif