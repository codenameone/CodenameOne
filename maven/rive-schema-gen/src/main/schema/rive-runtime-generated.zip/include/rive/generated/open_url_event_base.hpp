#ifndef _RIVE_OPEN_URL_EVENT_BASE_HPP_
#define _RIVE_OPEN_URL_EVENT_BASE_HPP_
#include <string>
#include "rive/core/field_types/core_string_type.hpp"
#include "rive/core/field_types/core_uint_type.hpp"
#include "rive/event.hpp"
namespace rive
{
class OpenUrlEventBase : public Event
{
protected:
  typedef Event Super;

public:
  static const uint16_t typeKey = 131;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t urlPropertyKey = 248;
  static const uint16_t targetValuePropertyKey = 249;

protected:
  std::string m_Url = "";
  uint32_t m_TargetValue = 0;

public:
  inline const std::string& url() const { return m_Url; }
  void url(std::string value)
  {
    if (m_Url == value)
    {
      return;
    }
    RIVE_EDITOR_STRING_CHANGING(urlPropertyKey, m_Url, value);
    m_Url = value;
    notifyPropertyChanged(urlPropertyKey);
  }

  inline uint32_t targetValue() const { return m_TargetValue; }
  void targetValue(uint32_t value)
  {
    if (m_TargetValue == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(targetValuePropertyKey, &m_TargetValue, &value);
    m_TargetValue = value;
    notifyPropertyChanged(targetValuePropertyKey);
  }

  Core* clone() const override;
  void copy(const OpenUrlEventBase& object)
  {
    m_Url = object.m_Url;
    m_TargetValue = object.m_TargetValue;
    Event::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case urlPropertyKey:
        m_Url = CoreStringType::deserialize(reader);
        return true;
      case targetValuePropertyKey:
        m_TargetValue = CoreUintType::deserialize(reader);
        return true;
    }
    return Event::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/open_url_event_ext.inl"
#endif
};
} // namespace rive

#endif