#ifndef _RIVE_STATE_MACHINE_LAYER_COMPONENT_BASE_HPP_
#define _RIVE_STATE_MACHINE_LAYER_COMPONENT_BASE_HPP_
#include "rive/core.hpp"
namespace rive
{
class StateMachineLayerComponentBase : public Core
{
protected:
  typedef Core Super;

public:
  static const uint16_t typeKey = 66;

  uint16_t coreType() const override { return typeKey; }

  void copy(const StateMachineLayerComponentBase& object)
  {
    RIVE_EDITOR_COPY_VALIDATED(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    return false;
  }
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/animation/state_machine_layer_component_ext.inl"
#endif
};
} // namespace rive

#endif