#ifndef _RIVE_KEYBOARD_INPUT_BASE_HPP_
#define _RIVE_KEYBOARD_INPUT_BASE_HPP_
#include "rive/core/field_types/core_uint_type.hpp"
#include "rive/inputs/user_input.hpp"
namespace rive
{
class KeyboardInputBase : public UserInput
{
protected:
  typedef UserInput Super;

public:
  static const uint16_t typeKey = 664;

  uint16_t coreType() const override { return typeKey; }

  static const uint16_t keyTypePropertyKey = 971;
  static const uint16_t keyPhasePropertyKey = 972;
  static const uint16_t modifiersPropertyKey = 973;

protected:
  uint32_t m_KeyType = -1;
  uint32_t m_KeyPhase = 0;
  uint32_t m_Modifiers = 0;

public:
  inline uint32_t keyType() const { return m_KeyType; }
  void keyType(uint32_t value)
  {
    if (m_KeyType == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(keyTypePropertyKey, &m_KeyType, &value);
    m_KeyType = value;
    notifyPropertyChanged(keyTypePropertyKey);
  }

  inline uint32_t keyPhase() const { return m_KeyPhase; }
  void keyPhase(uint32_t value)
  {
    if (m_KeyPhase == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(keyPhasePropertyKey, &m_KeyPhase, &value);
    m_KeyPhase = value;
    notifyPropertyChanged(keyPhasePropertyKey);
  }

  inline uint32_t modifiers() const { return m_Modifiers; }
  void modifiers(uint32_t value)
  {
    if (m_Modifiers == value)
    {
      return;
    }
    RIVE_EDITOR_CHANGING(modifiersPropertyKey, &m_Modifiers, &value);
    m_Modifiers = value;
    notifyPropertyChanged(modifiersPropertyKey);
  }

  Core* clone() const override;
  void copy(const KeyboardInputBase& object)
  {
    m_KeyType = object.m_KeyType;
    m_KeyPhase = object.m_KeyPhase;
    m_Modifiers = object.m_Modifiers;
    UserInput::copy(object);
  }

  bool deserialize(uint16_t propertyKey, BinaryReader& reader) override
  {
    switch (propertyKey)
    {
      case keyTypePropertyKey:
        m_KeyType = CoreUintType::deserialize(reader);
        return true;
      case keyPhasePropertyKey:
        m_KeyPhase = CoreUintType::deserialize(reader);
        return true;
      case modifiersPropertyKey:
        m_Modifiers = CoreUintType::deserialize(reader);
        return true;
    }
    return UserInput::deserialize(propertyKey, reader);
  }

protected:
#ifdef WITH_RIVE_EDITOR
#include "editor_native/generated/inputs/keyboard_input_ext.inl"
#endif
};
} // namespace rive

#endif