import pathlib,subprocess,os,shutil,time,json
root=pathlib.Path(os.environ['CN1_REPO']).resolve();work=pathlib.Path(os.environ.get('BENCH_OUTPUT','hello-results')).resolve();work.mkdir(exist_ok=False)
j8=pathlib.Path(os.environ['JDK_8_HOME'])
j25=pathlib.Path(os.environ['JDK_25_HOME'])
graal=pathlib.Path(os.environ['GRAALVM_HOME'])
meta={}
def run(label,args,cwd=work):
 start=time.perf_counter()
 with open(work/(label+'.log'),'w') as out:p=subprocess.run([str(x) for x in args],cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 meta[label]={'seconds':time.perf_counter()-start,'exit':p.returncode};print(label,meta[label],flush=True)
 if p.returncode: print((work/(label+'.log')).read_text()[-5000:]);raise SystemExit(p.returncode)
(work/'Hello.java').write_text('public class Hello { public static void main(String[] args) { System.out.println("Hello, world!"); } }\n')
for name in ['classes','translator','javaapi','out']:(work/name).mkdir(exist_ok=True)
run('javac',[j8/'bin/javac','-d',work/'classes',work/'Hello.java'])
asm=(root/'vm/ByteCodeTranslator/target/bench-asm-classpath.txt').read_text().strip()
run('translator-javac',[j8/'bin/javac','-nowarn','-source','8','-target','8','-cp',asm,'-d',work/'translator',*sorted((root/'vm/ByteCodeTranslator/src').rglob('*.java'))])
for src in (root/'vm/ByteCodeTranslator/src').rglob('*'):
 if src.is_file() and src.suffix!='.java':
  dst=work/'translator'/src.relative_to(root/'vm/ByteCodeTranslator/src');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
run('javaapi-javac',[j8/'bin/javac','-nowarn','-source','8','-target','8','-d',work/'javaapi',*sorted((root/'vm/JavaAPI/src').rglob('*.java'))])
run('parpar-translate',[j8/'bin/java','-cp',str(work/'translator')+':'+asm,'com.codename1.tools.translator.ByteCodeTranslator','clean',str(work/'javaapi')+';'+str(work/'classes'),work/'out','Hello','','Hello','1.0','clean','none'])
src=work/'out/dist/Hello-src'
run('parpar-clang',['clang','-O3','-flto=thin','-w','-fwrapv','-fno-strict-aliasing','-fno-builtin-fmod','-fno-builtin-fmodf','-I'+str(src),*sorted(src.glob('*.c')),*sorted(src.glob('*.S')),'-lm','-lpthread','-o',work/'hello-parpar'])
run('graal-build',[graal/'bin/native-image','--no-fallback','-O3','-cp',work/'classes','Hello',work/'hello-graal'])
run('jlink',[j25/'bin/jlink','--add-modules','java.base','--strip-debug','--no-header-files','--no-man-pages','--output',work/'jdk25-runtime'])
run('jar',[j25/'bin/jar','--create','--file',work/'hello.jar','-C',work/'classes','.'])
run('jdk25-aot-train',[work/'jdk25-runtime/bin/java','-XX:AOTCacheOutput='+str(work/'hello.aot'),'-cp',work/'hello.jar','Hello'])
(work/'build-results.json').write_text(json.dumps(meta,indent=2))
print('Builds ready. Measure sequentially after other heavy work finishes.',flush=True)
