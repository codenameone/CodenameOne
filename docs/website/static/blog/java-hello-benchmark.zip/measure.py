from pathlib import Path
import subprocess,time,statistics,json,platform,os,re
w=Path(os.environ.get('BENCH_OUTPUT','hello-results')).resolve()
cmds={'ParparVM':[str(w/'hello-parpar')],'GraalVM 21.0.11':[str(w/'hello-graal')],'JDK 25 AOT cache':[str(w/'jdk25-runtime/bin/java'),'-XX:AOTCache='+str(w/'hello.aot'),'-cp',str(w/'hello.jar'),'Hello']}
result={k:[] for k in cmds}
for k,c in cmds.items():
 for i in range(5):
  p=subprocess.run(c,capture_output=True);assert p.returncode==0 and p.stdout==b'Hello, world!\n',(k,p.stdout,p.stderr)
keys=list(cmds)
for i in range(31):
 for k in keys[i%3:]+keys[:i%3]:
  c=cmds[k];t=time.perf_counter_ns();p=subprocess.run(['/usr/bin/time','-l',*c],capture_output=True);elapsed=(time.perf_counter_ns()-t)/1e6
  assert p.returncode==0 and p.stdout==b'Hello, world!\n',(k,p.stdout,p.stderr)
  rss=int(re.search(rb'(\d+)\s+maximum resident set size',p.stderr).group(1));result[k].append({'elapsed_ms':elapsed,'max_rss_bytes':rss})
sizes={'ParparVM':(w/'hello-parpar').stat().st_size,'GraalVM 21.0.11':(w/'hello-graal').stat().st_size,'JDK 25 AOT cache':sum(p.stat().st_size for p in (w/'jdk25-runtime').rglob('*') if p.is_file())+(w/'hello.jar').stat().st_size+(w/'hello.aot').stat().st_size}
summary={k:{'median_ms':statistics.median(x['elapsed_ms'] for x in v),'min_ms':min(x['elapsed_ms'] for x in v),'max_ms':max(x['elapsed_ms'] for x in v),'median_peak_rss_bytes':statistics.median(x['max_rss_bytes'] for x in v),'deployment_bytes':sizes[k]} for k,v in result.items()}
meta={'os':platform.platform(),'arch':platform.machine(),'machine':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory':subprocess.check_output(['sysctl','-n','hw.memsize'],text=True).strip(),'loadavg':os.getloadavg(),'runs':31,'warmups':5,'commands':cmds,'summary':summary,'samples':result,'jdk_version':subprocess.run([str(w/'jdk25-runtime/bin/java'),'-version'],capture_output=True,text=True).stderr,'graal_version':subprocess.run([str(Path(os.environ['GRAALVM_HOME'])/'bin/native-image'),'--version'],capture_output=True,text=True).stdout}
(w/'measurements.json').write_text(json.dumps(meta,indent=2));print(json.dumps({k:v for k,v in meta.items() if k!='samples'},indent=2))
