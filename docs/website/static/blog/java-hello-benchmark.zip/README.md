# Java Hello World footprint, September 18, 2026

The article's measured baseline is Codename One master
2697dcfa2f0425170efd08655243032571b65869.

Host: Apple M4 Max, 64 GiB, macOS 26.6.2, ARM64.
JDK frontend: Azul Java 8. JDK AOT arm: Zulu 25+36.
GraalVM Native Image arm: Oracle 21.0.11+9.1, ARM64, serial GC.
Native flags: -O3 for both; ParparVM also uses ThinLTO, -fwrapv,
-fno-strict-aliasing, -fno-builtin-fmod, and -fno-builtin-fmodf.
These are the installed runtime versions, not a latest-version contest.

## Reproduce on macOS ARM64

Requires Python 3, Xcode command-line tools, Java 8, Java 25, and GraalVM
with native-image. Use a fresh output directory. All work stays there.

    export CN1_REPO=/path/to/CodenameOne
    export JDK_8_HOME=/path/to/jdk8/Contents/Home
    export JDK_25_HOME=/path/to/jdk25/Contents/Home
    export GRAALVM_HOME=/path/to/graalvm/Contents/Home
    export JAVA_HOME="$JDK_8_HOME"
    export PATH="$JAVA_HOME/bin:$PATH"
    export BENCH_OUTPUT="$PWD/hello-results"

Resolve ASM once if the checkout does not have a valid classpath file:

    cd "$CN1_REPO/vm"
    mvn -pl ByteCodeTranslator dependency:build-classpath \
      -Dmdep.outputFile=target/bench-asm-classpath.txt

Return to the directory containing these scripts, then:

    python3 build.py
    python3 measure.py

build.py recompiles the current translator and JavaAPI into the scratch
folder. It does not rely on the checkout's cached class files. It builds
one Java 8 Hello.class for the application and uses it in all three arms.
The minimal JDK runtime is created with jlink using java.base only,
--strip-debug, --no-header-files, and --no-man-pages. Its AOT cache is trained
and consumed by that exact runtime. The native executables are unstripped.

measure.py performs five warm-ups per arm, then 31 interleaved measurements
with rotating arm order. Each sample starts a new process and verifies the
exact stdout and exit status. Files are warm in the OS cache. Timing wraps
/usr/bin/time -l and includes its process overhead. Peak RSS is the child
process's maximum resident set size reported by macOS, in bytes.

The recorded run was not isolated from other host activity. Its one-, five-,
and fifteen-minute load averages were 3.75, 6.17, and 4.94. The elapsed times
therefore describe that run, not a quiet-machine baseline.

For your own run, stop builds and other benchmarks before measuring. Samples are not HTTP
latencies, cloud cold starts, or steady-state throughput. The native rows
count the executable; the JDK row counts the full minimal runtime directory,
JAR, and AOT cache. All sizes are uncompressed file bytes. Shared operating
system libraries are excluded for all rows. MB in the article means 1,000,000
bytes. The raw ranges and samples are retained in measurements.json.

The AOT cache was confirmed active with -Xlog:aot=info before timing. Both
native executables were checked with `file` and are ARM64. The artifact sizes
and runtime measurements below belong to the published source revision;
running these scripts on a newer checkout measures that newer code.
