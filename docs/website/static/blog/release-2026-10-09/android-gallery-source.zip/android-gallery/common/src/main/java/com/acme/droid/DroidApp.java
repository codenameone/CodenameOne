package com.acme.droid;

/// The Codename One entry point: starts the imported Android application's launcher activity.
public class DroidApp extends com.codename1.androidcompat.runtime.AndroidLifecycle {
    public DroidApp() {
        super(new com.codename1.generated.android.AndroidAppImpl());
    }
}
