Asset text file
