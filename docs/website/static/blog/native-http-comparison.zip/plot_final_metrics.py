from pathlib import Path
import json,statistics as st
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
r=Path(__file__).resolve().parent/'linux';build=json.loads((r/'build-times/results.json').read_text());warm=json.loads((r/'warmed-pair/results.json').read_text());assert build['complete'] and warm['complete']
assert len(build['samples'])==12 and all(x['exit_code']==0 for x in build['samples'])
b={a:[x['seconds'] for x in build['samples'] if x['arm']==a] for a in ['cn1-debug','cn1-native','spring-jdk25','spring-graal25']}
w={x['arm']:x['routes'] for x in warm['samples']}
out=Path(__file__).resolve().parent/'charts/native-http';out.mkdir(parents=True,exist_ok=True);colors={'cn1-native':'#56d2d0','cn1-debug':'#56d2d0','spring-jdk25':'#f6ae55','spring-graal25':'#9cafff'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':16,'axes.titlesize':22,'axes.labelsize':16,'figure.facecolor':'#0b142a','axes.facecolor':'#0b142a','text.color':'#eef3ff','axes.labelcolor':'#d5e2f7','xtick.color':'#d5e2f7','ytick.color':'#eef3ff','axes.edgecolor':'#5f728f','savefig.facecolor':'#0b142a'})
def style(ax):
 ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
fig,axs=plt.subplots(2,1,figsize=(9,9))
for ax,arms,names,title in zip(axs,[['spring-jdk25','cn1-debug'],['cn1-native','spring-graal25']],[['Spring / JDK 25','CN1 debug / JDK 25'],['CN1 native','Spring / GraalVM 25']],['JVM development builds','Native executable builds']):
 vals=[st.median(b[a]) for a in arms];ax.barh(names,vals,color=[colors[a] for a in arms],height=.45);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.4)
 for i,v in enumerate(vals):ax.text(v+max(vals)*.03,i,f'{v:.2f} s',va='center',fontsize=18)
 ax.set_xlabel('Build elapsed time in seconds');ax.set_title(title+'\nLower is better',loc='left',pad=20);style(ax)
fig.subplots_adjust(hspace=.85);fig.text(.5,-.02,'Local Linux ARM64, 4 vCPUs / 8 GiB | Medians of three clean-output builds\nDependencies cached; no downloads or tests. Panels use different scales.',ha='center',fontsize=11);fig.savefig(out/'build-time.png',dpi=160,bbox_inches='tight',pad_inches=.25);plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(9,9))
for ax,route,title in zip(axs,['plaintext','json'],['Plaintext after 60 s warmup','JSON after 60 s warmup']):
 arms=['cn1-native','spring-jdk25'];vals=[st.median(w[a][route])/1000 for a in arms];ax.barh(['CN1 native','Spring / JDK 25'],vals,color=[colors[a] for a in arms],height=.45);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.4)
 for i,v in enumerate(vals):ax.text(v+max(vals)*.03,i,f'{v:.1f}k req/s',va='center',fontsize=18)
 ax.set_xlabel('Thousand requests per second');ax.set_title(title+'\nHigher is better',loc='left',pad=20);style(ax)
fig.subplots_adjust(hspace=.85);fig.text(.5,-.02,'2 server CPUs + 2 load CPUs | 32 connections\nOne fresh process per runtime; median of three 10 s windows per route.',ha='center',fontsize=11);fig.savefig(out/'warmed-throughput.png',dpi=160,bbox_inches='tight',pad_inches=.25);plt.close(fig)
print('Charts in',out)
