from pathlib import Path
import json,statistics as st
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
r=Path('/tmp/cn1-release-oct2/linux');build=json.loads((r/'build-times/results.json').read_text());warm=json.loads((r/'warmed-pair/results.json').read_text());assert build['complete'] and warm['complete']
assert len(build['samples'])==12 and all(x['exit_code']==0 for x in build['samples'])
b={a:[x['seconds'] for x in build['samples'] if x['arm']==a] for a in ['cn1-debug','cn1-native','spring-jdk25','spring-graal25']}
w={x['arm']:x['routes'] for x in warm['samples']}
out=Path('docs/website/static/blog/native-http-charts');colors={'cn1-native':'#56d2d0','cn1-debug':'#56d2d0','spring-jdk25':'#f6ae55','spring-graal25':'#9cafff'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':16,'axes.titlesize':22,'axes.labelsize':16,'figure.facecolor':'#0b142a','axes.facecolor':'#0b142a','text.color':'#eef3ff','axes.labelcolor':'#d5e2f7','xtick.color':'#d5e2f7','ytick.color':'#eef3ff','axes.edgecolor':'#5f728f','savefig.facecolor':'#0b142a'})
def style(ax):
 ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
fig,axs=plt.subplots(2,1,figsize=(9,9))
for ax,arms,names,title in zip(axs,[['spring-jdk25','cn1-debug'],['cn1-native','spring-graal25']],[['Spring / JDK 25','CN1 debug / JDK 25'],['CN1 native','Spring / GraalVM 25']],['JVM development builds','Native executable builds']):
 vals=[st.median(b[a]) for a in arms];ax.barh(names,vals,color=[colors[a] for a in arms],height=.45);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.4)
 for i,v in enumerate(vals):ax.text(v+max(vals)*.03,i,f'{v:.2f} s',va='center',fontsize=18)
 ax.set_xlabel('Build elapsed time in seconds');ax.set_title(title+'\nLower is better',loc='left',pad=20);style(ax)
fig.subplots_adjust(hspace=.85);fig.text(.5,-.02,'Local Linux ARM64, 4 vCPUs / 8 GiB | Medians of three clean-output builds\nDependencies cached; no downloads or tests. Panels use different scales.',ha='center',fontsize=11);fig.savefig(out/'build-time.png',dpi=160,bbox_inches='tight',pad_inches=.25);plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(9,9))
for ax,route,title in zip(axs,['plaintext','json'],['Plaintext after 60 s warmup','JSON after 60 s warmup']):
 arms=['cn1-native','spring-jdk25'];vals=[st.median(w[a][route])/1000 for a in arms];ax.barh(['CN1 native','Spring / JDK 25'],vals,color=[colors[a] for a in arms],height=.45);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.4)
 for i,v in enumerate(vals):ax.text(v+max(vals)*.03,i,f'{v:.1f}k req/s',va='center',fontsize=18)
 ax.set_xlabel('Thousand requests per second');ax.set_title(title+'\nHigher is better',loc='left',pad=20);style(ax)
fig.subplots_adjust(hspace=.85);fig.text(.5,-.02,'2 server CPUs + 2 load CPUs | 32 connections\nOne fresh process per runtime; median of three 10 s windows per route.',ha='center',fontsize=11);fig.savefig(out/'warmed-throughput.png',dpi=160,bbox_inches='tight',pad_inches=.25);plt.close(fig)
p=Path('docs/website/content/blog/java-server-work-before-startup.md');s=p.read_text()
a=s.index('These short runs show');end=s.index('\n\nThe matrix rotates',a)
plain=[st.median(w[a]['plaintext']) for a in ['cn1-native','spring-jdk25']];js=[st.median(w[a]['json']) for a in ['cn1-native','spring-jdk25']]
block=f'''### Does HotSpot catch up after warmup?

CN1 still leads after a minute of warmup per endpoint: **{plain[0]/plain[1]:.1f} times the plaintext throughput and {js[0]/js[1]:.1f} times the JSON throughput** of Spring/JDK 25 in the matched two-core follow-up. Both servers received the same longer warmup, followed by three consecutive ten-second measurement windows for each route.

| Application, 2 allowed CPUs | Plaintext requests/s | JSON requests/s |
| --- | ---: | ---: |
| CN1 native, 60 s warmup per route | {plain[0]:,.0f} | {js[0]:,.0f} |
| Spring Boot / JDK 25, 60 s warmup per route | {plain[1]:,.0f} | {js[1]:,.0f} |

[![Throughput after matched 60-second warmups for CN1 and Spring JDK 25; higher is better](/blog/native-http-charts/warmed-throughput.png)](/blog/native-http-charts/warmed-throughput.png)

*Higher is better. These are medians of three windows within one fresh process per runtime, separate from the three-process matrix above. The server uses CPUs 0 and 1; `wrk` uses CPUs 2 and 3, with 32 connections. Both routes completed without socket or non-2xx errors.*

We checked HotSpot's compiled-method list during warmup: Spring's request dispatcher and handler adapter had reached tier-4 compilation. The snapshot is included in the reproduction bundle. The extra warmup does not close the gap for these two handlers. More complex application code, dependencies and different concurrency levels can change that comparison.'''
s=s[:a]+block+s[end:]
# Timings belong beside runtime costs, before API walkthrough.
a=s.index('## Start your service with less runtime setup')
rows=[]
for arm,name in [('spring-jdk25','Spring Boot / JDK 25'),('cn1-debug','CN1 debug / JVM'),('cn1-native','CN1 native'),('spring-graal25','Spring Boot / GraalVM 25')]:
 vals=b[arm];rows.append(f'| {name} | {st.median(vals):.2f} | {min(vals):.2f}-{max(vals):.2f} |')
compileblock='''### How long do you wait for a build?

Native compilation moves work out of startup and into the build. You do not need to pay that cost after every edit: CN1's debug/development mode runs on the JVM, while the native build produces the deployment executable.

| Build | Median elapsed, seconds | Three-run range, seconds |
| --- | ---: | ---: |
'''+ '\n'.join(rows)+f'''

[![Compilation and packaging time for CN1 debug and native builds versus Spring JDK 25 and GraalVM; lower is better](/blog/native-http-charts/build-time.png)](/blog/native-http-charts/build-time.png)

*Lower is better. Three builds per configuration, with runtime order rotated, on the same four-vCPU, `8 GiB` Linux VM. Application outputs are rebuilt each time; dependencies and toolchains are cached. Downloads, tests and server startup are excluded.*

For this example, the CN1 native build takes **{100*(1-st.median(b['cn1-native'])/st.median(b['spring-graal25'])):.0f}% less elapsed time** than Spring/GraalVM. The JVM builds take seconds. That keeps the edit-and-debug loop short while letting you check the native artifact before deployment.

The CN1 development measurement compiles the repository's `Bench` handler, JavaSE backend runtime and shared sources with JDK 25. The native path compiles Java with JDK 8, translates it, then compiles and links the generated C with Clang at `-O3`; the translator and Java API dependencies are prebuilt. Spring uses Maven `clean package` on JDK 25; its native build adds Spring AOT processing and GraalVM `native:compile`. These are build-path timings for the HTTP examples, including their different build tools, rather than isolated `javac` or incremental-build timings.

'''
s=s[:a]+compileblock+s[a:]
# Put the reproduction link after all the measured costs.
import re
bundle_paragraph=re.search(r'The \[reproduction bundle\].*?(?=\n\n)',s,re.S)[0]
s=s.replace(bundle_paragraph+'\n\n','')
s=s.replace('## Start your service with less runtime setup',bundle_paragraph+'\n\n## Start your service with less runtime setup')
s=s.replace('## Compare startup, throughput and deployment size','## Compare startup, memory, throughput and build time')
s=s.replace('First response, ms: median (range)','First response, ms: median (range), lower is better').replace('Native executable, MiB |','Native executable, MiB, lower is better |')
s=s.replace('*Idle before load is sampled','*Lower is better in all three memory columns. Idle before load is sampled').replace('*Points are medians;','*Higher is better. Points are medians;')
s=s.replace('the longer-warmup check, and the generated Java example.','the matched longer-warmup comparison, clean-output build timings, and the generated Java example.')
p.write_text(s)
print(json.dumps({'build_medians':{a:st.median(v) for a,v in b.items()},'warmed_medians':{a:{route:st.median(v) for route,v in routes.items()} for a,routes in w.items()}},indent=2))
