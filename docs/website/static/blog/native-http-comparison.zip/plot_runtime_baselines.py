from pathlib import Path
import json,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path(__file__).resolve().parent/'charts/runtime';root.mkdir(parents=True,exist_ok=True)
b=json.loads((Path(__file__).resolve().parent/'runtime-baseline.json').read_text())['platforms']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':15,'axes.titlesize':21,'figure.facecolor':'#0b142a','axes.facecolor':'#0b142a','text.color':'#eef3ff','axes.labelcolor':'#d5e2f7','xtick.color':'#d5e2f7','ytick.color':'#eef3ff','axes.edgecolor':'#5f728f','savefig.facecolor':'#0b142a'})
colors=['#56d2d0','#9cafff']
def graph(data,labels,name,title,footer,height):
 fig,axs=plt.subplots(1,2,figsize=(15,height),sharey=True)
 for ax,key,color,heading in zip(axs,['time','memory'],colors,['Elapsed time','Peak process memory']):
  vals=[x[key] for x in data];y=np.arange(len(vals));ax.barh(y,vals,color=color,height=.58);ax.set_yticks(y,labels);ax.axvline(1,color='#f6ae55',linestyle='--',label='JDK 25 = 1.0');ax.set_xlim(0,max(1,max(vals))*1.25)
  for i,v in enumerate(vals):ax.text(v+.025,i,f'{v:.3f}',va='center',fontsize=12,bbox={'facecolor':'#0b142a','edgecolor':'none','pad':1})
  ax.set_title(heading+'\nLower is better',loc='left',pad=14);ax.set_xlabel('ParparVM / JDK 25');ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
 axs[0].invert_yaxis()
 fig.suptitle(title,fontsize=24,y=1.03);fig.text(.5,-.04,footer,ha='center',fontsize=11);fig.tight_layout();fig.savefig(root/name,dpi=145,bbox_inches='tight',pad_inches=.25);plt.close(fig)
platform_labels={'linux-arm64@neoverse-n2': 'Linux ARM64, Neoverse N2', 'linux-x64@amd-epyc-7763-64-core-processor': 'Linux x64, EPYC 7763', 'linux-x64@amd-epyc-9v45-96-core-processor': 'Linux x64, EPYC 9V45', 'linux-x64@amd-epyc-9v74-80-core-processor': 'Linux x64, EPYC 9V74', 'linux-x64@intel-xeon-6973p-c': 'Linux x64, Xeon 6973P-C', 'linux-x64@intel-xeon-platinum-8370c': 'Linux x64, Xeon Platinum 8370C', 'linux-x64@intel-xeon-platinum-8573c': 'Linux x64, Xeon Platinum 8573C', 'macos-arm64': 'macOS ARM64', 'windows-arm64@armv8-64-bit-family-8-model-d49-microsoft-corporation': 'Windows ARM64, model D49', 'windows-arm64@armv8-64-bit-family-8-model-d84-microsoft-corporation': 'Windows ARM64, model D84', 'windows-x64@amd64-family-25-model-1-authenticamd': 'Windows x64, AMD family 25/model 1', 'windows-x64@amd64-family-25-model-17-authenticamd': 'Windows x64, AMD family 25/model 17', 'windows-x64@amd64-family-26-model-2-authenticamd': 'Windows x64, AMD family 26/model 2', 'windows-x64@intel64-family-6-model-106-genuineintel': 'Windows x64, Intel family 6/model 106', 'windows-x64@intel64-family-6-model-173-genuineintel': 'Windows x64, Intel family 6/model 173', 'windows-x64@intel64-family-6-model-207-genuineintel': 'Windows x64, Intel family 6/model 207'}
platforms=list(b)
labels=[platform_labels[k].replace(', ', '\n',1)+'\n'+str(b[k]['translator']['all']['runs'])+' calibration run(s)' for k in platforms]
graph([b[k]['translator']['all'] for k in platforms],labels,'translation-baselines.png','Self-translation across every recorded platform','Repository baselines | JDK 25 = 1.0 | Linux/macOS: peak RSS; Windows: peak working set',15)
arm=b[platforms[0]];keys=['translator','hello','arraySequential','arrayRandom','hashMapChurn','valueEscape','longArithmetic','intArithmetic','mathTranscendental','quicksort','stringBuilding','recursion','objectAllocation'];labels=['Self-translation','App translation','Sequential arrays','Random arrays','Hash-map churn','Value escape','Long arithmetic','Integer arithmetic','Transcendental math','Quicksort','String building','Recursion','Object allocation']
graph([arm[k]['all'] for k in keys],labels,'arm64-baselines.png','The complete Linux ARM64 baseline','Neoverse N2 | Seven calibration runs per row | Dashed line: JDK 25 = 1.0\nTranslation: whole process. Other time: fastest repetition after workload warmup. Memory: process peak RSS.',9)
