from pathlib import Path
import json,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('docs/website/static/blog/runtime-diagrams');root.mkdir(exist_ok=True)
b=json.loads(Path('vm/selfhost/perf-baseline.json').read_text())['platforms']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':15,'axes.titlesize':21,'figure.facecolor':'#0b142a','axes.facecolor':'#0b142a','text.color':'#eef3ff','axes.labelcolor':'#d5e2f7','xtick.color':'#d5e2f7','ytick.color':'#eef3ff','axes.edgecolor':'#5f728f','savefig.facecolor':'#0b142a'})
colors=['#56d2d0','#9cafff']
def graph(data,labels,name,title,footer,height):
 fig,axs=plt.subplots(1,2,figsize=(13,height),sharey=True)
 for ax,key,color,heading in zip(axs,['time','memory'],colors,['Elapsed time','Peak process memory']):
  vals=[x[key] for x in data];y=np.arange(len(vals));ax.barh(y,vals,color=color,height=.58);ax.set_yticks(y,labels);ax.axvline(1,color='#f6ae55',linestyle='--',label='JDK 25 = 1.0');ax.set_xlim(0,max(1,max(vals))*1.25)
  for i,v in enumerate(vals):ax.text(v+.025,i,f'{v:.3f}',va='center',fontsize=12,bbox={'facecolor':'#0b142a','edgecolor':'none','pad':1})
  ax.set_title(heading+'\nLower is better',loc='left',pad=14);ax.set_xlabel('ParparVM / JDK 25');ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
 axs[0].invert_yaxis()
 fig.suptitle(title,fontsize=24,y=1.03);fig.text(.5,-.04,footer,ha='center',fontsize=11);fig.tight_layout();fig.savefig(root/name,dpi=145,bbox_inches='tight',pad_inches=.25);plt.close(fig)
platforms=['linux-arm64@neoverse-n2','linux-x64@amd-epyc-7763-64-core-processor','linux-x64@intel-xeon-platinum-8370c']
graph([b[x]['translator']['all'] for x in platforms],['ARM64 / N2\n7 recorded runs','x64 / EPYC 7763\n3 recorded runs','x64 / Xeon 8370C\n3 recorded runs'],'translation-baselines.png','Same compiler, less time and memory','Recorded repository baselines, October 1, 2026 | Whole-process translation time and Linux peak RSS',4.8)
arm=b[platforms[0]];keys=['translator','hello','arraySequential','arrayRandom','hashMapChurn','valueEscape','longArithmetic','intArithmetic','mathTranscendental','quicksort','stringBuilding','recursion','objectAllocation'];labels=['Self-translation','App translation','Sequential arrays','Random arrays','Hash-map churn','Value escape','Long arithmetic','Integer arithmetic','Transcendental math','Quicksort','String building','Recursion','Object allocation']
graph([arm[k]['all'] for k in keys],labels,'arm64-baselines.png','The complete Linux ARM64 baseline','Neoverse N2 | Seven calibration runs per row | Dashed line: JDK 25 = 1.0\nTranslation: whole process. Other time: fastest repetition after workload warmup. Memory: process peak RSS.',9)
fig=plt.figure(figsize=(10,1.4));fig.text(.5,.55,r'$\ddot{x} + 2\zeta\omega\dot{x} + \omega^2(x-x_t) = 0$',fontsize=32,ha='center',va='center');fig.savefig(root/'damped-spring.svg',bbox_inches='tight',pad_inches=.25);plt.close(fig)
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="490" viewBox="0 0 1000 490" role="img" aria-labelledby="title desc"><title id="title">Four-byte ParparVM object metadata</title><desc id="desc">A 16-bit class index refers to a shared class table. The mark epoch and heap state each use eight bits. Object fields follow, with alignment and allocator rounding additional.</desc><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8" fill="#d9e5ff"/></marker></defs><rect width="1000" height="490" rx="20" fill="#0b142a"/><g font-family="Arial, sans-serif" fill="#eef3ff"><text x="40" y="48" font-size="28" font-weight="bold">Four bytes of metadata per object</text><text x="40" y="80" font-size="19" fill="#b9cbe2">ParparVM release layout</text><rect x="40" y="112" width="400" height="104" rx="8" fill="#56d2d0"/><rect x="445" y="112" width="200" height="104" rx="8" fill="#9cafff"/><rect x="650" y="112" width="200" height="104" rx="8" fill="#f6ae55"/><g fill="#0b142a" text-anchor="middle" font-size="23" font-weight="bold"><text x="240" y="154">Class index</text><text x="545" y="154">Mark epoch</text><text x="750" y="154">Heap state</text></g><g fill="#0b142a" text-anchor="middle" font-size="20"><text x="240" y="188">16 bits · 2 bytes</text><text x="545" y="188">8 bits · 1 byte</text><text x="750" y="188">8 bits · 1 byte</text></g><text x="866" y="152" font-size="19">Then:</text><text x="866" y="179" font-size="19">fields</text><path d="M240,222 V280" stroke="#d9e5ff" stroke-width="3" marker-end="url(#arrow)"/><rect x="40" y="292" width="440" height="90" rx="8" fill="#23344f"/><text x="62" y="329" font-size="23">Shared class table</text><text x="62" y="359" font-size="19">Class information stored once per class</text><text x="523" y="312" font-size="21">No class pointer in each object.</text><text x="523" y="346" font-size="19">GC state fits in the remaining two bytes.</text><text x="40" y="428" font-size="20">Fields, alignment, allocator rounding and optional side-table data are additional.</text><text x="40" y="461" font-size="19" fill="#b9cbe2">A four-byte header is not a four-byte object allocation.</text></g></svg>'''
(root/'object-header.svg').write_text(svg)
print('Created runtime charts, object header and spring equation')

for svg_path in root.glob("*.svg"):
 svg_path.write_text("\n".join(line.rstrip() for line in svg_path.read_text().splitlines())+"\n")
