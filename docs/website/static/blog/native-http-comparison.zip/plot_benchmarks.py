from pathlib import Path
import json,statistics as st
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path(__file__).resolve().parent/'linux';data=json.loads((root/'results/results.json').read_text())
out=Path(__file__).resolve().parent/'charts/native-http';out.mkdir(parents=True,exist_ok=True)
assert data.get("complete"), "The HTTP measurement matrix is incomplete"
colors=['#56d2d0','#f6ae55','#9cafff'];arms=['cn1-native','spring-jdk25','spring-graal25'];names=['CN1 native','Spring / JDK 25','Spring / GraalVM 25']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':17,'axes.titlesize':23,'axes.labelsize':17,'xtick.labelsize':16,'ytick.labelsize':17,'figure.facecolor':'#0b142a','axes.facecolor':'#0b142a','text.color':'#eef3ff','axes.labelcolor':'#d5e2f7','xtick.color':'#d5e2f7','ytick.color':'#eef3ff','axes.edgecolor':'#5f728f','savefig.facecolor':'#0b142a'})
def style(ax):
 for s in ['top','right']:ax.spines[s].set_visible(False)
 ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
def save(fig,name):
 note='Local Linux ARM64 HTTP test | '+('default native build outputs' if name=='binary-size.png' else 'medians of three fresh processes per cell')
 if name=='throughput.png':note+='\nAt 4 CPUs, the server shares CPUs with the load generator.'
 fig.text(.5,-.05,note,ha='center',fontsize=11,color='#b4c5de')
 fig.savefig(out/name,dpi=160,bbox_inches='tight',pad_inches=.24);plt.close(fig)
def samples(arm,c):return [s for s in data['samples'] if s['arm']==arm and s['cores']==c]
def val(arm,c,key):return st.median(s[key] for s in samples(arm,c))
# Use all available CPU configurations; final output is produced only after the full matrix.
fig,axs=plt.subplots(2,1,figsize=(9,10),sharex=True)
for ax,route,label in zip(axs,['plaintext','json'],['Plaintext requests','JSON serialization']):
 for arm,name,color in zip(arms,names,colors):
  cores=[c for c in [1,2,4] if samples(arm,c)]
  series=[[s['routes'][route]['rps']/1000 for s in samples(arm,c)] for c in cores]
  med=[st.median(a) for a in series]
  ax.errorbar(cores,med,yerr=[[m-min(a) for m,a in zip(med,series)],[max(a)-m for m,a in zip(med,series)]],color=color,label=name,marker='o',linewidth=2.8,capsize=5,markersize=8)
 ax.set_title(label+'\nHigher is better',loc='left',pad=12);ax.set_ylabel('Thousand requests/s');ax.set_ylim(bottom=0);ax.grid(alpha=.16);ax.spines[['top','right']].set_visible(False)
handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.54,1.02),ncol=3,fontsize=12,frameon=False)
axs[1].set_xticks([1,2,4]);axs[1].set_xlabel('Allowed server CPUs in the 4-vCPU Linux VM')
fig.subplots_adjust(top=.89,hspace=.4);save(fig,'throughput.png')
if all(samples(a,2) for a in arms):
 fig,ax=plt.subplots(figsize=(9,5.5));vals=[val(a,2,'startup_ms') for a in arms]
 ax.barh(names,vals,color=colors,height=.48);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.3)
 for i,v in enumerate(vals):ax.text(v+max(vals)*.025,i,f'{v:,.1f} ms',va='center',fontsize=18)
 ax.set_xlabel('Milliseconds to first verified HTTP response');ax.set_title('Startup with 2 allowed CPUs\nLower is better',loc='left',pad=22);style(ax);save(fig,'startup.png')
 fig,axs=plt.subplots(3,1,figsize=(9,12.5));
 memmax=max(val(a,2,k)/1024 for a in arms for k in ['idle_before_kib','peak_kib','idle_after_kib'])
 for ax,key,label in zip(axs,['idle_before_kib','peak_kib','idle_after_kib'],['Idle before load','Peak RSS through both routes','Idle 5 seconds after load']):
  vals=[val(a,2,key)/1024 for a in arms];ax.barh(names,vals,color=colors,height=.5);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.32)
  for i,v in enumerate(vals):ax.text(v+max(vals)*.025,i,f'{v:.1f} MiB',va='center',fontsize=18)
  ax.set_xlim(0,memmax*1.32);ax.set_title(label+'\nLower is better',loc='left',pad=16);ax.set_xlabel('Resident memory, 2 allowed CPUs');style(ax)
 fig.subplots_adjust(hspace=.85);save(fig,'memory.png')
# Deployable default build output; size is independent of the CPU run.
art=data['artifacts'];vals=[art['cn1-bench']['bytes']/1048576,art['release-bench']['bytes']/1048576]
fig,ax=plt.subplots(figsize=(9,4.4));ax.barh([names[0],names[2]],vals,color=[colors[0],colors[2]],height=.48);ax.invert_yaxis();ax.set_xlim(0,max(vals)*1.3)
for i,v in enumerate(vals):ax.text(v+max(vals)*.025,i,f'{v:.2f} MiB',va='center',fontsize=20)
ax.set_title('Native executable size\nLower is better',loc='left',pad=22);ax.set_xlabel('MiB on disk; shared libraries excluded');style(ax);save(fig,'binary-size.png')
print('Charts in',out)
