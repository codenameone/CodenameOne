from pathlib import Path
import subprocess, shutil,xml.etree.ElementTree as ET,json
root=Path('/tmp/cn1-release-oct2/gradle-count');root.mkdir(exist_ok=True)
source=root/'HelloCodenameOne';source.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-files','scripts/hellocodenameone'],text=True).splitlines()
for f in files:
 p=Path(f);dest=source/p.relative_to('scripts/hellocodenameone');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
cp=ET.parse('maven/build-engine/target/surefire-reports/TEST-com.codename1.maven.processors.BackendBeansTest.xml').find(".//property[@name='java.class.path']").attrib['value']
(root/'Convert.java').write_text('''import com.codename1.maven.GradleConversion; import com.codename1.build.SystemStreamLog; import java.io.File; public class Convert { public static void main(String[] a) throws Exception {new GradleConversion(new SystemStreamLog()).convert(new File(a[0]),new File(a[1]),"8.0-SNAPSHOT");}}''')
java='/Users/shai/Library/Java/JavaVirtualMachines/azul-25/Contents/Home/bin/'
subprocess.run([java+'javac','-cp',cp,str(root/'Convert.java')],check=True)
subprocess.run([java+'java','-cp',str(root)+':'+cp,'Convert',str(source),str(root/'HelloCodenameOne-gradle')],check=True)
a=[str(p.relative_to(source)) for p in source.rglob('*') if p.is_file()];b=[str(p.relative_to(root/'HelloCodenameOne-gradle')) for p in (root/'HelloCodenameOne-gradle').rglob('*') if p.is_file()]
(root/'counts.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'before_count':len(a),'after_count':len(b),'before':a,'after':b},indent=2));print(len(a),len(b))
