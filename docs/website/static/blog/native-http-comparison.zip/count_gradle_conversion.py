from pathlib import Path
import subprocess,shutil,xml.etree.ElementTree as ET,json,argparse,os
parser=argparse.ArgumentParser(description="Count files before and after converting a tracked HelloCodenameOne sample")
parser.add_argument("--repo",type=Path,required=True)
parser.add_argument("--output-dir",type=Path,required=True,help="A new directory for the copied sample and results")
parser.add_argument("--classpath",help="Compiled build-engine and dependency classpath; defaults to the BackendBeansTest Surefire report")
parser.add_argument("--java-home",type=Path,default=Path(os.environ["JAVA_HOME"]) if os.environ.get("JAVA_HOME") else None)
a=parser.parse_args();repo=a.repo.resolve();root=a.output_dir.resolve();root.mkdir(parents=True,exist_ok=False)
source=root/'HelloCodenameOne';source.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-files','scripts/hellocodenameone'],cwd=repo,text=True).splitlines()
for f in files:
 p=repo/f;dest=source/Path(f).relative_to('scripts/hellocodenameone');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
cp=a.classpath or ET.parse(repo/'maven/build-engine/target/surefire-reports/TEST-com.codename1.maven.processors.BackendBeansTest.xml').find(".//property[@name='java.class.path']").attrib['value']
(root/'Convert.java').write_text('''import com.codename1.maven.GradleConversion; import com.codename1.build.SystemStreamLog; import java.io.File; public class Convert { public static void main(String[] a) throws Exception {new GradleConversion(new SystemStreamLog()).convert(new File(a[0]),new File(a[1]),"8.0-SNAPSHOT");}}''')
java=str(a.java_home.resolve()/'bin')+'/' if a.java_home else ''
subprocess.run([java+'javac','-cp',cp,str(root/'Convert.java')],check=True)
subprocess.run([java+'java','-cp',str(root)+':'+cp,'Convert',str(source),str(root/'HelloCodenameOne-gradle')],check=True)
a=[str(p.relative_to(source)) for p in source.rglob('*') if p.is_file()];b=[str(p.relative_to(root/'HelloCodenameOne-gradle')) for p in (root/'HelloCodenameOne-gradle').rglob('*') if p.is_file()]
(root/'gradle-conversion-counts.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'before_count':len(a),'after_count':len(b),'before':a,'after':b},indent=2));print(len(a),len(b))
