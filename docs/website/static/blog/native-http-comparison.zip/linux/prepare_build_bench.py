from pathlib import Path
import tarfile,subprocess,shutil
r=Path('/Users/shai/dev/cn1'); dst=Path('/tmp/cn1-release-oct2/linux/build-input');dst.mkdir(exist_ok=True)
paths=['vm/backend/src','vm/backend/impl','vm/backend/native','vm/backend/demo/bench','vm/backend/target/javaapi-classes','vm/JavaAPI/src','vm/ByteCodeTranslator/src','vm/ByteCodeTranslator/target/classes','CodenameOne/src']
paths += [str(p.relative_to(r)) for p in (r/'vm/backend').glob('*.sh')]
with tarfile.open(dst/'repo.tar','w') as t:
 for p in paths:t.add(r/p,arcname=p)
 jars=(r/'vm/ByteCodeTranslator/target/bench-asm-classpath.txt').read_text().strip().split(':')
 for p in jars:t.add(p,arcname='asm/'+Path(p).name)
print((dst/'repo.tar').stat().st_size)
