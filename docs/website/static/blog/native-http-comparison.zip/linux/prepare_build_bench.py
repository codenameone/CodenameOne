from pathlib import Path
import tarfile,argparse
parser=argparse.ArgumentParser(description="Package a prebuilt CN1 checkout for local build timings")
parser.add_argument("--repo",type=Path,required=True,help="Pinned CodenameOne checkout with translator and JavaAPI already built")
parser.add_argument("--output-dir",type=Path,default=Path.cwd()/"build-input")
a=parser.parse_args();r=a.repo.resolve();dst=a.output_dir.resolve();dst.mkdir(parents=True,exist_ok=True)
paths=['vm/backend/src','vm/backend/impl','vm/backend/native','vm/backend/demo/bench','vm/backend/target/javaapi-classes','vm/JavaAPI/src','vm/ByteCodeTranslator/src','vm/ByteCodeTranslator/target/classes','CodenameOne/src']
paths += [str(p.relative_to(r)) for p in (r/'vm/backend').glob('*.sh')]
with tarfile.open(dst/'repo.tar','w') as t:
 for p in paths:t.add(r/p,arcname=p)
 jars=(r/'vm/ByteCodeTranslator/target/bench-asm-classpath.txt').read_text().strip().split(':')
 for p in jars:t.add(p,arcname='asm/'+Path(p).name)
print((dst/'repo.tar').stat().st_size)
