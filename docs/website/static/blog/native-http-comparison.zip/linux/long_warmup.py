# Diagnostic follow-up: give HotSpot substantially longer before judging the short-run table.
import subprocess,time,urllib.request,json,re,os
from pathlib import Path
cmd=['taskset','-c','0,1','/opt/jdk25/bin/java','-jar','/spring/target/release-bench-1.0.jar','--server.port=18765','--server.tomcat.max-keep-alive-requests=-1']
root=Path('/out/long-warmup');root.mkdir(exist_ok=True)
p=subprocess.Popen(cmd,stdout=open(root/'server.log','w'),stderr=subprocess.STDOUT)
results={'arm':'spring-jdk25','cores':2,'warmup_seconds_per_route':60,'measure_seconds':10,'measure_repetitions_per_route':3,'connections':32,'load_threads':2,'load_cpus':'2,3','routes':{},'note':'One additional fresh JVM process; 60 s warmup per route, then three consecutive windows. Diagnostic, not pooled into the rotating matrix.'}
try:
 for n in range(600):
  try:
   with urllib.request.urlopen('http://localhost:18765/plaintext',timeout=.2) as r:assert r.read()==b'Hello, World!'
   break
  except Exception:time.sleep(.1)
 else:raise RuntimeError('Startup failed')
 for route in ['plaintext','json']:
  url='http://127.0.0.1:18765/'+route
  with urllib.request.urlopen(url) as r:
   b=r.read();assert r.status==200
   assert (json.loads(b)=={'message':'Hello, World!'} if route=='json' else b==b'Hello, World!')
  base=['taskset','-c','2,3','wrk','-t2','-c32','--latency']
  warm=subprocess.check_output(base+['-d60s',url],text=True);(root/(route+'-warm.txt')).write_text(warm)
  assert 'Socket errors' not in warm and 'Non-2xx' not in warm
  vals=[]
  for i in range(3):
   out=subprocess.check_output(base+['-d10s',url],text=True);(root/(route+'-'+str(i)+'.txt')).write_text(out)
   assert 'Socket errors' not in out and 'Non-2xx' not in out
   vals.append(float(re.search(r'Requests/sec:\s+(\S+)',out)[1]))
  results['routes'][route]=vals;print(route,vals,flush=True)
 results['complete']=True;(root/'results.json').write_text(json.dumps(results,indent=2))
finally:
 p.terminate()
 try:p.wait(timeout=8)
 except subprocess.TimeoutExpired:p.kill();p.wait()
