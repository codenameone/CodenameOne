import os,subprocess,time,json,shutil
from pathlib import Path
root=Path('/out/build-times');root.mkdir(exist_ok=True)
repo=Path('/repo');repo.mkdir(exist_ok=True)
subprocess.run(['tar','xf','/repo.tar','-C','/repo'],check=True)
(repo/'vm/ByteCodeTranslator/target/bench-asm-classpath.txt').write_text(':'.join(str(p) for p in (repo/'asm').glob('*.jar')))
# Dependencies are prebuilt compiler/runtime inputs. Source timestamps survive tar.
stamp=repo/'vm/ByteCodeTranslator/target/classes/com/codename1/tools/translator/ByteCodeTranslator.class';stamp.touch()
(repo/'vm/backend/target/javaapi-classes/java/lang/Object.class').touch()
base=dict(os.environ,JDK_8_HOME='/opt/jdk8',JAVA_HOME='/opt/jdk8',PATH='/opt/jdk8/bin:'+os.environ['PATH'],CN1_BACKEND_STANDALONE_DEMO='1',CN1_BACKEND_DEMO='demo/bench',CN1_BACKEND_SRC_OUT='/src')
shared=subprocess.check_output(['/repo/vm/backend/shared-sources.sh'],text=True).splitlines()
sources=[str(p) for folder in ['src','impl/javase','demo/bench'] for p in (repo/'vm/backend'/folder).rglob('*.java')]+shared
commands={
 'cn1-debug':['/opt/jdk25/bin/javac','-nowarn','-encoding','UTF-8','-d','/out/debug-classes']+sources,
 'cn1-native':['bash','-c','./vm/backend/build.sh Bench com.demo unused && CN1_OUT_NAME=cn1-build-timed CN1_EXTRA_CFLAGS="$(cat /src/cn1-cflags.txt)" /usr/local/bin/link.sh'],
 'spring-jdk25':['mvn','-o','-Dmaven.repo.local=/m2','-DskipTests','clean','package'],
 'spring-graal25':['mvn','-o','-Dmaven.repo.local=/m2','-DskipTests','-Pnative','clean','package','native:compile']}
result={'source_commit':'60c4f310bddcfc51e5acc75c63a57c43c73430d3','machine':'same local Linux ARM64 VM, four vCPUs, 8 GiB','cached_dependencies':True,'rounds':3,'samples':[],'commands':commands,'note':'Clean application outputs per build. CN1 debug compiles Bench plus JavaSE backend runtime and shared sources; native compiles same handler plus native runtime, translates and links -O3. Prebuilt translator and JavaAPI excluded. Spring clean package includes Maven, native arm adds Spring AOT and native-image. No tests/network/downloads. All four VM CPUs available.'}
for rnd in range(3):
 names=list(commands);names=names[rnd:]+names[:rnd]
 for name in names:
  env=dict(base);cwd='/repo'
  if name=='cn1-debug':
   shutil.rmtree('/out/debug-classes',ignore_errors=True);Path('/out/debug-classes').mkdir()
  if name.startswith('spring'):
   cwd='/spring';jhome='/opt/java' if name=='spring-graal25' else '/opt/jdk25';env.update(JAVA_HOME=jhome,PATH=jhome+'/bin:'+os.environ['PATH'])
  cmd=commands[name];start=time.perf_counter()
  with (root/f'{name}-{rnd}.log').open('w') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
  row={'arm':name,'round':rnd,'seconds':time.perf_counter()-start,'exit_code':r.returncode}
  result['samples'].append(row);(root/'results.json').write_text(json.dumps(result,indent=2));print(row,flush=True)
  if r.returncode:raise RuntimeError('build failed '+name)
result['complete']=True;(root/'results.json').write_text(json.dumps(result,indent=2))
