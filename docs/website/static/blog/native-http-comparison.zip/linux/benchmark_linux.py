import subprocess,time,os,json,urllib.request,threading,statistics,re,hashlib
from pathlib import Path
root=Path('/out/results');root.mkdir(exist_ok=True)
commands={'cn1-native':['/out/cn1-bench'],'spring-jdk25':['/opt/jdk25/bin/java','-jar','/spring/target/release-bench-1.0.jar'],'spring-graal25':['/spring/target/release-bench']}
data={'source_commit':'60c4f310bddcfc51e5acc75c63a57c43c73430d3','rounds':3,'cores':[1,2,4],'connections':32,'warmup_seconds_per_route':10,'measure_seconds_per_route':10,'preload_idle_seconds':3,'postload_idle_seconds':5,'samples':[],'notes':'Linux ARM64 4-vCPU 8GiB Apple Virtualization VM. taskset server affinity; wrk on remaining vCPUs at 1/2, shares all at 4. WORKERS=core count. Normal allocating Response, new JSON map. Keepalive limits disabled equally. No heap caps, no PGO, no Spring AOT cache for JVM arm.'}
for path in ['/out/cn1-bench','/spring/target/release-bench','/spring/target/release-bench-1.0.jar']:
 p=Path(path);data.setdefault('artifacts',{})[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for rnd in range(3):
 for cores in ([1,2,4] if rnd%2==0 else [4,2,1]):
  names=list(commands);names=names[rnd:]+names[:rnd]
  for name in names:
   tag=f'{name}-c{cores}-r{rnd}';log=open(root/(tag+'.log'),'w')
   cpus=','.join(str(i) for i in range(cores));loadcpus=','.join(str(i) for i in (range(cores,4) if cores<4 else range(4)))
   cmd=['taskset','-c',cpus]+commands[name]
   if name.startswith('spring'):cmd+=['--server.port=18765','--server.tomcat.max-keep-alive-requests=-1']
   env=dict(os.environ,PORT='18765',WORKERS=str(cores),BENCH_JSON_MODE='0',BENCH_REUSE_RESPONSE='0',CN1_HTTP_KEEPALIVE_BURST='1000000000')
   start=time.perf_counter();p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
   stop=threading.Event();rss=[]
   def mem():
    s=Path(f'/proc/{p.pid}/status').read_text()
    return {key:int(re.search(r'^'+key+r':\s+(\d+)',s,re.M)[1]) for key in ['VmRSS','VmHWM']}
   def sample():
    while not stop.is_set():
     try:rss.append(mem()['VmRSS'])
     except:pass
     stop.wait(.05)
   try:
    while True:
     try:
      with urllib.request.urlopen('http://127.0.0.1:18765/plaintext',timeout=.2) as r:assert r.status==200 and r.read()==b'Hello, World!'
      break
     except Exception:
      if p.poll() is not None or time.perf_counter()-start>60:raise RuntimeError('startup failure '+tag)
      time.sleep(.001)
    item={'arm':name,'cores':cores,'round':rnd,'startup_ms':(time.perf_counter()-start)*1000,'command':cmd,'allowed_cpus':re.search(r'Cpus_allowed_list:\s+(\S+)',Path(f'/proc/{p.pid}/status').read_text())[1],'routes':{}}
    time.sleep(3);item['idle_before_kib']=mem()['VmRSS']
    for route in ['plaintext','json']:
     url='http://127.0.0.1:18765/'+route
     with urllib.request.urlopen(url) as r:
      b=r.read();assert r.status==200
      assert (json.loads(b)=={'message':'Hello, World!'} if route=='json' else b==b'Hello, World!')
     load=['taskset','-c',loadcpus,'wrk','-t2','-c32','-d10s','--latency',url]
     warm=subprocess.check_output(load,text=True);(root/(tag+'-'+route+'-warm.txt')).write_text(warm)
     if 'Socket errors' in warm or 'Non-2xx' in warm:raise RuntimeError('warm errors '+warm)
     rss=[];stop.clear();t=threading.Thread(target=sample);t.start()
     out=subprocess.check_output(load,text=True)
     stop.set();t.join();(root/(tag+'-'+route+'.txt')).write_text(out)
     if 'Socket errors' in out or 'Non-2xx' in out:raise RuntimeError('load errors '+out)
     item['routes'][route]={'rps':float(re.search(r'Requests/sec:\s+(\S+)',out)[1]),'rss_median_kib':statistics.median(rss),'rss_max_sample_kib':max(rss),'raw_output':out}
    item['peak_kib']=mem()['VmHWM'];time.sleep(5);item['idle_after_kib']=mem()['VmRSS']
    data['samples'].append(item);(root/'results.json').write_text(json.dumps(data,indent=2))
    print(tag,'startup',round(item['startup_ms'],1),'idle',round(item['idle_before_kib']/1024,1),'peak',round(item['peak_kib']/1024,1),'rps', {k:round(v['rps']) for k,v in item['routes'].items()},flush=True)
   finally:
    stop.set();p.terminate()
    try:p.wait(timeout=8)
    except subprocess.TimeoutExpired:p.kill();p.wait()
    log.close();time.sleep(.3)
data['complete']=True;(root/'results.json').write_text(json.dumps(data,indent=2))
