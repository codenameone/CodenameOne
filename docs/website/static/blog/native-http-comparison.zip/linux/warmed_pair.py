import subprocess,time,urllib.request,json,re,os,hashlib
from pathlib import Path
# Wait for the compilation benchmark to leave the VM idle.
while any(p.read_bytes().replace(b'\0',b' ').strip()==b'python3 /build_bench.py' for p in Path('/proc').glob('[0-9]*/cmdline') if p.exists()):time.sleep(2)
root=Path('/out/warmed-pair');root.mkdir(exist_ok=True)
commands={'cn1-native':['/out/cn1-bench'],'spring-jdk25':['/opt/jdk25/bin/java','-jar','/spring/target/release-bench-1.0.jar']}
results={'warmup_seconds_per_route':60,'measure_seconds':10,'windows_per_route':3,'server_cpus':'0,1','load_cpus':'2,3','connections':32,'samples':[]}
for name,cmd in commands.items():
 args=['taskset','-c','0,1']+cmd
 if name.startswith('spring'):args+=['--server.port=18765','--server.tomcat.max-keep-alive-requests=-1']
 env=dict(os.environ,PORT='18765',WORKERS='2',BENCH_JSON_MODE='0',BENCH_REUSE_RESPONSE='0',CN1_HTTP_KEEPALIVE_BURST='1000000000')
 p=subprocess.Popen(args,env=env,stdout=open(root/(name+'.log'),'w'),stderr=subprocess.STDOUT)
 row={'arm':name,'command':args,'routes':{}}
 try:
  for n in range(600):
   try:
    with urllib.request.urlopen('http://localhost:18765/plaintext',timeout=.2) as r:assert r.read()==b'Hello, World!'
    break
   except Exception:time.sleep(.1)
  else:raise RuntimeError('Startup failed')
  for route in ['plaintext','json']:
   url='http://127.0.0.1:18765/'+route
   with urllib.request.urlopen(url) as r:
    b=r.read();assert r.status==200
    assert (json.loads(b)=={'message':'Hello, World!'} if route=='json' else b==b'Hello, World!')
   base=['taskset','-c','2,3','wrk','-t2','-c32','--latency']
   warm=subprocess.check_output(base+['-d60s',url],text=True);(root/(name+'-'+route+'-warm.txt')).write_text(warm)
   assert 'Socket errors' not in warm and 'Non-2xx' not in warm
   vals=[]
   for i in range(3):
    out=subprocess.check_output(base+['-d10s',url],text=True);(root/(name+'-'+route+'-'+str(i)+'.txt')).write_text(out)
    assert 'Socket errors' not in out and 'Non-2xx' not in out
    vals.append(float(re.search(r'Requests/sec:\s+(\S+)',out)[1]))
   row['routes'][route]=vals;print(name,route,vals,flush=True)
  results['samples'].append(row);(root/'results.json').write_text(json.dumps(results,indent=2))
 finally:
  p.terminate()
  try:p.wait(timeout=8)
  except subprocess.TimeoutExpired:p.kill();p.wait()
results['complete']=True;(root/'results.json').write_text(json.dumps(results,indent=2))
