import subprocess, time, os, json, urllib.request, threading, statistics, re, platform
from pathlib import Path
root=Path(os.environ['BENCH_ROOT'])
java=str(Path(os.environ['JDK_25_HOME'])/'bin/java')
commands={
 'cn1-native':[str(root/'cn1-bench')],
 'spring-jdk25':[java,'-jar',str(root/'spring/target/release-bench-1.0.jar'),'--server.port=18765','--server.tomcat.max-keep-alive-requests=-1'],
 'spring-graal25':[str(root/'spring/target/release-bench'),'--server.port=18765','--server.tomcat.max-keep-alive-requests=-1']}
results={'source_commit':'60c4f310bddcfc51e5acc75c63a57c43c73430d3','machine':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'os':platform.platform(),'rounds':3,'connections':32,'load_threads':4,'warmup_seconds_per_route':5,'measure_seconds_per_route':10,'samples':[], 'configuration_note':'macOS exploratory native pool build; CN1 WORKERS=32, KEEPALIVE_BURST=1000000000; Tomcat max-keep-alive-requests=-1; default other settings; same-machine load generator, no affinity' }
wrk=str(root/'wrk/wrk')
for rnd in range(3):
 names=list(commands);names=names[rnd:]+names[:rnd]
 for name in names:
  log=open(root/f'{name}-{rnd}.log','w');env=dict(os.environ,PORT='18765',BENCH_JSON_MODE='0',BENCH_REUSE_RESPONSE='1',WORKERS='32',CN1_HTTP_KEEPALIVE_BURST='1000000000')
  start=time.perf_counter();p=subprocess.Popen(commands[name],env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   while True:
    try:
     with urllib.request.urlopen('http://127.0.0.1:18765/plaintext',timeout=.2) as r: body=r.read(); assert r.status==200 and body==b'Hello, World!'
     break
    except Exception:
     if p.poll() is not None or time.perf_counter()-start>30: raise RuntimeError(f'{name} failed to start')
     time.sleep(.001)
   startup=(time.perf_counter()-start)*1000
   sample={'arm':name,'round':rnd,'startup_first_response_ms':startup,'routes':{}}
   for route in ['plaintext','json']:
    url='http://127.0.0.1:18765/'+route
    with urllib.request.urlopen(url) as r:
     body=r.read();assert r.status==200
     if route=='json':assert json.loads(body)=={'message':'Hello, World!'}
     else:assert body==b'Hello, World!'
    subprocess.run([wrk,'-t4','-c32','-d5s',url],stdout=subprocess.DEVNULL,check=True)
    rss=[];stop=threading.Event()
    def sample_rss():
     while not stop.is_set():
      try:rss.append(int(subprocess.check_output(['ps','-o','rss=','-p',str(p.pid)],text=True).strip()))
      except Exception: pass
      stop.wait(.1)
    t=threading.Thread(target=sample_rss);t.start()
    out=subprocess.check_output([wrk,'-t4','-c32','-d10s','--latency',url],text=True)
    stop.set();t.join()
    (root/f'{name}-{rnd}-{route}.txt').write_text(out)
    if 'Socket errors' in out or 'Non-2xx' in out:raise RuntimeError(out)
    sample['routes'][route]={'requests_per_second':float(re.search(r'Requests/sec:\s+(\S+)',out)[1]),'rss_median_kib':statistics.median(rss),'rss_max_kib':max(rss),'wrk_output':out}
   results['samples'].append(sample);(root/'http-results.json').write_text(json.dumps(results,indent=2))
   print(name,rnd,round(startup,1),{k:round(v['requests_per_second']) for k,v in sample['routes'].items()},flush=True)
  finally:
   p.terminate()
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   log.close()
results['complete']=True
(root/'http-results.json').write_text(json.dumps(results,indent=2))
