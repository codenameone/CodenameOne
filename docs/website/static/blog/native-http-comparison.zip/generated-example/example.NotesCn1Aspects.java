package example;

// Generated from the aspects of example.Notes. Do not edit.
@com.codename1.backend.annotations.Generated
final class NotesCn1Aspects {
    private NotesCn1Aspects() {
    }

    static void add(example.Notes self, java.lang.String a0) throws Throwable {
        Object cn1Tx = com.codename1.impl.backend.BackendAccess.get().begin(com.codename1.impl.backend.BackendAccess.REQUIRED, false, -1);
        try {
            self.add$cn1body_Notes(a0);
        } catch (Throwable cn1Error) {
            com.codename1.impl.backend.BackendAccess.get().afterThrow(cn1Tx, cn1Error instanceof java.io.IOException ? true : (cn1Error instanceof java.lang.RuntimeException || cn1Error instanceof java.lang.Error || cn1Error instanceof com.codename1.backend.DataAccessException));
            throw cn1Error;
        }
        com.codename1.impl.backend.BackendAccess.get().commit(cn1Tx);
    }

}
