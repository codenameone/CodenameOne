package example;

// Generated from the beans of this module. Do not edit.
@com.codename1.backend.annotations.Generated
public final class BackendWiring implements com.codename1.impl.backend.BackendApplication {
    private com.codename1.backend.Config config;
    private com.codename1.backend.DataSource dataSource;
    private com.codename1.backend.orm.EntityManager entities;
    private com.codename1.impl.backend.TransactionSession transactionSession;
    private com.codename1.impl.backend.Scheduler scheduler;
    private final java.util.Set active = new java.util.HashSet();
    private example.GreetingApi b_greetingApi;
    private example.Notes b_notes;

    public BackendWiring() {
    }

    public com.codename1.backend.HttpServer.Handler[] create(
            com.codename1.impl.backend.WiringEnvironment environment) throws Exception {
        synchronized (this) {
            scheduler = null;
            transactionSession = null;
            active.clear();
            b_greetingApi = null;
            b_notes = null;
        }
        config = environment.getConfig();
        dataSource = environment.getDataSource();
        entities = environment.getEntityManager();
        // Construction, each bean after what its constructor needs.
        b_greetingApi = new example.GreetingApi();
        b_notes = new example.Notes(com.codename1.backend.Backend.requireDataSource(dataSource, "constructor parameter 1 of example.Notes"));
        // Members, once everything exists, so fields may form cycles.
        // Initialization, in dependency order.
        java.util.List handlers = new java.util.ArrayList();
        {
        example.GreetingApi routedb_greetingApi = b_greetingApi;
        if (routedb_greetingApi != null) {
            handlers.add(new example.GreetingApiRouter(routedb_greetingApi));
            synchronized (this) {
                active.add("example.GreetingApi");
            }
        }
        }
        com.codename1.backend.HttpServer.Handler[] out =
                new com.codename1.backend.HttpServer.Handler[handlers.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = (com.codename1.backend.HttpServer.Handler) handlers.get(i);
        }
        return out;
    }

    public void registerWebSockets(
            com.codename1.backend.HttpServer.WebSocketRegistry registry) throws Exception {
    }

    public void started(com.codename1.backend.Backend backend) throws Exception {
    }

    public void stopping() {
        if (scheduler != null) {
            scheduler.stop(0);
        }
    }

    public void stopped() {
    }

    public boolean tracksCurrentRequest() {
        return false;
    }

    public void requestEnded(Object[] beans) {
    }

    public void sessionEnded(Object[] beans) {
    }

    public com.codename1.impl.backend.Scheduler getScheduler() {
        return scheduler;
    }

    public java.util.List describeBeans() {
        java.util.List out = new java.util.ArrayList();
        out.add(bean("greetingApi", "example.GreetingApi", "singleton", null, true, new String[] {}));
        out.add(bean("notes", "example.Notes", "singleton", null, true, new String[] {"(dataSource)"}));
        return out;
    }

    private static java.util.Map bean(String name, String type, String scope,
            String condition, boolean active, String[] dependencies) {
        java.util.Map m = new java.util.LinkedHashMap();
        m.put("name", name);
        m.put("type", type);
        m.put("scope", scope);
        if (condition != null) {
            m.put("condition", condition);
            m.put("active", Boolean.valueOf(active));
        }
        m.put("dependencies", java.util.Arrays.asList(dependencies));
        return m;
    }

    public synchronized java.util.List describeRoutes() {
        java.util.List out = new java.util.ArrayList();
        return out;
    }

    private static java.util.Map route(String method, String path, String handler) {
        java.util.Map m = new java.util.LinkedHashMap();
        m.put("method", method);
        m.put("path", path);
        m.put("handler", handler);
        return m;
    }

}
